#!/usr/bin/env node
/**
 * packages/LocalVectorServer/scripts/cli.mjs
 * CLI entry point — delegates to cli.ts via tsx
 */
import { spawn } from "node:child_process";
import * as path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const cliTs = path.join(__dirname, "..", "cli.ts");
const args = process.argv.slice(2);

const child = spawn("npx", ["tsx", cliTs, ...args], {
  stdio: "inherit",
  shell: true,
  cwd: path.join(__dirname, ".."),
});

child.on("exit", (code) => process.exit(code ?? 0));
