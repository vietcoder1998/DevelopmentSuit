/**
 * packages/LocalVectorServer/cli.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * LocalVectorServer CLI Entry Point
 * Supports: start, status, version, help commands
 * ─────────────────────────────────────────────────────────────────────────────
 */

import {
  startLocalVectorServer,
  stopLocalVectorServer,
} from "./server";

import {
  DEFAULT_VECTOR_HTTP_HOST,
  DEFAULT_VECTOR_HTTP_PORT,
} from "./sources/server/http-server";

import {
  DEFAULT_VECTOR_GRPC_HOST,
  DEFAULT_VECTOR_GRPC_PORT,
} from "./sources/server/grpc-server";

import {
  DEFAULT_VECTOR_SOCKET_HOST,
  DEFAULT_VECTOR_SOCKET_PORT,
} from "./sources/server/socket-server";

export async function runCli(argv: string[] = process.argv.slice(2)): Promise<void> {
  let httpPort: number = DEFAULT_VECTOR_HTTP_PORT;
  let httpHost: string = DEFAULT_VECTOR_HTTP_HOST;
  let grpcPort: number = DEFAULT_VECTOR_GRPC_PORT;
  let grpcHost: string = DEFAULT_VECTOR_GRPC_HOST;
  let socketPort: number = DEFAULT_VECTOR_SOCKET_PORT;
  let socketHost: string = DEFAULT_VECTOR_SOCKET_HOST;
  let outputJson: boolean = false;
  let command: string = "start";

  for (let i: number = 0; i < argv.length; i++) {
    const arg: string = argv[i];

    if (arg === "--help" || arg === "-h" || arg === "help") {
      printHelp();
      return;
    }

    if (arg === "--version" || arg === "-v" || arg === "version") {
      console.log("LocalVectorServer v1.0.2");
      return;
    }

    if (arg === "--json") {
      outputJson = true;
      continue;
    }

    if (arg === "--port" || arg === "-p") {
      const nextArg: string | undefined = argv[++i];
      if (nextArg) httpPort = parseInt(nextArg, 10);
      continue;
    }

    if (arg.startsWith("--port=")) {
      httpPort = parseInt(arg.split("=")[1], 10);
      continue;
    }

    if (arg === "--host") {
      const nextArg: string | undefined = argv[++i];
      if (nextArg) httpHost = nextArg;
      continue;
    }

    if (arg === "--grpc-port") {
      const nextArg: string | undefined = argv[++i];
      if (nextArg) grpcPort = parseInt(nextArg, 10);
      continue;
    }

    if (arg === "--grpc-host") {
      const nextArg: string | undefined = argv[++i];
      if (nextArg) grpcHost = nextArg;
      continue;
    }

    if (arg === "--socket-port") {
      const nextArg: string | undefined = argv[++i];
      if (nextArg) socketPort = parseInt(nextArg, 10);
      continue;
    }

    if (arg === "--socket-host") {
      const nextArg: string | undefined = argv[++i];
      if (nextArg) socketHost = nextArg;
      continue;
    }

    if (!arg.startsWith("-")) {
      if (command === "start" && (arg === "status" || arg === "start")) {
        command = arg;
      }
    }
  }

  const effectiveHost: string = httpHost === "0.0.0.0" ? "127.0.0.1" : httpHost;
  const baseUrl: string = `http://${effectiveHost}:${httpPort}`;

  // Status command — ping HTTP server
  if (command === "status") {
    try {
      const response: Response = await fetch(`${baseUrl}/api/status`, {
        signal: AbortSignal.timeout(2000),
      });
      if (response.ok) {
        const data: unknown = await response.json();
        if (outputJson) {
          console.log(JSON.stringify(data, null, 2));
        } else {
          const statusObj: {
            vectorCount?: number;
            collectionsCount?: number;
            metrics?: { uptimeSeconds?: number; memoryHeapUsedBytes?: number };
          } = data as {
            vectorCount?: number;
            collectionsCount?: number;
            metrics?: { uptimeSeconds?: number; memoryHeapUsedBytes?: number };
          };
          console.log(`[LocalVectorServer] Status: ONLINE`);
          console.log(`  - URL:               ${baseUrl}`);
          console.log(`  - Vectors:           ${statusObj.vectorCount ?? 0}`);
          console.log(`  - Collections:       ${statusObj.collectionsCount ?? 0}`);
          if (statusObj.metrics) {
            console.log(`  - Uptime:            ${statusObj.metrics.uptimeSeconds ?? 0}s`);
            const memMb: string = ((statusObj.metrics.memoryHeapUsedBytes || 0) / 1024 / 1024).toFixed(1);
            console.log(`  - Memory Used:       ${memMb} MB`);
          }
        }
      } else {
        console.log(`[LocalVectorServer] Status: OFFLINE (HTTP ${response.status} on ${baseUrl})`);
      }
    } catch {
      console.log(`[LocalVectorServer] Status: OFFLINE (not reachable on ${baseUrl})`);
    }
    return;
  }

  // Start command (default)
  await startLocalVectorServer({
    httpHost,
    httpPort,
    grpcHost,
    grpcPort,
    socketHost,
    socketPort,
  });

  const handleShutdown = async (): Promise<void> => {
    await stopLocalVectorServer();
    process.exit(0);
  };

  process.on("SIGINT", handleShutdown);
  process.on("SIGTERM", handleShutdown);
}

function printHelp(): void {
  console.log(`
LocalVectorServer — High-performance Local Vector Database Engine

Usage:
  localvectorserver [command] [options]

Commands:
  start                    Start HTTP REST, gRPC, and WebSocket servers (default)
  status                   Check server status and connectivity
  version, -v              Show version information
  help, -h                 Show this help message

Options:
  --port, -p <port>        HTTP port (default: ${DEFAULT_VECTOR_HTTP_PORT})
  --host <host>            HTTP host (default: ${DEFAULT_VECTOR_HTTP_HOST})
  --grpc-port <port>       gRPC port (default: ${DEFAULT_VECTOR_GRPC_PORT})
  --grpc-host <host>       gRPC host (default: ${DEFAULT_VECTOR_GRPC_HOST})
  --socket-port <port>     WebSocket port (default: ${DEFAULT_VECTOR_SOCKET_PORT})
  --socket-host <host>     WebSocket host (default: ${DEFAULT_VECTOR_SOCKET_HOST})
  --json                   Output raw JSON (for status command)

Examples:
  localvectorserver                       # Start with default ports
  localvectorserver --port 4120           # Start on custom HTTP port
  localvectorserver status                # Check server status
  localvectorserver status --json         # Check status as JSON
  localvectorserver --version             # Show version
`);
}

// Auto-run when executed directly
const isDirectCliRun: boolean =
  typeof require !== "undefined"
    ? require.main === module
    : Boolean(
        process.argv[1]?.endsWith("cli.ts") ||
        process.argv[1]?.endsWith("cli.mjs") ||
        process.argv[1]?.endsWith("cli.js")
      );

if (isDirectCliRun) {
  runCli().catch((err: unknown): void => {
    console.error("[LocalVectorServer] Fatal CLI error:", err);
    process.exit(1);
  });
}
