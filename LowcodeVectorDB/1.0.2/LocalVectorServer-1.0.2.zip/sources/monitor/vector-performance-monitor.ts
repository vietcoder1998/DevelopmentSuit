import { VectorServerTelemetry } from "../engine/vector-types";
import { VectorDbEngine } from "../engine/vector-db-engine";

export class VectorPerformanceMonitor {
  private readonly startTime: number = Date.now();
  private totalQueriesCount: number = 0;
  private totalInsertsCount: number = 0;
  private latenciesSum: number = 0;
  private latenciesCount: number = 0;
  private readonly engine: VectorDbEngine;

  public constructor(engine: VectorDbEngine) {
    this.engine = engine;
  }

  public recordQuery(latencyMs: number): void {
    this.totalQueriesCount++;
    this.latenciesSum += latencyMs;
    this.latenciesCount++;
  }

  public recordInsert(count: number = 1): void {
    this.totalInsertsCount += count;
  }

  public getTelemetry(): VectorServerTelemetry {
    const uptimeSeconds: number = Math.floor((Date.now() - this.startTime) / 1000);
    const stats = this.engine.getStats();
    const averageLatency: number = this.latenciesCount > 0
      ? Number((this.latenciesSum / this.latenciesCount).toFixed(3))
      : 0;
    const memoryUsage = process.memoryUsage();

    return {
      uptimeSeconds,
      totalQueries: this.totalQueriesCount,
      totalInserts: this.totalInsertsCount,
      collectionsCount: stats.collectionsCount,
      totalVectorsCount: stats.totalVectorsCount,
      totalConversations: stats.totalConversations,
      totalKnowledgeDocs: stats.totalKnowledgeDocs,
      averageSearchLatencyMs: averageLatency,
      memoryHeapUsedBytes: memoryUsage.heapUsed,
    };
  }

  public resetMetrics(): void {
    this.totalQueriesCount = 0;
    this.totalInsertsCount = 0;
    this.latenciesSum = 0;
    this.latenciesCount = 0;
  }
}
