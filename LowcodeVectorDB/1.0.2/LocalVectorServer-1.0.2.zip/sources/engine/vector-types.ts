export type VectorMetric = "cosine" | "euclidean" | "dot";

export interface VectorRecord {
  id: string;
  values: number[];
  metadata: Record<string, string | number | boolean | null>;
  createdAt: number;
}

export interface VectorCollection {
  name: string;
  dimension: number;
  metric: VectorMetric;
  createdAt: number;
  records: Map<string, VectorRecord>;
}

export interface VectorSearchResult {
  id: string;
  score: number;
  values?: number[];
  metadata: Record<string, string | number | boolean | null>;
}

export interface ConversationTurn {
  id: string;
  role: "system" | "user" | "assistant" | "function";
  content: string;
  timestamp: string;
  vectorId?: string;
}

export interface ConversationDocument {
  conversationId: string;
  title: string;
  createdAt: string;
  updatedAt: string;
  metadata: Record<string, string | number | boolean | null>;
  messages: ConversationTurn[];
}

export interface RelatedConversationMatch {
  conversationId: string;
  title: string;
  messageId: string;
  role: string;
  snippet: string;
  score: number;
  timestamp: string;
}

export interface KnowledgeDocument {
  documentId: string;
  title: string;
  category: string;
  tags: string[];
  content: string;
  createdAt: string;
  chunks: Array<{
    chunkIndex: number;
    text: string;
    vectorId: string;
  }>;
}

export type TrainingExportFormat = "sharegpt" | "openai";

export interface TrainingExportResult {
  format: TrainingExportFormat;
  recordCount: number;
  jsonlContent: string;
}

export interface VectorServerTelemetry {
  uptimeSeconds: number;
  totalQueries: number;
  totalInserts: number;
  collectionsCount: number;
  totalVectorsCount: number;
  totalConversations: number;
  totalKnowledgeDocs: number;
  averageSearchLatencyMs: number;
  memoryHeapUsedBytes: number;
}
