import fs from "node:fs";
import path from "node:path";
import os from "node:os";
import {
  VectorCollection,
  VectorRecord,
  VectorSearchResult,
  VectorMetric,
  ConversationDocument,
  ConversationTurn,
  RelatedConversationMatch,
  KnowledgeDocument,
  TrainingExportFormat,
  TrainingExportResult,
} from "./vector-types";
import { VectorMath } from "./vector-math";
import { LocalEmbeddingGenerator } from "./embedding-generator";

export class VectorDbEngine {
  private readonly collections: Map<string, VectorCollection> = new Map<string, VectorCollection>();
  private readonly conversations: Map<string, ConversationDocument> = new Map<string, ConversationDocument>();
  private readonly knowledgeDocs: Map<string, KnowledgeDocument> = new Map<string, KnowledgeDocument>();
  private readonly embeddingGenerator: LocalEmbeddingGenerator;
  private readonly storageDir: string;
  private isPersisting: boolean = false;

  public constructor(storageDirectory?: string, defaultDimension: number = 128) {
    this.embeddingGenerator = new LocalEmbeddingGenerator(defaultDimension);
    const baseDir: string = storageDirectory || process.env.VECTOR_STORAGE_PATH || path.join(os.homedir(), ".2tek", "vector_storage");
    this.storageDir = baseDir;

    this.ensureStorageDirectory();
    this.initializeDefaultCollections();
    this.loadFromDisk();
  }

  public getStorageDirectory(): string {
    return this.storageDir;
  }

  public getEmbeddingGenerator(): LocalEmbeddingGenerator {
    return this.embeddingGenerator;
  }

  private ensureStorageDirectory(): void {
    if (!fs.existsSync(this.storageDir)) {
      try {
        fs.mkdirSync(this.storageDir, { recursive: true });
      } catch {
        // Fallback silently if sandboxed
      }
    }
  }

  private initializeDefaultCollections(): void {
    if (!this.collections.has("default")) {
      const defCol: VectorCollection = this.createCollection("default", 128, "cosine");
      if (defCol.records.size === 0) {
        this.insertVectors("default", [
          {
            id: "vec-default-001",
            text: "Initial seed embedding for general semantic similarity search and vector indexing.",
            metadata: { title: "General Seed", category: "system", snippet: "Initial seed embedding for general semantic similarity search and vector indexing." },
          },
          {
            id: "vec-default-002",
            text: "System telemetry and vector operational benchmarks across node endpoints.",
            metadata: { title: "Telemetry Seed", category: "benchmark", snippet: "System telemetry and vector operational benchmarks across node endpoints." },
          },
        ]);
      }
    }
    if (!this.collections.has("conversations_vectors")) {
      const convCol: VectorCollection = this.createCollection("conversations_vectors", 128, "cosine");
      if (convCol.records.size === 0) {
        this.insertVectors("conversations_vectors", [
          {
            id: "vec-conv-001-turn-0",
            text: "Can you explain how HNSW vector indexing works in local databases?",
            metadata: {
              conversationId: "conv-seed-01",
              title: "HNSW Vector Indexing",
              role: "user",
              contentSnippet: "Can you explain how HNSW vector indexing works in local databases?",
              turnIndex: 0,
            },
          },
          {
            id: "vec-conv-001-turn-1",
            text: "HNSW builds hierarchical graphs with logarithmic search complexity for nearest neighbor queries.",
            metadata: {
              conversationId: "conv-seed-01",
              title: "HNSW Vector Indexing",
              role: "assistant",
              contentSnippet: "HNSW builds hierarchical graphs with logarithmic search complexity for nearest neighbor queries.",
              turnIndex: 1,
            },
          },
        ]);
      }
    }
    if (!this.collections.has("knowledge_vectors")) {
      const kbCol: VectorCollection = this.createCollection("knowledge_vectors", 128, "cosine");
      if (kbCol.records.size === 0) {
        this.insertVectors("knowledge_vectors", [
          {
            id: "vec-kb-001-chunk-0",
            text: "Vector databases index high-dimensional embeddings for approximate nearest neighbor search.",
            metadata: {
              documentId: "kb-seed-01",
              title: "Vector Architecture",
              category: "architecture",
              chunkIndex: 0,
              snippet: "Vector databases index high-dimensional embeddings for approximate nearest neighbor search.",
            },
          },
          {
            id: "vec-kb-001-chunk-1",
            text: "Cosine similarity measures the orientation between vectors to evaluate semantic similarity.",
            metadata: {
              documentId: "kb-seed-01",
              title: "Vector Architecture",
              category: "metrics",
              chunkIndex: 1,
              snippet: "Cosine similarity measures the orientation between vectors to evaluate semantic similarity.",
            },
          },
        ]);
      }
    }
  }

  public createCollection(name: string, dimension: number = 128, metric: VectorMetric = "cosine"): VectorCollection {
    if (this.collections.has(name)) {
      return this.collections.get(name)!;
    }
    const collection: VectorCollection = {
      name,
      dimension,
      metric,
      createdAt: Date.now(),
      records: new Map<string, VectorRecord>(),
    };
    this.collections.set(name, collection);
    this.scheduleSave();
    return collection;
  }

  public getCollection(name: string): VectorCollection | undefined {
    return this.collections.get(name);
  }

  public listCollections(): Array<{ name: string; dimension: number; metric: VectorMetric; vectorCount: number; createdAt: number }> {
    const list: Array<{ name: string; dimension: number; metric: VectorMetric; vectorCount: number; createdAt: number }> = [];
    for (const [name, col] of this.collections.entries()) {
      list.push({
        name,
        dimension: col.dimension,
        metric: col.metric,
        vectorCount: col.records.size,
        createdAt: col.createdAt,
      });
    }
    return list;
  }

  public getCollectionRecords(
    collectionName: string,
    limit: number = 100,
    offset: number = 0
  ): {
    collection: string;
    total: number;
    records: Array<{
      id: string;
      values: number[];
      metadata: Record<string, string | number | boolean | null>;
      createdAt: number;
      text: string;
    }>;
  } {
    const col: VectorCollection | undefined = this.collections.get(collectionName);
    if (!col) {
      return { collection: collectionName, total: 0, records: [] };
    }
    const allRecords: VectorRecord[] = Array.from(col.records.values());
    const total: number = allRecords.length;
    const paged: VectorRecord[] = allRecords.slice(offset, offset + limit);
    return {
      collection: collectionName,
      total,
      records: paged.map((rec: VectorRecord) => {
        const text: string =
          (rec.metadata.contentSnippet as string) ||
          (rec.metadata.snippet as string) ||
          (rec.metadata.text as string) ||
          (rec.metadata.content as string) ||
          (rec.metadata.title as string) ||
          `Vector embedding ${rec.id} (${rec.values.length} dimensions)`;
        return {
          id: rec.id,
          values: rec.values,
          metadata: rec.metadata,
          createdAt: rec.createdAt,
          text,
        };
      }),
    };
  }

  public deleteCollection(name: string): boolean {
    if (name === "default" || name === "conversations_vectors" || name === "knowledge_vectors") {
      const col: VectorCollection | undefined = this.collections.get(name);
      if (col) {
        col.records.clear();
        this.scheduleSave();
        return true;
      }
      return false;
    }
    const deleted: boolean = this.collections.delete(name);
    if (deleted) {
      this.scheduleSave();
    }
    return deleted;
  }

  public insertVectors(
    collectionName: string,
    vectors: Array<{ id: string; values?: number[]; text?: string; metadata?: Record<string, string | number | boolean | null> }>
  ): { insertedCount: number; success: boolean } {
    let col: VectorCollection | undefined = this.collections.get(collectionName);
    if (!col) {
      col = this.createCollection(collectionName);
    }

    let insertedCount: number = 0;
    const now: number = Date.now();

    for (let index: number = 0; index < vectors.length; index++) {
      const item: { id: string; values?: number[]; text?: string; metadata?: Record<string, string | number | boolean | null> } = vectors[index];
      let values: number[];
      if (item.values && item.values.length > 0) {
        values = item.values;
      } else if (item.text) {
        values = this.embeddingGenerator.generate(item.text, col.dimension);
      } else {
        values = new Array<number>(col.dimension).fill(0);
      }

      const record: VectorRecord = {
        id: item.id,
        values,
        metadata: item.metadata || {},
        createdAt: now,
      };

      col.records.set(item.id, record);
      insertedCount++;
    }

    this.scheduleSave();
    return { insertedCount, success: true };
  }

  public searchVectors(params: {
    collectionName: string;
    queryVector?: number[];
    queryText?: string;
    topK?: number;
    minScore?: number;
    filter?: Record<string, string | number | boolean | null>;
  }): VectorSearchResult[] {
    const col: VectorCollection | undefined = this.collections.get(params.collectionName);
    if (!col) {
      return [];
    }

    let queryVector: number[];
    if (params.queryVector && params.queryVector.length > 0) {
      queryVector = params.queryVector;
    } else if (params.queryText) {
      queryVector = this.embeddingGenerator.generate(params.queryText, col.dimension);
    } else {
      return [];
    }

    const topK: number = params.topK && params.topK > 0 ? params.topK : 10;
    const minScore: number = params.minScore !== undefined ? params.minScore : -1.0;
    const matches: VectorSearchResult[] = [];

    for (const record of col.records.values()) {
      // Check metadata filter
      if (params.filter) {
        let matchesFilter: boolean = true;
        for (const [key, value] of Object.entries(params.filter)) {
          if (record.metadata[key] !== value) {
            matchesFilter = false;
            break;
          }
        }
        if (!matchesFilter) {
          continue;
        }
      }

      let score: number = 0;
      if (col.metric === "cosine") {
        score = VectorMath.cosineSimilarity(queryVector, record.values);
      } else if (col.metric === "dot") {
        score = VectorMath.dotProduct(queryVector, record.values);
      } else if (col.metric === "euclidean") {
        const dist: number = VectorMath.euclideanDistance(queryVector, record.values);
        score = 1.0 / (1.0 + dist);
      }

      if (score >= minScore) {
        matches.push({
          id: record.id,
          score,
          values: record.values,
          metadata: record.metadata,
        });
      }
    }

    // Sort descending by score
    matches.sort((a: VectorSearchResult, b: VectorSearchResult): number => b.score - a.score);
    return matches.slice(0, topK);
  }

  public uploadConversation(conversation: {
    conversationId?: string;
    title?: string;
    metadata?: Record<string, string | number | boolean | null>;
    messages: Array<{ id?: string; role: "system" | "user" | "assistant" | "function"; content: string; timestamp?: string }>;
  }): { conversationId: string; turnsIndexed: number; success: boolean } {
    const convId: string = conversation.conversationId || `conv-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
    const title: string = conversation.title || (conversation.messages.length > 0 ? conversation.messages[0].content.substring(0, 50) : "Untitled Conversation");
    const nowIso: string = new Date().toISOString();

    const parsedMessages: ConversationTurn[] = [];
    const vectorRecordsToInsert: Array<{ id: string; values: number[]; metadata: Record<string, string | number | boolean | null> }> = [];

    for (let index: number = 0; index < conversation.messages.length; index++) {
      const msg: { id?: string; role: "system" | "user" | "assistant" | "function"; content: string; timestamp?: string } = conversation.messages[index];
      const msgId: string = msg.id || `${convId}-turn-${index}`;
      const turnVectorId: string = `vec-${msgId}`;
      const vectorValues: number[] = this.embeddingGenerator.generate(msg.content, 128);

      parsedMessages.push({
        id: msgId,
        role: msg.role,
        content: msg.content,
        timestamp: msg.timestamp || nowIso,
        vectorId: turnVectorId,
      });

      vectorRecordsToInsert.push({
        id: turnVectorId,
        values: vectorValues,
        metadata: {
          conversationId: convId,
          title,
          messageId: msgId,
          role: msg.role,
          contentSnippet: msg.content.substring(0, 150),
          turnIndex: index,
          ...(conversation.metadata || {}),
        },
      });
    }

    const doc: ConversationDocument = {
      conversationId: convId,
      title,
      createdAt: nowIso,
      updatedAt: nowIso,
      metadata: conversation.metadata || {},
      messages: parsedMessages,
    };

    this.conversations.set(convId, doc);
    this.insertVectors("conversations_vectors", vectorRecordsToInsert);
    this.scheduleSave();

    return {
      conversationId: convId,
      turnsIndexed: parsedMessages.length,
      success: true,
    };
  }

  public getConversation(id: string): ConversationDocument | undefined {
    return this.conversations.get(id);
  }

  public listConversations(): ConversationDocument[] {
    return Array.from(this.conversations.values());
  }

  public getRelatedConversations(params: {
    queryText?: string;
    queryVector?: number[];
    topK?: number;
    excludeConversationId?: string;
  }): RelatedConversationMatch[] {
    const searchMatches: VectorSearchResult[] = this.searchVectors({
      collectionName: "conversations_vectors",
      queryText: params.queryText,
      queryVector: params.queryVector,
      topK: (params.topK || 5) * 2,
    });

    const relatedMap: Map<string, RelatedConversationMatch> = new Map<string, RelatedConversationMatch>();

    for (let index: number = 0; index < searchMatches.length; index++) {
      const match: VectorSearchResult = searchMatches[index];
      const convId: string = String(match.metadata.conversationId || "");
      if (!convId || (params.excludeConversationId && convId === params.excludeConversationId)) {
        continue;
      }

      if (!relatedMap.has(convId) || relatedMap.get(convId)!.score < match.score) {
        relatedMap.set(convId, {
          conversationId: convId,
          title: String(match.metadata.title || "Conversation"),
          messageId: String(match.metadata.messageId || match.id),
          role: String(match.metadata.role || "user"),
          snippet: String(match.metadata.contentSnippet || ""),
          score: match.score,
          timestamp: new Date().toISOString(),
        });
      }

      if (relatedMap.size >= (params.topK || 5)) {
        break;
      }
    }

    return Array.from(relatedMap.values()).sort(
      (a: RelatedConversationMatch, b: RelatedConversationMatch): number => b.score - a.score
    );
  }

  public uploadKnowledgeDocument(doc: {
    documentId?: string;
    title: string;
    category?: string;
    tags?: string[];
    content: string;
  }): { documentId: string; chunkCount: number; success: boolean } {
    const docId: string = doc.documentId || `kb-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
    const nowIso: string = new Date().toISOString();

    // Chunk by paragraphs or double newlines
    const rawChunks: string[] = doc.content
      .split(/\n\s*\n/)
      .map((c: string): string => c.trim())
      .filter((c: string): boolean => c.length > 0);

    const chunkItems: Array<{ chunkIndex: number; text: string; vectorId: string }> = [];
    const vectorRecordsToInsert: Array<{ id: string; values: number[]; metadata: Record<string, string | number | boolean | null> }> = [];

    for (let index: number = 0; index < rawChunks.length; index++) {
      const chunkText: string = rawChunks[index];
      const chunkVectorId: string = `vec-kb-${docId}-${index}`;
      const values: number[] = this.embeddingGenerator.generate(chunkText, 128);

      chunkItems.push({
        chunkIndex: index,
        text: chunkText,
        vectorId: chunkVectorId,
      });

      vectorRecordsToInsert.push({
        id: chunkVectorId,
        values,
        metadata: {
          documentId: docId,
          title: doc.title,
          category: doc.category || "general",
          chunkIndex: index,
          snippet: chunkText.substring(0, 150),
        },
      });
    }

    const knowledgeDoc: KnowledgeDocument = {
      documentId: docId,
      title: doc.title,
      category: doc.category || "general",
      tags: doc.tags || [],
      content: doc.content,
      createdAt: nowIso,
      chunks: chunkItems,
    };

    this.knowledgeDocs.set(docId, knowledgeDoc);
    this.insertVectors("knowledge_vectors", vectorRecordsToInsert);
    this.scheduleSave();

    return {
      documentId: docId,
      chunkCount: chunkItems.length,
      success: true,
    };
  }

  public listKnowledgeDocuments(): KnowledgeDocument[] {
    return Array.from(this.knowledgeDocs.values());
  }

  public exportTrainingDataset(params: {
    format?: TrainingExportFormat;
    limit?: number;
    domainFilter?: string;
  }): TrainingExportResult {
    const format: TrainingExportFormat = params.format === "sharegpt" ? "sharegpt" : "openai";
    const limit: number = params.limit && params.limit > 0 ? params.limit : 1000;
    const lines: string[] = [];

    let count: number = 0;
    for (const conv of this.conversations.values()) {
      if (params.domainFilter && conv.metadata.domain !== params.domainFilter) {
        continue;
      }
      if (conv.messages.length === 0) {
        continue;
      }

      if (format === "openai") {
        const messagesPayload: Array<{ role: string; content: string }> = conv.messages.map(
          (m: ConversationTurn): { role: string; content: string } => ({
            role: m.role,
            content: m.content,
          })
        );
        lines.push(JSON.stringify({ messages: messagesPayload }));
      } else {
        // sharegpt format
        const conversationsPayload: Array<{ from: string; value: string }> = conv.messages.map(
          (m: ConversationTurn): { from: string; value: string } => ({
            from: m.role === "assistant" ? "gpt" : m.role === "system" ? "system" : "human",
            value: m.content,
          })
        );
        lines.push(JSON.stringify({ conversations: conversationsPayload }));
      }

      count++;
      if (count >= limit) {
        break;
      }
    }

    return {
      format,
      recordCount: count,
      jsonlContent: lines.join("\n"),
    };
  }

  public getStats(): {
    collectionsCount: number;
    totalVectorsCount: number;
    totalConversations: number;
    totalKnowledgeDocs: number;
  } {
    let totalVectors: number = 0;
    for (const col of this.collections.values()) {
      totalVectors += col.records.size;
    }
    return {
      collectionsCount: this.collections.size,
      totalVectorsCount: totalVectors,
      totalConversations: this.conversations.size,
      totalKnowledgeDocs: this.knowledgeDocs.size,
    };
  }

  private scheduleSave(): void {
    if (this.isPersisting) {
      return;
    }
    this.isPersisting = true;
    setTimeout((): void => {
      this.saveToDisk();
      this.isPersisting = false;
    }, 100);
  }

  private saveToDisk(): void {
    try {
      this.ensureStorageDirectory();

      // Save collections
      const collectionsExport: Record<string, unknown> = {};
      for (const [name, col] of this.collections.entries()) {
        const recordsExport: Record<string, unknown> = {};
        for (const [id, rec] of col.records.entries()) {
          recordsExport[id] = rec;
        }
        collectionsExport[name] = {
          name: col.name,
          dimension: col.dimension,
          metric: col.metric,
          createdAt: col.createdAt,
          records: recordsExport,
        };
      }
      fs.writeFileSync(
        path.join(this.storageDir, "collections.json"),
        JSON.stringify(collectionsExport, null, 2),
        "utf-8"
      );

      // Save conversations
      const convExport: Record<string, ConversationDocument> = {};
      for (const [id, doc] of this.conversations.entries()) {
        convExport[id] = doc;
      }
      fs.writeFileSync(
        path.join(this.storageDir, "conversations.json"),
        JSON.stringify(convExport, null, 2),
        "utf-8"
      );

      // Save knowledge documents
      const kbExport: Record<string, KnowledgeDocument> = {};
      for (const [id, doc] of this.knowledgeDocs.entries()) {
        kbExport[id] = doc;
      }
      fs.writeFileSync(
        path.join(this.storageDir, "knowledge.json"),
        JSON.stringify(kbExport, null, 2),
        "utf-8"
      );
    } catch {
      // Storage save errors are caught gracefully
    }
  }

  private loadFromDisk(): void {
    try {
      const collectionsFile: string = path.join(this.storageDir, "collections.json");
      if (fs.existsSync(collectionsFile)) {
        const rawContent: string = fs.readFileSync(collectionsFile, "utf-8");
        const parsed: Record<string, { name: string; dimension: number; metric: VectorMetric; createdAt: number; records: Record<string, VectorRecord> }> = JSON.parse(rawContent);
        for (const [name, colData] of Object.entries(parsed)) {
          const col: VectorCollection = {
            name: colData.name,
            dimension: colData.dimension,
            metric: colData.metric,
            createdAt: colData.createdAt,
            records: new Map<string, VectorRecord>(),
          };
          if (colData.records) {
            for (const [recId, rec] of Object.entries(colData.records)) {
              col.records.set(recId, rec);
            }
          }
          this.collections.set(name, col);
        }
      }

      const convFile: string = path.join(this.storageDir, "conversations.json");
      if (fs.existsSync(convFile)) {
        const rawContent: string = fs.readFileSync(convFile, "utf-8");
        const parsed: Record<string, ConversationDocument> = JSON.parse(rawContent);
        for (const [id, doc] of Object.entries(parsed)) {
          this.conversations.set(id, doc);
        }
      }

      const kbFile: string = path.join(this.storageDir, "knowledge.json");
      if (fs.existsSync(kbFile)) {
        const rawContent: string = fs.readFileSync(kbFile, "utf-8");
        const parsed: Record<string, KnowledgeDocument> = JSON.parse(rawContent);
        for (const [id, doc] of Object.entries(parsed)) {
          this.knowledgeDocs.set(id, doc);
        }
      }
    } catch {
      // Load fallback cleanly
    }
  }
}
