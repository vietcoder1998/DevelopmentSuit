import { VectorMath } from "./vector-math";

export class LocalEmbeddingGenerator {
  private readonly defaultDimension: number;

  public constructor(dimension: number = 128) {
    this.defaultDimension = dimension;
  }

  public getDimension(): number {
    return this.defaultDimension;
  }

  /**
   * Generates a dense, normalized vector representation for input text
   * using token hashing and n-gram subword frequency distributions.
   */
  public generate(text: string, targetDimension?: number): number[] {
    const dimension: number = targetDimension || this.defaultDimension;
    const vector: number[] = new Array<number>(dimension).fill(0);

    if (!text || text.trim().length === 0) {
      return vector;
    }

    const normalizedText: string = text.toLowerCase().trim();
    const tokens: string[] = normalizedText.split(/[\s,.;:!?()[\]{}"'`/\\]+/).filter(Boolean);

    // 1. Unigram feature hashing
    for (let tokenIndex: number = 0; tokenIndex < tokens.length; tokenIndex++) {
      const token: string = tokens[tokenIndex];
      const hashVal: number = this.hashString(token);
      const bucketIndex: number = Math.abs(hashVal) % dimension;
      const sign: number = (hashVal & 1) === 0 ? 1 : -1;
      vector[bucketIndex] += sign * (1.0 + Math.log(1 + token.length));

      // 2. Character 3-gram feature hashing for subword semantics
      if (token.length >= 3) {
        for (let charIndex: number = 0; charIndex <= token.length - 3; charIndex++) {
          const triGram: string = token.substring(charIndex, charIndex + 3);
          const triHash: number = this.hashString(triGram);
          const triBucket: number = Math.abs(triHash) % dimension;
          const triSign: number = (triHash & 1) === 0 ? 0.5 : -0.5;
          vector[triBucket] += triSign;
        }
      }
    }

    // 3. Bigram feature hashing for phrase semantics
    for (let index: number = 0; index < tokens.length - 1; index++) {
      const bigram: string = `${tokens[index]}_${tokens[index + 1]}`;
      const biHash: number = this.hashString(bigram);
      const biBucket: number = Math.abs(biHash) % dimension;
      const biSign: number = (biHash & 1) === 0 ? 0.75 : -0.75;
      vector[biBucket] += biSign;
    }

    // Normalize final vector
    return VectorMath.normalize(vector);
  }

  private hashString(input: string): number {
    let hash: number = 5381;
    for (let index: number = 0; index < input.length; index++) {
      hash = ((hash << 5) + hash) + input.charCodeAt(index);
      hash = hash & hash; // Convert to 32bit integer
    }
    return hash;
  }
}
