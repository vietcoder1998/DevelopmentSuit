export class VectorMath {
  public static dotProduct(vectorA: number[], vectorB: number[]): number {
    const dimension: number = Math.min(vectorA.length, vectorB.length);
    let dot: number = 0;
    for (let index: number = 0; index < dimension; index++) {
      dot += vectorA[index] * vectorB[index];
    }
    return dot;
  }

  public static magnitude(vector: number[]): number {
    let sumOfSquares: number = 0;
    for (let index: number = 0; index < vector.length; index++) {
      sumOfSquares += vector[index] * vector[index];
    }
    return Math.sqrt(sumOfSquares);
  }

  public static cosineSimilarity(vectorA: number[], vectorB: number[]): number {
    const magnitudeA: number = VectorMath.magnitude(vectorA);
    const magnitudeB: number = VectorMath.magnitude(vectorB);
    if (magnitudeA === 0 || magnitudeB === 0) {
      return 0;
    }
    const dot: number = VectorMath.dotProduct(vectorA, vectorB);
    const similarity: number = dot / (magnitudeA * magnitudeB);
    return Math.max(-1, Math.min(1, similarity));
  }

  public static euclideanDistance(vectorA: number[], vectorB: number[]): number {
    const dimension: number = Math.min(vectorA.length, vectorB.length);
    let sumOfSquaredDifferences: number = 0;
    for (let index: number = 0; index < dimension; index++) {
      const difference: number = vectorA[index] - vectorB[index];
      sumOfSquaredDifferences += difference * difference;
    }
    return Math.sqrt(sumOfSquaredDifferences);
  }

  public static normalize(vector: number[]): number[] {
    const mag: number = VectorMath.magnitude(vector);
    if (mag === 0) {
      return new Array<number>(vector.length).fill(0);
    }
    const normalized: number[] = new Array<number>(vector.length);
    for (let index: number = 0; index < vector.length; index++) {
      normalized[index] = vector[index] / mag;
    }
    return normalized;
  }
}
