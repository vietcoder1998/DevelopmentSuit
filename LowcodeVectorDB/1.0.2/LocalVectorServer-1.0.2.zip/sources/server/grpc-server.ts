import * as grpc from "@grpc/grpc-js";
import * as protoLoader from "@grpc/proto-loader";
import fs from "node:fs";
import path from "node:path";
import process from "node:process";
import { VectorDbEngine } from "../engine/vector-db-engine";
import { VectorPerformanceMonitor } from "../monitor/vector-performance-monitor";
import { TrainingExportFormat } from "../engine/vector-types";

export interface VectorGrpcServerConfig {
  readonly host: string;
  readonly port: number;
}

export const DEFAULT_VECTOR_GRPC_HOST: string = process.env.LOCAL_VECTOR_GRPC_HOST || "0.0.0.0";
export const DEFAULT_VECTOR_GRPC_PORT: number = Number(process.env.LOCAL_VECTOR_GRPC_PORT || 50056);

interface GrpcUnaryCall<TRequest, TResponse> {
  request: TRequest;
}

type GrpcUnaryCallback<TResponse> = (
  error: grpc.ServiceError | null,
  value?: TResponse
) => void;

export class VectorGrpcServer {
  private server: grpc.Server | null = null;
  private readonly config: VectorGrpcServerConfig;
  private readonly engine: VectorDbEngine;
  private readonly monitor: VectorPerformanceMonitor;
  private isRunning: boolean = false;

  public constructor(
    config?: Partial<VectorGrpcServerConfig>,
    customEngine?: VectorDbEngine,
    customMonitor?: VectorPerformanceMonitor
  ) {
    this.config = {
      host: config?.host || DEFAULT_VECTOR_GRPC_HOST,
      port: config?.port || DEFAULT_VECTOR_GRPC_PORT,
    };
    this.engine = customEngine || new VectorDbEngine();
    this.monitor = customMonitor || new VectorPerformanceMonitor(this.engine);
  }

  public resolveProtoFilePath(): string {
    const candidatePaths: string[] = [
      path.resolve(__dirname, "../../proto/vector.proto"),
      path.resolve(process.cwd(), "proto/vector.proto"),
      path.resolve(process.cwd(), "packages/LocalVectorServer/proto/vector.proto"),
    ];

    for (const cand of candidatePaths) {
      if (fs.existsSync(cand)) {
        return cand;
      }
    }
    return candidatePaths[0];
  }

  public async start(): Promise<void> {
    if (this.isRunning && this.server) {
      return;
    }

    const protoPath: string = this.resolveProtoFilePath();
    if (!fs.existsSync(protoPath)) {
      throw new Error(`Vector Proto file not found at: ${protoPath}`);
    }

    const packageDefinition: protoLoader.PackageDefinition = protoLoader.loadSync(protoPath, {
      keepCase: true,
      longs: String,
      enums: String,
      defaults: true,
      oneofs: true,
    });

    const grpcObject = grpc.loadPackageDefinition(packageDefinition) as Record<string, unknown>;
    const vtek = grpcObject.vtek as Record<string, unknown>;
    const vector = vtek.vector as Record<string, unknown>;
    const grpcPkg = vector.grpc as { VectorService: { service: grpc.ServiceDefinition } };

    if (!grpcPkg || !grpcPkg.VectorService) {
      throw new Error("Failed to load vtek.vector.grpc.VectorService from proto definition");
    }

    this.server = new grpc.Server();

    this.server.addService(grpcPkg.VectorService.service, {
      Ping: this.handlePing.bind(this),
      InsertVectors: this.handleInsertVectors.bind(this),
      SearchVectors: this.handleSearchVectors.bind(this),
      UploadConversation: this.handleUploadConversation.bind(this),
      GetRelatedConversations: this.handleGetRelatedConversations.bind(this),
      ExportTrainingData: this.handleExportTrainingData.bind(this),
      GetPerformanceMetrics: this.handleGetPerformanceMetrics.bind(this),
    });

    const bindAddress: string = `${this.config.host}:${this.config.port}`;
    return new Promise<void>((resolve: () => void, reject: (err: Error) => void): void => {
      this.server!.bindAsync(
        bindAddress,
        grpc.ServerCredentials.createInsecure(),
        (err: Error | null, port: number): void => {
          if (err) {
            reject(err);
            return;
          }
          if (port === 0) {
            reject(new Error(`Failed to bind VectorService on ${bindAddress}: Port already in use`));
            return;
          }
          this.isRunning = true;
          resolve();
        }
      );
    });
  }

  public async stop(): Promise<void> {
    if (!this.server || !this.isRunning) {
      return;
    }
    return new Promise<void>((resolve: () => void): void => {
      this.server!.tryShutdown((): void => {
        this.server = null;
        this.isRunning = false;
        resolve();
      });
    });
  }

  private handlePing(
    call: GrpcUnaryCall<{ client_id?: string; timestamp?: string | number }, unknown>,
    callback: GrpcUnaryCallback<{
      status: string;
      server_version: string;
      server_time: number;
      collections_count: number;
      total_vectors_count: number;
    }>
  ): void {
    const stats = this.engine.getStats();
    callback(null, {
      status: "ok",
      server_version: "1.0.0",
      server_time: Date.now(),
      collections_count: stats.collectionsCount,
      total_vectors_count: stats.totalVectorsCount,
    });
  }

  private handleInsertVectors(
    call: GrpcUnaryCall<{
      collection?: string;
      vectors?: Array<{ id: string; values?: number[]; metadata_json?: string }>;
    }, unknown>,
    callback: GrpcUnaryCallback<{
      success: boolean;
      inserted_count: number;
      message: string;
    }>
  ): void {
    try {
      const collection: string = call.request.collection || "default";
      const rawVectors = call.request.vectors || [];

      const parsedVectors: Array<{
        id: string;
        values?: number[];
        metadata?: Record<string, string | number | boolean | null>;
      }> = rawVectors.map((item) => {
        let metadata: Record<string, string | number | boolean | null> = {};
        if (item.metadata_json) {
          try {
            metadata = JSON.parse(item.metadata_json);
          } catch {
            metadata = {};
          }
        }
        return {
          id: item.id,
          values: item.values,
          metadata,
        };
      });

      const result = this.engine.insertVectors(collection, parsedVectors);
      this.monitor.recordInsert(result.insertedCount);

      callback(null, {
        success: true,
        inserted_count: result.insertedCount,
        message: `Successfully inserted ${result.insertedCount} vectors`,
      });
    } catch (err: unknown) {
      const msg: string = err instanceof Error ? err.message : String(err);
      callback({
        code: grpc.status.INTERNAL,
        message: msg,
        name: "VectorInsertError",
      });
    }
  }

  private handleSearchVectors(
    call: GrpcUnaryCall<{
      collection?: string;
      query_vector?: number[];
      query_text?: string;
      top_k?: number;
      min_score?: number;
      filter_json?: string;
    }, unknown>,
    callback: GrpcUnaryCallback<{
      collection: string;
      matches: Array<{
        id: string;
        score: number;
        values: number[];
        metadata_json: string;
      }>;
      duration_microseconds: number;
    }>
  ): void {
    const startTime: number = Date.now();
    try {
      const collection: string = call.request.collection || "default";
      let filter: Record<string, string | number | boolean | null> | undefined;
      if (call.request.filter_json) {
        try {
          filter = JSON.parse(call.request.filter_json);
        } catch {
          filter = undefined;
        }
      }

      const results = this.engine.searchVectors({
        collectionName: collection,
        queryVector: call.request.query_vector && call.request.query_vector.length > 0 ? call.request.query_vector : undefined,
        queryText: call.request.query_text,
        topK: call.request.top_k || 10,
        minScore: call.request.min_score !== undefined ? call.request.min_score : -1.0,
        filter,
      });

      const latencyMs: number = Date.now() - startTime;
      this.monitor.recordQuery(latencyMs);

      const matches = results.map((r) => ({
        id: r.id,
        score: r.score,
        values: r.values || [],
        metadata_json: JSON.stringify(r.metadata),
      }));

      callback(null, {
        collection,
        matches,
        duration_microseconds: latencyMs * 1000,
      });
    } catch (err: unknown) {
      const msg: string = err instanceof Error ? err.message : String(err);
      callback({
        code: grpc.status.INTERNAL,
        message: msg,
        name: "VectorSearchError",
      });
    }
  }

  private handleUploadConversation(
    call: GrpcUnaryCall<{
      conversation_id?: string;
      title?: string;
      messages?: Array<{ id?: string; role?: string; content: string; timestamp?: string }>;
      metadata_json?: string;
    }, unknown>,
    callback: GrpcUnaryCallback<{
      success: boolean;
      conversation_id: string;
      turns_indexed: number;
      timestamp: number;
    }>
  ): void {
    try {
      let metadata: Record<string, string | number | boolean | null> = {};
      if (call.request.metadata_json) {
        try {
          metadata = JSON.parse(call.request.metadata_json);
        } catch {
          metadata = {};
        }
      }

      const rawMessages = call.request.messages || [];
      const messages = rawMessages.map((m) => ({
        id: m.id,
        role: (m.role as "system" | "user" | "assistant" | "function") || "user",
        content: m.content || "",
        timestamp: m.timestamp,
      }));

      const result = this.engine.uploadConversation({
        conversationId: call.request.conversation_id,
        title: call.request.title,
        metadata,
        messages,
      });

      this.monitor.recordInsert(result.turnsIndexed);

      callback(null, {
        success: true,
        conversation_id: result.conversationId,
        turns_indexed: result.turnsIndexed,
        timestamp: Date.now(),
      });
    } catch (err: unknown) {
      const msg: string = err instanceof Error ? err.message : String(err);
      callback({
        code: grpc.status.INTERNAL,
        message: msg,
        name: "ConversationUploadError",
      });
    }
  }

  private handleGetRelatedConversations(
    call: GrpcUnaryCall<{
      query_text?: string;
      query_vector?: number[];
      top_k?: number;
    }, unknown>,
    callback: GrpcUnaryCallback<{
      related: Array<{
        conversation_id: string;
        title: string;
        message_id: string;
        role: string;
        snippet: string;
        score: number;
      }>;
      duration_microseconds: number;
    }>
  ): void {
    const startTime: number = Date.now();
    try {
      const related = this.engine.getRelatedConversations({
        queryText: call.request.query_text,
        queryVector: call.request.query_vector && call.request.query_vector.length > 0 ? call.request.query_vector : undefined,
        topK: call.request.top_k || 5,
      });

      const latencyMs: number = Date.now() - startTime;
      this.monitor.recordQuery(latencyMs);

      callback(null, {
        related: related.map((r) => ({
          conversation_id: r.conversationId,
          title: r.title,
          message_id: r.messageId,
          role: r.role,
          snippet: r.snippet,
          score: r.score,
        })),
        duration_microseconds: latencyMs * 1000,
      });
    } catch (err: unknown) {
      const msg: string = err instanceof Error ? err.message : String(err);
      callback({
        code: grpc.status.INTERNAL,
        message: msg,
        name: "GetRelatedConversationsError",
      });
    }
  }

  private handleExportTrainingData(
    call: GrpcUnaryCall<{
      format?: string;
      limit?: number;
      domain_filter?: string;
    }, unknown>,
    callback: GrpcUnaryCallback<{
      format: string;
      record_count: number;
      jsonl_content: string;
    }>
  ): void {
    try {
      const format: TrainingExportFormat = call.request.format === "openai" ? "openai" : "sharegpt";
      const result = this.engine.exportTrainingDataset({
        format,
        limit: call.request.limit || 1000,
        domainFilter: call.request.domain_filter || undefined,
      });

      callback(null, {
        format: result.format,
        record_count: result.recordCount,
        jsonl_content: result.jsonlContent,
      });
    } catch (err: unknown) {
      const msg: string = err instanceof Error ? err.message : String(err);
      callback({
        code: grpc.status.INTERNAL,
        message: msg,
        name: "ExportTrainingError",
      });
    }
  }

  private handleGetPerformanceMetrics(
    call: GrpcUnaryCall<unknown, unknown>,
    callback: GrpcUnaryCallback<{
      uptime_seconds: number;
      total_queries: number;
      total_inserts: number;
      collections_count: number;
      total_vectors_count: number;
      total_conversations: number;
      average_search_latency_ms: number;
      memory_heap_used_bytes: number;
    }>
  ): void {
    const telemetry = this.monitor.getTelemetry();
    callback(null, {
      uptime_seconds: telemetry.uptimeSeconds,
      total_queries: telemetry.totalQueries,
      total_inserts: telemetry.totalInserts,
      collections_count: telemetry.collectionsCount,
      total_vectors_count: telemetry.totalVectorsCount,
      total_conversations: telemetry.totalConversations,
      average_search_latency_ms: telemetry.averageSearchLatencyMs,
      memory_heap_used_bytes: telemetry.memoryHeapUsedBytes,
    });
  }
}
