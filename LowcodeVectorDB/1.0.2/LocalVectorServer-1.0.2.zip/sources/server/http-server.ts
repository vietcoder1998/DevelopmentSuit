import http from "node:http";
import { URL } from "node:url";
import { VectorDbEngine } from "../engine/vector-db-engine";
import { VectorPerformanceMonitor } from "../monitor/vector-performance-monitor";
import { TrainingExportFormat } from "../engine/vector-types";

export interface VectorHttpServerConfig {
  readonly host: string;
  readonly port: number;
}

export const DEFAULT_VECTOR_HTTP_HOST: string = process.env.LOCAL_VECTOR_HOST || "0.0.0.0";
export const DEFAULT_VECTOR_HTTP_PORT: number = Number(process.env.LOCAL_VECTOR_HTTP_PORT || 3120);

export class VectorHttpServer {
  private server: http.Server | null = null;
  private readonly config: VectorHttpServerConfig;
  private readonly engine: VectorDbEngine;
  private readonly monitor: VectorPerformanceMonitor;

  public constructor(
    config?: Partial<VectorHttpServerConfig>,
    customEngine?: VectorDbEngine,
    customMonitor?: VectorPerformanceMonitor
  ) {
    this.config = {
      host: config?.host || DEFAULT_VECTOR_HTTP_HOST,
      port: config?.port || DEFAULT_VECTOR_HTTP_PORT,
    };
    this.engine = customEngine || new VectorDbEngine();
    this.monitor = customMonitor || new VectorPerformanceMonitor(this.engine);
  }

  public getEngine(): VectorDbEngine {
    return this.engine;
  }

  public getMonitor(): VectorPerformanceMonitor {
    return this.monitor;
  }

  public async start(): Promise<void> {
    if (this.server) {
      return;
    }

    this.server = http.createServer(
      async (req: http.IncomingMessage, res: http.ServerResponse): Promise<void> => {
        // CORS
        res.setHeader("Access-Control-Allow-Origin", "*");
        res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
        res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Requested-With");

        if (req.method === "OPTIONS") {
          res.writeHead(204);
          res.end();
          return;
        }

        const requestUrl: URL = new URL(req.url || "/", `http://${req.headers.host || "localhost"}`);
        const pathname: string = requestUrl.pathname;
        const method: string = req.method || "GET";
        const startTime: number = Date.now();

        try {
          // Route: /health
          if (pathname === "/health" && method === "GET") {
            this.sendJson(res, 200, {
              status: "ok",
              name: "LocalVectorServer",
              version: "1.0.0",
              timestamp: Date.now(),
            });
            return;
          }

          // Route: /api/status
          if (pathname === "/api/status" && method === "GET") {
            const stats = this.engine.getStats();
            const telemetry = this.monitor.getTelemetry();
            this.sendJson(res, 200, {
              status: "online",
              version: "1.0.0",
              stats,
              telemetry,
              collections: this.engine.listCollections(),
            });
            return;
          }

          // Route: /api/metrics
          if (pathname === "/api/metrics" && method === "GET") {
            const telemetry = this.monitor.getTelemetry();
            this.sendJson(res, 200, telemetry);
            return;
          }

          // Route: /api/collections (GET)
          if (pathname === "/api/collections" && method === "GET") {
            const collections = this.engine.listCollections();
            this.sendJson(res, 200, { collections });
            return;
          }

          // Route: /api/collections/:name/records or /api/collections/records (GET)
          const isRecordsRoute: boolean =
            (pathname.startsWith("/api/collections/") && pathname.endsWith("/records")) ||
            pathname === "/api/collections/records" ||
            pathname === "/api/vectors";

          if (isRecordsRoute && method === "GET") {
            let collectionName: string = requestUrl.searchParams.get("collection") || requestUrl.searchParams.get("name") || "";
            if (!collectionName && pathname.startsWith("/api/collections/")) {
              const parts: string[] = pathname.split("/").filter(Boolean);
              if (parts.length >= 3 && parts[0] === "api" && parts[1] === "collections") {
                collectionName = decodeURIComponent(parts[2]);
              }
            }
            if (!collectionName) {
              collectionName = "default";
            }
            const limit: number = Number(requestUrl.searchParams.get("limit") || 100);
            const offset: number = Number(requestUrl.searchParams.get("offset") || 0);
            const data = this.engine.getCollectionRecords(collectionName, limit, offset);
            this.sendJson(res, 200, data);
            return;
          }

          // Route: /api/collections (POST)
          if ((pathname === "/api/collections" || pathname === "/api/collections/create") && method === "POST") {
            const body = await this.readJsonBody(req);
            const name: string = String(body.name || "");
            if (!name) {
              this.sendJson(res, 400, { error: "Collection name is required" });
              return;
            }
            const dimension: number = Number(body.dimension || 128);
            const metric = body.metric === "euclidean" || body.metric === "dot" ? body.metric : "cosine";
            const col = this.engine.createCollection(name, dimension, metric);
            this.sendJson(res, 201, {
              name: col.name,
              dimension: col.dimension,
              metric: col.metric,
              createdAt: col.createdAt,
            });
            return;
          }

          // Route: /api/vectors/insert (POST)
          if (pathname === "/api/vectors/insert" && method === "POST") {
            const body = await this.readJsonBody(req);
            const collection: string = String(body.collection || "default");
            const vectors = Array.isArray(body.vectors) ? body.vectors : [];
            const result = this.engine.insertVectors(collection, vectors);
            this.monitor.recordInsert(result.insertedCount);
            this.sendJson(res, 200, result);
            return;
          }

          // Route: /api/vectors/search (POST)
          if (pathname === "/api/vectors/search" && method === "POST") {
            const body = await this.readJsonBody(req);
            const collectionName: string = String(body.collection || "default");
            const topK: number = Number(body.topK || 10);
            const minScore: number = Number(body.minScore || -1.0);
            const queryVector = Array.isArray(body.queryVector) ? body.queryVector : undefined;
            const queryText = body.queryText ? String(body.queryText) : undefined;
            const filter = body.filter && typeof body.filter === "object" ? body.filter : undefined;

            const matches = this.engine.searchVectors({
              collectionName,
              queryVector,
              queryText,
              topK,
              minScore,
              filter,
            });

            const latencyMs: number = Date.now() - startTime;
            this.monitor.recordQuery(latencyMs);

            this.sendJson(res, 200, {
              collection: collectionName,
              topK,
              matches,
              latencyMs,
            });
            return;
          }

          // Route: /api/conversations/upload (POST)
          if (pathname === "/api/conversations/upload" && method === "POST") {
            const body = await this.readJsonBody(req);
            const conversation = body.conversation || body;
            if (!conversation.messages || !Array.isArray(conversation.messages)) {
              this.sendJson(res, 400, { error: "Invalid conversation structure: messages array required" });
              return;
            }

            const result = this.engine.uploadConversation(conversation);
            this.monitor.recordInsert(result.turnsIndexed);
            this.sendJson(res, 201, result);
            return;
          }

          // Route: /api/conversations (GET)
          if (pathname === "/api/conversations" && method === "GET") {
            const list = this.engine.listConversations();
            this.sendJson(res, 200, { conversations: list });
            return;
          }

          // Route: /api/conversations/related (GET or POST)
          if ((pathname === "/api/conversations/related" || pathname === "/api/conversations/search") && (method === "GET" || method === "POST")) {
            let queryText: string = "";
            let topK: number = 5;

            if (method === "GET") {
              queryText = requestUrl.searchParams.get("query") || requestUrl.searchParams.get("q") || "";
              topK = Number(requestUrl.searchParams.get("topK") || 5);
            } else {
              const body = await this.readJsonBody(req);
              queryText = String(body.queryText || body.query || "");
              topK = Number(body.topK || 5);
            }

            const related = this.engine.getRelatedConversations({ queryText, topK });
            const latencyMs: number = Date.now() - startTime;
            this.monitor.recordQuery(latencyMs);

            this.sendJson(res, 200, {
              queryText,
              topK,
              related,
              latencyMs,
            });
            return;
          }

          // Route: /api/knowledge/upload (POST)
          if (pathname === "/api/knowledge/upload" && method === "POST") {
            const body = await this.readJsonBody(req);
            const title: string = String(body.title || "Untitled Document");
            const content: string = String(body.content || "");
            if (!content) {
              this.sendJson(res, 400, { error: "Content is required for knowledge document" });
              return;
            }

            const result = this.engine.uploadKnowledgeDocument({
              documentId: body.documentId,
              title,
              category: body.category,
              tags: body.tags,
              content,
            });
            this.monitor.recordInsert(result.chunkCount);
            this.sendJson(res, 201, result);
            return;
          }

          // Route: /api/knowledge (GET)
          if (pathname === "/api/knowledge" && method === "GET") {
            const docs = this.engine.listKnowledgeDocuments();
            this.sendJson(res, 200, { documents: docs });
            return;
          }

          // Route: /api/training/export (GET)
          if (pathname === "/api/training/export" && method === "GET") {
            const formatParam: string = requestUrl.searchParams.get("format") || "sharegpt";
            const format: TrainingExportFormat = formatParam === "openai" ? "openai" : "sharegpt";
            const limit: number = Number(requestUrl.searchParams.get("limit") || 1000);
            const domainFilter: string = requestUrl.searchParams.get("domain") || "";

            const exportResult = this.engine.exportTrainingDataset({
              format,
              limit,
              domainFilter: domainFilter || undefined,
            });

            const download: boolean = requestUrl.searchParams.get("download") === "true";
            if (download) {
              res.writeHead(200, {
                "Content-Type": "application/x-jsonlines",
                "Content-Disposition": `attachment; filename="training_dataset_${format}.jsonl"`,
              });
              res.end(exportResult.jsonlContent);
              return;
            }

            this.sendJson(res, 200, exportResult);
            return;
          }

          // 404 Route Not Found
          this.sendJson(res, 404, { error: `Route not found: ${method} ${pathname}` });
        } catch (error: unknown) {
          const message: string = error instanceof Error ? error.message : String(error);
          this.sendJson(res, 500, { error: "Internal Server Error", message });
        }
      }
    );

    return new Promise<void>((resolve: () => void, reject: (err: Error) => void): void => {
      this.server!.listen(this.config.port, this.config.host, (): void => {
        resolve();
      });
      this.server!.on("error", (err: Error): void => {
        reject(err);
      });
    });
  }

  public async stop(): Promise<void> {
    if (!this.server) {
      return;
    }
    return new Promise<void>((resolve: () => void, reject: (err?: Error) => void): void => {
      this.server!.close((err?: Error): void => {
        this.server = null;
        if (err) {
          reject(err);
        } else {
          resolve();
        }
      });
    });
  }

  private sendJson(res: http.ServerResponse, statusCode: number, payload: unknown): void {
    res.writeHead(statusCode, { "Content-Type": "application/json; charset=utf-8" });
    res.end(JSON.stringify(payload));
  }

  private readJsonBody(req: http.IncomingMessage): Promise<Record<string, unknown>> {
    return new Promise<Record<string, unknown>>((resolve: (data: Record<string, unknown>) => void, reject: (err: Error) => void): void => {
      const chunks: Buffer[] = [];
      req.on("data", (chunk: Buffer): void => {
        chunks.push(chunk);
      });
      req.on("end", (): void => {
        try {
          const bodyStr: string = Buffer.concat(chunks).toString("utf-8");
          if (!bodyStr || bodyStr.trim().length === 0) {
            resolve({});
            return;
          }
          const parsed = JSON.parse(bodyStr);
          resolve(parsed && typeof parsed === "object" ? parsed : {});
        } catch (err: unknown) {
          reject(new Error(`Failed to parse JSON body: ${String(err)}`));
        }
      });
      req.on("error", (err: Error): void => {
        reject(err);
      });
    });
  }
}
