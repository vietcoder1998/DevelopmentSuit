import http from "node:http";
import crypto from "node:crypto";
import { VectorDbEngine } from "../engine/vector-db-engine";
import { VectorPerformanceMonitor } from "../monitor/vector-performance-monitor";

export interface VectorSocketServerConfig {
  readonly host: string;
  readonly port: number;
}

export const DEFAULT_VECTOR_SOCKET_HOST: string = process.env.LOCAL_VECTOR_SOCKET_HOST || "0.0.0.0";
export const DEFAULT_VECTOR_SOCKET_PORT: number = Number(process.env.LOCAL_VECTOR_SOCKET_PORT || 3121);

export class VectorSocketServer {
  private server: http.Server | null = null;
  private readonly config: VectorSocketServerConfig;
  private readonly engine: VectorDbEngine;
  private readonly monitor: VectorPerformanceMonitor;
  private readonly clients: Set<any> = new Set<any>();
  private telemetryInterval: NodeJS.Timeout | null = null;

  public constructor(
    config?: Partial<VectorSocketServerConfig>,
    customEngine?: VectorDbEngine,
    customMonitor?: VectorPerformanceMonitor
  ) {
    this.config = {
      host: config?.host || DEFAULT_VECTOR_SOCKET_HOST,
      port: config?.port || DEFAULT_VECTOR_SOCKET_PORT,
    };
    this.engine = customEngine || new VectorDbEngine();
    this.monitor = customMonitor || new VectorPerformanceMonitor(this.engine);
  }

  public async start(): Promise<void> {
    if (this.server) {
      return;
    }

    this.server = http.createServer((req: http.IncomingMessage, res: http.ServerResponse): void => {
      res.writeHead(200, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ service: "VectorSocketServer", status: "listening", clients: this.clients.size }));
    });

    // Handle WebSocket Upgrade
    this.server.on("upgrade", (req, socket, head): void => {
      const upgradeHeader: string = req.headers["upgrade"] || "";
      if (upgradeHeader.toLowerCase() !== "websocket") {
        socket.destroy();
        return;
      }

      const key: string = req.headers["sec-websocket-key"] || "";
      const acceptKey: string = crypto
        .createHash("sha1")
        .update(key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11")
        .digest("base64");

      const responseHeaders: string[] = [
        "HTTP/1.1 101 Switching Protocols",
        "Upgrade: websocket",
        "Connection: Upgrade",
        `Sec-WebSocket-Accept: ${acceptKey}`,
      ];

      socket.write(responseHeaders.join("\r\n") + "\r\n\r\n");
      this.clients.add(socket);

      // Send initial welcome & telemetry
      this.sendSocketMessage(socket, {
        type: "welcome",
        server: "LocalVectorServer",
        timestamp: Date.now(),
        telemetry: this.monitor.getTelemetry(),
      });

      socket.on("data", (buffer: Buffer): void => {
        try {
          const payload = this.decodeWebSocketFrame(buffer);
          if (payload) {
            this.handleClientMessage(socket, payload);
          }
        } catch {
          // ignore malformed frame
        }
      });

      socket.on("close", (): void => {
        this.clients.delete(socket);
      });

      socket.on("error", (): void => {
        this.clients.delete(socket);
      });
    });

    // Telemetry tick every 3 seconds
    this.telemetryInterval = setInterval((): void => {
      if (this.clients.size > 0) {
        this.broadcast({
          type: "telemetry",
          telemetry: this.monitor.getTelemetry(),
        });
      }
    }, 3000);

    return new Promise<void>((resolve: () => void, reject: (err: Error) => void): void => {
      this.server!.listen(this.config.port, this.config.host, (): void => {
        resolve();
      });
      this.server!.on("error", (err: Error): void => {
        reject(err);
      });
    });
  }

  public async stop(): Promise<void> {
    if (this.telemetryInterval) {
      clearInterval(this.telemetryInterval);
      this.telemetryInterval = null;
    }
    for (const client of this.clients) {
      try {
        client.destroy();
      } catch {
        // ignore
      }
    }
    this.clients.clear();

    if (!this.server) {
      return;
    }
    return new Promise<void>((resolve: () => void, reject: (err?: Error) => void): void => {
      this.server!.close((err?: Error): void => {
        this.server = null;
        if (err) {
          reject(err);
        } else {
          resolve();
        }
      });
    });
  }

  public broadcast(message: Record<string, unknown>): void {
    for (const client of this.clients) {
      this.sendSocketMessage(client, message);
    }
  }

  private handleClientMessage(socket: any, rawMessage: string): void {
    try {
      const data = JSON.parse(rawMessage);
      if (data.type === "ping") {
        this.sendSocketMessage(socket, { type: "pong", timestamp: Date.now() });
      } else if (data.type === "search") {
        const matches = this.engine.searchVectors({
          collectionName: data.collection || "conversations_vectors",
          queryText: data.queryText,
          topK: data.topK || 5,
        });
        this.sendSocketMessage(socket, {
          type: "search_result",
          queryId: data.queryId,
          matches,
        });
      } else if (data.type === "upload_turn") {
        if (data.conversationId && data.message) {
          const result = this.engine.uploadConversation({
            conversationId: data.conversationId,
            title: data.title,
            messages: [data.message],
          });
          this.sendSocketMessage(socket, {
            type: "turn_indexed",
            result,
          });
        }
      }
    } catch {
      // ignore
    }
  }

  private sendSocketMessage(socket: any, message: Record<string, unknown>): void {
    try {
      const jsonStr: string = JSON.stringify(message);
      const frame: Buffer = this.encodeWebSocketFrame(jsonStr);
      socket.write(frame);
    } catch {
      this.clients.delete(socket);
    }
  }

  private encodeWebSocketFrame(text: string): Buffer {
    const payload: Buffer = Buffer.from(text, "utf-8");
    const length: number = payload.length;
    let header: Buffer;

    if (length <= 125) {
      header = Buffer.alloc(2);
      header[0] = 0x81; // FIN + text opcode
      header[1] = length;
    } else if (length <= 65535) {
      header = Buffer.alloc(4);
      header[0] = 0x81;
      header[1] = 126;
      header.writeUInt16BE(length, 2);
    } else {
      header = Buffer.alloc(10);
      header[0] = 0x81;
      header[1] = 127;
      header.writeBigUInt64BE(BigInt(length), 2);
    }

    return Buffer.concat([header, payload]);
  }

  private decodeWebSocketFrame(buffer: Buffer): string | null {
    if (buffer.length < 2) {
      return null;
    }

    const secondByte: number = buffer[1];
    const isMasked: boolean = (secondByte & 0x80) !== 0;
    let payloadLength: number = secondByte & 0x7f;
    let offset: number = 2;

    if (payloadLength === 126) {
      if (buffer.length < 4) return null;
      payloadLength = buffer.readUInt16BE(2);
      offset = 4;
    } else if (payloadLength === 127) {
      if (buffer.length < 10) return null;
      payloadLength = Number(buffer.readBigUInt64BE(2));
      offset = 10;
    }

    let maskingKey: Buffer | null = null;
    if (isMasked) {
      if (buffer.length < offset + 4) return null;
      maskingKey = buffer.subarray(offset, offset + 4);
      offset += 4;
    }

    const payload: Buffer = buffer.subarray(offset, offset + payloadLength);
    if (isMasked && maskingKey) {
      for (let i = 0; i < payload.length; i++) {
        payload[i] ^= maskingKey[i % 4];
      }
    }

    return payload.toString("utf-8");
  }
}
