import { VectorHttpServer, DEFAULT_VECTOR_HTTP_HOST, DEFAULT_VECTOR_HTTP_PORT } from "./sources/server/http-server";
import { VectorGrpcServer, DEFAULT_VECTOR_GRPC_HOST, DEFAULT_VECTOR_GRPC_PORT } from "./sources/server/grpc-server";
import { VectorSocketServer, DEFAULT_VECTOR_SOCKET_HOST, DEFAULT_VECTOR_SOCKET_PORT } from "./sources/server/socket-server";
import { VectorDbEngine } from "./sources/engine/vector-db-engine";
import { VectorPerformanceMonitor } from "./sources/monitor/vector-performance-monitor";

export interface VectorServerBundle {
  engine: VectorDbEngine;
  monitor: VectorPerformanceMonitor;
  httpServer: VectorHttpServer;
  grpcServer: VectorGrpcServer;
  socketServer: VectorSocketServer;
}

let activeVectorServers: VectorServerBundle | null = null;

export async function startLocalVectorServer(options?: {
  httpHost?: string;
  httpPort?: number;
  grpcHost?: string;
  grpcPort?: number;
  socketHost?: string;
  socketPort?: number;
}): Promise<VectorServerBundle> {
  if (activeVectorServers) {
    return activeVectorServers;
  }

  // 1. Shared Engine and Monitor instances
  const engine: VectorDbEngine = new VectorDbEngine();
  const monitor: VectorPerformanceMonitor = new VectorPerformanceMonitor(engine);

  // 2. Start HTTP REST Server
  const httpServer: VectorHttpServer = new VectorHttpServer(
    {
      host: options?.httpHost || DEFAULT_VECTOR_HTTP_HOST,
      port: options?.httpPort || DEFAULT_VECTOR_HTTP_PORT,
    },
    engine,
    monitor
  );
  await httpServer.start();

  // 3. Start gRPC Server
  const grpcServer: VectorGrpcServer = new VectorGrpcServer(
    {
      host: options?.grpcHost || DEFAULT_VECTOR_GRPC_HOST,
      port: options?.grpcPort || DEFAULT_VECTOR_GRPC_PORT,
    },
    engine,
    monitor
  );

  try {
    await grpcServer.start();
  } catch (grpcErr: unknown) {
    console.warn(`[LocalVectorServer] gRPC server startup warning: ${String(grpcErr)}`);
  }

  // 4. Start WebSocket Server
  const socketServer: VectorSocketServer = new VectorSocketServer(
    {
      host: options?.socketHost || DEFAULT_VECTOR_SOCKET_HOST,
      port: options?.socketPort || DEFAULT_VECTOR_SOCKET_PORT,
    },
    engine,
    monitor
  );

  try {
    await socketServer.start();
  } catch (socketErr: unknown) {
    console.warn(`[LocalVectorServer] Socket server startup warning: ${String(socketErr)}`);
  }

  activeVectorServers = {
    engine,
    monitor,
    httpServer,
    grpcServer,
    socketServer,
  };

  console.log(
    `[LocalVectorServer] Started successfully:\n` +
    `  - HTTP REST: http://${options?.httpHost || DEFAULT_VECTOR_HTTP_HOST}:${options?.httpPort || DEFAULT_VECTOR_HTTP_PORT}\n` +
    `  - gRPC RPC:  ${options?.grpcHost || DEFAULT_VECTOR_GRPC_HOST}:${options?.grpcPort || DEFAULT_VECTOR_GRPC_PORT}\n` +
    `  - WebSocket: ws://${options?.socketHost || DEFAULT_VECTOR_SOCKET_HOST}:${options?.socketPort || DEFAULT_VECTOR_SOCKET_PORT}`
  );

  return activeVectorServers;
}

export async function stopLocalVectorServer(): Promise<void> {
  if (!activeVectorServers) {
    return;
  }

  try {
    await activeVectorServers.httpServer.stop();
  } catch {
    // Ignore
  }

  try {
    await activeVectorServers.grpcServer.stop();
  } catch {
    // Ignore
  }

  try {
    await activeVectorServers.socketServer.stop();
  } catch {
    // Ignore
  }

  activeVectorServers = null;
  console.log("[LocalVectorServer] Stopped successfully.");
}

// Auto-start when executed directly via tsx or node
const isDirectRun: boolean =
  typeof require !== "undefined"
    ? require.main === module
    : Boolean(process.argv[1]?.endsWith("server.ts") || process.argv[1]?.endsWith("server.js"));

if (isDirectRun) {
  startLocalVectorServer().catch((err: unknown): void => {
    console.error("[LocalVectorServer] Fatal startup error:", err);
    process.exit(1);
  });

  const handleShutdown: () => Promise<void> = async (): Promise<void> => {
    await stopLocalVectorServer();
    process.exit(0);
  };

  process.on("SIGINT", handleShutdown);
  process.on("SIGTERM", handleShutdown);

  process.on("uncaughtException", (err: Error): void => {
    console.error("[LocalVectorServer] Uncaught exception:", err);
  });
  process.on("unhandledRejection", (reason: unknown): void => {
    console.error("[LocalVectorServer] Unhandled rejection:", reason);
  });
}
