"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// packages/LocalVectorServer/server.ts
var server_exports = {};
__export(server_exports, {
  startLocalVectorServer: () => startLocalVectorServer,
  stopLocalVectorServer: () => stopLocalVectorServer
});
module.exports = __toCommonJS(server_exports);

// packages/LocalVectorServer/sources/server/http-server.ts
var import_node_http = __toESM(require("node:http"));
var import_node_url = require("node:url");

// packages/LocalVectorServer/sources/engine/vector-db-engine.ts
var import_node_fs = __toESM(require("node:fs"));
var import_node_path = __toESM(require("node:path"));
var import_node_os = __toESM(require("node:os"));

// packages/LocalVectorServer/sources/engine/vector-math.ts
var VectorMath = class _VectorMath {
  static dotProduct(vectorA, vectorB) {
    const dimension = Math.min(vectorA.length, vectorB.length);
    let dot = 0;
    for (let index = 0; index < dimension; index++) {
      dot += vectorA[index] * vectorB[index];
    }
    return dot;
  }
  static magnitude(vector) {
    let sumOfSquares = 0;
    for (let index = 0; index < vector.length; index++) {
      sumOfSquares += vector[index] * vector[index];
    }
    return Math.sqrt(sumOfSquares);
  }
  static cosineSimilarity(vectorA, vectorB) {
    const magnitudeA = _VectorMath.magnitude(vectorA);
    const magnitudeB = _VectorMath.magnitude(vectorB);
    if (magnitudeA === 0 || magnitudeB === 0) {
      return 0;
    }
    const dot = _VectorMath.dotProduct(vectorA, vectorB);
    const similarity = dot / (magnitudeA * magnitudeB);
    return Math.max(-1, Math.min(1, similarity));
  }
  static euclideanDistance(vectorA, vectorB) {
    const dimension = Math.min(vectorA.length, vectorB.length);
    let sumOfSquaredDifferences = 0;
    for (let index = 0; index < dimension; index++) {
      const difference = vectorA[index] - vectorB[index];
      sumOfSquaredDifferences += difference * difference;
    }
    return Math.sqrt(sumOfSquaredDifferences);
  }
  static normalize(vector) {
    const mag = _VectorMath.magnitude(vector);
    if (mag === 0) {
      return new Array(vector.length).fill(0);
    }
    const normalized = new Array(vector.length);
    for (let index = 0; index < vector.length; index++) {
      normalized[index] = vector[index] / mag;
    }
    return normalized;
  }
};

// packages/LocalVectorServer/sources/engine/embedding-generator.ts
var LocalEmbeddingGenerator = class {
  defaultDimension;
  constructor(dimension = 128) {
    this.defaultDimension = dimension;
  }
  getDimension() {
    return this.defaultDimension;
  }
  /**
   * Generates a dense, normalized vector representation for input text
   * using token hashing and n-gram subword frequency distributions.
   */
  generate(text, targetDimension) {
    const dimension = targetDimension || this.defaultDimension;
    const vector = new Array(dimension).fill(0);
    if (!text || text.trim().length === 0) {
      return vector;
    }
    const normalizedText = text.toLowerCase().trim();
    const tokens = normalizedText.split(/[\s,.;:!?()[\]{}"'`/\\]+/).filter(Boolean);
    for (let tokenIndex = 0; tokenIndex < tokens.length; tokenIndex++) {
      const token = tokens[tokenIndex];
      const hashVal = this.hashString(token);
      const bucketIndex = Math.abs(hashVal) % dimension;
      const sign = (hashVal & 1) === 0 ? 1 : -1;
      vector[bucketIndex] += sign * (1 + Math.log(1 + token.length));
      if (token.length >= 3) {
        for (let charIndex = 0; charIndex <= token.length - 3; charIndex++) {
          const triGram = token.substring(charIndex, charIndex + 3);
          const triHash = this.hashString(triGram);
          const triBucket = Math.abs(triHash) % dimension;
          const triSign = (triHash & 1) === 0 ? 0.5 : -0.5;
          vector[triBucket] += triSign;
        }
      }
    }
    for (let index = 0; index < tokens.length - 1; index++) {
      const bigram = `${tokens[index]}_${tokens[index + 1]}`;
      const biHash = this.hashString(bigram);
      const biBucket = Math.abs(biHash) % dimension;
      const biSign = (biHash & 1) === 0 ? 0.75 : -0.75;
      vector[biBucket] += biSign;
    }
    return VectorMath.normalize(vector);
  }
  hashString(input) {
    let hash = 5381;
    for (let index = 0; index < input.length; index++) {
      hash = (hash << 5) + hash + input.charCodeAt(index);
      hash = hash & hash;
    }
    return hash;
  }
};

// packages/LocalVectorServer/sources/engine/vector-db-engine.ts
var VectorDbEngine = class {
  collections = /* @__PURE__ */ new Map();
  conversations = /* @__PURE__ */ new Map();
  knowledgeDocs = /* @__PURE__ */ new Map();
  embeddingGenerator;
  storageDir;
  isPersisting = false;
  constructor(storageDirectory, defaultDimension = 128) {
    this.embeddingGenerator = new LocalEmbeddingGenerator(defaultDimension);
    const baseDir = storageDirectory || process.env.VECTOR_STORAGE_PATH || import_node_path.default.join(import_node_os.default.homedir(), ".2tek", "vector_storage");
    this.storageDir = baseDir;
    this.ensureStorageDirectory();
    this.initializeDefaultCollections();
    this.loadFromDisk();
  }
  getStorageDirectory() {
    return this.storageDir;
  }
  getEmbeddingGenerator() {
    return this.embeddingGenerator;
  }
  ensureStorageDirectory() {
    if (!import_node_fs.default.existsSync(this.storageDir)) {
      try {
        import_node_fs.default.mkdirSync(this.storageDir, { recursive: true });
      } catch {
      }
    }
  }
  initializeDefaultCollections() {
    if (!this.collections.has("default")) {
      const defCol = this.createCollection("default", 128, "cosine");
      if (defCol.records.size === 0) {
        this.insertVectors("default", [
          {
            id: "vec-default-001",
            text: "Initial seed embedding for general semantic similarity search and vector indexing.",
            metadata: { title: "General Seed", category: "system", snippet: "Initial seed embedding for general semantic similarity search and vector indexing." }
          },
          {
            id: "vec-default-002",
            text: "System telemetry and vector operational benchmarks across node endpoints.",
            metadata: { title: "Telemetry Seed", category: "benchmark", snippet: "System telemetry and vector operational benchmarks across node endpoints." }
          }
        ]);
      }
    }
    if (!this.collections.has("conversations_vectors")) {
      const convCol = this.createCollection("conversations_vectors", 128, "cosine");
      if (convCol.records.size === 0) {
        this.insertVectors("conversations_vectors", [
          {
            id: "vec-conv-001-turn-0",
            text: "Can you explain how HNSW vector indexing works in local databases?",
            metadata: {
              conversationId: "conv-seed-01",
              title: "HNSW Vector Indexing",
              role: "user",
              contentSnippet: "Can you explain how HNSW vector indexing works in local databases?",
              turnIndex: 0
            }
          },
          {
            id: "vec-conv-001-turn-1",
            text: "HNSW builds hierarchical graphs with logarithmic search complexity for nearest neighbor queries.",
            metadata: {
              conversationId: "conv-seed-01",
              title: "HNSW Vector Indexing",
              role: "assistant",
              contentSnippet: "HNSW builds hierarchical graphs with logarithmic search complexity for nearest neighbor queries.",
              turnIndex: 1
            }
          }
        ]);
      }
    }
    if (!this.collections.has("knowledge_vectors")) {
      const kbCol = this.createCollection("knowledge_vectors", 128, "cosine");
      if (kbCol.records.size === 0) {
        this.insertVectors("knowledge_vectors", [
          {
            id: "vec-kb-001-chunk-0",
            text: "Vector databases index high-dimensional embeddings for approximate nearest neighbor search.",
            metadata: {
              documentId: "kb-seed-01",
              title: "Vector Architecture",
              category: "architecture",
              chunkIndex: 0,
              snippet: "Vector databases index high-dimensional embeddings for approximate nearest neighbor search."
            }
          },
          {
            id: "vec-kb-001-chunk-1",
            text: "Cosine similarity measures the orientation between vectors to evaluate semantic similarity.",
            metadata: {
              documentId: "kb-seed-01",
              title: "Vector Architecture",
              category: "metrics",
              chunkIndex: 1,
              snippet: "Cosine similarity measures the orientation between vectors to evaluate semantic similarity."
            }
          }
        ]);
      }
    }
  }
  createCollection(name, dimension = 128, metric = "cosine") {
    if (this.collections.has(name)) {
      return this.collections.get(name);
    }
    const collection = {
      name,
      dimension,
      metric,
      createdAt: Date.now(),
      records: /* @__PURE__ */ new Map()
    };
    this.collections.set(name, collection);
    this.scheduleSave();
    return collection;
  }
  getCollection(name) {
    return this.collections.get(name);
  }
  listCollections() {
    const list = [];
    for (const [name, col] of this.collections.entries()) {
      list.push({
        name,
        dimension: col.dimension,
        metric: col.metric,
        vectorCount: col.records.size,
        createdAt: col.createdAt
      });
    }
    return list;
  }
  getCollectionRecords(collectionName, limit = 100, offset = 0) {
    const col = this.collections.get(collectionName);
    if (!col) {
      return { collection: collectionName, total: 0, records: [] };
    }
    const allRecords = Array.from(col.records.values());
    const total = allRecords.length;
    const paged = allRecords.slice(offset, offset + limit);
    return {
      collection: collectionName,
      total,
      records: paged.map((rec) => {
        const text = rec.metadata.contentSnippet || rec.metadata.snippet || rec.metadata.text || rec.metadata.content || rec.metadata.title || `Vector embedding ${rec.id} (${rec.values.length} dimensions)`;
        return {
          id: rec.id,
          values: rec.values,
          metadata: rec.metadata,
          createdAt: rec.createdAt,
          text
        };
      })
    };
  }
  deleteCollection(name) {
    if (name === "default" || name === "conversations_vectors" || name === "knowledge_vectors") {
      const col = this.collections.get(name);
      if (col) {
        col.records.clear();
        this.scheduleSave();
        return true;
      }
      return false;
    }
    const deleted = this.collections.delete(name);
    if (deleted) {
      this.scheduleSave();
    }
    return deleted;
  }
  insertVectors(collectionName, vectors) {
    let col = this.collections.get(collectionName);
    if (!col) {
      col = this.createCollection(collectionName);
    }
    let insertedCount = 0;
    const now = Date.now();
    for (let index = 0; index < vectors.length; index++) {
      const item = vectors[index];
      let values;
      if (item.values && item.values.length > 0) {
        values = item.values;
      } else if (item.text) {
        values = this.embeddingGenerator.generate(item.text, col.dimension);
      } else {
        values = new Array(col.dimension).fill(0);
      }
      const record = {
        id: item.id,
        values,
        metadata: item.metadata || {},
        createdAt: now
      };
      col.records.set(item.id, record);
      insertedCount++;
    }
    this.scheduleSave();
    return { insertedCount, success: true };
  }
  searchVectors(params) {
    const col = this.collections.get(params.collectionName);
    if (!col) {
      return [];
    }
    let queryVector;
    if (params.queryVector && params.queryVector.length > 0) {
      queryVector = params.queryVector;
    } else if (params.queryText) {
      queryVector = this.embeddingGenerator.generate(params.queryText, col.dimension);
    } else {
      return [];
    }
    const topK = params.topK && params.topK > 0 ? params.topK : 10;
    const minScore = params.minScore !== void 0 ? params.minScore : -1;
    const matches = [];
    for (const record of col.records.values()) {
      if (params.filter) {
        let matchesFilter = true;
        for (const [key, value] of Object.entries(params.filter)) {
          if (record.metadata[key] !== value) {
            matchesFilter = false;
            break;
          }
        }
        if (!matchesFilter) {
          continue;
        }
      }
      let score = 0;
      if (col.metric === "cosine") {
        score = VectorMath.cosineSimilarity(queryVector, record.values);
      } else if (col.metric === "dot") {
        score = VectorMath.dotProduct(queryVector, record.values);
      } else if (col.metric === "euclidean") {
        const dist = VectorMath.euclideanDistance(queryVector, record.values);
        score = 1 / (1 + dist);
      }
      if (score >= minScore) {
        matches.push({
          id: record.id,
          score,
          values: record.values,
          metadata: record.metadata
        });
      }
    }
    matches.sort((a, b) => b.score - a.score);
    return matches.slice(0, topK);
  }
  uploadConversation(conversation) {
    const convId = conversation.conversationId || `conv-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
    const title = conversation.title || (conversation.messages.length > 0 ? conversation.messages[0].content.substring(0, 50) : "Untitled Conversation");
    const nowIso = (/* @__PURE__ */ new Date()).toISOString();
    const parsedMessages = [];
    const vectorRecordsToInsert = [];
    for (let index = 0; index < conversation.messages.length; index++) {
      const msg = conversation.messages[index];
      const msgId = msg.id || `${convId}-turn-${index}`;
      const turnVectorId = `vec-${msgId}`;
      const vectorValues = this.embeddingGenerator.generate(msg.content, 128);
      parsedMessages.push({
        id: msgId,
        role: msg.role,
        content: msg.content,
        timestamp: msg.timestamp || nowIso,
        vectorId: turnVectorId
      });
      vectorRecordsToInsert.push({
        id: turnVectorId,
        values: vectorValues,
        metadata: {
          conversationId: convId,
          title,
          messageId: msgId,
          role: msg.role,
          contentSnippet: msg.content.substring(0, 150),
          turnIndex: index,
          ...conversation.metadata || {}
        }
      });
    }
    const doc = {
      conversationId: convId,
      title,
      createdAt: nowIso,
      updatedAt: nowIso,
      metadata: conversation.metadata || {},
      messages: parsedMessages
    };
    this.conversations.set(convId, doc);
    this.insertVectors("conversations_vectors", vectorRecordsToInsert);
    this.scheduleSave();
    return {
      conversationId: convId,
      turnsIndexed: parsedMessages.length,
      success: true
    };
  }
  getConversation(id) {
    return this.conversations.get(id);
  }
  listConversations() {
    return Array.from(this.conversations.values());
  }
  getRelatedConversations(params) {
    const searchMatches = this.searchVectors({
      collectionName: "conversations_vectors",
      queryText: params.queryText,
      queryVector: params.queryVector,
      topK: (params.topK || 5) * 2
    });
    const relatedMap = /* @__PURE__ */ new Map();
    for (let index = 0; index < searchMatches.length; index++) {
      const match = searchMatches[index];
      const convId = String(match.metadata.conversationId || "");
      if (!convId || params.excludeConversationId && convId === params.excludeConversationId) {
        continue;
      }
      if (!relatedMap.has(convId) || relatedMap.get(convId).score < match.score) {
        relatedMap.set(convId, {
          conversationId: convId,
          title: String(match.metadata.title || "Conversation"),
          messageId: String(match.metadata.messageId || match.id),
          role: String(match.metadata.role || "user"),
          snippet: String(match.metadata.contentSnippet || ""),
          score: match.score,
          timestamp: (/* @__PURE__ */ new Date()).toISOString()
        });
      }
      if (relatedMap.size >= (params.topK || 5)) {
        break;
      }
    }
    return Array.from(relatedMap.values()).sort(
      (a, b) => b.score - a.score
    );
  }
  uploadKnowledgeDocument(doc) {
    const docId = doc.documentId || `kb-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
    const nowIso = (/* @__PURE__ */ new Date()).toISOString();
    const rawChunks = doc.content.split(/\n\s*\n/).map((c) => c.trim()).filter((c) => c.length > 0);
    const chunkItems = [];
    const vectorRecordsToInsert = [];
    for (let index = 0; index < rawChunks.length; index++) {
      const chunkText = rawChunks[index];
      const chunkVectorId = `vec-kb-${docId}-${index}`;
      const values = this.embeddingGenerator.generate(chunkText, 128);
      chunkItems.push({
        chunkIndex: index,
        text: chunkText,
        vectorId: chunkVectorId
      });
      vectorRecordsToInsert.push({
        id: chunkVectorId,
        values,
        metadata: {
          documentId: docId,
          title: doc.title,
          category: doc.category || "general",
          chunkIndex: index,
          snippet: chunkText.substring(0, 150)
        }
      });
    }
    const knowledgeDoc = {
      documentId: docId,
      title: doc.title,
      category: doc.category || "general",
      tags: doc.tags || [],
      content: doc.content,
      createdAt: nowIso,
      chunks: chunkItems
    };
    this.knowledgeDocs.set(docId, knowledgeDoc);
    this.insertVectors("knowledge_vectors", vectorRecordsToInsert);
    this.scheduleSave();
    return {
      documentId: docId,
      chunkCount: chunkItems.length,
      success: true
    };
  }
  listKnowledgeDocuments() {
    return Array.from(this.knowledgeDocs.values());
  }
  exportTrainingDataset(params) {
    const format = params.format === "sharegpt" ? "sharegpt" : "openai";
    const limit = params.limit && params.limit > 0 ? params.limit : 1e3;
    const lines = [];
    let count = 0;
    for (const conv of this.conversations.values()) {
      if (params.domainFilter && conv.metadata.domain !== params.domainFilter) {
        continue;
      }
      if (conv.messages.length === 0) {
        continue;
      }
      if (format === "openai") {
        const messagesPayload = conv.messages.map(
          (m) => ({
            role: m.role,
            content: m.content
          })
        );
        lines.push(JSON.stringify({ messages: messagesPayload }));
      } else {
        const conversationsPayload = conv.messages.map(
          (m) => ({
            from: m.role === "assistant" ? "gpt" : m.role === "system" ? "system" : "human",
            value: m.content
          })
        );
        lines.push(JSON.stringify({ conversations: conversationsPayload }));
      }
      count++;
      if (count >= limit) {
        break;
      }
    }
    return {
      format,
      recordCount: count,
      jsonlContent: lines.join("\n")
    };
  }
  getStats() {
    let totalVectors = 0;
    for (const col of this.collections.values()) {
      totalVectors += col.records.size;
    }
    return {
      collectionsCount: this.collections.size,
      totalVectorsCount: totalVectors,
      totalConversations: this.conversations.size,
      totalKnowledgeDocs: this.knowledgeDocs.size
    };
  }
  scheduleSave() {
    if (this.isPersisting) {
      return;
    }
    this.isPersisting = true;
    setTimeout(() => {
      this.saveToDisk();
      this.isPersisting = false;
    }, 100);
  }
  saveToDisk() {
    try {
      this.ensureStorageDirectory();
      const collectionsExport = {};
      for (const [name, col] of this.collections.entries()) {
        const recordsExport = {};
        for (const [id, rec] of col.records.entries()) {
          recordsExport[id] = rec;
        }
        collectionsExport[name] = {
          name: col.name,
          dimension: col.dimension,
          metric: col.metric,
          createdAt: col.createdAt,
          records: recordsExport
        };
      }
      import_node_fs.default.writeFileSync(
        import_node_path.default.join(this.storageDir, "collections.json"),
        JSON.stringify(collectionsExport, null, 2),
        "utf-8"
      );
      const convExport = {};
      for (const [id, doc] of this.conversations.entries()) {
        convExport[id] = doc;
      }
      import_node_fs.default.writeFileSync(
        import_node_path.default.join(this.storageDir, "conversations.json"),
        JSON.stringify(convExport, null, 2),
        "utf-8"
      );
      const kbExport = {};
      for (const [id, doc] of this.knowledgeDocs.entries()) {
        kbExport[id] = doc;
      }
      import_node_fs.default.writeFileSync(
        import_node_path.default.join(this.storageDir, "knowledge.json"),
        JSON.stringify(kbExport, null, 2),
        "utf-8"
      );
    } catch {
    }
  }
  loadFromDisk() {
    try {
      const collectionsFile = import_node_path.default.join(this.storageDir, "collections.json");
      if (import_node_fs.default.existsSync(collectionsFile)) {
        const rawContent = import_node_fs.default.readFileSync(collectionsFile, "utf-8");
        const parsed = JSON.parse(rawContent);
        for (const [name, colData] of Object.entries(parsed)) {
          const col = {
            name: colData.name,
            dimension: colData.dimension,
            metric: colData.metric,
            createdAt: colData.createdAt,
            records: /* @__PURE__ */ new Map()
          };
          if (colData.records) {
            for (const [recId, rec] of Object.entries(colData.records)) {
              col.records.set(recId, rec);
            }
          }
          this.collections.set(name, col);
        }
      }
      const convFile = import_node_path.default.join(this.storageDir, "conversations.json");
      if (import_node_fs.default.existsSync(convFile)) {
        const rawContent = import_node_fs.default.readFileSync(convFile, "utf-8");
        const parsed = JSON.parse(rawContent);
        for (const [id, doc] of Object.entries(parsed)) {
          this.conversations.set(id, doc);
        }
      }
      const kbFile = import_node_path.default.join(this.storageDir, "knowledge.json");
      if (import_node_fs.default.existsSync(kbFile)) {
        const rawContent = import_node_fs.default.readFileSync(kbFile, "utf-8");
        const parsed = JSON.parse(rawContent);
        for (const [id, doc] of Object.entries(parsed)) {
          this.knowledgeDocs.set(id, doc);
        }
      }
    } catch {
    }
  }
};

// packages/LocalVectorServer/sources/monitor/vector-performance-monitor.ts
var VectorPerformanceMonitor = class {
  startTime = Date.now();
  totalQueriesCount = 0;
  totalInsertsCount = 0;
  latenciesSum = 0;
  latenciesCount = 0;
  engine;
  constructor(engine) {
    this.engine = engine;
  }
  recordQuery(latencyMs) {
    this.totalQueriesCount++;
    this.latenciesSum += latencyMs;
    this.latenciesCount++;
  }
  recordInsert(count = 1) {
    this.totalInsertsCount += count;
  }
  getTelemetry() {
    const uptimeSeconds = Math.floor((Date.now() - this.startTime) / 1e3);
    const stats = this.engine.getStats();
    const averageLatency = this.latenciesCount > 0 ? Number((this.latenciesSum / this.latenciesCount).toFixed(3)) : 0;
    const memoryUsage = process.memoryUsage();
    return {
      uptimeSeconds,
      totalQueries: this.totalQueriesCount,
      totalInserts: this.totalInsertsCount,
      collectionsCount: stats.collectionsCount,
      totalVectorsCount: stats.totalVectorsCount,
      totalConversations: stats.totalConversations,
      totalKnowledgeDocs: stats.totalKnowledgeDocs,
      averageSearchLatencyMs: averageLatency,
      memoryHeapUsedBytes: memoryUsage.heapUsed
    };
  }
  resetMetrics() {
    this.totalQueriesCount = 0;
    this.totalInsertsCount = 0;
    this.latenciesSum = 0;
    this.latenciesCount = 0;
  }
};

// packages/LocalVectorServer/sources/server/http-server.ts
var DEFAULT_VECTOR_HTTP_HOST = process.env.LOCAL_VECTOR_HOST || "0.0.0.0";
var DEFAULT_VECTOR_HTTP_PORT = Number(process.env.LOCAL_VECTOR_HTTP_PORT || 3120);
var VectorHttpServer = class {
  server = null;
  config;
  engine;
  monitor;
  constructor(config, customEngine, customMonitor) {
    this.config = {
      host: config?.host || DEFAULT_VECTOR_HTTP_HOST,
      port: config?.port || DEFAULT_VECTOR_HTTP_PORT
    };
    this.engine = customEngine || new VectorDbEngine();
    this.monitor = customMonitor || new VectorPerformanceMonitor(this.engine);
  }
  getEngine() {
    return this.engine;
  }
  getMonitor() {
    return this.monitor;
  }
  async start() {
    if (this.server) {
      return;
    }
    this.server = import_node_http.default.createServer(
      async (req, res) => {
        res.setHeader("Access-Control-Allow-Origin", "*");
        res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
        res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Requested-With");
        if (req.method === "OPTIONS") {
          res.writeHead(204);
          res.end();
          return;
        }
        const requestUrl = new import_node_url.URL(req.url || "/", `http://${req.headers.host || "localhost"}`);
        const pathname = requestUrl.pathname;
        const method = req.method || "GET";
        const startTime = Date.now();
        try {
          if (pathname === "/health" && method === "GET") {
            this.sendJson(res, 200, {
              status: "ok",
              name: "LocalVectorServer",
              version: "1.0.0",
              timestamp: Date.now()
            });
            return;
          }
          if (pathname === "/api/status" && method === "GET") {
            const stats = this.engine.getStats();
            const telemetry = this.monitor.getTelemetry();
            this.sendJson(res, 200, {
              status: "online",
              version: "1.0.0",
              stats,
              telemetry,
              collections: this.engine.listCollections()
            });
            return;
          }
          if (pathname === "/api/metrics" && method === "GET") {
            const telemetry = this.monitor.getTelemetry();
            this.sendJson(res, 200, telemetry);
            return;
          }
          if (pathname === "/api/collections" && method === "GET") {
            const collections = this.engine.listCollections();
            this.sendJson(res, 200, { collections });
            return;
          }
          const isRecordsRoute = pathname.startsWith("/api/collections/") && pathname.endsWith("/records") || pathname === "/api/collections/records" || pathname === "/api/vectors";
          if (isRecordsRoute && method === "GET") {
            let collectionName = requestUrl.searchParams.get("collection") || requestUrl.searchParams.get("name") || "";
            if (!collectionName && pathname.startsWith("/api/collections/")) {
              const parts = pathname.split("/").filter(Boolean);
              if (parts.length >= 3 && parts[0] === "api" && parts[1] === "collections") {
                collectionName = decodeURIComponent(parts[2]);
              }
            }
            if (!collectionName) {
              collectionName = "default";
            }
            const limit = Number(requestUrl.searchParams.get("limit") || 100);
            const offset = Number(requestUrl.searchParams.get("offset") || 0);
            const data = this.engine.getCollectionRecords(collectionName, limit, offset);
            this.sendJson(res, 200, data);
            return;
          }
          if ((pathname === "/api/collections" || pathname === "/api/collections/create") && method === "POST") {
            const body = await this.readJsonBody(req);
            const name = String(body.name || "");
            if (!name) {
              this.sendJson(res, 400, { error: "Collection name is required" });
              return;
            }
            const dimension = Number(body.dimension || 128);
            const metric = body.metric === "euclidean" || body.metric === "dot" ? body.metric : "cosine";
            const col = this.engine.createCollection(name, dimension, metric);
            this.sendJson(res, 201, {
              name: col.name,
              dimension: col.dimension,
              metric: col.metric,
              createdAt: col.createdAt
            });
            return;
          }
          if (pathname === "/api/vectors/insert" && method === "POST") {
            const body = await this.readJsonBody(req);
            const collection = String(body.collection || "default");
            const vectors = Array.isArray(body.vectors) ? body.vectors : [];
            const result = this.engine.insertVectors(collection, vectors);
            this.monitor.recordInsert(result.insertedCount);
            this.sendJson(res, 200, result);
            return;
          }
          if (pathname === "/api/vectors/search" && method === "POST") {
            const body = await this.readJsonBody(req);
            const collectionName = String(body.collection || "default");
            const topK = Number(body.topK || 10);
            const minScore = Number(body.minScore || -1);
            const queryVector = Array.isArray(body.queryVector) ? body.queryVector : void 0;
            const queryText = body.queryText ? String(body.queryText) : void 0;
            const filter = body.filter && typeof body.filter === "object" ? body.filter : void 0;
            const matches = this.engine.searchVectors({
              collectionName,
              queryVector,
              queryText,
              topK,
              minScore,
              filter
            });
            const latencyMs = Date.now() - startTime;
            this.monitor.recordQuery(latencyMs);
            this.sendJson(res, 200, {
              collection: collectionName,
              topK,
              matches,
              latencyMs
            });
            return;
          }
          if (pathname === "/api/conversations/upload" && method === "POST") {
            const body = await this.readJsonBody(req);
            const conversation = body.conversation || body;
            if (!conversation.messages || !Array.isArray(conversation.messages)) {
              this.sendJson(res, 400, { error: "Invalid conversation structure: messages array required" });
              return;
            }
            const result = this.engine.uploadConversation(conversation);
            this.monitor.recordInsert(result.turnsIndexed);
            this.sendJson(res, 201, result);
            return;
          }
          if (pathname === "/api/conversations" && method === "GET") {
            const list = this.engine.listConversations();
            this.sendJson(res, 200, { conversations: list });
            return;
          }
          if ((pathname === "/api/conversations/related" || pathname === "/api/conversations/search") && (method === "GET" || method === "POST")) {
            let queryText = "";
            let topK = 5;
            if (method === "GET") {
              queryText = requestUrl.searchParams.get("query") || requestUrl.searchParams.get("q") || "";
              topK = Number(requestUrl.searchParams.get("topK") || 5);
            } else {
              const body = await this.readJsonBody(req);
              queryText = String(body.queryText || body.query || "");
              topK = Number(body.topK || 5);
            }
            const related = this.engine.getRelatedConversations({ queryText, topK });
            const latencyMs = Date.now() - startTime;
            this.monitor.recordQuery(latencyMs);
            this.sendJson(res, 200, {
              queryText,
              topK,
              related,
              latencyMs
            });
            return;
          }
          if (pathname === "/api/knowledge/upload" && method === "POST") {
            const body = await this.readJsonBody(req);
            const title = String(body.title || "Untitled Document");
            const content = String(body.content || "");
            if (!content) {
              this.sendJson(res, 400, { error: "Content is required for knowledge document" });
              return;
            }
            const result = this.engine.uploadKnowledgeDocument({
              documentId: body.documentId,
              title,
              category: body.category,
              tags: body.tags,
              content
            });
            this.monitor.recordInsert(result.chunkCount);
            this.sendJson(res, 201, result);
            return;
          }
          if (pathname === "/api/knowledge" && method === "GET") {
            const docs = this.engine.listKnowledgeDocuments();
            this.sendJson(res, 200, { documents: docs });
            return;
          }
          if (pathname === "/api/training/export" && method === "GET") {
            const formatParam = requestUrl.searchParams.get("format") || "sharegpt";
            const format = formatParam === "openai" ? "openai" : "sharegpt";
            const limit = Number(requestUrl.searchParams.get("limit") || 1e3);
            const domainFilter = requestUrl.searchParams.get("domain") || "";
            const exportResult = this.engine.exportTrainingDataset({
              format,
              limit,
              domainFilter: domainFilter || void 0
            });
            const download = requestUrl.searchParams.get("download") === "true";
            if (download) {
              res.writeHead(200, {
                "Content-Type": "application/x-jsonlines",
                "Content-Disposition": `attachment; filename="training_dataset_${format}.jsonl"`
              });
              res.end(exportResult.jsonlContent);
              return;
            }
            this.sendJson(res, 200, exportResult);
            return;
          }
          this.sendJson(res, 404, { error: `Route not found: ${method} ${pathname}` });
        } catch (error) {
          const message = error instanceof Error ? error.message : String(error);
          this.sendJson(res, 500, { error: "Internal Server Error", message });
        }
      }
    );
    return new Promise((resolve, reject) => {
      this.server.listen(this.config.port, this.config.host, () => {
        resolve();
      });
      this.server.on("error", (err) => {
        reject(err);
      });
    });
  }
  async stop() {
    if (!this.server) {
      return;
    }
    return new Promise((resolve, reject) => {
      this.server.close((err) => {
        this.server = null;
        if (err) {
          reject(err);
        } else {
          resolve();
        }
      });
    });
  }
  sendJson(res, statusCode, payload) {
    res.writeHead(statusCode, { "Content-Type": "application/json; charset=utf-8" });
    res.end(JSON.stringify(payload));
  }
  readJsonBody(req) {
    return new Promise((resolve, reject) => {
      const chunks = [];
      req.on("data", (chunk) => {
        chunks.push(chunk);
      });
      req.on("end", () => {
        try {
          const bodyStr = Buffer.concat(chunks).toString("utf-8");
          if (!bodyStr || bodyStr.trim().length === 0) {
            resolve({});
            return;
          }
          const parsed = JSON.parse(bodyStr);
          resolve(parsed && typeof parsed === "object" ? parsed : {});
        } catch (err) {
          reject(new Error(`Failed to parse JSON body: ${String(err)}`));
        }
      });
      req.on("error", (err) => {
        reject(err);
      });
    });
  }
};

// packages/LocalVectorServer/sources/server/grpc-server.ts
var grpc = __toESM(require("@grpc/grpc-js"));
var protoLoader = __toESM(require("@grpc/proto-loader"));
var import_node_fs2 = __toESM(require("node:fs"));
var import_node_path2 = __toESM(require("node:path"));
var import_node_process = __toESM(require("node:process"));
var DEFAULT_VECTOR_GRPC_HOST = import_node_process.default.env.LOCAL_VECTOR_GRPC_HOST || "0.0.0.0";
var DEFAULT_VECTOR_GRPC_PORT = Number(import_node_process.default.env.LOCAL_VECTOR_GRPC_PORT || 50056);
var VectorGrpcServer = class {
  server = null;
  config;
  engine;
  monitor;
  isRunning = false;
  constructor(config, customEngine, customMonitor) {
    this.config = {
      host: config?.host || DEFAULT_VECTOR_GRPC_HOST,
      port: config?.port || DEFAULT_VECTOR_GRPC_PORT
    };
    this.engine = customEngine || new VectorDbEngine();
    this.monitor = customMonitor || new VectorPerformanceMonitor(this.engine);
  }
  resolveProtoFilePath() {
    const candidatePaths = [
      import_node_path2.default.resolve(__dirname, "../../proto/vector.proto"),
      import_node_path2.default.resolve(import_node_process.default.cwd(), "proto/vector.proto"),
      import_node_path2.default.resolve(import_node_process.default.cwd(), "packages/LocalVectorServer/proto/vector.proto")
    ];
    for (const cand of candidatePaths) {
      if (import_node_fs2.default.existsSync(cand)) {
        return cand;
      }
    }
    return candidatePaths[0];
  }
  async start() {
    if (this.isRunning && this.server) {
      return;
    }
    const protoPath = this.resolveProtoFilePath();
    if (!import_node_fs2.default.existsSync(protoPath)) {
      throw new Error(`Vector Proto file not found at: ${protoPath}`);
    }
    const packageDefinition = protoLoader.loadSync(protoPath, {
      keepCase: true,
      longs: String,
      enums: String,
      defaults: true,
      oneofs: true
    });
    const grpcObject = grpc.loadPackageDefinition(packageDefinition);
    const vtek = grpcObject.vtek;
    const vector = vtek.vector;
    const grpcPkg = vector.grpc;
    if (!grpcPkg || !grpcPkg.VectorService) {
      throw new Error("Failed to load vtek.vector.grpc.VectorService from proto definition");
    }
    this.server = new grpc.Server();
    this.server.addService(grpcPkg.VectorService.service, {
      Ping: this.handlePing.bind(this),
      InsertVectors: this.handleInsertVectors.bind(this),
      SearchVectors: this.handleSearchVectors.bind(this),
      UploadConversation: this.handleUploadConversation.bind(this),
      GetRelatedConversations: this.handleGetRelatedConversations.bind(this),
      ExportTrainingData: this.handleExportTrainingData.bind(this),
      GetPerformanceMetrics: this.handleGetPerformanceMetrics.bind(this)
    });
    const bindAddress = `${this.config.host}:${this.config.port}`;
    return new Promise((resolve, reject) => {
      this.server.bindAsync(
        bindAddress,
        grpc.ServerCredentials.createInsecure(),
        (err, port) => {
          if (err) {
            reject(err);
            return;
          }
          if (port === 0) {
            reject(new Error(`Failed to bind VectorService on ${bindAddress}: Port already in use`));
            return;
          }
          this.isRunning = true;
          resolve();
        }
      );
    });
  }
  async stop() {
    if (!this.server || !this.isRunning) {
      return;
    }
    return new Promise((resolve) => {
      this.server.tryShutdown(() => {
        this.server = null;
        this.isRunning = false;
        resolve();
      });
    });
  }
  handlePing(call, callback) {
    const stats = this.engine.getStats();
    callback(null, {
      status: "ok",
      server_version: "1.0.0",
      server_time: Date.now(),
      collections_count: stats.collectionsCount,
      total_vectors_count: stats.totalVectorsCount
    });
  }
  handleInsertVectors(call, callback) {
    try {
      const collection = call.request.collection || "default";
      const rawVectors = call.request.vectors || [];
      const parsedVectors = rawVectors.map((item) => {
        let metadata = {};
        if (item.metadata_json) {
          try {
            metadata = JSON.parse(item.metadata_json);
          } catch {
            metadata = {};
          }
        }
        return {
          id: item.id,
          values: item.values,
          metadata
        };
      });
      const result = this.engine.insertVectors(collection, parsedVectors);
      this.monitor.recordInsert(result.insertedCount);
      callback(null, {
        success: true,
        inserted_count: result.insertedCount,
        message: `Successfully inserted ${result.insertedCount} vectors`
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      callback({
        code: grpc.status.INTERNAL,
        message: msg,
        name: "VectorInsertError"
      });
    }
  }
  handleSearchVectors(call, callback) {
    const startTime = Date.now();
    try {
      const collection = call.request.collection || "default";
      let filter;
      if (call.request.filter_json) {
        try {
          filter = JSON.parse(call.request.filter_json);
        } catch {
          filter = void 0;
        }
      }
      const results = this.engine.searchVectors({
        collectionName: collection,
        queryVector: call.request.query_vector && call.request.query_vector.length > 0 ? call.request.query_vector : void 0,
        queryText: call.request.query_text,
        topK: call.request.top_k || 10,
        minScore: call.request.min_score !== void 0 ? call.request.min_score : -1,
        filter
      });
      const latencyMs = Date.now() - startTime;
      this.monitor.recordQuery(latencyMs);
      const matches = results.map((r) => ({
        id: r.id,
        score: r.score,
        values: r.values || [],
        metadata_json: JSON.stringify(r.metadata)
      }));
      callback(null, {
        collection,
        matches,
        duration_microseconds: latencyMs * 1e3
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      callback({
        code: grpc.status.INTERNAL,
        message: msg,
        name: "VectorSearchError"
      });
    }
  }
  handleUploadConversation(call, callback) {
    try {
      let metadata = {};
      if (call.request.metadata_json) {
        try {
          metadata = JSON.parse(call.request.metadata_json);
        } catch {
          metadata = {};
        }
      }
      const rawMessages = call.request.messages || [];
      const messages = rawMessages.map((m) => ({
        id: m.id,
        role: m.role || "user",
        content: m.content || "",
        timestamp: m.timestamp
      }));
      const result = this.engine.uploadConversation({
        conversationId: call.request.conversation_id,
        title: call.request.title,
        metadata,
        messages
      });
      this.monitor.recordInsert(result.turnsIndexed);
      callback(null, {
        success: true,
        conversation_id: result.conversationId,
        turns_indexed: result.turnsIndexed,
        timestamp: Date.now()
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      callback({
        code: grpc.status.INTERNAL,
        message: msg,
        name: "ConversationUploadError"
      });
    }
  }
  handleGetRelatedConversations(call, callback) {
    const startTime = Date.now();
    try {
      const related = this.engine.getRelatedConversations({
        queryText: call.request.query_text,
        queryVector: call.request.query_vector && call.request.query_vector.length > 0 ? call.request.query_vector : void 0,
        topK: call.request.top_k || 5
      });
      const latencyMs = Date.now() - startTime;
      this.monitor.recordQuery(latencyMs);
      callback(null, {
        related: related.map((r) => ({
          conversation_id: r.conversationId,
          title: r.title,
          message_id: r.messageId,
          role: r.role,
          snippet: r.snippet,
          score: r.score
        })),
        duration_microseconds: latencyMs * 1e3
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      callback({
        code: grpc.status.INTERNAL,
        message: msg,
        name: "GetRelatedConversationsError"
      });
    }
  }
  handleExportTrainingData(call, callback) {
    try {
      const format = call.request.format === "openai" ? "openai" : "sharegpt";
      const result = this.engine.exportTrainingDataset({
        format,
        limit: call.request.limit || 1e3,
        domainFilter: call.request.domain_filter || void 0
      });
      callback(null, {
        format: result.format,
        record_count: result.recordCount,
        jsonl_content: result.jsonlContent
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      callback({
        code: grpc.status.INTERNAL,
        message: msg,
        name: "ExportTrainingError"
      });
    }
  }
  handleGetPerformanceMetrics(call, callback) {
    const telemetry = this.monitor.getTelemetry();
    callback(null, {
      uptime_seconds: telemetry.uptimeSeconds,
      total_queries: telemetry.totalQueries,
      total_inserts: telemetry.totalInserts,
      collections_count: telemetry.collectionsCount,
      total_vectors_count: telemetry.totalVectorsCount,
      total_conversations: telemetry.totalConversations,
      average_search_latency_ms: telemetry.averageSearchLatencyMs,
      memory_heap_used_bytes: telemetry.memoryHeapUsedBytes
    });
  }
};

// packages/LocalVectorServer/sources/server/socket-server.ts
var import_node_http2 = __toESM(require("node:http"));
var import_node_crypto = __toESM(require("node:crypto"));
var DEFAULT_VECTOR_SOCKET_HOST = process.env.LOCAL_VECTOR_SOCKET_HOST || "0.0.0.0";
var DEFAULT_VECTOR_SOCKET_PORT = Number(process.env.LOCAL_VECTOR_SOCKET_PORT || 3121);
var VectorSocketServer = class {
  server = null;
  config;
  engine;
  monitor;
  clients = /* @__PURE__ */ new Set();
  telemetryInterval = null;
  constructor(config, customEngine, customMonitor) {
    this.config = {
      host: config?.host || DEFAULT_VECTOR_SOCKET_HOST,
      port: config?.port || DEFAULT_VECTOR_SOCKET_PORT
    };
    this.engine = customEngine || new VectorDbEngine();
    this.monitor = customMonitor || new VectorPerformanceMonitor(this.engine);
  }
  async start() {
    if (this.server) {
      return;
    }
    this.server = import_node_http2.default.createServer((req, res) => {
      res.writeHead(200, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ service: "VectorSocketServer", status: "listening", clients: this.clients.size }));
    });
    this.server.on("upgrade", (req, socket, head) => {
      const upgradeHeader = req.headers["upgrade"] || "";
      if (upgradeHeader.toLowerCase() !== "websocket") {
        socket.destroy();
        return;
      }
      const key = req.headers["sec-websocket-key"] || "";
      const acceptKey = import_node_crypto.default.createHash("sha1").update(key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").digest("base64");
      const responseHeaders = [
        "HTTP/1.1 101 Switching Protocols",
        "Upgrade: websocket",
        "Connection: Upgrade",
        `Sec-WebSocket-Accept: ${acceptKey}`
      ];
      socket.write(responseHeaders.join("\r\n") + "\r\n\r\n");
      this.clients.add(socket);
      this.sendSocketMessage(socket, {
        type: "welcome",
        server: "LocalVectorServer",
        timestamp: Date.now(),
        telemetry: this.monitor.getTelemetry()
      });
      socket.on("data", (buffer) => {
        try {
          const payload = this.decodeWebSocketFrame(buffer);
          if (payload) {
            this.handleClientMessage(socket, payload);
          }
        } catch {
        }
      });
      socket.on("close", () => {
        this.clients.delete(socket);
      });
      socket.on("error", () => {
        this.clients.delete(socket);
      });
    });
    this.telemetryInterval = setInterval(() => {
      if (this.clients.size > 0) {
        this.broadcast({
          type: "telemetry",
          telemetry: this.monitor.getTelemetry()
        });
      }
    }, 3e3);
    return new Promise((resolve, reject) => {
      this.server.listen(this.config.port, this.config.host, () => {
        resolve();
      });
      this.server.on("error", (err) => {
        reject(err);
      });
    });
  }
  async stop() {
    if (this.telemetryInterval) {
      clearInterval(this.telemetryInterval);
      this.telemetryInterval = null;
    }
    for (const client of this.clients) {
      try {
        client.destroy();
      } catch {
      }
    }
    this.clients.clear();
    if (!this.server) {
      return;
    }
    return new Promise((resolve, reject) => {
      this.server.close((err) => {
        this.server = null;
        if (err) {
          reject(err);
        } else {
          resolve();
        }
      });
    });
  }
  broadcast(message) {
    for (const client of this.clients) {
      this.sendSocketMessage(client, message);
    }
  }
  handleClientMessage(socket, rawMessage) {
    try {
      const data = JSON.parse(rawMessage);
      if (data.type === "ping") {
        this.sendSocketMessage(socket, { type: "pong", timestamp: Date.now() });
      } else if (data.type === "search") {
        const matches = this.engine.searchVectors({
          collectionName: data.collection || "conversations_vectors",
          queryText: data.queryText,
          topK: data.topK || 5
        });
        this.sendSocketMessage(socket, {
          type: "search_result",
          queryId: data.queryId,
          matches
        });
      } else if (data.type === "upload_turn") {
        if (data.conversationId && data.message) {
          const result = this.engine.uploadConversation({
            conversationId: data.conversationId,
            title: data.title,
            messages: [data.message]
          });
          this.sendSocketMessage(socket, {
            type: "turn_indexed",
            result
          });
        }
      }
    } catch {
    }
  }
  sendSocketMessage(socket, message) {
    try {
      const jsonStr = JSON.stringify(message);
      const frame = this.encodeWebSocketFrame(jsonStr);
      socket.write(frame);
    } catch {
      this.clients.delete(socket);
    }
  }
  encodeWebSocketFrame(text) {
    const payload = Buffer.from(text, "utf-8");
    const length = payload.length;
    let header;
    if (length <= 125) {
      header = Buffer.alloc(2);
      header[0] = 129;
      header[1] = length;
    } else if (length <= 65535) {
      header = Buffer.alloc(4);
      header[0] = 129;
      header[1] = 126;
      header.writeUInt16BE(length, 2);
    } else {
      header = Buffer.alloc(10);
      header[0] = 129;
      header[1] = 127;
      header.writeBigUInt64BE(BigInt(length), 2);
    }
    return Buffer.concat([header, payload]);
  }
  decodeWebSocketFrame(buffer) {
    if (buffer.length < 2) {
      return null;
    }
    const secondByte = buffer[1];
    const isMasked = (secondByte & 128) !== 0;
    let payloadLength = secondByte & 127;
    let offset = 2;
    if (payloadLength === 126) {
      if (buffer.length < 4) return null;
      payloadLength = buffer.readUInt16BE(2);
      offset = 4;
    } else if (payloadLength === 127) {
      if (buffer.length < 10) return null;
      payloadLength = Number(buffer.readBigUInt64BE(2));
      offset = 10;
    }
    let maskingKey = null;
    if (isMasked) {
      if (buffer.length < offset + 4) return null;
      maskingKey = buffer.subarray(offset, offset + 4);
      offset += 4;
    }
    const payload = buffer.subarray(offset, offset + payloadLength);
    if (isMasked && maskingKey) {
      for (let i = 0; i < payload.length; i++) {
        payload[i] ^= maskingKey[i % 4];
      }
    }
    return payload.toString("utf-8");
  }
};

// packages/LocalVectorServer/server.ts
var activeVectorServers = null;
async function startLocalVectorServer(options) {
  if (activeVectorServers) {
    return activeVectorServers;
  }
  const engine = new VectorDbEngine();
  const monitor = new VectorPerformanceMonitor(engine);
  const httpServer = new VectorHttpServer(
    {
      host: options?.httpHost || DEFAULT_VECTOR_HTTP_HOST,
      port: options?.httpPort || DEFAULT_VECTOR_HTTP_PORT
    },
    engine,
    monitor
  );
  await httpServer.start();
  const grpcServer = new VectorGrpcServer(
    {
      host: options?.grpcHost || DEFAULT_VECTOR_GRPC_HOST,
      port: options?.grpcPort || DEFAULT_VECTOR_GRPC_PORT
    },
    engine,
    monitor
  );
  try {
    await grpcServer.start();
  } catch (grpcErr) {
    console.warn(`[LocalVectorServer] gRPC server startup warning: ${String(grpcErr)}`);
  }
  const socketServer = new VectorSocketServer(
    {
      host: options?.socketHost || DEFAULT_VECTOR_SOCKET_HOST,
      port: options?.socketPort || DEFAULT_VECTOR_SOCKET_PORT
    },
    engine,
    monitor
  );
  try {
    await socketServer.start();
  } catch (socketErr) {
    console.warn(`[LocalVectorServer] Socket server startup warning: ${String(socketErr)}`);
  }
  activeVectorServers = {
    engine,
    monitor,
    httpServer,
    grpcServer,
    socketServer
  };
  console.log(
    `[LocalVectorServer] Started successfully:
  - HTTP REST: http://${options?.httpHost || DEFAULT_VECTOR_HTTP_HOST}:${options?.httpPort || DEFAULT_VECTOR_HTTP_PORT}
  - gRPC RPC:  ${options?.grpcHost || DEFAULT_VECTOR_GRPC_HOST}:${options?.grpcPort || DEFAULT_VECTOR_GRPC_PORT}
  - WebSocket: ws://${options?.socketHost || DEFAULT_VECTOR_SOCKET_HOST}:${options?.socketPort || DEFAULT_VECTOR_SOCKET_PORT}`
  );
  return activeVectorServers;
}
async function stopLocalVectorServer() {
  if (!activeVectorServers) {
    return;
  }
  try {
    await activeVectorServers.httpServer.stop();
  } catch {
  }
  try {
    await activeVectorServers.grpcServer.stop();
  } catch {
  }
  try {
    await activeVectorServers.socketServer.stop();
  } catch {
  }
  activeVectorServers = null;
  console.log("[LocalVectorServer] Stopped successfully.");
}
var isDirectRun = typeof require !== "undefined" ? require.main === module : Boolean(process.argv[1]?.endsWith("server.ts") || process.argv[1]?.endsWith("server.js"));
if (isDirectRun) {
  startLocalVectorServer().catch((err) => {
    console.error("[LocalVectorServer] Fatal startup error:", err);
    process.exit(1);
  });
  const handleShutdown = async () => {
    await stopLocalVectorServer();
    process.exit(0);
  };
  process.on("SIGINT", handleShutdown);
  process.on("SIGTERM", handleShutdown);
  process.on("uncaughtException", (err) => {
    console.error("[LocalVectorServer] Uncaught exception:", err);
  });
  process.on("unhandledRejection", (reason) => {
    console.error("[LocalVectorServer] Unhandled rejection:", reason);
  });
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  startLocalVectorServer,
  stopLocalVectorServer
});
