/**
 * packages/LocalSQLServer/server.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * LocalSQLServer Process Launcher
 * Runs high-performance SQL database services across Local, LAN, HTTP, and gRPC.
 * ─────────────────────────────────────────────────────────────────────────────
 */

import fs from "node:fs";
import path from "node:path";
import Module from "node:module";

// Ensure Node module resolution can discover workspace and app node_modules
const candidateNodeModulesPaths: string[] = [
  path.join(__dirname, "node_modules"),
  path.join(__dirname, "..", "node_modules"),
  path.join(__dirname, "..", "..", "node_modules"),
  path.join(__dirname, "..", "..", "..", "node_modules"),
  path.join(process.cwd(), "node_modules"),
  process.env.WORKSPACE_ROOT ? path.join(process.env.WORKSPACE_ROOT, "node_modules") : null,
].filter((p: string | null | undefined): p is string => typeof p === "string" && p.length > 0 && fs.existsSync(p));

if (candidateNodeModulesPaths.length > 0) {
  process.env.NODE_PATH = candidateNodeModulesPaths.join(path.delimiter);
  if (typeof (Module as unknown as { _initPaths?: () => void })._initPaths === "function") {
    (Module as unknown as { _initPaths: () => void })._initPaths();
  }
}

import { LocalSqlHttpServer, DEFAULT_HTTP_HOST, DEFAULT_HTTP_PORT } from "./sources/server/http-server";
import { LocalSqlGrpcServer, DEFAULT_GRPC_HOST, DEFAULT_GRPC_PORT } from "./sources/server/grpc-server";
import { lcLocalDbEngine, hydroelectricEngine } from "./sources/engine";

export interface ServerInstanceBundle {
  httpServer: LocalSqlHttpServer;
  grpcServer: LocalSqlGrpcServer;
}

let activeServers: ServerInstanceBundle | null = null;

export async function startLocalSqlServer(options?: {
  httpHost?: string;
  httpPort?: number;
  grpcHost?: string;
  grpcPort?: number;
}): Promise<ServerInstanceBundle> {
  if (activeServers) {
    return activeServers;
  }

  // 1. Initialize localdb engine
  lcLocalDbEngine.init();

  // 2. Start HTTP REST Server (Local & LAN)
  const httpServer: LocalSqlHttpServer = new LocalSqlHttpServer({
    host: options?.httpHost || DEFAULT_HTTP_HOST,
    port: options?.httpPort || DEFAULT_HTTP_PORT,
  });
  await httpServer.start();

  // 3. Start gRPC Server
  const grpcServer: LocalSqlGrpcServer = new LocalSqlGrpcServer({
    host: options?.grpcHost || DEFAULT_GRPC_HOST,
    port: options?.grpcPort || DEFAULT_GRPC_PORT,
  });

  try {
    await grpcServer.start();
  } catch (grpcErr: unknown) {
    console.warn(`[LocalSQLServer] gRPC server warning: ${String(grpcErr)}`);
  }

  activeServers = { httpServer, grpcServer };
  console.log(
    `[LocalSQLServer] Started successfully:\n` +
    `  - Local/LAN HTTP: http://${httpServer.getHost()}:${httpServer.getPort()}\n` +
    `  - gRPC Service:  ${grpcServer.getPort()}\n` +
    `  - Active DB:     ${lcLocalDbEngine.getCurrentDatabase()}`
  );

  return activeServers;
}

export async function stopLocalSqlServer(): Promise<void> {
  if (!activeServers) {
    return;
  }

  try {
    await activeServers.httpServer.stop();
  } catch {
    // Ignore http stop error
  }

  try {
    await activeServers.grpcServer.stop();
  } catch {
    // Ignore grpc stop error
  }

  activeServers = null;
  console.log("[LocalSQLServer] Stopped successfully.");
}

/**
 * Executes a CLI command or starts the server according to command line arguments.
 */
export async function runCli(argv: string[] = process.argv.slice(2)): Promise<void> {
  let httpPort: number = DEFAULT_HTTP_PORT;
  let httpHost: string = DEFAULT_HTTP_HOST;
  let grpcPort: number = DEFAULT_GRPC_PORT;
  let targetDatabase: string = "default";
  let outputJson: boolean = false;
  let command: string = "start";
  let sqlText: string = "";

  for (let i: number = 0; i < argv.length; i++) {
    const arg: string = argv[i];
    if (arg === "--help" || arg === "-h" || arg === "help") {
      printHelp();
      return;
    }
    if (arg === "--version" || arg === "-v" || arg === "version") {
      console.log("LocalSQLServer v1.0.2");
      return;
    }
    if (arg === "--json") {
      outputJson = true;
      continue;
    }
    if (arg === "--port" || arg === "-p") {
      const nextArg: string | undefined = argv[++i];
      if (nextArg) {
        httpPort = parseInt(nextArg, 10);
      }
      continue;
    }
    if (arg.startsWith("--port=")) {
      httpPort = parseInt(arg.split("=")[1], 10);
      continue;
    }
    if (arg === "--host") {
      const nextArg: string | undefined = argv[++i];
      if (nextArg) {
        httpHost = nextArg;
      }
      continue;
    }
    if (arg === "--grpc-port") {
      const nextArg: string | undefined = argv[++i];
      if (nextArg) {
        grpcPort = parseInt(nextArg, 10);
      }
      continue;
    }
    if (arg === "--db") {
      const nextArg: string | undefined = argv[++i];
      if (nextArg) {
        targetDatabase = nextArg;
      }
      continue;
    }
    if (!arg.startsWith("-")) {
      if (command === "start" && (arg === "status" || arg === "query" || arg === "tables" || arg === "databases" || arg === "hydroelectric" || arg === "stream" || arg === "start")) {
        command = arg;
      } else if (command === "query" && !sqlText) {
        sqlText = arg;
      }
    }
  }

  const effectiveHost: string = httpHost === "0.0.0.0" ? "127.0.0.1" : httpHost;
  const baseUrl: string = `http://${effectiveHost}:${httpPort}`;

  // 1. Status Command
  if (command === "status") {
    try {
      const response: Response = await fetch(`${baseUrl}/api/status`, { signal: AbortSignal.timeout(2000) });
      if (response.ok) {
        const data: unknown = await response.json();
        if (outputJson) {
          console.log(JSON.stringify(data, null, 2));
        } else {
          const statusObj: {
            activeDatabase?: string;
            databasesCount?: number;
            tablesCount?: number;
            metrics?: { uptimeSeconds?: number; totalQueries?: number; memoryHeapUsedBytes?: number };
          } = data as {
            activeDatabase?: string;
            databasesCount?: number;
            tablesCount?: number;
            metrics?: { uptimeSeconds?: number; totalQueries?: number; memoryHeapUsedBytes?: number };
          };
          console.log(`[LocalSQLServer] Status: ONLINE`);
          console.log(`  - URL:             ${baseUrl}`);
          console.log(`  - Active Database: ${statusObj.activeDatabase || "default"}`);
          console.log(`  - Databases Count: ${statusObj.databasesCount ?? 0}`);
          console.log(`  - Tables Count:    ${statusObj.tablesCount ?? 0}`);
          if (statusObj.metrics) {
            console.log(`  - Uptime:          ${statusObj.metrics.uptimeSeconds ?? 0}s`);
            console.log(`  - Total Queries:   ${statusObj.metrics.totalQueries ?? 0}`);
            const memMb: string = ((statusObj.metrics.memoryHeapUsedBytes || 0) / 1024 / 1024).toFixed(1);
            console.log(`  - Memory Used:     ${memMb} MB`);
          }
        }
        return;
      }
    } catch {
      // Server not reachable via HTTP, inspect local engine directly
    }

    lcLocalDbEngine.init();
    if (outputJson) {
      console.log(JSON.stringify({ status: "offline", activeDatabase: lcLocalDbEngine.getCurrentDatabase(), databases: lcLocalDbEngine.listDatabases() }, null, 2));
    } else {
      console.log(`[LocalSQLServer] Status: OFFLINE (HTTP server not reachable on ${baseUrl})`);
      console.log(`  - Active Database:   ${lcLocalDbEngine.getCurrentDatabase()}`);
      console.log(`  - Local Databases:   ${lcLocalDbEngine.listDatabases().join(", ") || "(none)"}`);
    }
    return;
  }

  // 2. Tables Command
  if (command === "tables") {
    try {
      const response: Response = await fetch(`${baseUrl}/api/tables?db=${targetDatabase}`, { signal: AbortSignal.timeout(2000) });
      if (response.ok) {
        const data: unknown = await response.json();
        if (outputJson) {
          console.log(JSON.stringify(data, null, 2));
        } else {
          const result: { tables?: Array<{ name: string; rowCount: number }> } = data as { tables?: Array<{ name: string; rowCount: number }> };
          console.log(`[LocalSQLServer] Tables in '${targetDatabase}':`);
          if (result.tables && result.tables.length > 0) {
            for (const tbl of result.tables) {
              console.log(`  • ${tbl.name} (${tbl.rowCount} rows)`);
            }
          } else {
            console.log("  (no tables found)");
          }
        }
        return;
      }
    } catch {
      // Fallback to local engine
    }

    lcLocalDbEngine.init();
    lcLocalDbEngine.useDatabase(targetDatabase);
    const tableNames: string[] = lcLocalDbEngine.getTableNames();
    if (outputJson) {
      console.log(JSON.stringify({ database: targetDatabase, tables: tableNames }, null, 2));
    } else {
      console.log(`[LocalSQLServer] Tables in '${targetDatabase}' (in-process):`);
      if (tableNames.length > 0) {
        for (const name of tableNames) {
          console.log(`  • ${name}`);
        }
      } else {
        console.log("  (no tables found)");
      }
    }
    return;
  }

  // 3. Databases Command
  if (command === "databases") {
    try {
      const response: Response = await fetch(`${baseUrl}/api/databases`, { signal: AbortSignal.timeout(2000) });
      if (response.ok) {
        const data: unknown = await response.json();
        if (outputJson) {
          console.log(JSON.stringify(data, null, 2));
        } else {
          const result: { databases?: string[]; current?: string } = data as { databases?: string[]; current?: string };
          console.log(`[LocalSQLServer] Databases:`);
          for (const db of (result.databases || [])) {
            const isCurrent: boolean = db === result.current;
            console.log(`  ${isCurrent ? "➔" : " "} ${db}${isCurrent ? " (active)" : ""}`);
          }
        }
        return;
      }
    } catch {
      // Fallback to local engine
    }

    lcLocalDbEngine.init();
    const dbs: string[] = lcLocalDbEngine.listDatabases();
    const currentDb: string = lcLocalDbEngine.getCurrentDatabase();
    if (outputJson) {
      console.log(JSON.stringify({ databases: dbs, current: currentDb }, null, 2));
    } else {
      console.log(`[LocalSQLServer] Databases (in-process):`);
      for (const db of dbs) {
        const isCurrent: boolean = db === currentDb;
        console.log(`  ${isCurrent ? "➔" : " "} ${db}${isCurrent ? " (active)" : ""}`);
      }
    }
    return;
  }

  // 4. Query Command
  if (command === "query") {
    if (!sqlText) {
      console.error("Error: SQL query text is required. Example: localsqlserver query 'SELECT 1'");
      process.exitCode = 1;
      return;
    }

    try {
      const response: Response = await fetch(`${baseUrl}/api/query`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sql: sqlText, database: targetDatabase }),
        signal: AbortSignal.timeout(5000),
      });

      if (response.ok) {
        const data: unknown = await response.json();
        if (outputJson) {
          console.log(JSON.stringify(data, null, 2));
        } else {
          const resObj: { success?: boolean; rows?: unknown[]; rowCount?: number; executionTimeMs?: number; error?: string } =
            data as { success?: boolean; rows?: unknown[]; rowCount?: number; executionTimeMs?: number; error?: string };
          if (resObj.success) {
            console.log(`[LocalSQLServer] Query executed in ${resObj.executionTimeMs?.toFixed(2) || 0}ms (${resObj.rowCount || 0} rows):`);
            console.log(JSON.stringify(resObj.rows || [], null, 2));
          } else {
            console.error(`[LocalSQLServer] Query error: ${resObj.error || "Unknown error"}`);
            process.exitCode = 1;
          }
        }
        return;
      }
    } catch {
      // Fallback to in-process execution
    }

    lcLocalDbEngine.init();
    lcLocalDbEngine.useDatabase(targetDatabase);
    try {
      const startTime: number = Date.now();
      const rows: unknown[] = lcLocalDbEngine.query(sqlText);
      const elapsedMs: number = Date.now() - startTime;
      if (outputJson) {
        console.log(JSON.stringify({ success: true, database: targetDatabase, rowCount: rows.length, rows, executionTimeMs: elapsedMs }, null, 2));
      } else {
        console.log(`[LocalSQLServer] In-process query executed in ${elapsedMs}ms (${rows.length} rows):`);
        console.log(JSON.stringify(rows, null, 2));
      }
    } catch (queryErr: unknown) {
      const errorMsg: string = queryErr instanceof Error ? queryErr.message : String(queryErr);
      console.error(`[LocalSQLServer] In-process query error: ${errorMsg}`);
      process.exitCode = 1;
    }
    return;
  }

  // 5. Hydroelectric Command
  if (command === "hydroelectric" || command === "stream") {
    try {
      const response: Response = await fetch(`${baseUrl}/api/hydroelectric/status`, { signal: AbortSignal.timeout(2000) });
      if (response.ok) {
        const data: unknown = await response.json();
        if (outputJson) {
          console.log(JSON.stringify(data, null, 2));
        } else {
          const resObj: {
            config?: { mode?: string; timeComplexity?: string; spaceComplexity?: string; largeFileThresholdBytes?: number };
            metrics?: { totalStreamsExecuted?: number; totalGigabytesStreamed?: number; currentHeapUsedMb?: number };
          } = data as {
            config?: { mode?: string; timeComplexity?: string; spaceComplexity?: string; largeFileThresholdBytes?: number };
            metrics?: { totalStreamsExecuted?: number; totalGigabytesStreamed?: number; currentHeapUsedMb?: number };
          };
          console.log(`[LocalSQLServer] HydroelectricEngine: ACTIVE`);
          console.log(`  - Mode:               ${resObj.config?.mode || "STREAMING_PIPELINE"}`);
          console.log(`  - Time Complexity:    ${resObj.config?.timeComplexity || "O(n)"}`);
          console.log(`  - Space Complexity:   ${resObj.config?.spaceComplexity || "O(1)"}`);
          console.log(`  - Large File Barrier: ${(Number(resObj.config?.largeFileThresholdBytes || 0) / 1024 / 1024).toFixed(0)} MB (> 10 GB safe streaming)`);
          console.log(`  - Total Streams:      ${resObj.metrics?.totalStreamsExecuted || 0}`);
          console.log(`  - Total Streamed:     ${resObj.metrics?.totalGigabytesStreamed || 0} GB`);
          console.log(`  - Heap Usage:         ${resObj.metrics?.currentHeapUsedMb || 0} MB`);
        }
        return;
      }
    } catch {
      // Fallback to in-process engine
    }

    const metrics = hydroelectricEngine.getMetrics();
    const config = hydroelectricEngine.getConfig();
    if (outputJson) {
      console.log(JSON.stringify({ config, metrics }, null, 2));
    } else {
      console.log(`[LocalSQLServer] HydroelectricEngine (Local In-Process): ACTIVE`);
      console.log(`  - Mode:               ${config.mode}`);
      console.log(`  - Time Complexity:    ${config.timeComplexity}`);
      console.log(`  - Space Complexity:   ${config.spaceComplexity}`);
      console.log(`  - Large File Barrier: ${(config.largeFileThresholdBytes / 1024 / 1024).toFixed(0)} MB (> 10 GB safe streaming)`);
      console.log(`  - Total Streams:      ${metrics.totalStreamsExecuted}`);
      console.log(`  - Total Streamed:     ${metrics.totalGigabytesStreamed} GB`);
      console.log(`  - Heap Usage:         ${metrics.currentHeapUsedMb} MB`);
    }
    return;
  }

  // 6. Start Server (Default)
  await startLocalSqlServer({
    httpHost,
    httpPort,
    grpcHost: "0.0.0.0",
    grpcPort,
  });

  const handleShutdown = async (): Promise<void> => {
    await stopLocalSqlServer();
    process.exit(0);
  };

  process.on("SIGINT", handleShutdown);
  process.on("SIGTERM", handleShutdown);
}

function printHelp(): void {
  console.log(`
LocalSQLServer — High-performance Local & LAN Database Engine

Usage:
  localsqlserver [command] [options]

Commands:
  start                  Start HTTP REST and gRPC servers (default)
  status                 Check server status and connectivity
  query <sql>            Execute SQL query on database
  tables                 List tables in active database
  databases              List available databases
  hydroelectric, stream  Inspect Hydroelectric streaming engine status & metrics
  version, -v            Show version information
  help, -h               Show this help message

Options:
  --port, -p <port>      HTTP port (default: 3110)
  --host <host>          HTTP host (default: 0.0.0.0)
  --grpc-port <port>     gRPC port (default: 50055)
  --db <name>            Database name (default: default)
  --json                 Output raw JSON
`);
}

// Auto-start when executed directly via tsx or node
const isDirectRun: boolean =
  typeof require !== "undefined"
    ? require.main === module
    : process.argv[1]?.endsWith("server.ts") || process.argv[1]?.endsWith("server.js") || false;

if (isDirectRun) {
  runCli().catch((err: unknown): void => {
    console.error("[LocalSQLServer] Fatal CLI error:", err);
    process.exit(1);
  });

  process.on("uncaughtException", (err: Error): void => {
    console.error("[LocalSQLServer] Uncaught exception:", err);
  });
  process.on("unhandledRejection", (reason: unknown): void => {
    console.error("[LocalSQLServer] Unhandled rejection:", reason);
  });
}
