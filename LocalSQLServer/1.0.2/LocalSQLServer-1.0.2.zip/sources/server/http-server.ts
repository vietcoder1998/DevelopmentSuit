/**
 * packages/LocalSQLServer/sources/server/http-server.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * High-performance HTTP/REST server for LocalSQLServer
 * Runs on Local and LAN interfaces (0.0.0.0) with low latency JSON endpoints.
 * ─────────────────────────────────────────────────────────────────────────────
 */

import http from "node:http";
import fs from "node:fs";
import { URL } from "node:url";
import {
  lcLocalDbEngine,
  LcLocalDbEngine,
  type LcLocalDbRecord,
  hydroelectricEngine,
  type HydroelectricStreamResult,
  type HydroelectricMetrics,
} from "../engine";
import { lcPerformanceMonitor, type ServerPerformanceMetrics } from "../monitor/lc-performance-monitor";

export interface HttpServerConfig {
  readonly host: string;
  readonly port: number;
}

export const DEFAULT_HTTP_HOST: string = process.env.LOCAL_SQL_HOST || "0.0.0.0";
export const DEFAULT_HTTP_PORT: number = Number(process.env.LOCAL_SQL_HTTP_PORT || 3110);

export class LocalSqlHttpServer {
  private server: http.Server | null = null;
  private readonly config: HttpServerConfig;
  private readonly engine: LcLocalDbEngine;

  public constructor(config?: Partial<HttpServerConfig>, customEngine?: LcLocalDbEngine) {
    this.config = {
      host: config?.host || DEFAULT_HTTP_HOST,
      port: config?.port !== undefined ? config.port : DEFAULT_HTTP_PORT,
    };
    this.engine = customEngine || lcLocalDbEngine;
  }

  public async start(): Promise<void> {
    if (this.server) {
      return;
    }

    this.server = http.createServer(
      async (req: http.IncomingMessage, res: http.ServerResponse): Promise<void> => {
        lcPerformanceMonitor.trackHttpConnectionChange(1);
        res.on("finish", (): void => {
          lcPerformanceMonitor.trackHttpConnectionChange(-1);
        });

        // Set CORS headers for browser clients (LAN & Local)
        res.setHeader("Access-Control-Allow-Origin", "*");
        res.setHeader(
          "Access-Control-Allow-Methods",
          "GET, POST, PUT, DELETE, OPTIONS"
        );
        res.setHeader(
          "Access-Control-Allow-Headers",
          "Content-Type, Authorization, X-Requested-With"
        );

        if (req.method === "OPTIONS") {
          res.writeHead(204);
          res.end();
          return;
        }

        try {
          await this.handleRequest(req, res);
        } catch (error: unknown) {
          const errorMessage: string =
            error instanceof Error ? error.message : String(error);
          this.sendJson(res, 500, {
            success: false,
            error: errorMessage,
            timestamp: new Date().toISOString(),
          });
        }
      }
    );

    return new Promise<void>((resolve: () => void, reject: (err: Error) => void): void => {
      this.server?.listen(this.config.port, this.config.host, (): void => {
        resolve();
      });
      this.server?.on("error", (err: Error): void => {
        reject(err);
      });
    });
  }

  public async stop(): Promise<void> {
    if (!this.server) {
      return;
    }

    return new Promise<void>((resolve: () => void): void => {
      this.server?.close((): void => {
        this.server = null;
        resolve();
      });
    });
  }

  public getPort(): number {
    if (this.server) {
      const addr = this.server.address();
      if (addr && typeof addr === "object") {
        return addr.port;
      }
    }
    return this.config.port;
  }

  public getHost(): string {
    return this.config.host;
  }

  public isListening(): boolean {
    return this.server !== null && this.server.listening;
  }

  private async handleRequest(
    req: http.IncomingMessage,
    res: http.ServerResponse
  ): Promise<void> {
    const rawUrl: string = req.url || "/";
    const parsedUrl: URL = new URL(rawUrl, `http://${req.headers.host || "localhost"}`);
    const pathname: string = parsedUrl.pathname;
    const method: string = req.method || "GET";

    // 1. Health checks
    if ((pathname === "/health" || pathname === "/api/health") && method === "GET") {
      this.sendJson(res, 200, {
        status: "ok",
        service: "LocalSQLServer",
        version: "1.0.0",
        host: this.config.host,
        port: this.config.port,
        timestamp: new Date().toISOString(),
      });
      return;
    }

    // 2. Metrics & Performance
    if ((pathname === "/api/metrics" || pathname === "/api/performance") && method === "GET") {
      const metrics: ServerPerformanceMetrics = lcPerformanceMonitor.getMetrics();
      this.sendJson(res, 200, {
        success: true,
        metrics,
      });
      return;
    }

    // 3. Status
    if (pathname === "/api/status" && method === "GET") {
      const targetDbQuery: string | null = parsedUrl.searchParams.get("db") || parsedUrl.searchParams.get("database");
      if (targetDbQuery && targetDbQuery !== this.engine.getCurrentDatabase()) {
        this.engine.useDatabase(targetDbQuery);
      }
      const currentDb: string = this.engine.getCurrentDatabase();
      const tables: string[] = this.engine.getTableNames(currentDb);
      const databases: string[] = this.engine.listDatabases();
      const metrics: ServerPerformanceMetrics = lcPerformanceMonitor.getMetrics();

      this.sendJson(res, 200, {
        success: true,
        service: "LocalSQLServer",
        activeDatabase: currentDb,
        tablesCount: tables.length,
        databasesCount: databases.length,
        databases,
        metrics,
      });
      return;
    }

    // 4. Databases API
    if (pathname === "/api/databases") {
      if (method === "GET") {
        const databases: string[] = this.engine.listDatabases();
        this.sendJson(res, 200, {
          success: true,
          databases,
          current: this.engine.getCurrentDatabase(),
        });
        return;
      }

      if (method === "POST") {
        const body: Record<string, unknown> = await this.readJsonBody(req);
        const dbName: string = String(body.name || "").trim();
        if (!dbName) {
          this.sendJson(res, 400, { success: false, error: "Database name is required" });
          return;
        }
        const created: boolean = this.engine.createDatabase(dbName);
        this.sendJson(res, 200, { success: created, database: dbName });
        return;
      }
    }

    if (pathname.startsWith("/api/databases/") && method === "DELETE") {
      const targetDb: string = pathname.replace("/api/databases/", "").trim();
      if (!targetDb) {
        this.sendJson(res, 400, { success: false, error: "Database name is required" });
        return;
      }
      const dropped: boolean = this.engine.dropDatabase(targetDb);
      this.sendJson(res, 200, { success: dropped, database: targetDb });
      return;
    }

    // 5. Tables API
    if (pathname === "/api/tables" && method === "GET") {
      const targetDbQuery: string | null = parsedUrl.searchParams.get("db") || parsedUrl.searchParams.get("database");
      if (targetDbQuery && targetDbQuery !== this.engine.getCurrentDatabase()) {
        this.engine.useDatabase(targetDbQuery);
      }

      const activeDatabaseName: string = this.engine.getCurrentDatabase();
      const tableNames: string[] = this.engine.getTableNames(activeDatabaseName);
      const tablesList: Array<{
        name: string;
        rowCount: number;
        columnCount: number;
        columns: string[];
      }> = tableNames.map((tblName: string) => {
        const rawRecords: LcLocalDbRecord[] = this.engine.getAll(tblName as never);
        const rows: Array<Record<string, unknown>> = rawRecords.map((rec: LcLocalDbRecord): Record<string, unknown> => {
          return this.unwrapRecord(rec);
        });
        const rawSchema: unknown = this.engine.getTableSchema(tblName);
        const { columns }: { columns: string[]; schema: unknown } = this.deriveTableColumnsAndSchema(
          tblName,
          rawSchema,
          rows
        );

        return {
          name: tblName,
          rowCount: rows.length,
          columnCount: columns.length,
          columns,
        };
      });

      this.sendJson(res, 200, {
        success: true,
        database: activeDatabaseName,
        tables: tablesList,
      });
      return;
    }

    // 6. Table Details & Data
    if (pathname.startsWith("/api/tables/") && method === "GET") {
      const rawTableName: string = pathname.replace("/api/tables/", "").trim();
      const targetDbQuery: string | null = parsedUrl.searchParams.get("db") || parsedUrl.searchParams.get("database");
      if (targetDbQuery && targetDbQuery !== this.engine.getCurrentDatabase()) {
        this.engine.useDatabase(targetDbQuery);
      }

      const cleanTableName: string = rawTableName.replace(/[`"']/g, "").trim();
      if (!this.engine.hasTable(cleanTableName) && !this.engine.getTableNames().includes(cleanTableName)) {
        this.sendJson(res, 404, {
          success: false,
          error: `Table '${cleanTableName}' not found in database '${this.engine.getCurrentDatabase()}'`,
        });
        return;
      }

      let rows: Array<Record<string, unknown>> = [];
      let totalRowsCount: number = 0;

      if (this.engine.isTableLarge(cleanTableName)) {
        // Hydroelectric stream mode for large tables (> 50MB, up to > 10GB scale)
        const queryRes = await this.engine.streamQueryTable(cleanTableName, { limit: 500 });
        rows = queryRes.records.map((rec: LcLocalDbRecord) => this.unwrapRecord(rec));
        totalRowsCount = queryRes.stats.totalRecordsScanned;
      } else {
        const rawRecords: LcLocalDbRecord[] = this.engine.getAll(cleanTableName as never);
        rows = rawRecords.map((rec: LcLocalDbRecord): Record<string, unknown> => {
          return this.unwrapRecord(rec);
        });
        totalRowsCount = rows.length;
      }

      const rawSchema: unknown = this.engine.getTableSchema(cleanTableName);
      const { schema }: { columns: string[]; schema: unknown } = this.deriveTableColumnsAndSchema(
        cleanTableName,
        rawSchema,
        rows
      );

      this.sendJson(res, 200, {
        success: true,
        database: this.engine.getCurrentDatabase(),
        tableName: cleanTableName,
        table: cleanTableName,
        schema,
        rowsCount: totalRowsCount,
        rowsAffected: rows.length,
        rows: rows.slice(0, 500),
        data: rows.slice(0, 500),
      });
      return;
    }

    // 6.1 Delete Table API (DROP TABLE)
    if (pathname.startsWith("/api/tables/") && !pathname.endsWith("/delete-rows") && method === "DELETE") {
      const rawTableName: string = pathname.replace("/api/tables/", "").trim();
      const targetDbQuery: string | null = parsedUrl.searchParams.get("db") || parsedUrl.searchParams.get("database");
      if (targetDbQuery && targetDbQuery !== this.engine.getCurrentDatabase()) {
        this.engine.useDatabase(targetDbQuery);
      }

      const cleanTableName: string = rawTableName.replace(/[`"']/g, "").trim();
      const dropped: boolean = this.engine.dropTable(cleanTableName);
      this.sendJson(res, 200, {
        success: dropped,
        database: this.engine.getCurrentDatabase(),
        tableName: cleanTableName,
        dropped,
      });
      return;
    }

    // 6.2 Rename / Edit Table API (ALTER TABLE RENAME TO)
    if (pathname.startsWith("/api/tables/") && (method === "PUT" || method === "PATCH")) {
      const rawTableName: string = pathname.replace("/api/tables/", "").trim();
      const targetDbQuery: string | null = parsedUrl.searchParams.get("db") || parsedUrl.searchParams.get("database");
      if (targetDbQuery && targetDbQuery !== this.engine.getCurrentDatabase()) {
        this.engine.useDatabase(targetDbQuery);
      }

      const cleanTableName: string = rawTableName.replace(/[`"']/g, "").trim();
      const body: Record<string, unknown> = await this.readJsonBody(req);
      const newName: string = String(body.newName || body.name || "").trim().replace(/[`"']/g, "");

      if (!newName) {
        this.sendJson(res, 400, { success: false, error: "New table name is required" });
        return;
      }

      const renamed: boolean = this.engine.renameTable(cleanTableName, newName);
      this.sendJson(res, 200, {
        success: renamed,
        database: this.engine.getCurrentDatabase(),
        oldName: cleanTableName,
        newName,
        renamed,
      });
      return;
    }

    // 6.3 Bulk Delete Rows API
    if (pathname.startsWith("/api/tables/") && pathname.endsWith("/delete-rows") && method === "POST") {
      const rawTableName: string = pathname.replace("/api/tables/", "").replace("/delete-rows", "").trim();
      const targetDbQuery: string | null = parsedUrl.searchParams.get("db") || parsedUrl.searchParams.get("database");
      if (targetDbQuery && targetDbQuery !== this.engine.getCurrentDatabase()) {
        this.engine.useDatabase(targetDbQuery);
      }

      const cleanTableName: string = rawTableName.replace(/[`"']/g, "").trim();
      const body: Record<string, unknown> = await this.readJsonBody(req);
      const rawIds: unknown[] = Array.isArray(body.ids)
        ? (body.ids as unknown[])
        : Array.isArray(body.keys)
        ? (body.keys as unknown[])
        : Array.isArray(body.rowKeys)
        ? (body.rowKeys as unknown[])
        : [];

      let deletedCount: number = 0;
      const targetKeysSet: Set<string> = new Set<string>(rawIds.map((id: unknown): string => String(id)));

      const rawRecords: LcLocalDbRecord[] = this.engine.getAll(cleanTableName as never);
      for (const rec of rawRecords) {
        const unwrapped: Record<string, unknown> = this.unwrapRecord(rec);
        const matches: boolean =
          targetKeysSet.has(rec.key) ||
          (unwrapped.id !== undefined && targetKeysSet.has(String(unwrapped.id))) ||
          (unwrapped.key !== undefined && targetKeysSet.has(String(unwrapped.key)));

        if (matches) {
          const deleted: boolean = this.engine.delete(cleanTableName as never, rec.key);
          if (deleted) {
            deletedCount += 1;
          }
        }
      }

      this.sendJson(res, 200, {
        success: true,
        database: this.engine.getCurrentDatabase(),
        tableName: cleanTableName,
        deletedCount,
      });
      return;
    }

    // 7. Execute SQL Query (supports both POST and GET)
    if (pathname === "/api/query" && (method === "POST" || method === "GET")) {
      let sqlQueryText: string = "";
      let targetDb: string | undefined = undefined;

      if (method === "POST") {
        const body: Record<string, unknown> = await this.readJsonBody(req);
        sqlQueryText = String(body.sql || body.query || "").trim();
        targetDb =
          typeof body.database === "string"
            ? body.database
            : typeof body.db === "string"
            ? body.db
            : undefined;
      } else {
        sqlQueryText = String(parsedUrl.searchParams.get("sql") || parsedUrl.searchParams.get("q") || "").trim();
        const dbParam: string | null = parsedUrl.searchParams.get("db") || parsedUrl.searchParams.get("database");
        if (dbParam) {
          targetDb = dbParam.trim();
        }
      }

      if (!sqlQueryText) {
        this.sendJson(res, 400, { success: false, error: "SQL query is required" });
        return;
      }

      if (targetDb && targetDb !== this.engine.getCurrentDatabase()) {
        this.engine.useDatabase(targetDb);
      }

      const startHrTime: bigint = process.hrtime.bigint();
      try {
        const queryResult: unknown = this.engine.executeSql(sqlQueryText);
        const endHrTime: bigint = process.hrtime.bigint();
        const durationMs: number = Number(endHrTime - startHrTime) / 1_000_000;

        // Record in performance monitor
        lcPerformanceMonitor.recordQuery(durationMs, sqlQueryText);

        const rowsAffected: number = Array.isArray(queryResult) ? queryResult.length : 1;

        // Extract table schema if query is a SELECT from a table
        let tableSchemaResult: unknown = null;
        const selectFromMatch: RegExpMatchArray | null = sqlQueryText.match(
          /^SELECT\s+[\s\S]+?\s+FROM\s+([`"']?[a-zA-Z0-9_.-]+[`"']?)/i
        );
        if (selectFromMatch) {
          const rawTable: string = selectFromMatch[1].replace(/[`"']/g, "").trim();
          tableSchemaResult = this.engine.getTableSchema(rawTable);
        }

        this.sendJson(res, 200, {
          success: true,
          database: this.engine.getCurrentDatabase(),
          data: queryResult,
          rows: queryResult,
          schema: tableSchemaResult,
          rowsAffected,
          executionTimeMs: Number(durationMs.toFixed(3)),
          timestamp: new Date().toISOString(),
        });
      } catch (queryError: unknown) {
        const endHrTime: bigint = process.hrtime.bigint();
        const durationMs: number = Number(endHrTime - startHrTime) / 1_000_000;
        lcPerformanceMonitor.recordQuery(durationMs, sqlQueryText);

        const errMsg: string = queryError instanceof Error ? queryError.message : String(queryError);
        this.sendJson(res, 400, {
          success: false,
          error: errMsg,
          executionTimeMs: Number(durationMs.toFixed(3)),
          timestamp: new Date().toISOString(),
        });
      }
      return;
    }

    // 8. Cache API (Centralized LocalSQLServer cache replacing legacy .Cache)
    if (pathname === "/api/cache" || pathname.startsWith("/api/cache/")) {
      // 8.1 GET /api/cache: list all cached entries
      if (pathname === "/api/cache" && method === "GET") {
        const items: Array<{
          key: string;
          value: unknown;
          createdAt: string;
          updatedAt?: string;
          ttlMs?: number | null;
        }> = this.engine.getAllCache();
        this.sendJson(res, 200, {
          success: true,
          database: this.engine.getCurrentDatabase(),
          count: items.length,
          items,
        });
        return;
      }

      // 8.2 GET /api/cache/:key: get specific cached entry
      if (pathname.startsWith("/api/cache/") && method === "GET") {
        const rawKey: string = pathname.replace("/api/cache/", "").trim();
        const key: string = decodeURIComponent(rawKey);
        const record: LcLocalDbRecord | null = this.engine.getCacheRecord(key);

        if (!record) {
          this.sendJson(res, 404, {
            success: false,
            error: `Cache key '${key}' not found or expired`,
          });
          return;
        }

        this.sendJson(res, 200, {
          success: true,
          key,
          value: record.value,
          record,
        });
        return;
      }

      // 8.3 POST /api/cache: set cache entry with optional ttlMs
      if (pathname === "/api/cache" && method === "POST") {
        const body: Record<string, unknown> = await this.readJsonBody(req);
        const key: string = String(body.key || "").trim();
        if (!key) {
          this.sendJson(res, 400, { success: false, error: "Cache key is required" });
          return;
        }

        const ttlMs: number | undefined =
          typeof body.ttlMs === "number" && body.ttlMs > 0 ? body.ttlMs : undefined;
        const record: LcLocalDbRecord = this.engine.setCache(key, body.value, ttlMs);

        this.sendJson(res, 200, {
          success: true,
          key,
          record,
        });
        return;
      }

      // 8.4 DELETE /api/cache/:key: delete specific cache entry
      if (pathname.startsWith("/api/cache/") && method === "DELETE") {
        const rawKey: string = pathname.replace("/api/cache/", "").trim();
        const key: string = decodeURIComponent(rawKey);
        const deleted: boolean = this.engine.deleteCache(key);

        this.sendJson(res, 200, {
          success: true,
          key,
          deleted,
        });
        return;
      }

      // 8.5 DELETE /api/cache: clear all cached entries
      if (pathname === "/api/cache" && method === "DELETE") {
        const clearedCount: number = this.engine.clearCache();
        this.sendJson(res, 200, {
          success: true,
          clearedCount,
        });
        return;
      }
    }

    // 9. Hydroelectric Streaming Endpoints
    // 9.1 GET /api/hydroelectric/status & /api/hydroelectric/config
    if ((pathname === "/api/hydroelectric/status" || pathname === "/api/hydroelectric/config") && method === "GET") {
      const metrics: HydroelectricMetrics = hydroelectricEngine.getMetrics();
      const config = hydroelectricEngine.getConfig();
      this.sendJson(res, 200, {
        success: true,
        service: "LocalSQLServer",
        engine: "HydroelectricEngine",
        config,
        metrics,
        timestamp: new Date().toISOString(),
      });
      return;
    }

    // 9.2 POST /api/hydroelectric/read-file: Stream and scan any SQL file (> 10 GB) with bounded O(1) buffer memory
    if (pathname === "/api/hydroelectric/read-file" && method === "POST") {
      const body: Record<string, unknown> = await this.readJsonBody(req);
      const filePath: string = String(body.filePath || body.path || "").trim();
      if (!filePath) {
        this.sendJson(res, 400, { success: false, error: "filePath is required" });
        return;
      }

      if (!fs.existsSync(filePath)) {
        this.sendJson(res, 404, { success: false, error: `File not found: ${filePath}` });
        return;
      }

      const limit: number = typeof body.limit === "number" && body.limit > 0 ? body.limit : 50;
      const offset: number = typeof body.offset === "number" && body.offset >= 0 ? body.offset : 0;
      const queryRes = await hydroelectricEngine.streamQuery(filePath, { limit, offset });

      this.sendJson(res, 200, {
        success: true,
        service: "LocalSQLServer",
        engine: "HydroelectricEngine",
        stats: queryRes.stats,
        sampleRecords: queryRes.records.slice(0, 10),
        recordsCount: queryRes.records.length,
        timestamp: new Date().toISOString(),
      });
      return;
    }

    // 10. Streaming Tables API: GET /api/stream/tables/:tableName
    // Streams records directly with chunked transfer-encoding (NDJSON or JSON stream)
    if (pathname.startsWith("/api/stream/tables/") && method === "GET") {
      const rawTableName: string = pathname.replace("/api/stream/tables/", "").trim();
      const targetDbQuery: string | null = parsedUrl.searchParams.get("db") || parsedUrl.searchParams.get("database");
      if (targetDbQuery && targetDbQuery !== this.engine.getCurrentDatabase()) {
        this.engine.useDatabase(targetDbQuery);
      }

      const cleanTableName: string = rawTableName.replace(/[`"']/g, "").trim();
      const format: "ndjson" | "json" = parsedUrl.searchParams.get("format") === "ndjson" ? "ndjson" : "json";
      const limit: number = parseInt(parsedUrl.searchParams.get("limit") || "1000", 10);
      const offset: number = parseInt(parsedUrl.searchParams.get("offset") || "0", 10);

      res.writeHead(200, {
        "Content-Type": format === "ndjson" ? "application/x-ndjson; charset=utf-8" : "application/json; charset=utf-8",
        "Transfer-Encoding": "chunked",
        "X-Hydroelectric-Stream": "true",
      });

      await this.engine.streamPipeTableToHttp(cleanTableName, res, { format, limit, offset });
      return;
    }

    // 11. Streaming Query API: POST /api/stream/query
    if (pathname === "/api/stream/query" && method === "POST") {
      const body: Record<string, unknown> = await this.readJsonBody(req);
      const tableName: string = String(body.table || body.tableName || "").replace(/[`"']/g, "").trim();
      const targetDb: string | undefined = typeof body.db === "string" ? body.db : (typeof body.database === "string" ? body.database : undefined);

      if (!tableName) {
        this.sendJson(res, 400, { success: false, error: "table name is required for streaming query" });
        return;
      }

      if (targetDb && targetDb !== this.engine.getCurrentDatabase()) {
        this.engine.useDatabase(targetDb);
      }

      const limit: number = typeof body.limit === "number" && body.limit > 0 ? body.limit : 500;
      const offset: number = typeof body.offset === "number" && body.offset >= 0 ? body.offset : 0;

      const whereFilter = (rec: LcLocalDbRecord): boolean => {
        if (!body.where || typeof body.where !== "object") return true;
        const unwrapped = this.unwrapRecord(rec);
        const whereObj = body.where as Record<string, unknown>;
        for (const [k, v] of Object.entries(whereObj)) {
          if (unwrapped[k] !== v) return false;
        }
        return true;
      };

      const result = await this.engine.streamQueryTable(tableName, {
        where: whereFilter,
        limit,
        offset,
      });

      this.sendJson(res, 200, {
        success: true,
        database: this.engine.getCurrentDatabase(),
        tableName,
        rowsAffected: result.records.length,
        rows: result.records.map((r) => this.unwrapRecord(r)),
        stats: result.stats,
        timestamp: new Date().toISOString(),
      });
      return;
    }

    // Default: 404
    this.sendJson(res, 404, {
      success: false,
      error: `Endpoint not found: ${method} ${pathname}`,
      timestamp: new Date().toISOString(),
    });
  }

  private sendJson(res: http.ServerResponse, statusCode: number, payload: unknown): void {
    const jsonString: string = JSON.stringify(payload);
    res.writeHead(statusCode, {
      "Content-Type": "application/json; charset=utf-8",
      "Content-Length": Buffer.byteLength(jsonString),
    });
    res.end(jsonString);
  }

  private async readJsonBody(req: http.IncomingMessage): Promise<Record<string, unknown>> {
    return new Promise<Record<string, unknown>>(
      (resolve: (data: Record<string, unknown>) => void, reject: (err: Error) => void): void => {
        const chunks: Buffer[] = [];
        req.on("data", (chunk: Buffer): void => {
          chunks.push(chunk);
        });
        req.on("end", (): void => {
          try {
            const bodyString: string = Buffer.concat(chunks).toString("utf8");
            if (!bodyString.trim()) {
              resolve({});
              return;
            }
            const parsed: unknown = JSON.parse(bodyString);
            if (typeof parsed === "object" && parsed !== null) {
              resolve(parsed as Record<string, unknown>);
            } else {
              resolve({});
            }
          } catch (err: unknown) {
            reject(new Error(`Invalid JSON body: ${String(err)}`));
          }
        });
        req.on("error", (err: Error): void => {
          reject(err);
        });
      }
    );
  }

  private unwrapRecord(rec: LcLocalDbRecord): Record<string, unknown> {
    if (!rec || typeof rec !== "object") {
      return { value: rec };
    }
    let parsedValue: unknown = rec.value;
    if (typeof rec.value === "string" && (rec.value.trim().startsWith("{") || rec.value.trim().startsWith("["))) {
      try {
        parsedValue = JSON.parse(rec.value);
      } catch {
        parsedValue = rec.value;
      }
    }
    if (parsedValue && typeof parsedValue === "object" && !Array.isArray(parsedValue)) {
      const rowVal: Record<string, unknown> = { ...(parsedValue as Record<string, unknown>) };
      if (rowVal.id === undefined && rec.key !== undefined) {
        rowVal.id = rec.key;
      }
      return rowVal;
    }
    return { id: rec.key, value: parsedValue ?? rec.value };
  }

  private deriveTableColumnsAndSchema(
    tableName: string,
    rawSchema: unknown,
    rows: Array<Record<string, unknown>>
  ): { columns: string[]; schema: unknown } {
    const genericStorageSet: Set<string> = new Set<string>([
      "key",
      "value",
      "namespace",
      "createdAt",
      "updatedAt",
      "ttlMs",
      "version",
      "tags",
    ]);

    let schemaCols: string[] = [];
    if (rawSchema && typeof rawSchema === "object" && "columns" in rawSchema) {
      const colsObj: Record<string, unknown> =
        (rawSchema as { columns: Record<string, unknown> }).columns || {};
      schemaCols = Object.keys(colsObj);
    }

    const isGeneric: boolean =
      schemaCols.length > 0 && schemaCols.every((c: string): boolean => genericStorageSet.has(c));

    if (schemaCols.length > 0 && !isGeneric) {
      return { columns: schemaCols, schema: rawSchema };
    }

    if (rows.length > 0) {
      const keysSet: Set<string> = new Set<string>();
      const derivedColDefs: Record<string, { type: string; primaryKey: boolean; nullable: boolean }> = {};

      for (const row of rows.slice(0, 100)) {
        for (const [k, v] of Object.entries(row)) {
          keysSet.add(k);
          if (!derivedColDefs[k]) {
            let colType: string = "VARCHAR";
            if (typeof v === "number") {
              colType = Number.isInteger(v) ? "INTEGER" : "REAL";
            } else if (typeof v === "boolean") {
              colType = "BOOLEAN";
            } else if (typeof v === "object" && v !== null) {
              colType = "JSON";
            }
            derivedColDefs[k] = {
              type: colType,
              primaryKey: k === "id" || k === "key",
              nullable: v === null || v === undefined,
            };
          }
        }
      }

      const allKeys: string[] = Array.from(keysSet);
      const idKeys: string[] = allKeys.filter((k: string): boolean => k === "id" || k === "key" || k === "_id");
      const metaKeys: string[] = allKeys.filter((k: string): boolean => genericStorageSet.has(k));
      const domainKeys: string[] = allKeys.filter(
        (k: string): boolean => !idKeys.includes(k) && !metaKeys.includes(k)
      );
      const sortedCols: string[] = [...idKeys, ...domainKeys, ...metaKeys];

      return {
        columns: sortedCols,
        schema: {
          tableName,
          columns: derivedColDefs,
        },
      };
    }

    return {
      columns: schemaCols,
      schema: rawSchema || { tableName, columns: {} },
    };
  }
}
