/**
 * packages/LocalSQLServer/sources/server/grpc-server.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * High-performance gRPC Server for LocalSQLServer
 * Implements binary RPC methods for SQL execution, table discovery, and telemetry.
 * ─────────────────────────────────────────────────────────────────────────────
 */

import fs from "node:fs";
import path from "node:path";
import process from "node:process";
import { lcLocalDbEngine, LcLocalDbEngine } from "../engine/lc-local-db-engine";
import { lcPerformanceMonitor, type ServerPerformanceMetrics } from "../monitor/lc-performance-monitor";

// Safe dynamic resolution of gRPC modules
// eslint-disable-next-line @typescript-eslint/no-explicit-any
let grpc: any = null;
// eslint-disable-next-line @typescript-eslint/no-explicit-any
let protoLoader: any = null;
try {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const dynamicRequire: (id: string) => any = eval("require");
  grpc = dynamicRequire("@grpc/grpc-js");
  protoLoader = dynamicRequire("@grpc/proto-loader");
} catch {
  // Gracefully handle environments without @grpc dependencies
}

export interface GrpcServerConfig {
  readonly host: string;
  readonly port: number;
}

export const DEFAULT_GRPC_HOST: string = process.env.LOCAL_SQL_GRPC_HOST || "0.0.0.0";
export const DEFAULT_GRPC_PORT: number = Number(process.env.LOCAL_SQL_GRPC_PORT || 50055);

interface GrpcUnaryCall<TRequest, TResponse> {
  request: TRequest;
}

type GrpcUnaryCallback<TResponse> = (
  error: unknown | null,
  value?: TResponse
) => void;

export class LocalSqlGrpcServer {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private server: any = null;
  private readonly config: GrpcServerConfig;
  private readonly engine: LcLocalDbEngine;
  private isRunning: boolean = false;

  public constructor(config?: Partial<GrpcServerConfig>, customEngine?: LcLocalDbEngine) {
    this.config = {
      host: config?.host || DEFAULT_GRPC_HOST,
      port: config?.port || DEFAULT_GRPC_PORT,
    };
    this.engine = customEngine || lcLocalDbEngine;
  }

  public resolveProtoFilePath(): string {
    const candidatePaths: string[] = [
      path.resolve(__dirname, "../../proto/local_sql.proto"),
      path.resolve(process.cwd(), "proto/local_sql.proto"),
      path.resolve(process.cwd(), "packages/LocalSQLServer/proto/local_sql.proto"),
    ];

    for (const cand of candidatePaths) {
      if (fs.existsSync(cand)) {
        return cand;
      }
    }
    return candidatePaths[0];
  }

  public async start(): Promise<number> {
    if (this.isRunning && this.server) {
      return this.config.port;
    }

    if (!grpc || !protoLoader) {
      console.warn("[LocalSQLServer] Optional @grpc/grpc-js not available. gRPC server disabled.");
      return this.config.port;
    }

    const protoPath: string = this.resolveProtoFilePath();
    if (!fs.existsSync(protoPath)) {
      throw new Error(`Proto file not found at: ${protoPath}`);
    }

    const packageDefinition: unknown = protoLoader.loadSync(
      protoPath,
      {
        keepCase: true,
        longs: String,
        enums: String,
        defaults: true,
        oneofs: true,
      }
    );

    const protoDescriptor: Record<string, unknown> = grpc.loadPackageDefinition(packageDefinition);
    const vtekPackage: Record<string, unknown> = protoDescriptor.vtek as Record<string, unknown>;
    const localsqlPackage: Record<string, unknown> = vtekPackage?.localsql as Record<string, unknown>;
    const grpcPackage: Record<string, unknown> = localsqlPackage?.grpc as Record<string, unknown>;

    if (!grpcPackage || !grpcPackage.LocalSqlService) {
      throw new Error("LocalSqlService not found in loaded protobuf descriptor");
    }

    const serviceConstructor: { service: unknown } =
      grpcPackage.LocalSqlService as unknown as { service: unknown };

    this.server = new grpc.Server();

    // Register service implementation
    this.server.addService(serviceConstructor.service, {
      ExecuteSql: this.handleExecuteSql.bind(this),
      GetTables: this.handleGetTables.bind(this),
      GetTableSchema: this.handleGetTableSchema.bind(this),
      GetPerformanceMetrics: this.handleGetPerformanceMetrics.bind(this),
      Ping: this.handlePing.bind(this),
    });

    const bindAddress: string = `${this.config.host}:${this.config.port}`;
    return new Promise<number>((resolve: (port: number) => void, reject: (err: Error) => void): void => {
      this.server?.bindAsync(
        bindAddress,
        grpc.ServerCredentials.createInsecure(),
        (bindError: Error | null, boundPort: number): void => {
          if (bindError) {
            reject(bindError);
            return;
          }
          if (boundPort === 0) {
            reject(new Error(`Failed to bind LocalSqlService on ${bindAddress}: Port already in use`));
            return;
          }
          this.isRunning = true;
          resolve(boundPort);
        }
      );
    });
  }

  public async stop(): Promise<void> {
    if (!this.server || !this.isRunning) {
      return;
    }

    return new Promise<void>((resolve: () => void): void => {
      this.server?.tryShutdown((): void => {
        this.isRunning = false;
        this.server = null;
        resolve();
      });
    });
  }

  public isServerRunning(): boolean {
    return this.isRunning;
  }

  public getPort(): number {
    return this.config.port;
  }

  private handleExecuteSql(
    call: GrpcUnaryCall<{ query: string; database?: string }, Record<string, unknown>>,
    callback: GrpcUnaryCallback<Record<string, unknown>>
  ): void {
    lcPerformanceMonitor.trackGrpcConnectionChange(1);
    const sqlText: string = String(call.request.query || "").trim();
    const targetDb: string | undefined = call.request.database?.trim();

    if (!sqlText) {
      lcPerformanceMonitor.trackGrpcConnectionChange(-1);
      callback(null, {
        success: false,
        data_json: "[]",
        rows_affected: 0,
        execution_time_ms: 0,
        error_message: "Query cannot be empty",
        timestamp: new Date().toISOString(),
      });
      return;
    }

    if (targetDb && targetDb !== this.engine.getCurrentDatabase()) {
      this.engine.useDatabase(targetDb);
    }

    const startHr: bigint = process.hrtime.bigint();
    try {
      const result: unknown = this.engine.executeSql(sqlText);
      const endHr: bigint = process.hrtime.bigint();
      const durationMs: number = Number(endHr - startHr) / 1_000_000;

      lcPerformanceMonitor.recordQuery(durationMs, sqlText);
      lcPerformanceMonitor.trackGrpcConnectionChange(-1);

      const rowsCount: number = Array.isArray(result) ? result.length : 1;
      callback(null, {
        success: true,
        data_json: JSON.stringify(result),
        rows_affected: rowsCount,
        execution_time_ms: Number(durationMs.toFixed(3)),
        error_message: "",
        timestamp: new Date().toISOString(),
      });
    } catch (err: unknown) {
      const endHr: bigint = process.hrtime.bigint();
      const durationMs: number = Number(endHr - startHr) / 1_000_000;
      lcPerformanceMonitor.recordQuery(durationMs, sqlText);
      lcPerformanceMonitor.trackGrpcConnectionChange(-1);

      const message: string = err instanceof Error ? err.message : String(err);
      callback(null, {
        success: false,
        data_json: "[]",
        rows_affected: 0,
        execution_time_ms: Number(durationMs.toFixed(3)),
        error_message: message,
        timestamp: new Date().toISOString(),
      });
    }
  }

  private handleGetTables(
    call: GrpcUnaryCall<{ database?: string }, Record<string, unknown>>,
    callback: GrpcUnaryCallback<Record<string, unknown>>
  ): void {
    const targetDb: string = call.request.database?.trim() || this.engine.getCurrentDatabase();
    if (targetDb !== this.engine.getCurrentDatabase()) {
      this.engine.useDatabase(targetDb);
    }

    try {
      const tableNames: string[] = this.engine.getTableNames();
      const tablesList: Array<Record<string, unknown>> = tableNames.map((name: string) => {
        const rows: unknown[] = this.engine.getAll(name as never);
        const schema: unknown = this.engine.getTableSchema(name);
        const colCount: number =
          schema && typeof schema === "object" && "columns" in schema
            ? Object.keys((schema as { columns: Record<string, unknown> }).columns || {}).length
            : rows.length > 0 && typeof rows[0] === "object" && rows[0] !== null
            ? Object.keys(rows[0] as Record<string, unknown>).length
            : 0;

        return {
          name,
          row_count: rows.length,
          column_count: colCount,
          size_bytes: JSON.stringify(rows).length,
          database: targetDb,
        };
      });

      callback(null, {
        success: true,
        tables: tablesList,
        database: targetDb,
        error_message: "",
      });
    } catch (err: unknown) {
      callback(null, {
        success: false,
        tables: [],
        database: targetDb,
        error_message: err instanceof Error ? err.message : String(err),
      });
    }
  }

  private handleGetTableSchema(
    call: GrpcUnaryCall<{ database?: string; table_name: string }, Record<string, unknown>>,
    callback: GrpcUnaryCallback<Record<string, unknown>>
  ): void {
    const tableName: string = String(call.request.table_name || "").trim();
    const targetDb: string = call.request.database?.trim() || this.engine.getCurrentDatabase();

    if (!tableName) {
      callback(null, {
        success: false,
        table_name: "",
        database: targetDb,
        columns: [],
        error_message: "Table name is required",
      });
      return;
    }

    try {
      const schema: unknown = this.engine.getTableSchema(tableName);
      const columnsList: Array<{
        name: string;
        data_type: string;
        is_primary_key: boolean;
        is_nullable: boolean;
        default_value: string;
      }> = [];

      if (schema && typeof schema === "object" && "columns" in schema) {
        const cols: Record<string, { type?: string; primaryKey?: boolean; nullable?: boolean; defaultValue?: unknown }> =
          (schema as { columns: Record<string, { type?: string; primaryKey?: boolean; nullable?: boolean; defaultValue?: unknown }> }).columns || {};
        for (const [colName, colDef] of Object.entries(cols)) {
          columnsList.push({
            name: colName,
            data_type: colDef?.type || "TEXT",
            is_primary_key: Boolean(colDef?.primaryKey),
            is_nullable: Boolean(colDef?.nullable ?? true),
            default_value: colDef?.defaultValue !== undefined ? String(colDef.defaultValue) : "",
          });
        }
      }

      callback(null, {
        success: true,
        table_name: tableName,
        database: targetDb,
        columns: columnsList,
        error_message: "",
      });
    } catch (err: unknown) {
      callback(null, {
        success: false,
        table_name: tableName,
        database: targetDb,
        columns: [],
        error_message: err instanceof Error ? err.message : String(err),
      });
    }
  }

  private handleGetPerformanceMetrics(
    _call: GrpcUnaryCall<Record<string, unknown>, Record<string, unknown>>,
    callback: GrpcUnaryCallback<Record<string, unknown>>
  ): void {
    const metrics: ServerPerformanceMetrics = lcPerformanceMonitor.getMetrics();
    callback(null, {
      success: true,
      uptime_seconds: metrics.uptimeSeconds,
      total_queries: metrics.totalQueries,
      reads_count: metrics.readsCount,
      writes_count: metrics.writesCount,
      queries_per_second: metrics.queriesPerSecond,
      latency: {
        min_ms: metrics.latency.minMs,
        max_ms: metrics.latency.maxMs,
        avg_ms: metrics.latency.avgMs,
        p50_ms: metrics.latency.p50Ms,
        p95_ms: metrics.latency.p95Ms,
        p99_ms: metrics.latency.p99Ms,
      },
      memory: {
        heap_used_mb: metrics.memory.heapUsedMb,
        heap_total_mb: metrics.memory.heapTotalMb,
        rss_mb: metrics.memory.rssMb,
        external_mb: metrics.memory.externalMb,
      },
      timestamp: metrics.timestamp,
    });
  }

  private handlePing(
    call: GrpcUnaryCall<{ message?: string }, Record<string, unknown>>,
    callback: GrpcUnaryCallback<Record<string, unknown>>
  ): void {
    const message: string = call.request.message || "ping";
    callback(null, {
      success: true,
      reply: `pong: ${message}`,
      version: "1.0.0",
      timestamp_ms: Date.now(),
    });
  }
}
