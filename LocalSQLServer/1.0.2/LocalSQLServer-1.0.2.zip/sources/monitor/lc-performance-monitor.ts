/**
 * packages/LocalSQLServer/sources/monitor/lc-performance-monitor.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * Real-time performance monitor and telemetry engine for LocalSQLServer
 * Tracks query throughput, latency percentiles, memory consumption, and connections.
 * ─────────────────────────────────────────────────────────────────────────────
 */

import os from "node:os";
import process from "node:process";

export interface LatencyStats {
  readonly minMs: number;
  readonly maxMs: number;
  readonly avgMs: number;
  readonly p50Ms: number;
  readonly p95Ms: number;
  readonly p99Ms: number;
}

export interface MemoryStats {
  readonly heapUsedMb: number;
  readonly heapTotalMb: number;
  readonly rssMb: number;
  readonly externalMb: number;
  readonly systemTotalMb: number;
  readonly systemFreeMb: number;
}

export interface ServerPerformanceMetrics {
  readonly uptimeSeconds: number;
  readonly totalQueries: number;
  readonly readsCount: number;
  readonly writesCount: number;
  readonly queriesPerSecond: number;
  readonly latency: LatencyStats;
  readonly memory: MemoryStats;
  readonly activeConnections: {
    readonly http: number;
    readonly grpc: number;
    readonly local: number;
    readonly total: number;
  };
  readonly timestamp: string;
}

export class LcPerformanceMonitor {
  private static instance: LcPerformanceMonitor | null = null;

  private readonly startTime: number = Date.now();
  private totalQueries: number = 0;
  private readsCount: number = 0;
  private writesCount: number = 0;
  private activeHttpConnections: number = 0;
  private activeGrpcConnections: number = 0;
  private activeLocalConnections: number = 0;

  // Circular buffer for latency tracking (last 1000 queries)
  private readonly latencySamples: number[] = [];
  private readonly maxSamples: number = 1000;

  // Windowed QPS tracking
  private recentQueryTimestamps: number[] = [];

  private constructor() {}

  public static getInstance(): LcPerformanceMonitor {
    if (!LcPerformanceMonitor.instance) {
      LcPerformanceMonitor.instance = new LcPerformanceMonitor();
    }
    return LcPerformanceMonitor.instance;
  }

  public recordQuery(durationMs: number, sqlQueryText: string): void {
    this.totalQueries += 1;
    const now: number = Date.now();
    this.recentQueryTimestamps.push(now);

    // Prune queries older than 5 seconds for QPS window
    const cutoff: number = now - 5000;
    this.recentQueryTimestamps = this.recentQueryTimestamps.filter(
      (ts: number): boolean => ts >= cutoff
    );

    // Record latency
    if (this.latencySamples.length >= this.maxSamples) {
      this.latencySamples.shift();
    }
    this.latencySamples.push(durationMs);

    // Classify read vs write
    const trimmedSql: string = sqlQueryText.trim().toUpperCase();
    if (
      trimmedSql.startsWith("SELECT") ||
      trimmedSql.startsWith("SHOW") ||
      trimmedSql.startsWith("DESCRIBE") ||
      trimmedSql.startsWith("EXPLAIN")
    ) {
      this.readsCount += 1;
    } else {
      this.writesCount += 1;
    }
  }

  public trackHttpConnectionChange(delta: number): void {
    this.activeHttpConnections = Math.max(0, this.activeHttpConnections + delta);
  }

  public trackGrpcConnectionChange(delta: number): void {
    this.activeGrpcConnections = Math.max(0, this.activeGrpcConnections + delta);
  }

  public trackLocalConnectionChange(delta: number): void {
    this.activeLocalConnections = Math.max(0, this.activeLocalConnections + delta);
  }

  public calculateLatencyStats(): LatencyStats {
    if (this.latencySamples.length === 0) {
      return {
        minMs: 0,
        maxMs: 0,
        avgMs: 0,
        p50Ms: 0,
        p95Ms: 0,
        p99Ms: 0,
      };
    }

    const sorted: number[] = [...this.latencySamples].sort(
      (first: number, second: number): number => first - second
    );
    const count: number = sorted.length;
    const sum: number = sorted.reduce(
      (acc: number, val: number): number => acc + val,
      0
    );
    const avg: number = Number((sum / count).toFixed(3));
    const min: number = sorted[0];
    const max: number = sorted[count - 1];

    const getPercentile = (pct: number): number => {
      const idx: number = Math.min(
        count - 1,
        Math.floor((pct / 100) * count)
      );
      return sorted[idx];
    };

    return {
      minMs: min,
      maxMs: max,
      avgMs: avg,
      p50Ms: getPercentile(50),
      p95Ms: getPercentile(95),
      p99Ms: getPercentile(99),
    };
  }

  public getMemoryStats(): MemoryStats {
    const memoryUsage: NodeJS.MemoryUsage = process.memoryUsage();
    const toMb = (bytes: number): number =>
      Number((bytes / (1024 * 1024)).toFixed(2));

    return {
      heapUsedMb: toMb(memoryUsage.heapUsed),
      heapTotalMb: toMb(memoryUsage.heapTotal),
      rssMb: toMb(memoryUsage.rss),
      externalMb: toMb(memoryUsage.external),
      systemTotalMb: toMb(os.totalmem()),
      systemFreeMb: toMb(os.freemem()),
    };
  }

  public getQueriesPerSecond(): number {
    const now: number = Date.now();
    const cutoff: number = now - 1000;
    const countInLastSecond: number = this.recentQueryTimestamps.filter(
      (ts: number): boolean => ts >= cutoff
    ).length;
    return countInLastSecond;
  }

  public getMetrics(): ServerPerformanceMetrics {
    const now: number = Date.now();
    const uptimeSeconds: number = Number(
      ((now - this.startTime) / 1000).toFixed(1)
    );
    const latency: LatencyStats = this.calculateLatencyStats();
    const memory: MemoryStats = this.getMemoryStats();
    const qps: number = this.getQueriesPerSecond();

    return {
      uptimeSeconds,
      totalQueries: this.totalQueries,
      readsCount: this.readsCount,
      writesCount: this.writesCount,
      queriesPerSecond: qps,
      latency,
      memory,
      activeConnections: {
        http: this.activeHttpConnections,
        grpc: this.activeGrpcConnections,
        local: this.activeLocalConnections,
        total:
          this.activeHttpConnections +
          this.activeGrpcConnections +
          this.activeLocalConnections,
      },
      timestamp: new Date().toISOString(),
    };
  }

  public resetMetrics(): void {
    this.totalQueries = 0;
    this.readsCount = 0;
    this.writesCount = 0;
    this.latencySamples.length = 0;
    this.recentQueryTimestamps.length = 0;
  }
}

export const lcPerformanceMonitor: LcPerformanceMonitor =
  LcPerformanceMonitor.getInstance();
