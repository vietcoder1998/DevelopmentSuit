/**
 * packages/LocalSQLServer/sources/engine/lc-relationship-manager.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * Relationship Table Manager for LcLocalDb
 * ─────────────────────────────────────────────────────────────────────────────
 */

import type {
  DbTable,
  LcLocalDbRecord,
  LcLocalDbRelationship,
  LcLocalDbRelationData,
  LcLocalDbRelationType,
} from "./lc-types";

function now(): string {
  return new Date().toISOString();
}

export class RelationshipManager {
  /**
   * Define or update a relationship specification on a table
   */
  public static defineRelationship(
    table: DbTable,
    rel: Omit<LcLocalDbRelationship, "id" | "createdAt" | "updatedAt"> & { id?: string }
  ): LcLocalDbRelationship {
    const id = rel.id ?? `rel-${rel.sourceTable}-${rel.sourceField}-${rel.targetTable}`;
    const ts = now();
    const existingIndex = table.relationships.findIndex((r) => r.id === id);

    const fullRel: LcLocalDbRelationship = {
      id,
      sourceTable: rel.sourceTable,
      sourceField: rel.sourceField,
      targetTable: rel.targetTable,
      targetField: rel.targetField,
      relationType: rel.relationType,
      onDelete: rel.onDelete ?? "CASCADE",
      onUpdate: rel.onUpdate ?? "CASCADE",
      createdAt: existingIndex >= 0 ? table.relationships[existingIndex].createdAt : ts,
      updatedAt: ts,
    };

    if (existingIndex >= 0) {
      table.relationships[existingIndex] = fullRel;
    } else {
      table.relationships.push(fullRel);
    }

    return fullRel;
  }

  /**
   * Remove a relationship definition
   */
  public static removeRelationship(table: DbTable, relationshipId: string): boolean {
    const idx = table.relationships.findIndex((r) => r.id === relationshipId);
    if (idx >= 0) {
      table.relationships.splice(idx, 1);
      return true;
    }
    return false;
  }

  /**
   * Link two records across tables
   */
  public static linkRecords(
    table: DbTable,
    recordKey: string,
    targetTable: string,
    targetKey: string,
    relationType: LcLocalDbRelationType | string = "1:N",
    metadata?: unknown
  ): LcLocalDbRelationData {
    const id = `link-${table.namespace}-${recordKey}-${targetTable}-${targetKey}`;
    const link: LcLocalDbRelationData = {
      id,
      recordKey,
      targetTable,
      targetKey,
      relationType,
      metadata,
      createdAt: now(),
    };
    table.relations[id] = link;
    return link;
  }

  /**
   * Unlink two records
   */
  public static unlinkRecords(
    table: DbTable,
    recordKey: string,
    targetTable: string,
    targetKey: string
  ): boolean {
    const id = `link-${table.namespace}-${recordKey}-${targetTable}-${targetKey}`;
    if (table.relations[id]) {
      delete table.relations[id];
      return true;
    }
    // Search by properties if id pattern doesn't match
    for (const [key, link] of Object.entries(table.relations)) {
      if (
        link.recordKey === recordKey &&
        link.targetTable === targetTable &&
        link.targetKey === targetKey
      ) {
        delete table.relations[key];
        return true;
      }
    }
    return false;
  }

  /**
   * Query related records for a given record in source table
   */
  public static getRelatedRecords(
    table: DbTable,
    recordKey: string,
    getRecordFn: (targetTable: string, targetKey: string) => LcLocalDbRecord | null,
    targetTableFilter?: string
  ): Array<{ relation: LcLocalDbRelationData; targetRecord: LcLocalDbRecord | null }> {
    const results: Array<{ relation: LcLocalDbRelationData; targetRecord: LcLocalDbRecord | null }> =
      [];

    for (const link of Object.values(table.relations)) {
      if (link.recordKey !== recordKey) continue;
      if (targetTableFilter && link.targetTable !== targetTableFilter) continue;

      const targetRecord = getRecordFn(link.targetTable, link.targetKey);
      results.push({
        relation: link,
        targetRecord,
      });
    }

    return results;
  }

  /**
   * Automatically detect foreign key patterns in records and propose relationships
   */
  public static autoDetectRelationships(
    tableName: string,
    records: Record<string, LcLocalDbRecord>,
    knownTables: string[]
  ): LcLocalDbRelationship[] {
    const detected: Map<string, LcLocalDbRelationship> = new Map();
    const tableKeysLower = new Map(knownTables.map((t) => [t.toLowerCase().replace(/^(lc_|tbl_)/, ""), t]));

    for (const record of Object.values(records)) {
      if (!record.value || typeof record.value !== "object") continue;
      const obj = record.value as Record<string, unknown>;

      for (const fieldName of Object.keys(obj)) {
        if (fieldName.endsWith("Id") && fieldName.length > 2 && fieldName !== "id") {
          const baseName = fieldName.slice(0, -2).toLowerCase();
          const matchedTarget =
            tableKeysLower.get(baseName) ||
            tableKeysLower.get(`${baseName}s`) ||
            knownTables.find((t) => t.toLowerCase().includes(baseName));

          if (matchedTarget) {
            const relId = `rel-${tableName}-${fieldName}-${matchedTarget}`;
            if (!detected.has(relId)) {
              detected.set(relId, {
                id: relId,
                sourceTable: tableName,
                sourceField: fieldName,
                targetTable: matchedTarget,
                targetField: "key",
                relationType: "1:N",
                onDelete: "CASCADE",
                onUpdate: "CASCADE",
                createdAt: now(),
                updatedAt: now(),
              });
            }
          }
        }
      }
    }

    return Array.from(detected.values());
  }
}
