/**
 * packages/LocalSQLServer/sources/engine/lc-legacy-migrator.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * Migrators & Converters for legacy formats (.db.lc, .Cache/localdb.json, :memory:)
 * ─────────────────────────────────────────────────────────────────────────────
 */

import type { DbTable, InternalDb, LcLocalDbMergeMemoryResult } from "./lc-types";
import { parseDblcSql } from "./lc-sql-serializer";

export const LEGACY_CACHE_FILE = ".Cache/localdb.json";
export const LEGACY_LS_KEY = "_lc_localdb";

export function isNodeEnv(): boolean {
  return typeof window === "undefined" && typeof process !== "undefined";
}

export function isBrowserEnv(): boolean {
  return typeof window !== "undefined" && typeof localStorage !== "undefined";
}

function getFs(): typeof import("node:fs") | null {
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  return typeof require !== "undefined" ? (require("node:fs") as typeof import("node:fs")) : null;
}

function getPath(): typeof import("node:path") | null {
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  return typeof require !== "undefined" ? (require("node:path") as typeof import("node:path")) : null;
}

export interface StorageTableHandler {
  loadTable(name: string, dbName?: string): DbTable | null;
  saveTable(table: DbTable, dbName?: string): string;
  getTablePath(name: string, dbName?: string): string;
  getDatabaseDir(dbName?: string): string;
}

/**
 * Merge tables from physical :memory: directory into target database and delete :memory: folder
 */
export function mergeMemoryIntoStorage(
  storage: StorageTableHandler,
  targetDbName = "default"
): LcLocalDbMergeMemoryResult {
  const mergedTables: string[] = [];
  let deletedMemoryDir = false;

  if (!isNodeEnv()) return { mergedTables, deletedMemoryDir };

  try {
    const fs = getFs();
    const path = getPath();
    if (!fs || !path) return { mergedTables, deletedMemoryDir };

    const memoryDir = path.resolve(process.cwd(), ":memory:");
    if (fs.existsSync(memoryDir)) {
      const files = fs.readdirSync(memoryDir);
      for (const file of files) {
        if (!file.endsWith(".dblc") && !file.endsWith(".db.lc")) continue;
        const tableName = file.replace(/\.(dblc|db\.lc)$/i, "");
        const memoryFilePath = path.join(memoryDir, file);
        const memoryRaw = fs.readFileSync(memoryFilePath, "utf8");
        const memoryParsed = parseDblcSql(memoryRaw, tableName);

        const existingTable = storage.loadTable(tableName, targetDbName);

        const mergedRecords = { ...(existingTable?.records ?? {}) };
        for (const [key, rec] of Object.entries(memoryParsed.records ?? {})) {
          if (!mergedRecords[key]) {
            mergedRecords[key] = rec;
          } else {
            const existingRec = mergedRecords[key];
            const memoryRec = rec;
            if (
              (memoryRec.version ?? 0) >= (existingRec.version ?? 0) ||
              (memoryRec.updatedAt && (!existingRec.updatedAt || memoryRec.updatedAt >= existingRec.updatedAt))
            ) {
              mergedRecords[key] = memoryRec;
            }
          }
        }

        const mergedRelationships = [
          ...(existingTable?.relationships ?? []),
          ...(memoryParsed.relationships ?? []).filter(
            (r) =>
              !existingTable?.relationships?.some(
                (er) =>
                  er.sourceField === r.sourceField &&
                  er.targetTable === r.targetTable &&
                  er.targetField === r.targetField
              )
          ),
        ];

        const mergedRelations = {
          ...(existingTable?.relations ?? {}),
          ...(memoryParsed.relations ?? {}),
        };

        const mergedTable: DbTable = {
          namespace: tableName,
          records: mergedRecords,
          relationships: mergedRelationships,
          relations: mergedRelations,
          schema: existingTable?.schema,
          createdAt: existingTable?.createdAt ?? new Date().toISOString(),
        };

        storage.saveTable(mergedTable, targetDbName);
        mergedTables.push(tableName);
      }

      fs.rmSync(memoryDir, { recursive: true, force: true });
      deletedMemoryDir = true;
    }
  } catch {
    // Ignore error
  }

  return { mergedTables, deletedMemoryDir };
}

/**
 * Auto-migrate from legacy .Cache/localdb.json or _lc_localdb localStorage
 */
export function migrateLegacyCacheStore(
  storage: StorageTableHandler
): Record<string, DbTable> | null {
  if (isBrowserEnv()) {
    try {
      const raw = localStorage.getItem(LEGACY_LS_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as Record<string, { namespace: string; records: any; createdAt: string }>;
        const migrated: Record<string, DbTable> = {};
        for (const [ns, tbl] of Object.entries(parsed)) {
          const table: DbTable = {
            namespace: ns,
            records: tbl.records ?? {},
            relationships: [],
            relations: {},
            createdAt: tbl.createdAt ?? new Date().toISOString(),
          };
          migrated[ns] = table;
          storage.saveTable(table);
        }
        return migrated;
      }
    } catch {
      return null;
    }
  }

  if (isNodeEnv()) {
    try {
      const fs: typeof import("node:fs") | null = getFs();
      const path: typeof import("node:path") | null = getPath();
      if (!fs || !path) return null;
      const legacyPath: string = path.resolve(process.cwd(), LEGACY_CACHE_FILE);
      if (fs.existsSync(legacyPath)) {
        const raw: string = fs.readFileSync(legacyPath, "utf8");
        const parsed: Record<string, { namespace: string; records: Record<string, unknown>; createdAt: string }> = JSON.parse(raw);
        const migrated: Record<string, DbTable> = {};
        for (const [ns, tbl] of Object.entries(parsed)) {
          const normalizedRecords: Record<string, import("./lc-types").LcLocalDbRecord> = {};
          for (const [recKey, rawRec] of Object.entries(tbl.records ?? {})) {
            const recObj: Record<string, unknown> = (rawRec && typeof rawRec === "object") ? (rawRec as Record<string, unknown>) : { value: rawRec };
            const recKeyStr: string = String(recObj.key || recObj.id || recKey);
            normalizedRecords[recKeyStr] = {
              key: recKeyStr,
              namespace: ns as never,
              value: "value" in recObj ? recObj.value : recObj,
              createdAt: (recObj.createdAt as string) || new Date().toISOString(),
              updatedAt: (recObj.updatedAt as string) || new Date().toISOString(),
              ttlMs: (recObj.ttlMs as number) || null,
              version: (recObj.version as number) || 1,
              tags: Array.isArray(recObj.tags) ? (recObj.tags as string[]) : ["migrated-cache"],
            };
          }
          const table: DbTable = {
            namespace: ns,
            records: normalizedRecords,
            relationships: [],
            relations: {},
            createdAt: tbl.createdAt ?? new Date().toISOString(),
          };
          migrated[ns] = table;
          storage.saveTable(table);
        }
        // Remove .Cache/localdb.json and remove .Cache directory
        try {
          fs.unlinkSync(legacyPath);
          const cacheDir: string = path.dirname(legacyPath);
          if (fs.existsSync(cacheDir)) {
            const remaining: string[] = fs.readdirSync(cacheDir);
            if (remaining.length === 0) {
              fs.rmdirSync(cacheDir);
            } else {
              fs.rmSync(cacheDir, { recursive: true, force: true });
            }
          }
        } catch {
          // Ignore removal error
        }
        return migrated;
      }
    } catch {
      return null;
    }
  }

  return null;
}

export interface MigrateCacheResult {
  readonly migratedKeysCount: number;
  readonly removedFiles: string[];
  readonly deletedCacheDir: boolean;
}

/**
 * Scan for .Cache directories, migrate any cached data into LocalSQLServer,
 * and remove the .Cache file/directory.
 */
export function migrateDotCacheDirectoryToLocalSql(
  storage: StorageTableHandler,
  baseDir: string = process.cwd()
): MigrateCacheResult {
  const result: {
    migratedKeysCount: number;
    removedFiles: string[];
    deletedCacheDir: boolean;
  } = {
    migratedKeysCount: 0,
    removedFiles: [],
    deletedCacheDir: false,
  };

  if (!isNodeEnv()) return result;

  try {
    const fs: typeof import("node:fs") | null = getFs();
    const path: typeof import("node:path") | null = getPath();
    if (!fs || !path) return result;

    const cacheDir: string = path.resolve(baseDir, ".Cache");
    if (!fs.existsSync(cacheDir)) return result;

    const entries: string[] = fs.readdirSync(cacheDir);
    for (const file of entries) {
      const fullPath: string = path.join(cacheDir, file);
      try {
        const stat: import("node:fs").Stats = fs.statSync(fullPath);
        if (stat.isFile() && file.endsWith(".json")) {
          const content: string = fs.readFileSync(fullPath, "utf8");
          const parsed: unknown = JSON.parse(content);

          if (typeof parsed === "object" && parsed !== null) {
            let isTableFormat: boolean = false;
            for (const v of Object.values(parsed as Record<string, unknown>)) {
              if (v && typeof v === "object" && ("records" in v || "namespace" in v)) {
                isTableFormat = true;
                break;
              }
            }

            if (isTableFormat) {
              for (const [ns, tbl] of Object.entries(parsed as Record<string, { records?: Record<string, unknown>; createdAt?: string }>)) {
                const normalizedRecords: Record<string, import("./lc-types").LcLocalDbRecord> = {};
                for (const [recKey, rawRec] of Object.entries(tbl.records ?? {})) {
                  const recObj: Record<string, unknown> = (rawRec && typeof rawRec === "object") ? (rawRec as Record<string, unknown>) : { value: rawRec };
                  const recKeyStr: string = String(recObj.key || recObj.id || recKey);
                  normalizedRecords[recKeyStr] = {
                    key: recKeyStr,
                    namespace: ns as never,
                    value: "value" in recObj ? recObj.value : recObj,
                    createdAt: (recObj.createdAt as string) || new Date().toISOString(),
                    updatedAt: (recObj.updatedAt as string) || new Date().toISOString(),
                    ttlMs: (recObj.ttlMs as number) || null,
                    version: (recObj.version as number) || 1,
                    tags: Array.isArray(recObj.tags) ? (recObj.tags as string[]) : ["migrated-cache"],
                  };
                }
                const table: DbTable = {
                  namespace: ns,
                  records: normalizedRecords,
                  relationships: [],
                  relations: {},
                  createdAt: tbl.createdAt ?? new Date().toISOString(),
                };
                storage.saveTable(table);
                result.migratedKeysCount += Object.keys(table.records).length;
              }
            } else {
              // General key-value cache: migrate to lc_cache table in LocalSQLServer
              const cacheTable: DbTable = storage.loadTable("lc_cache") || {
                namespace: "lc_cache",
                records: {},
                relationships: [],
                relations: {},
                createdAt: new Date().toISOString(),
              };
              for (const [key, val] of Object.entries(parsed as Record<string, unknown>)) {
                cacheTable.records[key] = {
                  key,
                  namespace: "lc_cache" as never,
                  value: val,
                  createdAt: new Date().toISOString(),
                  updatedAt: new Date().toISOString(),
                  ttlMs: null,
                  version: 1,
                  tags: ["migrated-cache"],
                };
                result.migratedKeysCount += 1;
              }
              storage.saveTable(cacheTable);
            }
          }
          fs.unlinkSync(fullPath);
          result.removedFiles.push(file);
        } else if (stat.isFile()) {
          fs.unlinkSync(fullPath);
          result.removedFiles.push(file);
        }
      } catch {
        try {
          if (fs.existsSync(fullPath)) {
            fs.unlinkSync(fullPath);
            result.removedFiles.push(file);
          }
        } catch {
          // Ignore
        }
      }
    }

    if (fs.existsSync(cacheDir)) {
      const remaining: string[] = fs.readdirSync(cacheDir);
      if (remaining.length === 0) {
        fs.rmdirSync(cacheDir);
        result.deletedCacheDir = true;
      } else {
        fs.rmSync(cacheDir, { recursive: true, force: true });
        result.deletedCacheDir = true;
      }
    }
  } catch {
    // Ignore
  }

  return result;
}

/**
 * Synchronize backward-compatible legacy localStorage JSON structure
 */
export function syncLegacyLocalStorageStore(table: DbTable): void {
  if (!isBrowserEnv()) return;
  try {
    const raw = localStorage.getItem(LEGACY_LS_KEY);
    const parsed: InternalDb = raw ? JSON.parse(raw) : {};
    parsed[table.namespace] = table;
    localStorage.setItem(LEGACY_LS_KEY, JSON.stringify(parsed));
  } catch {
    // Ignore
  }
}

/**
 * Scan database directories and migrate any legacy .db.lc files to .dblc format
 */
export function migrateAllDbLcToDblcFiles(
  storage: StorageTableHandler,
  storageDir: string,
  dbName = "default"
): string[] {
  const migrated: string[] = [];
  if (!isNodeEnv()) return migrated;

  try {
    const fs = getFs();
    const path = getPath();
    if (!fs || !path) return migrated;

    const dbDir = storage.getDatabaseDir ? storage.getDatabaseDir(dbName) : path.resolve(process.cwd(), storageDir, "schema", dbName);
    const dirsToCheck = [
      dbDir,
      path.resolve(process.cwd(), storageDir, "schema", dbName),
      path.resolve(process.cwd(), storageDir, "tables", dbName),
      path.resolve(process.cwd(), storageDir, "schema", "databases", dbName),
      path.resolve(process.cwd(), storageDir, "values", "databases", dbName),
      path.resolve(process.cwd(), storageDir, "values", dbName),
    ];
    for (const d of dirsToCheck) {
      if (!fs.existsSync(d)) continue;
      for (const file of fs.readdirSync(d)) {
        if (file.endsWith(".db.lc")) {
          const cleanName = file.slice(0, -".db.lc".length);
          const legacyPath = path.join(d, file);
          const raw = fs.readFileSync(legacyPath, "utf8");
          const parsed = parseDblcSql(raw, cleanName);
          const table: DbTable = {
            namespace: parsed.tableName || cleanName,
            records: parsed.records,
            relationships: parsed.relationships,
            relations: parsed.relations,
            createdAt: new Date().toISOString(),
          };
          storage.saveTable(table, dbName);
          try { fs.unlinkSync(legacyPath); } catch {}
          if (!migrated.includes(cleanName)) migrated.push(cleanName);
        }
      }
    }

    if (dbName === "default") {
      const rootDir = path.resolve(process.cwd(), storageDir);
      if (fs.existsSync(rootDir)) {
        for (const file of fs.readdirSync(rootDir)) {
          if (file.endsWith(".db.lc")) {
            const cleanName = file.slice(0, -".db.lc".length);
            const legacyPath = path.join(rootDir, file);
            const raw = fs.readFileSync(legacyPath, "utf8");
            const parsed = parseDblcSql(raw, cleanName);
            const table: DbTable = {
              namespace: parsed.tableName || cleanName,
              records: parsed.records,
              relationships: parsed.relationships,
              relations: parsed.relations,
              createdAt: new Date().toISOString(),
            };
            storage.saveTable(table, "default");
            try { fs.unlinkSync(legacyPath); } catch {}
            if (!migrated.includes(cleanName)) migrated.push(cleanName);
          }
        }
      }
    }
  } catch {}

  return migrated;
}
