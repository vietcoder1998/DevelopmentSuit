/**
 * packages/LocalSQLServer/sources/engine/lc-local-db-engine.ts
 * LcLocalDb SQL Engine — Local relational database engine
 */

import {
    LC_LOCAL_DB_DEFAULT_NAMESPACES,
    deepGet,
    estimateSizeBytes,
    isExpired,
    matchesWhere,
    nowIso as now,
    type DbTable,
    type InternalDb,
    type LcDatabaseFileInfo,
    type LcLocalDbColumnDef,
    type LcLocalDbDump,
    type LcLocalDbMergeMemoryResult,
    type LcLocalDbNamespace,
    type LcLocalDbQueryOptions,
    type LcLocalDbRecord,
    type LcLocalDbRelationData,
    type LcLocalDbRelationship,
    type LcLocalDbSetOptions,
    type LcLocalDbStats,
    type LcLocalDbTableSchema,
    type LcLocalDbTableStats
} from "./lc-types";

import {
    parseDblcSql,
    parseSqlValues,
    serializeTableSchemaToDblc,
    serializeTableToDblc,
    serializeTableValuesToDblc,
    type ParsedDbLcResult,
    type ParsedDblcResult
} from "./lc-sql-serializer";

import { RelationshipManager } from "./lc-relationship-manager";
import { StorageAdapter, isNode } from "./lc-storage-adapter";
import {
  hydroelectricEngine,
  HydroelectricEngine,
  type HydroelectricStreamOptions,
  type HydroelectricStreamResult,
} from "./hydroelectric-engine";

// Re-export all types and constants for consumer convenience
export * from "./lc-types";
export * from "./lc-legacy-migrator";
export * from "./lc-relationship-manager";
export * from "./lc-sql-serializer";
export * from "./lc-storage-adapter";

const ENGINE_VERSION = "1.0.0";


export class LcLocalDbEngine {
  private _db: InternalDb;
  private _initialized = false;
  private _storage: StorageAdapter;
  private _lastVacuumedAt: string | null = null;

  constructor(storageDirOrAdapter?: string | StorageAdapter, databaseName: string = "default") {
    if (storageDirOrAdapter instanceof StorageAdapter) {
      this._storage = storageDirOrAdapter;
    } else {
      this._storage = new StorageAdapter(storageDirOrAdapter, databaseName);
    }
    this._db = {};
    if (isNode() && !this._storage.isMemoryOnly) {
      this._storage.mergeMemoryIntoLocalDb();
      this._storage.migrateLegacyDatabasesDirectories();
      this._storage.cleanRootDblcFiles();
    }
  }

  // ── Storage Configuration ──────────────────────────────────────────────────

  public get storageAdapter(): StorageAdapter {
    return this._storage;
  }

  public get storageDir(): string {
    return this._storage.storageDir;
  }

  public set storageDir(dir: string) {
    this._storage.storageDir = dir;
  }

  // ── Multi-Database Management (Section 566) ────────────────────────────────

  public get currentDatabase(): string {
    return this._storage.currentDatabase;
  }

  public get databaseName(): string {
    return this._storage.databaseName;
  }

  public set databaseName(name: string) { this._storage.databaseName = name; }
  public useDatabase(name: string): this {
    this._storage.useDatabase(name);
    this._loadFromStorage();
    return this;
  }
  public listDatabases(): string[] { return this._storage.listDatabases(); }
  public createDatabase(name: string): boolean { return this._storage.createDatabase(name); }
  public dropDatabase(name: string): boolean {
    if (name === this._storage.currentDatabase) this.useDatabase("default");
    return this._storage.dropDatabase(name);
  }
  public mergeMemoryIntoLocalDb(targetDbName?: string): LcLocalDbMergeMemoryResult {
    return this._storage.mergeMemoryIntoLocalDb(targetDbName);
  }
  public syncRootTablesToDefaultDatabase(): string[] { return this._storage.syncRootTablesToDefaultDatabase(); }

  // ── Lifecycle ──────────────────────────────────────────────────────────────

  public async init(): Promise<void> {
    if (this._initialized) return;
    this._loadFromStorage();
    this._initialized = true;
  }

  private _loadFromStorage(): void {
    const ts: string = now();
    const newDb: InternalDb = {};
    const loaded: Record<string, DbTable> = this._storage.loadAllTables();
    for (const [ns, table] of Object.entries(loaded)) {
      newDb[ns] = {
        namespace: ns,
        records: { ...(table.records || {}) },
        relationships: [...(table.relationships ?? [])],
        relations: { ...(table.relations ?? {}) },
        createdAt: table.createdAt || ts,
        schema: table.schema,
      };
    }
    this._db = newDb;
  }

  public resolveTableName(name: string): string {
    const cleanName: string = this._storage.normalizeTableName(name).replace(/[`"']/g, "").trim();
    if (this._db[cleanName]) return cleanName;
    const lower: string = cleanName.toLowerCase();
    for (const k of Object.keys(this._db)) {
      if (k.toLowerCase() === lower) return k;
    }
    const storageTables: string[] = this._storage.listTableNames(this._storage.databaseName);
    for (const st of storageTables) {
      if (st.toLowerCase() === lower) return st;
    }
    return cleanName;
  }

  private _ensureTable(tableName: string): DbTable {
    const cleanName: string = this.resolveTableName(tableName);
    if (!this._db[cleanName]) {
      const loaded: DbTable | null = this._storage.loadTable(cleanName);
      if (loaded) {
        this._db[cleanName] = loaded;
        return loaded;
      }
      this._db[cleanName] = {
        namespace: cleanName,
        records: {},
        relationships: [],
        relations: {},
        createdAt: now(),
      };
    }
    return this._db[cleanName];
  }

  private _persistTable(tableName: string): void {
    const cleanName: string = this.resolveTableName(tableName);
    const table: DbTable | undefined = this._db[cleanName];
    if (table) {
      this._storage.saveTable(table);
    }
  }

  private _persistAll(): void {
    for (const table of Object.values(this._db)) {
      this._storage.saveTable(table);
    }
  }

  // ── Table Management ───────────────────────────────────────────────────────

  public createTable(name: string, schema?: Partial<LcLocalDbTableSchema>): boolean {
    const cleanName: string = this._storage.normalizeTableName(name);
    if (this._db[cleanName]) {
      if (schema && !this._db[cleanName].schema) {
        this._db[cleanName].schema = { tableName: cleanName, columns: schema.columns ?? {}, ...schema };
        this._persistTable(cleanName);
      }
      return false;
    }
    this._db[cleanName] = {
      namespace: cleanName,
      records: {},
      relationships: schema?.relationships ?? [],
      relations: {},
      schema: schema ? { tableName: cleanName, columns: schema.columns ?? {}, ...schema } : undefined,
      createdAt: now(),
    };
    this._persistTable(cleanName);
    return true;
  }

  public dropTable(name: string): boolean {
    const cleanName: string = this._storage.normalizeTableName(name);
    const inMem: boolean = Boolean(this._db[cleanName]);
    const inStorage: boolean = this._storage.hasTableFile(cleanName);
    if (!inMem && !inStorage) return false;
    delete this._db[cleanName];
    this._storage.deleteTable(cleanName);
    return true;
  }

  public renameTable(oldName: string, newName: string): boolean {
    const cleanOld: string = this._storage.normalizeTableName(oldName);
    const cleanNew: string = this._storage.normalizeTableName(newName);
    if (!this.hasTable(cleanOld) || this.hasTable(cleanNew)) {
      return false;
    }
    const table: DbTable = this._ensureTable(cleanOld);
    const updatedRecords: Record<string, LcLocalDbRecord> = {};
    for (const [k, rec] of Object.entries(table.records)) {
      updatedRecords[k] = { ...rec, namespace: cleanNew };
    }
    this._db[cleanNew] = {
      ...table,
      namespace: cleanNew,
      records: updatedRecords,
      schema: table.schema ? { ...table.schema, tableName: cleanNew } : undefined,
    };
    this._storage.saveTable(this._db[cleanNew]);
    this.dropTable(cleanOld);
    return true;
  }

  public getTableNames(dbName?: string): string[] {
    const targetDb: string = dbName || this.databaseName || "default";
    if (dbName && dbName !== this.databaseName) {
      this.useDatabase(dbName);
    }
    const fromStorage: string[] = this._storage.listTableNames(targetDb);
    const tableNamesSet: Set<string> = new Set<string>(fromStorage);

    for (const [rawName, table] of Object.entries(this._db)) {
      const cleanName: string = this._storage.normalizeTableName(rawName);
      const hasSchema: boolean = Boolean(table?.schema);
      const hasRecords: boolean = Object.keys(table?.records || {}).length > 0;
      if (hasSchema || hasRecords || fromStorage.includes(cleanName)) {
        tableNamesSet.add(cleanName);
      }
    }

    return Array.from(tableNamesSet);
  }

  public hasTable(name: string): boolean {
    const cleanName: string = this.resolveTableName(name);
    if (this._db[cleanName]) {
      const targetTable: DbTable = this._db[cleanName];
      if (targetTable.schema || Object.keys(targetTable.records || {}).length > 0 || this._storage.hasTableFile(cleanName)) {
        return true;
      }
    }
    const loaded: DbTable | null = this._storage.loadTable(cleanName);
    if (loaded) {
      this._db[cleanName] = loaded;
      return true;
    }
    return false;
  }

  // ── Core CRUD ─────────────────────────────────────────────────────────────

  public set<T = unknown>(
    namespace: LcLocalDbNamespace,
    key: string,
    value: T,
    opts: LcLocalDbSetOptions = {}
  ): LcLocalDbRecord<T> {
    const table = this._ensureTable(namespace);
    const existing = table.records[key] as LcLocalDbRecord<T> | undefined;
    const ts = now();
    const record: LcLocalDbRecord<T> = {
      key,
      namespace,
      value,
      createdAt: existing?.createdAt ?? ts,
      updatedAt: ts,
      ttlMs: opts.ttlMs !== undefined ? opts.ttlMs : existing?.ttlMs ?? null,
      version: (existing?.version ?? 0) + 1,
      tags: opts.tags ?? existing?.tags,
    };
    table.records[key] = record as LcLocalDbRecord;
    this._persistTable(namespace);
    return record;
  }

  public get<T = unknown>(namespace: LcLocalDbNamespace, key: string): T | null {
    const table = this._ensureTable(namespace);
    const record = table.records[key] as LcLocalDbRecord<T> | undefined;
    if (!record || isExpired(record)) return null;
    return record.value;
  }

  public getRecord<T = unknown>(namespace: LcLocalDbNamespace, key: string): LcLocalDbRecord<T> | null {
    const table = this._ensureTable(namespace);
    const record = table.records[key] as LcLocalDbRecord<T> | undefined;
    if (!record || isExpired(record)) return null;
    return record;
  }

  public getAll<T = unknown>(
    namespace: LcLocalDbNamespace,
    opts: Pick<LcLocalDbQueryOptions, "includeExpired"> = {}
  ): LcLocalDbRecord<T>[] {
    const table = this._ensureTable(namespace);
    return Object.values(table.records).filter(
      (r) => opts.includeExpired || !isExpired(r)
    ) as LcLocalDbRecord<T>[];
  }

  /**
   * Alias for getAll, providing backwards compatibility for consumers expecting a list() method
   */
  public list<T = unknown>(
    namespace: LcLocalDbNamespace,
    opts: Pick<LcLocalDbQueryOptions, "includeExpired"> = {}
  ): LcLocalDbRecord<T>[] {
    return this.getAll<T>(namespace, opts);
  }

  public query<T = unknown>(
    namespace: LcLocalDbNamespace,
    options: LcLocalDbQueryOptions = {}
  ): LcLocalDbRecord<T>[] {
    let records = this.getAll<T>(namespace, { includeExpired: options.includeExpired });

    if (options.where && Object.keys(options.where).length > 0) {
      records = records.filter((r) => matchesWhere(r, options.where!));
    }

    if (options.tags && options.tags.length > 0) {
      records = records.filter(
        (r) => r.tags && options.tags!.some((tag) => r.tags!.includes(tag))
      );
    }

    if (options.orderBy) {
      const { field, direction = "asc" } = options.orderBy;
      records = [...records].sort((a, b) => {
        const aVal = String(deepGet(a, field) ?? "");
        const bVal = String(deepGet(b, field) ?? "");
        return direction === "asc" ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
      });
    }

    const offset = options.offset ?? 0;
    const sliced = records.slice(offset);
    return options.limit != null ? sliced.slice(0, options.limit) : sliced;
  }

  public has(namespace: LcLocalDbNamespace, key: string): boolean {
    return this.get(namespace, key) !== null;
  }

  public keys(namespace: LcLocalDbNamespace): string[] {
    return this.getAll(namespace).map((r) => r.key);
  }

  public count(namespace?: LcLocalDbNamespace): number {
    if (namespace) return this.getAll(namespace).length;
    return Object.keys(this._db).reduce((sum, ns) => sum + this.getAll(ns).length, 0);
  }

  public delete(namespace: LcLocalDbNamespace, key: string): boolean {
    const table = this._db[namespace];
    if (!table || !table.records[key]) return false;
    delete table.records[key];
    this._persistTable(namespace);
    return true;
  }

  public clear(namespace?: LcLocalDbNamespace): void {
    if (namespace) {
      if (this._db[namespace]) {
        this._db[namespace].records = {};
        this._persistTable(namespace);
      }
    } else {
      for (const ns of Object.keys(this._db)) {
        this._db[ns].records = {};
      }
      this._persistAll();
    }
  }

  public transaction(fn: (db: this) => void): void {
    fn(this);
    this._persistAll();
  }

  public vacuum(): number {
    let removed = 0;
    for (const ns of Object.keys(this._db)) {
      const table = this._db[ns];
      let tableChanged = false;
      for (const key of Object.keys(table.records)) {
        if (isExpired(table.records[key])) {
          delete table.records[key];
          removed++;
          tableChanged = true;
        }
      }
      if (tableChanged) this._persistTable(ns);
    }
    this._lastVacuumedAt = now();
    return removed;
  }

  // ── Relationships & Link Data API ──────────────────────────────────────────

  public defineRelationship(
    rel: Omit<LcLocalDbRelationship, "id" | "createdAt" | "updatedAt"> & { id?: string }
  ): LcLocalDbRelationship {
    const table = this._ensureTable(rel.sourceTable);
    const created = RelationshipManager.defineRelationship(table, rel);
    this._persistTable(rel.sourceTable);
    return created;
  }

  public getRelationships(tableName?: string): LcLocalDbRelationship[] {
    if (tableName) {
      return this._db[tableName]?.relationships ?? [];
    }
    const all: LcLocalDbRelationship[] = [];
    for (const tbl of Object.values(this._db)) {
      if (tbl.relationships) all.push(...tbl.relationships);
    }
    return all;
  }

  public removeRelationship(relationshipId: string, tableName?: string): boolean {
    if (tableName) {
      const table = this._db[tableName];
      if (!table) return false;
      const res = RelationshipManager.removeRelationship(table, relationshipId);
      if (res) this._persistTable(tableName);
      return res;
    }
    for (const tbl of Object.values(this._db)) {
      if (RelationshipManager.removeRelationship(tbl, relationshipId)) {
        this._persistTable(tbl.namespace);
        return true;
      }
    }
    return false;
  }

  public linkRecords(
    sourceTable: string,
    recordKey: string,
    targetTable: string,
    targetKey: string,
    relationType = "1:N",
    metadata?: unknown
  ): LcLocalDbRelationData {
    const table = this._ensureTable(sourceTable);
    const link = RelationshipManager.linkRecords(
      table,
      recordKey,
      targetTable,
      targetKey,
      relationType,
      metadata
    );
    this._persistTable(sourceTable);
    return link;
  }

  public unlinkRecords(
    sourceTable: string,
    recordKey: string,
    targetTable: string,
    targetKey: string
  ): boolean {
    const table = this._db[sourceTable];
    if (!table) return false;
    const res = RelationshipManager.unlinkRecords(table, recordKey, targetTable, targetKey);
    if (res) this._persistTable(sourceTable);
    return res;
  }

  public getRelatedRecords(
    sourceTable: string,
    recordKey: string,
    targetTable?: string
  ): Array<{ relation: LcLocalDbRelationData; targetRecord: LcLocalDbRecord | null }> {
    const table = this._db[sourceTable];
    if (!table) return [];
    return RelationshipManager.getRelatedRecords(
      table,
      recordKey,
      (tbl, key) => this.getRecord(tbl, key),
      targetTable
    );
  }

  public autoDetectRelationships(tableName?: string): LcLocalDbRelationship[] {
    const known = this.getTableNames();
    if (tableName) {
      const clean = this._storage.normalizeTableName(tableName);
      const table = this._db[clean] ?? this._storage.loadTable(clean);
      if (!table) return [];
      return RelationshipManager.autoDetectRelationships(clean, table.records, known);
    }
    const detected: LcLocalDbRelationship[] = [];
    for (const name of known) {
      const tbl = this._db[name] ?? this._storage.loadTable(name);
      if (tbl) {
        detected.push(...RelationshipManager.autoDetectRelationships(name, tbl.records, known));
      }
    }
    return detected;
  }

  // ── {table-name}.dblc File I/O ───────────────────────────────────────────

  public serializeTableToDblc(tableName: string): string {
    return serializeTableToDblc(this._ensureTable(this._storage.normalizeTableName(tableName)), ENGINE_VERSION);
  }
  public serializeTableToDbLc(tableName: string): string { return this.serializeTableToDblc(tableName); }
  public parseDblcSql(sql: string, fallbackTableName?: string): ParsedDblcResult { return parseDblcSql(sql, fallbackTableName); }
  public parseDbLcSql(sql: string, fallbackTableName?: string): ParsedDbLcResult { return parseDblcSql(sql, fallbackTableName); }
  public saveTable(tableName: string): string { return this._storage.saveTable(this._ensureTable(this._storage.normalizeTableName(tableName))); }

  public loadTable(tableName: string): boolean {
    const cleanName = this._storage.normalizeTableName(tableName);
    const loaded = this._storage.loadTable(cleanName);
    if (!loaded) return false;
    this._db[cleanName] = loaded;
    return true;
  }

  public saveAll(): string[] {
    const paths: string[] = [];
    for (const tbl of Object.values(this._db)) {
      paths.push(this._storage.saveTable(tbl));
    }
    return paths;
  }

  public saveToStorage(): string[] {
    return this.saveAll();
  }

  public loadAll(): string[] {
    this._loadFromStorage();
    return Object.keys(this._db);
  }

  public exportTableDblc(tableName: string): string { return this.serializeTableToDblc(tableName); }
  public exportTableDbLc(tableName: string): string { return this.serializeTableToDblc(tableName); }
  public exportTableSchemaDblc(tableName: string): string {
    const table = this._ensureTable(tableName);
    return serializeTableSchemaToDblc(table);
  }
  public exportTableValuesDblc(tableName: string): string {
    const table = this._ensureTable(tableName);
    return serializeTableValuesToDblc(table);
  }
  public migrateAllToDblc(dbName?: string): string[] { return this._storage.migrateAllDbLcToDblc(dbName); }
  public getTablePath(tableName: string, dbName?: string): string { return this._storage.getTablePath(tableName, dbName); }
  public getTableSchemaPath(tableName: string, dbName?: string): string { return this._storage.getTableSchemaPath(tableName, dbName); }
  public getTableTablesPath(tableName: string, dbName?: string): string { return this._storage.getTableTablesPath(tableName, dbName); }
  public getTableValuesPath(tableName: string, dbName?: string): string { return this._storage.getTableValuesPath(tableName, dbName); }
  public getTableDisplaySchemaPath(tableName: string, dbName?: string): string { return this._storage.getTableDisplaySchemaPath(tableName, dbName); }
  public getTableDisplayTablesPath(tableName: string, dbName?: string): string { return this._storage.getTableDisplayTablesPath(tableName, dbName); }
  public getTableDisplayValuesPath(tableName: string, dbName?: string): string { return this._storage.getTableDisplayValuesPath(tableName, dbName); }
  public hasTableSchemaFile(tableName: string, dbName?: string): boolean { return this._storage.hasTableSchemaFile(tableName, dbName); }
  public hasTableTablesFile(tableName: string, dbName?: string): boolean { return this._storage.hasTableTablesFile(tableName, dbName); }
  public hasTableValuesFile(tableName: string, dbName?: string): boolean { return this._storage.hasTableValuesFile(tableName, dbName); }
  public listDatabaseFiles(dbName?: string): LcDatabaseFileInfo[] { return this._storage.listDatabaseFiles(dbName); }
  public cleanRootDblcFiles(): { migrated: string[]; removed: string[] } { return this._storage.cleanRootDblcFiles(); }
  public migrateLegacyDatabasesDirectories(): { migratedDatabases: string[]; tablesMigrated: string[] } { return this._storage.migrateLegacyDatabasesDirectories(); }
  public syncAllDatabaseValues(dbName?: string): string[] {
    const targetDb = dbName || this._storage.currentDatabase;
    const tableNames = this._storage.listTableNames(targetDb);
    const syncedTables: string[] = [];
    for (const tableName of tableNames) {
      const table = this._storage.loadTable(tableName, targetDb);
      if (table) {
        this._storage.saveTable(table, targetDb);
        syncedTables.push(tableName);
      }
    }
    return syncedTables;
  }

  public importTableDblc(sql: string): {
    tableName: string;
    importedRecords: number;
    importedRelationships: number;
    importedRelations: number;
  } {
    const parsed = parseDblcSql(sql);
    const table = this._ensureTable(parsed.tableName);

    const recordCount = Object.keys(parsed.records).length;
    table.records = { ...table.records, ...parsed.records };

    const relCount = parsed.relationships.length;
    for (const rel of parsed.relationships) {
      RelationshipManager.defineRelationship(table, rel);
    }

    const linksCount = Object.keys(parsed.relations).length;
    table.relations = { ...table.relations, ...parsed.relations };

    this._persistTable(parsed.tableName);

    return {
      tableName: parsed.tableName,
      importedRecords: recordCount,
      importedRelationships: relCount,
      importedRelations: linksCount,
    };
  }

  public importTableDbLc(sql: string) { return this.importTableDblc(sql); }


  // ── Global Dump / Restore / SQL ────────────────────────────────────────────

  public dump(): LcLocalDbDump {
    const tables = Object.fromEntries(
      Object.entries(this._db).map(([ns, tbl]) => [ns, { ...tbl }])
    );
    const totalRecords = Object.values(this._db).reduce(
      (sum, tbl) => sum + Object.keys(tbl.records).length,
      0
    );
    return {
      version: 1,
      exportedAt: now(),
      engineVersion: ENGINE_VERSION,
      tables,
      totalRecords,
      totalSizeBytes: estimateSizeBytes(this._db),
    };
  }

  public restore(dump: LcLocalDbDump): void {
    if (!dump?.tables) return;
    for (const [ns, tbl] of Object.entries(dump.tables)) {
      this._db[ns] = {
        namespace: ns,
        records: tbl.records ?? {},
        relationships: tbl.relationships ?? [],
        relations: tbl.relations ?? {},
        schema: tbl.schema,
        createdAt: tbl.createdAt || now(),
      };
    }
    this._persistAll();
  }

  public exportSql(): string {
    const lines: string[] = [
      `-- LcLocalDb SQL Multi-Table Bundle v${ENGINE_VERSION}`,
      `-- Exported at: ${now()}`,
      `-- Tables: ${Object.keys(this._db).join(", ")}`,
      "",
    ];
    for (const tableName of Object.keys(this._db)) {
      lines.push(this.serializeTableToDbLc(tableName));
    }
    return lines.join("\n");
  }

  public importSql(sql: string): number {
    let imported = 0;
    const insertRe =
      /INSERT\s+(?:OR\s+REPLACE\s+)?INTO\s+([a-zA-Z0-9_-]+)\s*\([^)]+\)\s*VALUES\s*\(([^;]+)\);/gi;

    let match: RegExpExecArray | null;
    while ((match = insertRe.exec(sql)) !== null) {
      const target = match[1].trim();
      if (target.endsWith("_relationships") || target.endsWith("_relations")) {
        continue;
      }
      const vals = parseSqlValues(match[2]);
      if (vals.length < 4) continue;
      try {
        const [key, valueJson, createdAt, updatedAt, ttlMsRaw, versionRaw, tagsRaw] = vals;
        const keyStr = key.replace(/^'|'$/g, "").replace(/''/g, "'");
        const value = JSON.parse(valueJson.replace(/^'|'$/g, "").replace(/''/g, "'"));
        const ttlMs = ttlMsRaw === "NULL" ? null : Number(ttlMsRaw);
        const version = Number(versionRaw || 1);
        const tags = tagsRaw && tagsRaw !== "NULL" ? tagsRaw.replace(/^'|'$/g, "").split(",") : undefined;

        this.set(target as LcLocalDbNamespace, keyStr, value, { ttlMs, tags });
        if (version > 1) {
          const r = this.getRecord(target as LcLocalDbNamespace, keyStr);
          if (r) r.version = version;
        }
        imported++;
      } catch {
        // Skip malformed row
      }
    }
    return imported;
  }

  public getCurrentDatabase(): string {
    return this._storage.databaseName;
  }

  public getTableSchema(tableName: string): LcLocalDbTableSchema | undefined {
    const cleanName: string = this.resolveTableName(tableName);
    const table: DbTable = this._ensureTable(cleanName);
    return table.schema;
  }

  public executeSql(sql: string): unknown {
    const trimmed: string = sql.trim();
    if (!trimmed) {
      return [];
    }

    const statements: string[] = trimmed
      .split(/;\s*(?=(?:[^']*'[^']*')*[^']*$)/)
      .map((s: string): string => s.trim())
      .filter(Boolean);

    let lastResult: unknown = [];

    for (const stmt of statements) {
      const upper: string = stmt.toUpperCase();

      // 1. USE db
      const useMatch: RegExpMatchArray | null = stmt.match(/^USE\s+([a-zA-Z0-9_-]+)/i);
      if (useMatch) {
        const dbName: string = useMatch[1].trim();
        this.useDatabase(dbName);
        lastResult = [{ database: dbName, status: "switched" }];
        continue;
      }

      // 2. CREATE DATABASE
      const createDbMatch: RegExpMatchArray | null = stmt.match(/^CREATE\s+DATABASE(?:\s+IF\s+NOT\s+EXISTS)?\s+([a-zA-Z0-9_-]+)/i);
      if (createDbMatch) {
        const dbName: string = createDbMatch[1].trim();
        const created: boolean = this.createDatabase(dbName);
        lastResult = [{ database: dbName, created }];
        continue;
      }

      // 3. DROP DATABASE
      const dropDbMatch: RegExpMatchArray | null = stmt.match(/^DROP\s+DATABASE(?:\s+IF\s+EXISTS)?\s+([a-zA-Z0-9_-]+)/i);
      if (dropDbMatch) {
        const dbName: string = dropDbMatch[1].trim();
        const dropped: boolean = this.dropDatabase(dbName);
        lastResult = [{ database: dbName, dropped }];
        continue;
      }

      // 4. SHOW TABLES
      if (upper === "SHOW TABLES" || upper.startsWith("SHOW TABLES")) {
        lastResult = this.getTableNames().map((name: string): { table_name: string } => ({ table_name: name }));
        continue;
      }

      // 5. SHOW DATABASES
      if (upper === "SHOW DATABASES" || upper.startsWith("SHOW DATABASES")) {
        lastResult = this.listDatabases().map((name: string): { database_name: string } => ({ database_name: name }));
        continue;
      }

      // 6. CREATE TABLE
      const createTableMatch: RegExpMatchArray | null = stmt.match(
        /^CREATE\s+TABLE(?:\s+IF\s+NOT\s+EXISTS)?\s+([a-zA-Z0-9_-]+)\s*\(([\s\S]+)\)/i
      );
      if (createTableMatch) {
        const tableName: string = createTableMatch[1].trim();
        const columnsRaw: string = createTableMatch[2].trim();
        const columnsDef: Record<string, LcLocalDbColumnDef> = {};

        const colLines: string[] = columnsRaw.split(/,\s*(?=(?:[^']*'[^']*')*[^']*$)/);
        for (const colLine of colLines) {
          const parts: string[] = colLine.trim().split(/\s+/);
          if (parts.length >= 2) {
            const colName: string = parts[0].replace(/[`"']/g, "");
            const colType: string = parts[1].toUpperCase();
            const isPk: boolean = colLine.toUpperCase().includes("PRIMARY KEY");
            const isNotNull: boolean = colLine.toUpperCase().includes("NOT NULL");
            columnsDef[colName] = {
              type: colType,
              primaryKey: isPk,
              notNull: isNotNull,
            };
          }
        }

        const created: boolean = this.createTable(tableName, {
          tableName,
          columns: columnsDef,
        });
        lastResult = [{ table: tableName, created }];
        continue;
      }

      // 7. DROP TABLE
      const dropTableMatch: RegExpMatchArray | null = stmt.match(/^DROP\s+TABLE(?:\s+IF\s+EXISTS)?\s+([a-zA-Z0-9_-]+)/i);
      if (dropTableMatch) {
        const tableName: string = dropTableMatch[1].trim();
        const dropped: boolean = this.dropTable(tableName);
        lastResult = [{ table: tableName, dropped }];
        continue;
      }

      // 7.5. ALTER TABLE ... RENAME TO ...
      const alterRenameMatch: RegExpMatchArray | null = stmt.match(
        /^ALTER\s+TABLE\s+([a-zA-Z0-9_-]+)\s+RENAME\s+TO\s+([a-zA-Z0-9_-]+)/i
      );
      if (alterRenameMatch) {
        const oldName: string = alterRenameMatch[1].trim();
        const newName: string = alterRenameMatch[2].trim();
        const renamed: boolean = this.renameTable(oldName, newName);
        lastResult = [{ table: newName, oldName, renamed }];
        continue;
      }

      // 8. INSERT INTO
      const insertMatch: RegExpMatchArray | null = stmt.match(
        /^INSERT\s+(?:OR\s+REPLACE\s+)?INTO\s+[`"']?([a-zA-Z0-9_-]+)[`"']?(?:\s*\(([^)]+)\))?\s*VALUES\s*\(([^)]+)\)/i
      );
      if (insertMatch) {
        const rawTableName: string = insertMatch[1].trim();
        const tableName: string = this.resolveTableName(rawTableName);
        const isOrReplace: boolean = /INSERT\s+OR\s+REPLACE\s+INTO/i.test(stmt);
        const colsRaw: string | undefined = insertMatch[2]?.trim();
        const valsRaw: string = insertMatch[3].trim();
        const vals: unknown[] = valsRaw.split(/,\s*(?=(?:[^']*'[^']*')*[^']*$)/).map((v: string): unknown => {
          const t: string = v.trim();
          if ((t.startsWith("'") && t.endsWith("'")) || (t.startsWith('"') && t.endsWith('"'))) {
            return t.slice(1, -1);
          }
          if (!isNaN(Number(t))) {
            return Number(t);
          }
          if (t.toLowerCase() === "true") return true;
          if (t.toLowerCase() === "false") return false;
          if (t.toLowerCase() === "null") return null;
          return t;
        });

        const recordData: Record<string, unknown> = {};
        if (colsRaw) {
          const cols: string[] = colsRaw.split(",").map((c: string): string => c.trim().replace(/[`"']/g, ""));
          cols.forEach((col: string, idx: number): void => {
            recordData[col] = vals[idx] !== undefined ? vals[idx] : null;
          });
        } else {
          vals.forEach((val: unknown, idx: number): void => {
            recordData[`col_${idx}`] = val;
          });
        }

        const tableSchema: unknown = this.getTableSchema(tableName);
        let primaryKeyName: string = "id";
        if (tableSchema && typeof tableSchema === "object" && "columns" in tableSchema) {
          const colsMap: Record<string, LcLocalDbColumnDef> = (tableSchema as { columns: Record<string, LcLocalDbColumnDef> }).columns || {};
          for (const [colName, colDef] of Object.entries(colsMap)) {
            if (typeof colDef === "object" && colDef !== null && (colDef as { primaryKey?: boolean }).primaryKey) {
              primaryKeyName = colName;
              break;
            }
          }
        } else {
          primaryKeyName = Object.keys(recordData)[0] || "id";
        }
        const primaryKeyValue: string = String(recordData[primaryKeyName] || recordData["id"] || `rec_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`);

        if (this.has(tableName as LcLocalDbNamespace, primaryKeyValue)) {
          if (!isOrReplace) {
            throw new Error(`Duplicate primary key: record '${primaryKeyValue}' already exists in table '${tableName}'`);
          }
          const existingRec: LcLocalDbRecord | null = this.getRecord(tableName as LcLocalDbNamespace, primaryKeyValue);
          const baseVal: Record<string, unknown> =
            existingRec && existingRec.value && typeof existingRec.value === "object"
              ? (existingRec.value as Record<string, unknown>)
              : {};
          const mergedData: Record<string, unknown> = { ...baseVal, ...recordData };
          this.set(tableName as LcLocalDbNamespace, primaryKeyValue, mergedData);
          lastResult = [{ inserted: 1, updated: 1, key: primaryKeyValue }];
          continue;
        }

        this.set(tableName as LcLocalDbNamespace, primaryKeyValue, recordData);
        lastResult = [{ inserted: 1, key: primaryKeyValue }];
        continue;
      }

      // 9. UPDATE
      const updateMatch: RegExpMatchArray | null = stmt.match(
        /^UPDATE\s+[`"']?([a-zA-Z0-9_-]+)[`"']?\s+SET\s+([^W]+)(?:\s+WHERE\s+(.+))?/i
      );
      if (updateMatch) {
        const rawTableName: string = updateMatch[1].trim();
        const tableName: string = this.resolveTableName(rawTableName);
        const setClause: string = updateMatch[2].trim();
        const whereClause: string | undefined = updateMatch[3]?.trim();

        const setPairs: string[] = setClause.split(/,\s*(?=(?:[^']*'[^']*')*[^']*$)/);
        const updates: Record<string, unknown> = {};
        for (const pair of setPairs) {
          const eqIdx: number = pair.indexOf("=");
          if (eqIdx > 0) {
            const field: string = pair.slice(0, eqIdx).trim().replace(/[`"']/g, "");
            const valStr: string = pair.slice(eqIdx + 1).trim();
            if ((valStr.startsWith("'") && valStr.endsWith("'")) || (valStr.startsWith('"') && valStr.endsWith('"'))) {
              updates[field] = valStr.slice(1, -1);
            } else if (!isNaN(Number(valStr))) {
              updates[field] = Number(valStr);
            } else if (valStr.toLowerCase() === "true") {
              updates[field] = true;
            } else if (valStr.toLowerCase() === "false") {
              updates[field] = false;
            } else if (valStr.toLowerCase() === "null") {
              updates[field] = null;
            } else {
              updates[field] = valStr;
            }
          }
        }

        const allRecords: LcLocalDbRecord[] = Object.values(this._ensureTable(tableName).records);
        let updatedCount: number = 0;

        for (const rec of allRecords) {
          const rowVal: Record<string, unknown> = rec.value && typeof rec.value === "object" ? (rec.value as Record<string, unknown>) : { id: rec.key, value: rec.value };
          let matchesWhere: boolean = true;
          if (whereClause) {
            const whereEq: RegExpMatchArray | null = whereClause.match(/([a-zA-Z0-9_]+)\s*=\s*(.+)/i);
            if (whereEq) {
              const fld: string = whereEq[1].trim();
              const val: string = whereEq[2].trim().replace(/^['"]|['"]$/g, "");
              matchesWhere = String(rowVal[fld]) === val || rec.key === val;
            }
          }

          if (matchesWhere) {
            const merged: Record<string, unknown> = { ...rowVal, ...updates };
            this.set(tableName as LcLocalDbNamespace, rec.key, merged);
            updatedCount += 1;
          }
        }

        lastResult = [{ updated: updatedCount }];
        continue;
      }

      // 10. DELETE FROM
      const deleteMatch: RegExpMatchArray | null = stmt.match(
        /^DELETE\s+FROM\s+[`"']?([a-zA-Z0-9_-]+)[`"']?(?:\s+WHERE\s+(.+))?/i
      );
      if (deleteMatch) {
        const rawTableName: string = deleteMatch[1].trim();
        const tableName: string = this.resolveTableName(rawTableName);
        const whereClause: string | undefined = deleteMatch[2]?.trim();

        const allRecords: LcLocalDbRecord[] = Object.values(this._ensureTable(tableName).records);
        let deletedCount: number = 0;

        for (const rec of allRecords) {
          const rowVal: Record<string, unknown> = rec.value && typeof rec.value === "object" ? (rec.value as Record<string, unknown>) : { id: rec.key, value: rec.value };
          let matchesWhere: boolean = true;
          if (whereClause) {
            const whereIn: RegExpMatchArray | null = whereClause.match(/([a-zA-Z0-9_]+)\s+IN\s*\(([^)]+)\)/i);
            const whereEq: RegExpMatchArray | null = whereClause.match(/([a-zA-Z0-9_]+)\s*=\s*(.+)/i);
            if (whereIn) {
              const fld: string = whereIn[1].trim();
              const inVals: string[] = whereIn[2]
                .split(",")
                .map((v: string): string => v.trim().replace(/^['"]|['"]$/g, ""));
              matchesWhere = inVals.includes(String(rowVal[fld])) || inVals.includes(rec.key);
            } else if (whereEq) {
              const fld: string = whereEq[1].trim();
              const val: string = whereEq[2].trim().replace(/^['"]|['"]$/g, "");
              matchesWhere = String(rowVal[fld]) === val || rec.key === val;
            }
          }

          if (matchesWhere) {
            this.delete(tableName as LcLocalDbNamespace, rec.key);
            deletedCount += 1;
          }
        }

        lastResult = [{ deleted: deletedCount }];
        continue;
      }

      // 10.5. SELECT ... JOIN ... ON ...
      const joinMatch: RegExpMatchArray | null = stmt.match(
        /^SELECT\s+([\s\S]+?)\s+FROM\s+([a-zA-Z0-9_-]+)\s+JOIN\s+([a-zA-Z0-9_-]+)\s+ON\s+([a-zA-Z0-9_.-]+)\s*=\s*([a-zA-Z0-9_.-]+)(?:\s+WHERE\s+(.+?))?(?:\s+LIMIT\s+(\d+))?$/i
      );
      if (joinMatch) {
        const fieldsRaw: string = joinMatch[1].trim();
        const t1Name: string = this._storage.normalizeTableName(joinMatch[2].trim());
        const t2Name: string = this._storage.normalizeTableName(joinMatch[3].trim());
        const onLeft: string = joinMatch[4].trim();
        const onRight: string = joinMatch[5].trim();
        const limitCount: number | undefined = joinMatch[7] ? Number(joinMatch[7]) : undefined;

        const table1: DbTable = this._ensureTable(t1Name);
        const table2: DbTable = this._ensureTable(t2Name);
        const records1: LcLocalDbRecord[] = Object.values(table1.records);
        const records2: LcLocalDbRecord[] = Object.values(table2.records);

        const leftField: string = onLeft.includes(".") ? onLeft.split(".")[1] : onLeft;
        const rightField: string = onRight.includes(".") ? onRight.split(".")[1] : onRight;

        const joinedRows: Array<Record<string, unknown>> = [];
        for (const r1 of records1) {
          const row1: Record<string, unknown> = r1.value && typeof r1.value === "object" ? (r1.value as Record<string, unknown>) : { id: r1.key, value: r1.value };
          for (const r2 of records2) {
            const row2: Record<string, unknown> = r2.value && typeof r2.value === "object" ? (r2.value as Record<string, unknown>) : { id: r2.key, value: r2.value };
            if (String(row1[leftField]) === String(row2[rightField]) || String(row1[rightField]) === String(row2[leftField])) {
              const merged: Record<string, unknown> = { ...row1, ...row2 };
              joinedRows.push(merged);
            }
          }
        }

        const limitedRows: Array<Record<string, unknown>> = limitCount !== undefined
          ? joinedRows.slice(0, limitCount)
          : joinedRows;

        if (fieldsRaw === "*") {
          lastResult = limitedRows;
        } else {
          const requestedFields: string[] = fieldsRaw.split(",").map((f: string): string => f.trim().replace(/[`"']/g, ""));
          lastResult = limitedRows.map((row: Record<string, unknown>): Record<string, unknown> => {
            const projected: Record<string, unknown> = {};
            for (const f of requestedFields) {
              const cleanF: string = f.includes(".") ? f.split(".")[1] : f;
              projected[f] = row[cleanF] !== undefined ? row[cleanF] : (row[f] !== undefined ? row[f] : null);
            }
            return projected;
          });
        }
        continue;
      }

      // 11. SELECT
      const selectMatch: RegExpMatchArray | null = stmt.match(
        /^SELECT\s+([\s\S]+?)\s+FROM\s+([`"']?[a-zA-Z0-9_.-]+[`"']?)(?:\s+WHERE\s+(.+?))?(?:\s+ORDER\s+BY\s+([a-zA-Z0-9_]+)(?:\s+(ASC|DESC))?)?(?:\s+LIMIT\s+(\d+))?$/i
      );
      if (selectMatch) {
        const fieldsRaw: string = selectMatch[1].trim();
        const rawTableName: string = selectMatch[2].replace(/[`"']/g, "").trim();
        const cleanTableName: string = rawTableName.includes(".") ? rawTableName.split(".").pop()! : rawTableName;
        const tableName: string = this.resolveTableName(cleanTableName);
        const whereClause: string | undefined = selectMatch[3]?.trim();
        const orderByCol: string | undefined = selectMatch[4]?.trim();
        const orderDir: string = (selectMatch[5] || "ASC").toUpperCase();
        const limitCount: number | undefined = selectMatch[6] ? Number(selectMatch[6]) : undefined;

        const table: DbTable = this._ensureTable(tableName);
        const allRecords: LcLocalDbRecord[] = Object.values(table.records);
        const matchedRows: Array<Record<string, unknown>> = [];

        for (const rec of allRecords) {
          const rowVal: Record<string, unknown> =
            rec.value && typeof rec.value === "object"
              ? (rec.value as Record<string, unknown>)
              : { id: rec.key, value: rec.value };

          let matches: boolean = true;
          if (whereClause) {
            const whereComp: RegExpMatchArray | null = whereClause.match(
              /([a-zA-Z0-9_]+)\s*(<=|>=|!=|<>|<|>|=)\s*(.+)/i
            );
            if (whereComp) {
              const fld: string = whereComp[1].trim();
              const op: string = whereComp[2].trim();
              const val: string = whereComp[3].trim().replace(/^['"]|['"]$/g, "");
              const actual: unknown = rowVal[fld] !== undefined ? rowVal[fld] : (fld === "id" ? rec.key : undefined);

              if (typeof actual === "number" && !isNaN(Number(val))) {
                const targetNum: number = Number(val);
                if (op === "=") matches = actual === targetNum;
                else if (op === "!=" || op === "<>") matches = actual !== targetNum;
                else if (op === ">") matches = actual > targetNum;
                else if (op === "<") matches = actual < targetNum;
                else if (op === ">=") matches = actual >= targetNum;
                else if (op === "<=") matches = actual <= targetNum;
              } else {
                const strActual: string = String(actual !== undefined ? actual : rec.key);
                if (op === "=") matches = strActual === val || rec.key === val;
                else if (op === "!=" || op === "<>") matches = strActual !== val;
                else if (op === ">") matches = strActual > val;
                else if (op === "<") matches = strActual < val;
                else if (op === ">=") matches = strActual >= val;
                else if (op === "<=") matches = strActual <= val;
              }
            }
          }

          if (matches) {
            matchedRows.push(rowVal);
          }
        }

        if (orderByCol) {
          matchedRows.sort((a: Record<string, unknown>, b: Record<string, unknown>): number => {
            const valA: unknown = a[orderByCol];
            const valB: unknown = b[orderByCol];
            if (valA === valB) return 0;
            if (valA === undefined || valA === null) return 1;
            if (valB === undefined || valB === null) return -1;
            const diff: number = valA < valB ? -1 : 1;
            return orderDir === "DESC" ? -diff : diff;
          });
        }

        const limitedRows: Array<Record<string, unknown>> = limitCount !== undefined
          ? matchedRows.slice(0, limitCount)
          : matchedRows;

        if (fieldsRaw.toUpperCase().includes("COUNT(")) {
          lastResult = [{ count: matchedRows.length }];
          continue;
        }

        if (fieldsRaw === "*") {
          lastResult = limitedRows;
        } else {
          const requestedFields: string[] = fieldsRaw.split(",").map((f: string): string => f.trim().replace(/[`"']/g, ""));
          lastResult = limitedRows.map((row: Record<string, unknown>): Record<string, unknown> => {
            const projected: Record<string, unknown> = {};
            for (const f of requestedFields) {
              projected[f] = row[f] !== undefined ? row[f] : null;
            }
            return projected;
          });
        }
        continue;
      }

      throw new Error(`SQL syntax error or unsupported command: ${stmt}`);
    }

    return lastResult;
  }

  // ── Stats ─────────────────────────────────────────────────────────────────

  public getStats(): LcLocalDbStats {
    const tableStats: Record<string, LcLocalDbTableStats> = {};
    let totalRecords = 0;
    let totalSizeBytes = 0;

    for (const [ns, table] of Object.entries(this._db)) {
      const records = Object.values(table.records);
      const alive = records.filter((r) => !isExpired(r));
      const sizeBytes = estimateSizeBytes(table.records);
      const lastUpdated = alive.reduce<string | null>((max, r) => {
        if (!max) return r.updatedAt;
        return r.updatedAt > max ? r.updatedAt : max;
      }, null);

      tableStats[ns] = {
        recordCount: alive.length,
        sizeBytes,
        lastUpdated,
        relationshipCount: table.relationships?.length ?? 0,
        relationLinksCount: Object.keys(table.relations ?? {}).length,
      };
      totalRecords += alive.length;
      totalSizeBytes += sizeBytes;
    }

    return {
      totalRecords,
      totalSizeBytes,
      tableStats,
      backend: this._storage.detectBackend(),
      lastVacuumedAt: this._lastVacuumedAt,
      engineVersion: ENGINE_VERSION,
    };
  }

  // ── Convenience Shortcuts ──────────────────────────────────────────────────

  public setDefault(key: string, value: unknown, opts?: LcLocalDbSetOptions): LcLocalDbRecord { return this.set("lc_defaults", key, value, opts); }
  public getDefault<T = unknown>(key: string): T | null { return this.get<T>("lc_defaults", key); }
  public setProject(projectId: string, data: unknown, opts?: LcLocalDbSetOptions): LcLocalDbRecord { return this.set("lc_projects", projectId, data, opts); }
  public getProject<T = unknown>(projectId: string): T | null { return this.get<T>("lc_projects", projectId); }
  public setUiState(key: string, value: unknown, opts?: LcLocalDbSetOptions): LcLocalDbRecord { return this.set("lc_ui", key, value, opts); }
  public getUiState<T = unknown>(key: string): T | null { return this.get<T>("lc_ui", key); }
  public setCache(key: string, value: unknown, ttlMs?: number): LcLocalDbRecord {
    return this.set("lc_cache", key, value, { ttlMs });
  }
  public getCache<T = unknown>(key: string): T | null {
    return this.get<T>("lc_cache", key);
  }
  public getCacheRecord<T = unknown>(key: string): LcLocalDbRecord<T> | null {
    return this.getRecord<T>("lc_cache", key);
  }
  public hasCache(key: string): boolean {
    return this.getCache(key) !== null;
  }
  public deleteCache(key: string): boolean {
    return this.delete("lc_cache", key);
  }
  public clearCache(): number {
    const table: DbTable | undefined = this._db["lc_cache"];
    const count: number = table ? Object.keys(table.records).length : 0;
    this.clear("lc_cache");
    return count;
  }
  public getAllCache<T = unknown>(): Array<{
    key: string;
    value: T;
    createdAt: string;
    updatedAt?: string;
    ttlMs?: number | null;
  }> {
    const records: LcLocalDbRecord<T>[] = this.getAll<T>("lc_cache");
    return records.map((r: LcLocalDbRecord<T>) => ({
      key: r.key,
      value: r.value,
      createdAt: r.createdAt,
      updatedAt: r.updatedAt,
      ttlMs: r.ttlMs,
    }));
  }
  public migrateLegacyDotCache(baseDir?: string): import("./lc-legacy-migrator").MigrateCacheResult {
    return this._storage.migrateDotCache(baseDir);
  }
  public setCode(projectId: string, filePath: string, content: string, fileType?: string, opts?: LcLocalDbSetOptions): LcLocalDbRecord {
    const key = `${projectId}:${filePath}`;
    return this.set("lc_code", key, {
      projectId,
      filePath,
      content,
      fileType: fileType || "plaintext",
      sizeBytes: content.length,
      updatedAt: new Date().toISOString(),
    }, { ...opts, tags: ["code", projectId, ...(opts?.tags || [])] });
  }
  public getCode(projectId: string, filePath: string): string | null {
    const key = `${projectId}:${filePath}`;
    const rec = this.get<{ content?: string }>("lc_code", key);
    return rec?.content ?? null;
  }
  public getProjectCodeFiles(projectId: string): Record<string, string> {
    const records = this.getAll<any>("lc_code");
    const result: Record<string, string> = {};
    for (const r of records) {
      const val = (r && (r as any).value ? (r as any).value : r) || {};
      if (val && val.projectId === projectId && val.filePath) {
        result[val.filePath] = val.content;
      }
    }
    return result;
  }
  public setService(serviceId: string, serviceData: unknown, opts?: LcLocalDbSetOptions): LcLocalDbRecord {
    return this.set("lc_services", serviceId, serviceData, opts);
  }
  public getService<T = unknown>(serviceId: string): T | null {
    return this.get<T>("lc_services", serviceId);
  }
  public getAllServices<T = unknown>(): T[] {
    const records = this.getAll<T>("lc_services");
    return records.map((r) => ((r && (r as any).value ? (r as any).value : r) as T)).filter(Boolean);
  }

  // ── HydroelectricEngine Integration ──────────────────────────────────────

  public getHydroelectricEngine(): HydroelectricEngine {
    return hydroelectricEngine;
  }

  public isTableLarge(tableName: string, thresholdBytes?: number): boolean {
    return this._storage.isTableFileLarge(tableName, this.currentDatabase, thresholdBytes);
  }

  public getTableSizeBytes(tableName: string): number {
    return this._storage.getTableFileSizeBytes(tableName, this.currentDatabase);
  }

  public async streamScanTable(
    tableName: string,
    options?: HydroelectricStreamOptions
  ): Promise<HydroelectricStreamResult> {
    return this._storage.streamScanTable(tableName, options, this.currentDatabase);
  }

  public async streamQueryTable(
    tableName: string,
    filter: {
      where?: (record: LcLocalDbRecord) => boolean;
      limit?: number;
      offset?: number;
      signal?: AbortSignal;
    }
  ): Promise<{ records: LcLocalDbRecord[]; stats: HydroelectricStreamResult }> {
    return this._storage.streamQueryTable(tableName, filter, this.currentDatabase);
  }

  public async streamPipeTableToHttp(
    tableName: string,
    writable: import("node:stream").Writable,
    options?: { format?: "ndjson" | "json"; limit?: number; offset?: number; signal?: AbortSignal }
  ): Promise<{ recordsStreamed: number; durationMs: number }> {
    const cleanName: string = this.resolveTableName(tableName);
    const tablesPath: string = this._storage.getTableTablesPath(cleanName, this.currentDatabase);
    return hydroelectricEngine.streamPipeToHttp(tablesPath, writable, options);
  }
}

export const lcLocalDbEngine = new LcLocalDbEngine();
lcLocalDbEngine.init();
export const lc_local_db_engine = lcLocalDbEngine;
