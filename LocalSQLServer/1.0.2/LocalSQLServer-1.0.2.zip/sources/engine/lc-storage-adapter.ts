/**
 * packages/LocalSQLServer/sources/engine/lc-storage-adapter.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * Storage Adapter for {table-name}.dblc SQL files, localStorage & multi-databases
 * ─────────────────────────────────────────────────────────────────────────────
 */

import {
  mergeMemoryIntoStorage,
  migrateAllDbLcToDblcFiles,
  migrateLegacyCacheStore,
  migrateDotCacheDirectoryToLocalSql,
  syncLegacyLocalStorageStore,
} from "./lc-legacy-migrator";
import {
  parseDblcSql,
  serializeTableSchemaToDblc,
  serializeTableValuesToDblc
} from "./lc-sql-serializer";
import type { DbTable, LcDatabaseFileInfo, LcLocalDbMergeMemoryResult, LcLocalDbRecord } from "./lc-types";
import {
  hydroelectricEngine,
  HydroelectricEngine,
  type HydroelectricStreamOptions,
  type HydroelectricStreamResult,
} from "./hydroelectric-engine";

function getOs(): typeof import("node:os") | null {
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  return typeof require !== "undefined" ? (require("node:os") as typeof import("node:os")) : null;
}

/**
 * Expands leading tilde (~) in path to user's home directory.
 */
export function resolveTildePath(inputPath: string): string {
  if (!inputPath) {
    return inputPath;
  }
  const trimmedPath: string = inputPath.trim();
  if (trimmedPath === "~") {
    const nodeOsModule: typeof import("node:os") | null = getOs();
    return nodeOsModule ? nodeOsModule.homedir() : (process.env.HOME || process.env.USERPROFILE || "~");
  }
  if (trimmedPath.startsWith("~/") || trimmedPath.startsWith("~\\")) {
    const nodeOsModule: typeof import("node:os") | null = getOs();
    const nodePathModule: typeof import("node:path") | null = getPath();
    const homeDirectory: string = nodeOsModule ? nodeOsModule.homedir() : (process.env.HOME || process.env.USERPROFILE || "");
    if (homeDirectory) {
      const pathSuffix: string = trimmedPath.slice(2);
      return nodePathModule ? nodePathModule.join(homeDirectory, pathSuffix) : `${homeDirectory}/${pathSuffix}`;
    }
  }
  return trimmedPath;
}

export const DEFAULT_LOCAL_DB_PATH: string = "~/.2tek/LocalDB";

/**
 * Resolves the LocalDB directory path from environment (.env -> LOCAL_DB_PATH or LOCAL_DB)
 * with default fallback to ~/.2tek/LocalDB.
 */
export function resolveLocalDbStorageDir(): string {
  try {
    if (typeof process !== "undefined") {
      const explicitEnvValue: string | undefined =
        process.env?.LOCAL_DB_PATH || process.env?.LOCAL_DB || process.env?.LOCALDB_PATH;
      if (explicitEnvValue && explicitEnvValue.trim() !== "") {
        return explicitEnvValue.trim();
      }
    }
    const nodeFileSystem: typeof import("node:fs") | null = getFs();
    const nodePathModule: typeof import("node:path") | null = getPath();
    if (nodeFileSystem && nodePathModule && typeof process !== "undefined" && process.cwd) {
      const currentWorkingDirectory: string = process.cwd();
      const possibleEnvironmentPaths: string[] = [
        nodePathModule.resolve(currentWorkingDirectory, ".env"),
        nodePathModule.resolve(currentWorkingDirectory, "..", ".env"),
        nodePathModule.resolve(currentWorkingDirectory, "../..", ".env"),
      ];
      for (let pathIndex: number = 0; pathIndex < possibleEnvironmentPaths.length; pathIndex += 1) {
        const environmentFilePath: string = possibleEnvironmentPaths[pathIndex];
        if (nodeFileSystem.existsSync(environmentFilePath)) {
          const fileContent: string = nodeFileSystem.readFileSync(environmentFilePath, "utf-8");
          const environmentMatch: RegExpMatchArray | null =
            fileContent.match(/^\s*LOCAL_DB_PATH\s*=\s*(.*)$/m) ||
            fileContent.match(/^\s*LOCAL_DB\s*=\s*(.*)$/m) ||
            fileContent.match(/^\s*LOCALDB_PATH\s*=\s*(.*)$/m);
          if (environmentMatch && environmentMatch[1]) {
            const rawExtractedValue: string = environmentMatch[1].trim();
            const cleanedPathValue: string = rawExtractedValue.replace(/^["']|["']$/g, "").trim();
            if (cleanedPathValue !== "") {
              return cleanedPathValue;
            }
          }
        }
      }
    }
  } catch {}
  return DEFAULT_LOCAL_DB_PATH;
}

export const DEFAULT_STORAGE_DIR: string = resolveLocalDbStorageDir();
const LS_KEY_PREFIX = "_lc_localdb_";

export function isNode(): boolean {
  return typeof window === "undefined" && typeof process !== "undefined";
}

export function isBrowser(): boolean {
  return typeof window !== "undefined" && typeof localStorage !== "undefined";
}

function getFs(): typeof import("node:fs") | null {
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  return typeof require !== "undefined" ? (require("node:fs") as typeof import("node:fs")) : null;
}

function getPath(): typeof import("node:path") | null {
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  return typeof require !== "undefined" ? (require("node:path") as typeof import("node:path")) : null;
}

export class StorageAdapter {
  private _storageDir: string;
  private _databaseName: string;
  private _isMemoryOnly: boolean = false;
  private _backend: "localStorage" | "file" | "memory" = "memory";
  private _memoryTables: Map<string, DbTable> = new Map();
  private _knownDatabases: Set<string> = new Set<string>(["default"]);

  constructor(storageDir?: string, databaseName: string = "default") {
    const rawTargetDir: string = storageDir || this.resolveConfiguredStorageDir();
    if (rawTargetDir === ":memory:") {
      this._isMemoryOnly = true;
      this._storageDir = resolveLocalDbStorageDir();
      this._backend = "memory";
    } else {
      const targetDir: string = resolveTildePath(rawTargetDir);
      this._storageDir = targetDir;
      this._isMemoryOnly = false;
      const nodeFileSystem: typeof import("node:fs") | null = getFs();
      const effectiveStorageDirectory: string = this.getEffectiveStorageDir();
      if (nodeFileSystem && effectiveStorageDirectory && !nodeFileSystem.existsSync(effectiveStorageDirectory)) {
        try {
          nodeFileSystem.mkdirSync(effectiveStorageDirectory, { recursive: true });
        } catch {}
      }
    }
    this._databaseName = databaseName || "default";
  }

  private resolveConfiguredStorageDir(): string {
    try {
      const configuredPath: string = resolveLocalDbStorageDir();
      const expandedPath: string = resolveTildePath(configuredPath);
      const nodePathModule: typeof import("node:path") | null = getPath();
      const nodeFileSystem: typeof import("node:fs") | null = getFs();
      if (nodePathModule && nodeFileSystem && typeof process !== "undefined" && process.cwd) {
        const currentWorkingDirectory: string = process.cwd();
        const resolvedPath: string = nodePathModule.isAbsolute(expandedPath)
          ? expandedPath
          : nodePathModule.resolve(currentWorkingDirectory, expandedPath);

        if (!nodeFileSystem.existsSync(resolvedPath)) {
          try {
            nodeFileSystem.mkdirSync(resolvedPath, { recursive: true });
          } catch {}
        }
        return resolvedPath;
      }
      return expandedPath;
    } catch {}
    return resolveTildePath(resolveLocalDbStorageDir());
  }

  public getEffectiveStorageDir(): string {
    const expandedDir: string = resolveTildePath(this._storageDir);
    const nodePathModule: typeof import("node:path") | null = getPath();
    if (!nodePathModule) return expandedDir;
    const currentWorkingDirectory: string = typeof process !== "undefined" && process.cwd ? process.cwd() : "";
    return nodePathModule.isAbsolute(expandedDir)
      ? expandedDir
      : nodePathModule.resolve(currentWorkingDirectory, expandedDir);
  }

  public get storageDir(): string { return this._isMemoryOnly ? ":memory:" : this._storageDir; }
  public set storageDir(dir: string) {
    if (dir === ":memory:") {
      this._isMemoryOnly = true;
      this._storageDir = resolveLocalDbStorageDir();
      this._backend = "memory";
    } else {
      this._isMemoryOnly = false;
      this._storageDir = resolveTildePath(dir);
      const nodeFileSystem: typeof import("node:fs") | null = getFs();
      const effectiveStorageDirectory: string = this.getEffectiveStorageDir();
      if (nodeFileSystem && effectiveStorageDirectory && !nodeFileSystem.existsSync(effectiveStorageDirectory)) {
        try {
          nodeFileSystem.mkdirSync(effectiveStorageDirectory, { recursive: true });
        } catch {}
      }
    }
  }

  public get databaseName(): string { return this._databaseName; }
  public set databaseName(name: string) { this._databaseName = name || "default"; }
  public get currentDatabase(): string { return this._databaseName; }
  public useDatabase(name: string): string { this._databaseName = name || "default"; return this._databaseName; }
  public get isMemoryOnly(): boolean { return this._isMemoryOnly; }
  public get backend(): "localStorage" | "file" | "memory" { return this._backend; }

  public detectBackend(): "localStorage" | "file" | "memory" {
    if (this._isMemoryOnly) this._backend = "memory";
    else if (isBrowser()) this._backend = "localStorage";
    else if (isNode()) this._backend = "file";
    else this._backend = "memory";
    return this._backend;
  }

  public getDatabaseSchemaDir(dbName?: string): string {
    const path = getPath();
    const db = dbName || this._databaseName || "default";
    const dir = this.getEffectiveStorageDir();
    return path ? path.resolve(dir, "schema", db) : `${dir}/schema/${db}`;
  }

  public getDatabaseTablesDir(dbName?: string): string {
    const path = getPath();
    const db = dbName || this._databaseName || "default";
    const dir = this.getEffectiveStorageDir();
    return path ? path.resolve(dir, "tables", db) : `${dir}/tables/${db}`;
  }

  public getDatabaseValuesDir(dbName?: string): string {
    return this.getDatabaseTablesDir(dbName);
  }

  public getLegacyDatabaseSchemaDir(dbName?: string): string {
    const path = getPath();
    const db = dbName || this._databaseName || "default";
    const dir = this.getEffectiveStorageDir();
    return path ? path.resolve(dir, "schema", "databases", db) : `${dir}/schema/databases/${db}`;
  }

  public getLegacyDatabaseValuesDir(dbName?: string): string {
    const path = getPath();
    const db = dbName || this._databaseName || "default";
    const dir = this.getEffectiveStorageDir();
    return path ? path.resolve(dir, "values", "databases", db) : `${dir}/values/databases/${db}`;
  }

  public getLegacyValuesDir(dbName?: string): string {
    const path = getPath();
    const db = dbName || this._databaseName || "default";
    const dir = this.getEffectiveStorageDir();
    return path ? path.resolve(dir, "values", db) : `${dir}/values/${db}`;
  }

  public getDatabaseDir(dbName?: string): string {
    return this.getDatabaseSchemaDir(dbName);
  }

  public normalizeTableName(name: string): string {
    return name.replace(/\.(dblc|db\.lc)$/i, "");
  }

  public getTableSchemaPath(tableName: string, dbName?: string): string {
    const path = getPath();
    const cleanName = this.normalizeTableName(tableName);
    const fileName = `${cleanName}.dblc`;
    return path ? path.join(this.getDatabaseSchemaDir(dbName), fileName) : `${this.getDatabaseSchemaDir(dbName)}/${fileName}`;
  }

  public getTableTablesPath(tableName: string, dbName?: string): string {
    const path = getPath();
    const cleanName = this.normalizeTableName(tableName);
    const fileName = `${cleanName}.dblc`;
    return path ? path.join(this.getDatabaseTablesDir(dbName), fileName) : `${this.getDatabaseTablesDir(dbName)}/${fileName}`;
  }

  public getTableValuesPath(tableName: string, dbName?: string): string {
    return this.getTableTablesPath(tableName, dbName);
  }

  public getLegacyTableSchemaPath(tableName: string, dbName?: string): string {
    const path = getPath();
    const cleanName = this.normalizeTableName(tableName);
    return path ? path.join(this.getLegacyDatabaseSchemaDir(dbName), `${cleanName}.dblc`) : `${this.getLegacyDatabaseSchemaDir(dbName)}/${cleanName}.dblc`;
  }

  public getLegacyTableValuesPath(tableName: string, dbName?: string): string {
    const path = getPath();
    const cleanName = this.normalizeTableName(tableName);
    return path ? path.join(this.getLegacyDatabaseValuesDir(dbName), `${cleanName}.dblc`) : `${this.getLegacyDatabaseValuesDir(dbName)}/${cleanName}.dblc`;
  }

  public getTableDisplaySchemaPath(tableName: string, dbName?: string): string {
    const db = dbName || this._databaseName || "default";
    const cleanName = this.normalizeTableName(tableName);
    return `/schema/${db}/${cleanName}`;
  }

  public getTableDisplayTablesPath(tableName: string, dbName?: string): string {
    const db = dbName || this._databaseName || "default";
    const cleanName = this.normalizeTableName(tableName);
    return `/tables/${db}/${cleanName}`;
  }

  public getTableDisplayValuesPath(tableName: string, dbName?: string): string {
    return this.getTableDisplayTablesPath(tableName, dbName);
  }

  public getTablePath(tableName: string, dbName?: string): string {
    return this.getTableSchemaPath(tableName, dbName);
  }

  public getLegacyTablePath(tableName: string, ext: ".dblc" | ".db.lc" = ".dblc"): string {
    const path = getPath();
    const cleanName = this.normalizeTableName(tableName);
    const fileName = `${cleanName}${ext}`;
    const dir = this.getEffectiveStorageDir();
    return path ? path.resolve(dir, fileName) : `${dir}/${fileName}`;
  }

  /**
   * Save a single table to:
   * 1. Schema file: .localdb/schema/{db}/{tableName}.dblc (DDL schema)
   * 2. Tables file: .localdb/tables/{db}/{tableName}.dblc (DML records/values)
   * Section 651: Zero .dblc files in root .localdb/. Clean any legacy root or legacy folders.
   */
  public saveTable(table: DbTable, dbName?: string): string {
    const targetDb = dbName || this._databaseName || "default";
    const schemaSql = serializeTableSchemaToDblc(table);
    const valuesSql = serializeTableValuesToDblc(table);
    const cleanName = this.normalizeTableName(table.namespace);

    if (this._isMemoryOnly) {
      this._memoryTables.set(`${targetDb}:${cleanName}`, table);
      return schemaSql;
    }

    if (isBrowser()) {
      try {
        localStorage.setItem(`${LS_KEY_PREFIX}schema_db_${targetDb}_${cleanName}.dblc`, schemaSql);
        localStorage.setItem(`${LS_KEY_PREFIX}tables_db_${targetDb}_${cleanName}.dblc`, valuesSql);
        localStorage.setItem(`${LS_KEY_PREFIX}values_db_${targetDb}_${cleanName}.dblc`, valuesSql);
        localStorage.removeItem(`${LS_KEY_PREFIX}db_${targetDb}_${cleanName}.dblc`);
        localStorage.removeItem(`${LS_KEY_PREFIX}db_${targetDb}_${cleanName}.db.lc`);
        if (targetDb === "default") {
          localStorage.removeItem(`${LS_KEY_PREFIX}${cleanName}.dblc`);
          localStorage.removeItem(`${LS_KEY_PREFIX}${cleanName}.db.lc`);
          localStorage.removeItem(`${LS_KEY_PREFIX}${cleanName}`);
        }
      } catch {
        // Fallback
      }
      return schemaSql;
    }

    if (isNode()) {
      try {
        const fs = getFs();
        const path = getPath();
        if (!fs || !path) return schemaSql;

        // 1. Write schema file: .localdb/schema/{targetDb}/{cleanName}.dblc
        const schemaDir = this.getDatabaseSchemaDir(targetDb);
        if (!fs.existsSync(schemaDir)) fs.mkdirSync(schemaDir, { recursive: true });
        const schemaPath = this.getTableSchemaPath(cleanName, targetDb);
        const schemaTmp = `${schemaPath}.tmp.${Date.now()}`;
        fs.writeFileSync(schemaTmp, schemaSql, "utf8");
        fs.renameSync(schemaTmp, schemaPath);

        // 2. Write tables (values) file: .localdb/tables/{targetDb}/{cleanName}.dblc
        const tablesDir = this.getDatabaseTablesDir(targetDb);
        if (!fs.existsSync(tablesDir)) fs.mkdirSync(tablesDir, { recursive: true });
        const tablesPath = this.getTableTablesPath(cleanName, targetDb);
        const tablesTmp = `${tablesPath}.tmp.${Date.now()}`;
        fs.writeFileSync(tablesTmp, valuesSql, "utf8");
        fs.renameSync(tablesTmp, tablesPath);

        // 3. Section 651: Remove any root .localdb/{cleanName}.dblc or .db.lc
        const rootDblc = this.getLegacyTablePath(cleanName, ".dblc");
        if (fs.existsSync(rootDblc)) {
          try { fs.unlinkSync(rootDblc); } catch {}
        }
        const rootDbLc = this.getLegacyTablePath(cleanName, ".db.lc");
        if (fs.existsSync(rootDbLc)) {
          try { fs.unlinkSync(rootDbLc); } catch {}
        }

        // 4. Remove any legacy schema/databases and values/databases files
        const legacySchema = this.getLegacyTableSchemaPath(cleanName, targetDb);
        if (fs.existsSync(legacySchema)) {
          try { fs.unlinkSync(legacySchema); } catch {}
        }
        const legacyValues = this.getLegacyTableValuesPath(cleanName, targetDb);
        if (fs.existsSync(legacyValues)) {
          try { fs.unlinkSync(legacyValues); } catch {}
        }
        const legacyValuesFlat = path.join(this.getLegacyValuesDir(targetDb), `${cleanName}.dblc`);
        if (fs.existsSync(legacyValuesFlat)) {
          try { fs.unlinkSync(legacyValuesFlat); } catch {}
        }

        // 5. Remove any legacy .db.lc in schema or tables directories
        const schemaDbLc = path.join(schemaDir, `${cleanName}.db.lc`);
        if (fs.existsSync(schemaDbLc)) {
          try { fs.unlinkSync(schemaDbLc); } catch {}
        }
        const tablesDbLc = path.join(tablesDir, `${cleanName}.db.lc`);
        if (fs.existsSync(tablesDbLc)) {
          try { fs.unlinkSync(tablesDbLc); } catch {}
        }
        const legacySchemaDbLc = path.join(this.getLegacyDatabaseSchemaDir(targetDb), `${cleanName}.db.lc`);
        if (fs.existsSync(legacySchemaDbLc)) {
          try { fs.unlinkSync(legacySchemaDbLc); } catch {}
        }
        const legacyValuesDbLc = path.join(this.getLegacyDatabaseValuesDir(targetDb), `${cleanName}.db.lc`);
        if (fs.existsSync(legacyValuesDbLc)) {
          try { fs.unlinkSync(legacyValuesDbLc); } catch {}
        }
        const legacyValuesFlatDbLc = path.join(this.getLegacyValuesDir(targetDb), `${cleanName}.db.lc`);
        if (fs.existsSync(legacyValuesFlatDbLc)) {
          try { fs.unlinkSync(legacyValuesFlatDbLc); } catch {}
        }

        return schemaPath;
      } catch {
        // Fallback
      }
    }
    return schemaSql;
  }

  /**
   * Load a single table with primary lookup in schema/{db}/ and tables/{db}/
   * and fallback lookup in legacy paths (schema/databases/{db}/, values/databases/{db}/, values/{db}/, or root .localdb/ for "default").
   * Automatically materializes tables (values) file if schema has records and tables file was missing.
   * Automatically migrates any legacy file to the new schema/{db} and tables/{db} structure and cleans up legacy files.
   */
  public loadTable(tableName: string, dbName?: string): DbTable | null {
    const targetDb = dbName || this._databaseName || "default";
    const cleanName = this.normalizeTableName(tableName);

    if (this._isMemoryOnly) {
      return (
        this._memoryTables.get(`${targetDb}:${cleanName}`) ??
        (targetDb === "default" ? this._memoryTables.get(cleanName) : undefined) ??
        null
      );
    }

    if (isBrowser()) {
      try {
        const schemaRaw =
          localStorage.getItem(`${LS_KEY_PREFIX}schema_db_${targetDb}_${cleanName}.dblc`) ??
          localStorage.getItem(`${LS_KEY_PREFIX}db_${targetDb}_${cleanName}.dblc`) ??
          localStorage.getItem(`${LS_KEY_PREFIX}db_${targetDb}_${cleanName}.db.lc`) ??
          (targetDb === "default"
            ? (localStorage.getItem(`${LS_KEY_PREFIX}${cleanName}.dblc`) ??
               localStorage.getItem(`${LS_KEY_PREFIX}${cleanName}.db.lc`) ??
               localStorage.getItem(`${LS_KEY_PREFIX}${cleanName}`))
            : null);

        const valuesRaw =
          localStorage.getItem(`${LS_KEY_PREFIX}tables_db_${targetDb}_${cleanName}.dblc`) ??
          localStorage.getItem(`${LS_KEY_PREFIX}values_db_${targetDb}_${cleanName}.dblc`);

        if (schemaRaw || valuesRaw) {
          const parsedSchema = schemaRaw ? parseDblcSql(schemaRaw, cleanName) : null;
          const parsedValues = valuesRaw ? parseDblcSql(valuesRaw, cleanName) : null;

          const combinedRecords = (parsedValues && Object.keys(parsedValues.records).length > 0)
            ? parsedValues.records
            : (parsedSchema ? parsedSchema.records : {});

          const combinedRelationships = [
            ...(parsedSchema?.relationships || []),
            ...(parsedValues?.relationships || []),
          ];

          const combinedRelations = (parsedValues && Object.keys(parsedValues.relations).length > 0)
            ? parsedValues.relations
            : (parsedSchema ? parsedSchema.relations : {});

          return {
            namespace: parsedSchema?.tableName || parsedValues?.tableName || cleanName,
            records: combinedRecords,
            relationships: combinedRelationships,
            relations: combinedRelations,
            createdAt: new Date().toISOString(),
          };
        }
      } catch {
        return null;
      }
    }

    if (isNode()) {
      try {
        const fs = getFs();
        const path = getPath();
        if (!fs) return null;

        // 1. Primary lookup: schema/{targetDb}/[cleanName].dblc and tables/{targetDb}/[cleanName].dblc
        const schemaPath = this.getTableSchemaPath(cleanName, targetDb);
        const tablesPath = this.getTableTablesPath(cleanName, targetDb);
        const hasSchema = fs.existsSync(schemaPath);
        const hasTables = fs.existsSync(tablesPath);

        let rawSchema: string | null = null;
        if (hasSchema) {
          try {
            rawSchema = fs.readFileSync(schemaPath, "utf8");
          } catch {
            rawSchema = null;
          }
        }

        let rawValues: string | null = null;
        let parsedValuesFromHydroelectric: Record<string, LcLocalDbRecord> | null = null;

        if (hasTables) {
          if (hydroelectricEngine.isLargeFile(tablesPath)) {
            // Large file (> 50MB, up to > 10GB): stream scan using HydroelectricEngine with bounded O(1) buffer memory
            const hydroScan = hydroelectricEngine.syncStreamScanFile(tablesPath);
            parsedValuesFromHydroelectric = hydroScan.records;
          } else {
            try {
              rawValues = fs.readFileSync(tablesPath, "utf8");
            } catch {
              const hydroScan = hydroelectricEngine.syncStreamScanFile(tablesPath);
              parsedValuesFromHydroelectric = hydroScan.records;
            }
          }
        }

        let needsSave = false;

        // 2. Fallback: check legacy values/{targetDb}/[cleanName].dblc
        if (!rawValues && !parsedValuesFromHydroelectric && path) {
          const legacyValuesFlat = path.join(this.getLegacyValuesDir(targetDb), `${cleanName}.dblc`);
          if (fs.existsSync(legacyValuesFlat)) {
            if (hydroelectricEngine.isLargeFile(legacyValuesFlat)) {
              const hydroScan = hydroelectricEngine.syncStreamScanFile(legacyValuesFlat);
              parsedValuesFromHydroelectric = hydroScan.records;
            } else {
              try {
                rawValues = fs.readFileSync(legacyValuesFlat, "utf8");
              } catch {
                const hydroScan = hydroelectricEngine.syncStreamScanFile(legacyValuesFlat);
                parsedValuesFromHydroelectric = hydroScan.records;
              }
            }
            needsSave = true;
          }
        }

        // 3. Fallback: check legacy schema/databases/{targetDb}/[cleanName].dblc and values/databases/{targetDb}/[cleanName].dblc
        if (!rawSchema) {
          const legacySchemaPath = this.getLegacyTableSchemaPath(cleanName, targetDb);
          if (fs.existsSync(legacySchemaPath)) {
            rawSchema = fs.readFileSync(legacySchemaPath, "utf8");
            needsSave = true;
          }
        }
        if (!rawValues && !parsedValuesFromHydroelectric) {
          const legacyValuesPath = this.getLegacyTableValuesPath(cleanName, targetDb);
          if (fs.existsSync(legacyValuesPath)) {
            if (hydroelectricEngine.isLargeFile(legacyValuesPath)) {
              const hydroScan = hydroelectricEngine.syncStreamScanFile(legacyValuesPath);
              parsedValuesFromHydroelectric = hydroScan.records;
            } else {
              try {
                rawValues = fs.readFileSync(legacyValuesPath, "utf8");
              } catch {
                const hydroScan = hydroelectricEngine.syncStreamScanFile(legacyValuesPath);
                parsedValuesFromHydroelectric = hydroScan.records;
              }
            }
            needsSave = true;
          }
        }

        // 4. Fallback: check legacy .db.lc versions in schema/tables/legacy
        if (!rawSchema && path) {
          const schemaDir = this.getDatabaseSchemaDir(targetDb);
          const legacyDbLc = path.join(schemaDir, `${cleanName}.db.lc`);
          if (fs.existsSync(legacyDbLc)) {
            rawSchema = fs.readFileSync(legacyDbLc, "utf8");
            needsSave = true;
          }
          const legacySchemaDir = this.getLegacyDatabaseSchemaDir(targetDb);
          const legacySchemaDbLc = path.join(legacySchemaDir, `${cleanName}.db.lc`);
          if (!rawSchema && fs.existsSync(legacySchemaDbLc)) {
            rawSchema = fs.readFileSync(legacySchemaDbLc, "utf8");
            needsSave = true;
          }
        }

        // 5. Dual-lookup fallback for "default": root .localdb/[cleanName].dblc or root .localdb/[cleanName].db.lc
        if ((!rawSchema || (!rawValues && !parsedValuesFromHydroelectric)) && targetDb === "default") {
          const rootDblcPath = this.getLegacyTablePath(cleanName, ".dblc");
          if (fs.existsSync(rootDblcPath)) {
            if (hydroelectricEngine.isLargeFile(rootDblcPath)) {
              const hydroScan = hydroelectricEngine.syncStreamScanFile(rootDblcPath);
              parsedValuesFromHydroelectric = hydroScan.records;
            } else {
              try {
                const rootRaw = fs.readFileSync(rootDblcPath, "utf8");
                if (!rawSchema) rawSchema = rootRaw;
                if (!rawValues) rawValues = rootRaw;
              } catch {
                const hydroScan = hydroelectricEngine.syncStreamScanFile(rootDblcPath);
                parsedValuesFromHydroelectric = hydroScan.records;
              }
            }
            needsSave = true;
          } else {
            const rootDbLcPath = this.getLegacyTablePath(cleanName, ".db.lc");
            if (fs.existsSync(rootDbLcPath)) {
              if (hydroelectricEngine.isLargeFile(rootDbLcPath)) {
                const hydroScan = hydroelectricEngine.syncStreamScanFile(rootDbLcPath);
                parsedValuesFromHydroelectric = hydroScan.records;
              } else {
                try {
                  const rootRaw = fs.readFileSync(rootDbLcPath, "utf8");
                  if (!rawSchema) rawSchema = rootRaw;
                  if (!rawValues) rawValues = rootRaw;
                } catch {
                  const hydroScan = hydroelectricEngine.syncStreamScanFile(rootDbLcPath);
                  parsedValuesFromHydroelectric = hydroScan.records;
                }
              }
              needsSave = true;
            }
          }
        }

        if (rawSchema || rawValues || parsedValuesFromHydroelectric) {
          const parsedSchema = rawSchema ? parseDblcSql(rawSchema, cleanName) : null;
          const parsedValues = parsedValuesFromHydroelectric
            ? { tableName: cleanName, records: parsedValuesFromHydroelectric, relationships: [], relations: {} }
            : (rawValues ? parseDblcSql(rawValues, cleanName) : null);

          const combinedRecords = (parsedValues && Object.keys(parsedValues.records).length > 0)
            ? parsedValues.records
            : (parsedSchema ? parsedSchema.records : {});

          const combinedRelationships = [
            ...(parsedSchema?.relationships || []),
            ...(parsedValues?.relationships || []),
          ];

          const combinedRelations = (parsedValues && Object.keys(parsedValues.relations).length > 0)
            ? parsedValues.relations
            : (parsedSchema ? parsedSchema.relations : {});

          const table: DbTable = {
            namespace: cleanName || parsedSchema?.tableName || parsedValues?.tableName || tableName,
            records: combinedRecords,
            relationships: combinedRelationships,
            relations: combinedRelations,
            createdAt: new Date().toISOString(),
          };

          // Auto-materialize tables (values) file if missing and records exist
          if (!hasTables && Object.keys(combinedRecords).length > 0) {
            needsSave = true;
          }

          if (needsSave || !hasSchema || !hasTables) {
            this.saveTable(table, targetDb);
          }

          return table;
        }
      } catch {
        return null;
      }
    }
    return null;
  }

  /**
   * Check if a table schema file exists in storage
   */
  public hasTableSchemaFile(tableName: string, dbName?: string): boolean {
    const targetDb = dbName || this._databaseName || "default";
    const cleanName = this.normalizeTableName(tableName);

    if (this._isMemoryOnly) {
      return (
        this._memoryTables.has(`${targetDb}:${cleanName}`) ||
        (targetDb === "default" && this._memoryTables.has(cleanName))
      );
    }

    if (isBrowser()) {
      return (
        localStorage.getItem(`${LS_KEY_PREFIX}schema_db_${targetDb}_${cleanName}.dblc`) !== null ||
        localStorage.getItem(`${LS_KEY_PREFIX}db_${targetDb}_${cleanName}.dblc`) !== null ||
        localStorage.getItem(`${LS_KEY_PREFIX}db_${targetDb}_${cleanName}.db.lc`) !== null ||
        (targetDb === "default" && (
          localStorage.getItem(`${LS_KEY_PREFIX}${cleanName}.dblc`) !== null ||
          localStorage.getItem(`${LS_KEY_PREFIX}${cleanName}.db.lc`) !== null
        ))
      );
    }

    if (isNode()) {
      const fs = getFs();
      const path = getPath();
      if (!fs) return false;
      if (fs.existsSync(this.getTableSchemaPath(cleanName, targetDb))) return true;
      if (fs.existsSync(this.getLegacyTableSchemaPath(cleanName, targetDb))) return true;
      const dbDir = this.getDatabaseSchemaDir(targetDb);
      const legacyDbLcPath = path ? path.join(dbDir, `${cleanName}.db.lc`) : `${dbDir}/${cleanName}.db.lc`;
      if (fs.existsSync(legacyDbLcPath)) return true;
      if (targetDb === "default") {
        if (fs.existsSync(this.getLegacyTablePath(cleanName, ".dblc"))) return true;
        if (fs.existsSync(this.getLegacyTablePath(cleanName, ".db.lc"))) return true;
      }
    }
    return false;
  }

  /**
   * Check if a table tables (values) file exists in storage
   */
  public hasTableTablesFile(tableName: string, dbName?: string): boolean {
    const targetDb = dbName || this._databaseName || "default";
    const cleanName = this.normalizeTableName(tableName);

    if (this._isMemoryOnly) {
      return (
        this._memoryTables.has(`${targetDb}:${cleanName}`) ||
        (targetDb === "default" && this._memoryTables.has(cleanName))
      );
    }

    if (isBrowser()) {
      return (
        localStorage.getItem(`${LS_KEY_PREFIX}tables_db_${targetDb}_${cleanName}.dblc`) !== null ||
        localStorage.getItem(`${LS_KEY_PREFIX}values_db_${targetDb}_${cleanName}.dblc`) !== null
      );
    }

    if (isNode()) {
      const fs = getFs();
      const path = getPath();
      if (!fs) return false;
      if (fs.existsSync(this.getTableTablesPath(cleanName, targetDb))) return true;
      if (fs.existsSync(this.getLegacyTableValuesPath(cleanName, targetDb))) return true;
      if (path && fs.existsSync(path.join(this.getLegacyValuesDir(targetDb), `${cleanName}.dblc`))) return true;
    }
    return false;
  }

  public hasTableValuesFile(tableName: string, dbName?: string): boolean {
    return this.hasTableTablesFile(tableName, dbName);
  }

  /**
   * Check if any table file (schema or tables or legacy) exists in storage
   */
  public hasTableFile(tableName: string, dbName?: string): boolean {
    return this.hasTableSchemaFile(tableName, dbName) || this.hasTableTablesFile(tableName, dbName);
  }

  /**
   * Delete table files (both schema and tables) and backups from storage completely
   */
  public deleteTable(tableName: string, dbName?: string): boolean {
    const targetDb = dbName || this._databaseName || "default";
    const cleanName = this.normalizeTableName(tableName);
    let deleted = false;

    if (this._isMemoryOnly) {
      if (this._memoryTables.delete(`${targetDb}:${cleanName}`)) deleted = true;
      if (targetDb === "default" && this._memoryTables.delete(cleanName)) deleted = true;
      return deleted;
    }

    if (isBrowser()) {
      try {
        const keysToRemove = [
          `${LS_KEY_PREFIX}schema_db_${targetDb}_${cleanName}.dblc`,
          `${LS_KEY_PREFIX}tables_db_${targetDb}_${cleanName}.dblc`,
          `${LS_KEY_PREFIX}values_db_${targetDb}_${cleanName}.dblc`,
          `${LS_KEY_PREFIX}db_${targetDb}_${cleanName}.dblc`,
          `${LS_KEY_PREFIX}db_${targetDb}_${cleanName}.db.lc`,
        ];
        if (targetDb === "default") {
          keysToRemove.push(
            `${LS_KEY_PREFIX}${cleanName}.dblc`,
            `${LS_KEY_PREFIX}${cleanName}.db.lc`,
            `${LS_KEY_PREFIX}${cleanName}`
          );
        }
        for (const k of keysToRemove) {
          if (localStorage.getItem(k) !== null) {
            localStorage.removeItem(k);
            deleted = true;
          }
        }
      } catch {}
    }

    if (isNode()) {
      try {
        const fs = getFs();
        const path = getPath();
        if (fs) {
          const filesToDelete = [
            this.getTableSchemaPath(cleanName, targetDb),
            this.getTableTablesPath(cleanName, targetDb),
            this.getLegacyTableSchemaPath(cleanName, targetDb),
            this.getLegacyTableValuesPath(cleanName, targetDb),
            path ? path.join(this.getLegacyValuesDir(targetDb), `${cleanName}.dblc`) : "",
            path ? path.join(this.getDatabaseSchemaDir(targetDb), `${cleanName}.db.lc`) : "",
            path ? path.join(this.getDatabaseTablesDir(targetDb), `${cleanName}.db.lc`) : "",
          ];
          if (targetDb === "default") {
            filesToDelete.push(
              this.getLegacyTablePath(cleanName, ".dblc"),
              this.getLegacyTablePath(cleanName, ".db.lc")
            );
          }
          for (const f of filesToDelete) {
            if (f && fs.existsSync(f)) {
              fs.unlinkSync(f);
              deleted = true;
            }
          }
        }
      } catch {}
    }

    return deleted;
  }

  /**
   * List all table names available in database (.dblc and .db.lc across schema and tables dirs)
   */
  public listTableNames(dbName?: string): string[] {
    const targetDb = dbName || this._databaseName || "default";
    const tableNames = new Set<string>();

    if (this._isMemoryOnly) {
      const prefix = `${targetDb}:`;
      for (const key of Array.from(this._memoryTables.keys())) {
        if (key.startsWith(prefix)) tableNames.add(this.normalizeTableName(key.slice(prefix.length)));
        else if (targetDb === "default" && !key.includes(":")) tableNames.add(this.normalizeTableName(key));
      }
      return Array.from(tableNames);
    }

    if (isBrowser()) {
      try {
        const schemaPrefix = `${LS_KEY_PREFIX}schema_db_${targetDb}_`;
        const tablesPrefix = `${LS_KEY_PREFIX}tables_db_${targetDb}_`;
        const valuesPrefix = `${LS_KEY_PREFIX}values_db_${targetDb}_`;
        const dbPrefix = `${LS_KEY_PREFIX}db_${targetDb}_`;
        for (let i = 0; i < localStorage.length; i++) {
          const key = localStorage.key(i);
          if (key?.startsWith(schemaPrefix)) {
            tableNames.add(this.normalizeTableName(key.slice(schemaPrefix.length)));
          } else if (key?.startsWith(tablesPrefix)) {
            tableNames.add(this.normalizeTableName(key.slice(tablesPrefix.length)));
          } else if (key?.startsWith(valuesPrefix)) {
            tableNames.add(this.normalizeTableName(key.slice(valuesPrefix.length)));
          } else if (key?.startsWith(dbPrefix)) {
            tableNames.add(this.normalizeTableName(key.slice(dbPrefix.length)));
          } else if (targetDb === "default" && key?.startsWith(LS_KEY_PREFIX) && !key.startsWith(`${LS_KEY_PREFIX}db_`) && !key.startsWith(`${LS_KEY_PREFIX}schema_`) && !key.startsWith(`${LS_KEY_PREFIX}tables_`) && !key.startsWith(`${LS_KEY_PREFIX}values_`)) {
            tableNames.add(this.normalizeTableName(key.slice(LS_KEY_PREFIX.length)));
          }
        }
      } catch {
        // Ignore
      }
    }

    if (isNode()) {
      try {
        const fs = getFs();
        const path = getPath();
        if (fs) {
          const schemaDir = this.getDatabaseSchemaDir(targetDb);
          if (fs.existsSync(schemaDir)) {
            for (const file of fs.readdirSync(schemaDir)) {
              if (file.endsWith(".dblc")) tableNames.add(file.slice(0, -".dblc".length));
              else if (file.endsWith(".db.lc")) tableNames.add(file.slice(0, -".db.lc".length));
            }
          }
          const tablesDir = this.getDatabaseTablesDir(targetDb);
          if (fs.existsSync(tablesDir)) {
            for (const file of fs.readdirSync(tablesDir)) {
              if (file.endsWith(".dblc")) tableNames.add(file.slice(0, -".dblc".length));
              else if (file.endsWith(".db.lc")) tableNames.add(file.slice(0, -".db.lc".length));
            }
          }
          // Check legacy schema/databases/{targetDb}
          const legacySchemaDir = this.getLegacyDatabaseSchemaDir(targetDb);
          if (fs.existsSync(legacySchemaDir)) {
            for (const file of fs.readdirSync(legacySchemaDir)) {
              if (file.endsWith(".dblc")) tableNames.add(file.slice(0, -".dblc".length));
              else if (file.endsWith(".db.lc")) tableNames.add(file.slice(0, -".db.lc".length));
            }
          }
          // Check legacy values/databases/{targetDb}
          const legacyValuesDir = this.getLegacyDatabaseValuesDir(targetDb);
          if (fs.existsSync(legacyValuesDir)) {
            for (const file of fs.readdirSync(legacyValuesDir)) {
              if (file.endsWith(".dblc")) tableNames.add(file.slice(0, -".dblc".length));
              else if (file.endsWith(".db.lc")) tableNames.add(file.slice(0, -".db.lc".length));
            }
          }
          // Check legacy values/{targetDb}
          const legacyValuesFlatDir = this.getLegacyValuesDir(targetDb);
          if (fs.existsSync(legacyValuesFlatDir)) {
            for (const file of fs.readdirSync(legacyValuesFlatDir)) {
              if (file.endsWith(".dblc")) tableNames.add(file.slice(0, -".dblc".length));
              else if (file.endsWith(".db.lc")) tableNames.add(file.slice(0, -".db.lc".length));
            }
          }
          if (targetDb === "default" && path) {
            const rootDir = this.getEffectiveStorageDir();
            if (fs.existsSync(rootDir)) {
              for (const file of fs.readdirSync(rootDir)) {
                if (file.endsWith(".dblc")) tableNames.add(file.slice(0, -".dblc".length));
                else if (file.endsWith(".db.lc")) tableNames.add(file.slice(0, -".db.lc".length));
              }
            }
          }
        }
      } catch {
        // Ignore
      }
    }
    return Array.from(tableNames);
  }

  /**
   * List all database table files with both schema and tables file paths and presence
   */
  public listDatabaseFiles(dbName?: string): LcDatabaseFileInfo[] {
    const targetDb = dbName || this._databaseName || "default";
    const tableNames = this.listTableNames(targetDb);
    const result: LcDatabaseFileInfo[] = [];

    for (const tableName of tableNames) {
      result.push({
        tableName,
        schemaPath: this.getTableSchemaPath(tableName, targetDb),
        tablesPath: this.getTableTablesPath(tableName, targetDb),
        valuesPath: this.getTableValuesPath(tableName, targetDb),
        hasSchemaFile: this.hasTableSchemaFile(tableName, targetDb),
        hasTablesFile: this.hasTableTablesFile(tableName, targetDb),
        hasValuesFile: this.hasTableValuesFile(tableName, targetDb),
        displaySchemaPath: this.getTableDisplaySchemaPath(tableName, targetDb),
        displayTablesPath: this.getTableDisplayTablesPath(tableName, targetDb),
        displayValuesPath: this.getTableDisplayValuesPath(tableName, targetDb),
      });
    }

    return result;
  }

  /**
   * List all database names available in storage across schema and tables directories
   */
  public listDatabases(): string[] {
    const dbs = new Set<string>(["default", ...Array.from(this._knownDatabases)]);

    if (this._isMemoryOnly) {
      for (const key of Array.from(this._memoryTables.keys())) {
        const colonIdx = key.indexOf(":");
        if (colonIdx > 0) dbs.add(key.slice(0, colonIdx));
      }
      return Array.from(dbs);
    }

    if (isBrowser()) {
      try {
        const prefixes = [
          `${LS_KEY_PREFIX}tables_db_`,
          `${LS_KEY_PREFIX}values_db_`,
          `${LS_KEY_PREFIX}schema_db_`,
          `${LS_KEY_PREFIX}db_`,
        ];
        for (let i = 0; i < localStorage.length; i++) {
          const key = localStorage.key(i);
          if (!key) continue;
          for (const prefix of prefixes) {
            if (key.startsWith(prefix)) {
              const parts = key.slice(prefix.length).split("_");
              if (parts.length > 1) dbs.add(parts[0]);
            }
          }
        }
      } catch {
        // Ignore
      }
    }

    if (isNode()) {
      try {
        const fs = getFs();
        const path = getPath();
        if (fs && path) {
          const schemaDir = path.resolve(this.getEffectiveStorageDir(), "schema");
          if (fs.existsSync(schemaDir)) {
            const entries = fs.readdirSync(schemaDir, { withFileTypes: true });
            for (const entry of entries) {
              if (entry.isDirectory() && !entry.name.startsWith(".") && entry.name !== "databases") {
                dbs.add(entry.name);
              }
            }
          }
          const tablesDir = path.resolve(this.getEffectiveStorageDir(), "tables");
          if (fs.existsSync(tablesDir)) {
            const entries = fs.readdirSync(tablesDir, { withFileTypes: true });
            for (const entry of entries) {
              if (entry.isDirectory() && !entry.name.startsWith(".") && entry.name !== "databases") {
                dbs.add(entry.name);
              }
            }
          }
          // Check legacy directories if still existing
          const legacySchemaDatabasesDir = path.resolve(this.getEffectiveStorageDir(), "schema", "databases");
          if (fs.existsSync(legacySchemaDatabasesDir)) {
            const entries = fs.readdirSync(legacySchemaDatabasesDir, { withFileTypes: true });
            for (const entry of entries) {
              if (entry.isDirectory() && !entry.name.startsWith(".")) dbs.add(entry.name);
            }
          }
          const legacyValuesDatabasesDir = path.resolve(this.getEffectiveStorageDir(), "values", "databases");
          if (fs.existsSync(legacyValuesDatabasesDir)) {
            const entries = fs.readdirSync(legacyValuesDatabasesDir, { withFileTypes: true });
            for (const entry of entries) {
              if (entry.isDirectory() && !entry.name.startsWith(".")) dbs.add(entry.name);
            }
          }
          const legacyValuesDir = path.resolve(this.getEffectiveStorageDir(), "values");
          if (fs.existsSync(legacyValuesDir)) {
            const entries = fs.readdirSync(legacyValuesDir, { withFileTypes: true });
            for (const entry of entries) {
              if (entry.isDirectory() && !entry.name.startsWith(".") && entry.name !== "databases") {
                dbs.add(entry.name);
              }
            }
          }
        }
      } catch {
        // Ignore
      }
    }
    return Array.from(dbs);
  }

  public createDatabase(name: string): boolean {
    if (!name || typeof name !== "string" || !/^[a-zA-Z0-9_-]+$/.test(name)) return false;
    this._knownDatabases.add(name);
    if (this._isMemoryOnly) return true;
    if (isNode()) {
      try {
        const fs = getFs();
        if (fs) {
          const schemaDir = this.getDatabaseSchemaDir(name);
          const tablesDir = this.getDatabaseTablesDir(name);
          if (!fs.existsSync(schemaDir)) fs.mkdirSync(schemaDir, { recursive: true });
          if (!fs.existsSync(tablesDir)) fs.mkdirSync(tablesDir, { recursive: true });
          return true;
        }
      } catch {
        return false;
      }
    }
    return true;
  }

  public dropDatabase(name: string): boolean {
    if (name === "default") return false;
    this._knownDatabases.delete(name);
    if (this._isMemoryOnly) {
      const prefix = `${name}:`;
      for (const key of Array.from(this._memoryTables.keys())) {
        if (key.startsWith(prefix)) this._memoryTables.delete(key);
      }
      return true;
    }
    if (isNode()) {
      try {
        const fs = getFs();
        if (fs) {
          const schemaDir = this.getDatabaseSchemaDir(name);
          const tablesDir = this.getDatabaseTablesDir(name);
          const legacySchemaDir = this.getLegacyDatabaseSchemaDir(name);
          const legacyValuesDir = this.getLegacyDatabaseValuesDir(name);
          const legacyValuesFlat = this.getLegacyValuesDir(name);
          for (const d of [schemaDir, tablesDir, legacySchemaDir, legacyValuesDir, legacyValuesFlat]) {
            if (fs.existsSync(d)) {
              fs.rmSync(d, { recursive: true, force: true });
            }
          }
          return true;
        }
      } catch {
        return false;
      }
    }
    return false;
  }

  /**
   * Merge tables from physical :memory: directory into .localdb and delete :memory: folder
   */
  public mergeMemoryIntoLocalDb(targetDbName = "default"): LcLocalDbMergeMemoryResult {
    return mergeMemoryIntoStorage(this, targetDbName);
  }

  /**
   * Section 651: Clean all root .localdb/*.dblc, .db.lc and .tmp.* files.
   * Migrates any table data into schema/default/ and tables/default/ before deleting root files.
   */
  public cleanRootDblcFiles(): { migrated: string[]; removed: string[] } {
    const migrated: string[] = [];
    const removed: string[] = [];
    if (!isNode()) return { migrated, removed };

    try {
      const fs = getFs();
      const path = getPath();
      if (!fs || !path) return { migrated, removed };

      const rootDir = this.getEffectiveStorageDir();
      if (!fs.existsSync(rootDir)) return { migrated, removed };

      const entries = fs.readdirSync(rootDir, { withFileTypes: true });
      for (const entry of entries) {
        if (entry.isDirectory()) continue;
        const fileName = entry.name;
        const fullPath = path.join(rootDir, fileName);

        // Handle temp files: *.tmp.* or ends with .tmp
        if (fileName.includes(".tmp.") || fileName.endsWith(".tmp")) {
          try {
            fs.unlinkSync(fullPath);
            removed.push(fileName);
          } catch {}
          continue;
        }

        // Handle root .dblc and .db.lc files
        if (fileName.endsWith(".dblc") || fileName.endsWith(".db.lc")) {
          const tableName = this.normalizeTableName(fileName);
          try {
            const raw = fs.readFileSync(fullPath, "utf8");
            const parsed = parseDblcSql(raw, tableName);
            const table: DbTable = {
              namespace: parsed.tableName || tableName,
              records: parsed.records,
              relationships: parsed.relationships,
              relations: parsed.relations,
              createdAt: new Date().toISOString(),
            };
            this.saveTable(table, "default");
            migrated.push(tableName);
            if (fs.existsSync(fullPath)) {
              fs.unlinkSync(fullPath);
              removed.push(fileName);
            }
          } catch {
            try {
              fs.unlinkSync(fullPath);
              removed.push(fileName);
            } catch {}
          }
        }
      }
    } catch {}

    return { migrated, removed };
  }

  /**
   * Section 651: Migrate legacy schema/databases/{db} and values/databases/{db} directories
   * to schema/{db} and tables/{db}.
   */
  public migrateLegacyDatabasesDirectories(): { migratedDatabases: string[]; tablesMigrated: string[] } {
    const migratedDatabases: string[] = [];
    const tablesMigrated: string[] = [];
    if (!isNode()) return { migratedDatabases, tablesMigrated };

    try {
      const fs = getFs();
      const path = getPath();
      if (!fs || !path) return { migratedDatabases, tablesMigrated };

      // 1. Migrate .localdb/schema/databases/{db}/*.dblc -> .localdb/schema/{db}/*.dblc
      const legacySchemaDatabasesDir = path.resolve(this.getEffectiveStorageDir(), "schema", "databases");
      if (fs.existsSync(legacySchemaDatabasesDir)) {
        const dbEntries = fs.readdirSync(legacySchemaDatabasesDir, { withFileTypes: true });
        for (const dbEntry of dbEntries) {
          if (!dbEntry.isDirectory() || dbEntry.name.startsWith(".")) continue;
          const dbName = dbEntry.name;
          if (!migratedDatabases.includes(dbName)) migratedDatabases.push(dbName);
          const legacyDbDir = path.join(legacySchemaDatabasesDir, dbName);
          const targetSchemaDir = this.getDatabaseSchemaDir(dbName);
          if (!fs.existsSync(targetSchemaDir)) fs.mkdirSync(targetSchemaDir, { recursive: true });

          const files = fs.readdirSync(legacyDbDir);
          for (const file of files) {
            const src = path.join(legacyDbDir, file);
            if (file.includes(".tmp.") || file.endsWith(".tmp")) {
              try { fs.unlinkSync(src); } catch {}
              continue;
            }
            if (file.endsWith(".dblc") || file.endsWith(".db.lc")) {
              const targetFile = file.endsWith(".db.lc") ? `${file.slice(0, -".db.lc".length)}.dblc` : file;
              const dest = path.join(targetSchemaDir, targetFile);
              try {
                fs.copyFileSync(src, dest);
                fs.unlinkSync(src);
                tablesMigrated.push(`schema:${dbName}:${file}`);
              } catch {}
            }
          }
          try { fs.rmdirSync(legacyDbDir); } catch {}
        }
        try { fs.rmdirSync(legacySchemaDatabasesDir); } catch {}
      }

      // 2. Migrate .localdb/values/databases/{db}/*.dblc -> .localdb/tables/{db}/*.dblc
      const legacyValuesDatabasesDir = path.resolve(this.getEffectiveStorageDir(), "values", "databases");
      if (fs.existsSync(legacyValuesDatabasesDir)) {
        const dbEntries = fs.readdirSync(legacyValuesDatabasesDir, { withFileTypes: true });
        for (const dbEntry of dbEntries) {
          if (!dbEntry.isDirectory() || dbEntry.name.startsWith(".")) continue;
          const dbName = dbEntry.name;
          if (!migratedDatabases.includes(dbName)) migratedDatabases.push(dbName);
          const legacyDbDir = path.join(legacyValuesDatabasesDir, dbName);
          const targetTablesDir = this.getDatabaseTablesDir(dbName);
          if (!fs.existsSync(targetTablesDir)) fs.mkdirSync(targetTablesDir, { recursive: true });

          const files = fs.readdirSync(legacyDbDir);
          for (const file of files) {
            const src = path.join(legacyDbDir, file);
            if (file.includes(".tmp.") || file.endsWith(".tmp")) {
              try { fs.unlinkSync(src); } catch {}
              continue;
            }
            if (file.endsWith(".dblc") || file.endsWith(".db.lc")) {
              const targetFile = file.endsWith(".db.lc") ? `${file.slice(0, -".db.lc".length)}.dblc` : file;
              const dest = path.join(targetTablesDir, targetFile);
              try {
                fs.copyFileSync(src, dest);
                fs.unlinkSync(src);
                tablesMigrated.push(`tables:${dbName}:${file}`);
              } catch {}
            }
          }
          try { fs.rmdirSync(legacyDbDir); } catch {}
        }
        try { fs.rmdirSync(legacyValuesDatabasesDir); } catch {}
      }

      // 3. Migrate any remaining .localdb/values/{db}/*.dblc -> .localdb/tables/{db}/*.dblc
      const legacyValuesDir = path.resolve(this.getEffectiveStorageDir(), "values");
      if (fs.existsSync(legacyValuesDir)) {
        const entries = fs.readdirSync(legacyValuesDir, { withFileTypes: true });
        for (const entry of entries) {
          if (entry.isDirectory() && !entry.name.startsWith(".")) {
            const dbName = entry.name;
            const subDir = path.join(legacyValuesDir, dbName);
            const targetTablesDir = this.getDatabaseTablesDir(dbName);
            if (!fs.existsSync(targetTablesDir)) fs.mkdirSync(targetTablesDir, { recursive: true });
            const files = fs.readdirSync(subDir);
            for (const file of files) {
              const src = path.join(subDir, file);
              if (file.endsWith(".dblc") || file.endsWith(".db.lc")) {
                const targetFile = file.endsWith(".db.lc") ? `${file.slice(0, -".db.lc".length)}.dblc` : file;
                const dest = path.join(targetTablesDir, targetFile);
                try {
                  fs.copyFileSync(src, dest);
                  fs.unlinkSync(src);
                  tablesMigrated.push(`tables:${dbName}:${file}`);
                } catch {}
              } else {
                try { fs.unlinkSync(src); } catch {}
              }
            }
            try { fs.rmdirSync(subDir); } catch {}
          }
        }
        try { fs.rmdirSync(legacyValuesDir); } catch {}
      }
    } catch {}

    return { migratedDatabases, tablesMigrated };
  }

  /**
   * Sync existing root .localdb tables into schema/default/ and tables/default/ and clean root files
   */
  public syncRootTablesToDefaultDatabase(): string[] {
    const { migrated } = this.cleanRootDblcFiles();
    return migrated;
  }

  /**
   * Migrate any existing legacy .db.lc files in storage to .dblc format
   */
  public migrateAllDbLcToDblc(dbName?: string): string[] {
    return migrateAllDbLcToDblcFiles(this, this.getEffectiveStorageDir(), dbName || this._databaseName || "default");
  }

  /**
   * Load all tables from storage or migrate from legacy store
   */
  public loadAllTables(dbName?: string): Record<string, DbTable> {
    this.detectBackend();
    const targetDb = dbName || this._databaseName || "default";
    const result: Record<string, DbTable> = {};
    const tableNames = this.listTableNames(targetDb);

    for (const name of tableNames) {
      const table = this.loadTable(name, targetDb);
      if (table) result[name] = table;
    }

    // If default db, attempt migration from legacy file, .Cache directory, or localStorage
    if (targetDb === "default") {
      if (Object.keys(result).length === 0) {
        const legacyTables = this.migrateFromLegacy();
        if (legacyTables) Object.assign(result, legacyTables);
      }
      this.migrateDotCache();
    }

    return result;
  }

  /**
   * Auto-migrate from legacy .Cache/localdb.json or _lc_localdb localStorage
   */
  public migrateFromLegacy(): Record<string, DbTable> | null {
    return migrateLegacyCacheStore(this);
  }

  /**
   * Auto-migrate and clean up any .Cache directory into LocalSQLServer
   */
  public migrateDotCache(baseDir?: string): import("./lc-legacy-migrator").MigrateCacheResult {
    return migrateDotCacheDirectoryToLocalSql(this, baseDir);
  }

  // ── HydroelectricEngine Integration ──────────────────────────────────────

  public getHydroelectricEngine(): HydroelectricEngine {
    return hydroelectricEngine;
  }

  public isTableFileLarge(tableName: string, dbName?: string, thresholdBytes?: number): boolean {
    const targetDb: string = dbName || this._databaseName || "default";
    const cleanName: string = this.normalizeTableName(tableName);
    const tablesPath: string = this.getTableTablesPath(cleanName, targetDb);
    return hydroelectricEngine.isLargeFile(tablesPath, thresholdBytes);
  }

  public getTableFileSizeBytes(tableName: string, dbName?: string): number {
    const targetDb: string = dbName || this._databaseName || "default";
    const cleanName: string = this.normalizeTableName(tableName);
    const tablesPath: string = this.getTableTablesPath(cleanName, targetDb);
    return hydroelectricEngine.getFileSize(tablesPath);
  }

  public async streamScanTable(
    tableName: string,
    options?: HydroelectricStreamOptions,
    dbName?: string
  ): Promise<HydroelectricStreamResult> {
    const targetDb: string = dbName || this._databaseName || "default";
    const cleanName: string = this.normalizeTableName(tableName);
    const tablesPath: string = this.getTableTablesPath(cleanName, targetDb);
    return hydroelectricEngine.streamScanRecords(tablesPath, options);
  }

  public async streamQueryTable(
    tableName: string,
    filter: {
      where?: (record: LcLocalDbRecord) => boolean;
      limit?: number;
      offset?: number;
      signal?: AbortSignal;
    },
    dbName?: string
  ): Promise<{ records: LcLocalDbRecord[]; stats: HydroelectricStreamResult }> {
    const targetDb: string = dbName || this._databaseName || "default";
    const cleanName: string = this.normalizeTableName(tableName);
    const tablesPath: string = this.getTableTablesPath(cleanName, targetDb);
    return hydroelectricEngine.streamQuery(tablesPath, filter);
  }

  private _syncLegacyLocalStorage(table: DbTable): void {
    syncLegacyLocalStorageStore(table);
  }
}

export { StorageAdapter as LcStorageAdapter };
