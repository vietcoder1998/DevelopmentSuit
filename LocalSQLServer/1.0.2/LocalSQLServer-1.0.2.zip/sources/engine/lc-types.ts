/**
 * packages/LocalSQLServer/sources/engine/lc-types.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * Type definitions for LocalDB SQL Engine
 * ─────────────────────────────────────────────────────────────────────────────
 */

export type LcLocalDbDefaultNamespace =
  | "lc_defaults"
  | "lc_projects"
  | "lc_workspaces"
  | "lc_ui"
  | "lc_services"
  | "lc_cache"
  | "lc_enums"
  | "lc_code"
  | "lc_project_files"
  | "lc_conversations";

export type LcLocalDbNamespace = LcLocalDbDefaultNamespace | (string & {});

export const LC_LOCAL_DB_DEFAULT_NAMESPACES: readonly LcLocalDbDefaultNamespace[] = [
  "lc_defaults",
  "lc_projects",
  "lc_workspaces",
  "lc_ui",
  "lc_services",
  "lc_cache",
  "lc_enums",
  "lc_code",
  "lc_project_files",
  "lc_conversations",
] as const;

export const LC_LOCAL_DB_NAMESPACES = [...LC_LOCAL_DB_DEFAULT_NAMESPACES] as LcLocalDbNamespace[];

export const LC_LOCAL_DB_FILE_EXTENSION = ".dblc";
export const LC_LOCAL_DB_LEGACY_FILE_EXTENSION = ".db.lc";

export interface LcLocalDbRecord<T = unknown> {
  key: string;
  namespace: string;
  value: T;
  createdAt: string;
  updatedAt: string;
  /** Optional TTL in ms. If set, record expires after this duration from createdAt */
  ttlMs?: number | null;
  /** Monotonic version counter for optimistic concurrency */
  version: number;
  tags?: string[];
}

export interface LcLocalDbSetOptions {
  /** TTL in milliseconds — null = permanent */
  ttlMs?: number | null;
  tags?: string[];
}

export interface LcLocalDbQueryOptions {
  /** Simple filter: keys are dot-separated paths into the record (e.g. "value.type") */
  where?: Record<string, unknown>;
  limit?: number;
  offset?: number;
  orderBy?: { field: string; direction?: "asc" | "desc" };
  tags?: string[];
  includeExpired?: boolean;
}

export type LcLocalDbRelationType = "1:1" | "1:N" | "N:N";
export type LcLocalDbCascadeAction = "CASCADE" | "SET_NULL" | "RESTRICT" | "NO_ACTION";

export interface LcLocalDbRelationship {
  id: string;
  sourceTable: string;
  sourceField: string;
  targetTable: string;
  targetField: string;
  relationType: LcLocalDbRelationType;
  onDelete?: LcLocalDbCascadeAction;
  onUpdate?: LcLocalDbCascadeAction;
  createdAt: string;
  updatedAt: string;
}

export interface LcLocalDbRelationData {
  id: string;
  recordKey: string;
  targetTable: string;
  targetKey: string;
  relationType: LcLocalDbRelationType | string;
  metadata?: unknown;
  createdAt: string;
}

export type LcLocalDbColumnDef =
  | string
  | {
      type: string;
      primaryKey?: boolean;
      notNull?: boolean;
      defaultValue?: unknown;
    };

export interface LcLocalDbIndexDef {
  name: string;
  columns: string[];
  unique?: boolean;
}

export interface LcLocalDbTableSchema {
  tableName: string;
  columns: Record<string, LcLocalDbColumnDef>;
  indexes?: LcLocalDbIndexDef[];
  relationships?: LcLocalDbRelationship[];
}

export interface LcLocalDbTableStats {
  recordCount: number;
  sizeBytes: number;
  lastUpdated: string | null;
  relationshipCount?: number;
  relationLinksCount?: number;
}

export interface LcLocalDbStats {
  totalRecords: number;
  totalSizeBytes: number;
  tableStats: Record<string, LcLocalDbTableStats>;
  backend: "localStorage" | "file" | "memory";
  lastVacuumedAt: string | null;
  engineVersion: string;
}

export interface DbTable {
  namespace: string;
  records: Record<string, LcLocalDbRecord>;
  relationships: LcLocalDbRelationship[];
  relations: Record<string, LcLocalDbRelationData>;
  schema?: LcLocalDbTableSchema;
  createdAt: string;
}

export type InternalDb = Record<string, DbTable>;

export interface LcLocalDbDump {
  version: number;
  exportedAt: string;
  engineVersion: string;
  tables: Record<
    string,
    {
      namespace: string;
      records: Record<string, LcLocalDbRecord>;
      relationships?: LcLocalDbRelationship[];
      relations?: Record<string, LcLocalDbRelationData>;
      schema?: LcLocalDbTableSchema;
      createdAt: string;
    }
  >;
  totalRecords: number;
  totalSizeBytes: number;
}

export interface LcLocalDbDatabaseInfo {
  name: string;
  path: string;
  tableCount: number;
  tables: string[];
}

export interface LcLocalDbMergeMemoryResult {
  mergedTables: string[];
  deletedMemoryDir: boolean;
}

export interface LcDatabaseFileInfo {
  tableName: string;
  schemaPath: string;
  tablesPath?: string;
  valuesPath: string;
  hasSchemaFile: boolean;
  hasTablesFile?: boolean;
  hasValuesFile: boolean;
  displaySchemaPath?: string;
  displayTablesPath?: string;
  displayValuesPath?: string;
}

export function nowIso(): string {
  return new Date().toISOString();
}

export function isExpired(record: LcLocalDbRecord): boolean {
  if (record.ttlMs == null) return false;
  return Date.now() >= new Date(record.createdAt).getTime() + record.ttlMs;
}

export function deepGet(obj: unknown, path: string): unknown {
  return path.split(".").reduce((acc: unknown, part) => {
    if (acc != null && typeof acc === "object") return (acc as Record<string, unknown>)[part];
    return undefined;
  }, obj);
}

export function matchesWhere(record: LcLocalDbRecord, where: Record<string, unknown>): boolean {
  return Object.entries(where).every(([path, expected]) => deepGet(record, path) === expected);
}

export function estimateSizeBytes(obj: unknown): number {
  try {
    return new Blob([JSON.stringify(obj)]).size;
  } catch {
    return JSON.stringify(obj).length * 2;
  }
}
