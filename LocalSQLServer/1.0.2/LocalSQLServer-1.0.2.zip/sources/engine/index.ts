/**
 * packages/LocalSQLServer/sources/engine/index.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * Barrel export for LocalSQL database engine modular architecture
 * ─────────────────────────────────────────────────────────────────────────────
 */

export * from "./lc-legacy-migrator";
export * from "./lc-relationship-manager";
export * from "./lc-sql-serializer";
export * from "./lc-storage-adapter";
export * from "./lc-types";
export * from "./hydroelectric-engine";

// Re-export the engine singleton
export * from "./lc-local-db-engine";
