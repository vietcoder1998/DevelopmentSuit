/**
 * packages/LocalSQLServer/sources/engine/lc-sql-serializer.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * SQL Serializer & Parser for {table-name}.dblc format
 * ─────────────────────────────────────────────────────────────────────────────
 */

import type {
  DbTable,
  LcLocalDbRecord,
  LcLocalDbRelationship,
  LcLocalDbRelationData,
} from "./lc-types";

export function escapeSqlString(str: string): string {
  const safeStr: string = typeof str === "string" ? str : String(str ?? "");
  return safeStr.replace(/'/g, "''");
}

export function unescapeSqlString(str: string): string {
  return str.replace(/^'|'$/g, "").replace(/''/g, "'");
}

export function parseSqlValues(raw: string): string[] {
  const values: string[] = [];
  let current = "";
  let inStr = false;
  let i = 0;
  while (i < raw.length) {
    const ch = raw[i];
    if (ch === "'" && !inStr) {
      inStr = true;
      current += ch;
    } else if (ch === "'" && inStr) {
      if (raw[i + 1] === "'") {
        current += "''";
        i++;
      } else {
        inStr = false;
        current += ch;
      }
    } else if (ch === "," && !inStr) {
      values.push(current.trim());
      current = "";
    } else {
      current += ch;
    }
    i++;
  }
  if (current.trim()) values.push(current.trim());
  return values;
}

/**
 * Serializes only the table schema (DDL) into {table-name}.dblc standard SQL syntax
 */
export function serializeTableSchemaToDblc(table: DbTable, engineVersion = "1.0.0"): string {
  const tableName = table.namespace;
  const now = new Date().toISOString();

  const lines: string[] = [
    `-- =============================================================================`,
    `-- LocalDB Table Schema: ${tableName}`,
    `-- File: ${tableName}.dblc`,
    `-- Format: Standard SQL (DDL Schema)`,
    `-- Schema Version: ${engineVersion}`,
    `-- Exported At: ${now}`,
    `-- =============================================================================`,
    "",
    `-- ── 1. Table Schema ─────────────────────────────────────────────────────────`,
    `CREATE TABLE IF NOT EXISTS ${tableName} (`,
    `  key TEXT PRIMARY KEY,`,
    `  value JSON,`,
    `  createdAt TEXT NOT NULL,`,
    `  updatedAt TEXT NOT NULL,`,
    `  ttlMs INTEGER,`,
    `  version INTEGER DEFAULT 1,`,
    `  tags TEXT`,
    `);`,
    "",
    `CREATE INDEX IF NOT EXISTS idx_${tableName}_updatedAt ON ${tableName}(updatedAt);`,
    "",
    `-- ── 2. Relationship Schema ──────────────────────────────────────────────────`,
    `CREATE TABLE IF NOT EXISTS ${tableName}_relationships (`,
    `  id TEXT PRIMARY KEY,`,
    `  sourceTable TEXT NOT NULL,`,
    `  sourceField TEXT NOT NULL,`,
    `  targetTable TEXT NOT NULL,`,
    `  targetField TEXT NOT NULL,`,
    `  relationType TEXT NOT NULL,`,
    `  onDelete TEXT DEFAULT 'CASCADE',`,
    `  onUpdate TEXT DEFAULT 'CASCADE',`,
    `  createdAt TEXT NOT NULL,`,
    `  updatedAt TEXT NOT NULL`,
    `);`,
    "",
    `-- ── 3. Relation Links Schema ────────────────────────────────────────────────`,
    `CREATE TABLE IF NOT EXISTS ${tableName}_relations (`,
    `  id TEXT PRIMARY KEY,`,
    `  recordKey TEXT NOT NULL,`,
    `  targetTable TEXT NOT NULL,`,
    `  targetKey TEXT NOT NULL,`,
    `  relationType TEXT NOT NULL,`,
    `  metadata JSON,`,
    `  createdAt TEXT NOT NULL`,
    `);`,
    "",
  ];

  return lines.join("\n");
}

/**
 * Serializes only the table values & records (DML) into {table-name}.dblc standard SQL syntax
 */
export function serializeTableValuesToDblc(table: DbTable, engineVersion = "1.0.0"): string {
  const tableName = table.namespace;
  const now = new Date().toISOString();

  const lines: string[] = [
    `-- =============================================================================`,
    `-- LocalDB Table Values: ${tableName}`,
    `-- File: ${tableName}.dblc`,
    `-- Format: Standard SQL (DML Values)`,
    `-- Schema Version: ${engineVersion}`,
    `-- Exported At: ${now}`,
    `-- Records Count: ${Object.keys(table.records).length}`,
    `-- Relationships Count: ${table.relationships?.length ?? 0}`,
    `-- Relations Count: ${Object.keys(table.relations ?? {}).length}`,
    `-- =============================================================================`,
    "",
    `-- ── 4. Table Records ────────────────────────────────────────────────────────`,
  ];

  // Records
  const records = Object.values(table.records);
  for (const record of records) {
    const valueJson = escapeSqlString(JSON.stringify(record.value));
    const tagsStr = escapeSqlString((record.tags ?? []).join(","));
    lines.push(
      `INSERT OR REPLACE INTO ${tableName} (key, value, createdAt, updatedAt, ttlMs, version, tags) VALUES (` +
        `'${escapeSqlString(record.key)}', ` +
        `'${valueJson}', ` +
        `'${escapeSqlString(record.createdAt)}', ` +
        `'${escapeSqlString(record.updatedAt)}', ` +
        `${record.ttlMs ?? "NULL"}, ` +
        `${record.version ?? 1}, ` +
        `'${tagsStr}'` +
        `);`
    );
  }

  // Relationships metadata
  lines.push("", `-- ── 5. Relationship Definitions ─────────────────────────────────────────────`);
  const rels = table.relationships ?? [];
  for (const rel of rels) {
    lines.push(
      `INSERT OR REPLACE INTO ${tableName}_relationships (id, sourceTable, sourceField, targetTable, targetField, relationType, onDelete, onUpdate, createdAt, updatedAt) VALUES (` +
        `'${escapeSqlString(rel.id)}', ` +
        `'${escapeSqlString(rel.sourceTable)}', ` +
        `'${escapeSqlString(rel.sourceField)}', ` +
        `'${escapeSqlString(rel.targetTable)}', ` +
        `'${escapeSqlString(rel.targetField)}', ` +
        `'${escapeSqlString(rel.relationType)}', ` +
        `'${escapeSqlString(rel.onDelete ?? "CASCADE")}', ` +
        `'${escapeSqlString(rel.onUpdate ?? "CASCADE")}', ` +
        `'${escapeSqlString(rel.createdAt)}', ` +
        `'${escapeSqlString(rel.updatedAt)}'` +
        `);`
    );
  }

  // Relations data
  lines.push("", `-- ── 6. Relation Links ────────────────────────────────────────────────────────`);
  const relationLinks = Object.values(table.relations ?? {});
  for (const link of relationLinks) {
    const metaJson = escapeSqlString(JSON.stringify(link.metadata ?? {}));
    lines.push(
      `INSERT OR REPLACE INTO ${tableName}_relations (id, recordKey, targetTable, targetKey, relationType, metadata, createdAt) VALUES (` +
        `'${escapeSqlString(link.id)}', ` +
        `'${escapeSqlString(link.recordKey)}', ` +
        `'${escapeSqlString(link.targetTable)}', ` +
        `'${escapeSqlString(link.targetKey)}', ` +
        `'${escapeSqlString(link.relationType)}', ` +
        `'${metaJson}', ` +
        `'${escapeSqlString(link.createdAt)}'` +
        `);`
    );
  }

  lines.push("");
  return lines.join("\n");
}

/**
 * Serializes an individual table into {table-name}.dblc standard SQL syntax (Combined DDL + DML)
 */
export function serializeTableToDblc(table: DbTable, engineVersion = "1.0.0"): string {
  const tableName = table.namespace;
  const now = new Date().toISOString();

  const lines: string[] = [
    `-- =============================================================================`,
    `-- LocalDB Table: ${tableName}`,
    `-- File: ${tableName}.dblc`,
    `-- Format: Standard SQL (DDL + DML)`,
    `-- Schema Version: ${engineVersion}`,
    `-- Exported At: ${now}`,
    `-- Records Count: ${Object.keys(table.records).length}`,
    `-- Relationships Count: ${table.relationships?.length ?? 0}`,
    `-- Relations Count: ${Object.keys(table.relations ?? {}).length}`,
    `-- =============================================================================`,
    "",
    `-- ── 1. Table Schema ─────────────────────────────────────────────────────────`,
    `CREATE TABLE IF NOT EXISTS ${tableName} (`,
    `  key TEXT PRIMARY KEY,`,
    `  value JSON,`,
    `  createdAt TEXT NOT NULL,`,
    `  updatedAt TEXT NOT NULL,`,
    `  ttlMs INTEGER,`,
    `  version INTEGER DEFAULT 1,`,
    `  tags TEXT`,
    `);`,
    "",
    `CREATE INDEX IF NOT EXISTS idx_${tableName}_updatedAt ON ${tableName}(updatedAt);`,
    "",
    `-- ── 2. Relationship Schema ──────────────────────────────────────────────────`,
    `CREATE TABLE IF NOT EXISTS ${tableName}_relationships (`,
    `  id TEXT PRIMARY KEY,`,
    `  sourceTable TEXT NOT NULL,`,
    `  sourceField TEXT NOT NULL,`,
    `  targetTable TEXT NOT NULL,`,
    `  targetField TEXT NOT NULL,`,
    `  relationType TEXT NOT NULL,`,
    `  onDelete TEXT DEFAULT 'CASCADE',`,
    `  onUpdate TEXT DEFAULT 'CASCADE',`,
    `  createdAt TEXT NOT NULL,`,
    `  updatedAt TEXT NOT NULL`,
    `);`,
    "",
    `-- ── 3. Relation Links Schema ────────────────────────────────────────────────`,
    `CREATE TABLE IF NOT EXISTS ${tableName}_relations (`,
    `  id TEXT PRIMARY KEY,`,
    `  recordKey TEXT NOT NULL,`,
    `  targetTable TEXT NOT NULL,`,
    `  targetKey TEXT NOT NULL,`,
    `  relationType TEXT NOT NULL,`,
    `  metadata JSON,`,
    `  createdAt TEXT NOT NULL`,
    `);`,
    "",
    `-- ── 4. Table Records ────────────────────────────────────────────────────────`,
  ];

  // Records
  const records = Object.values(table.records);
  for (const record of records) {
    const valueJson = escapeSqlString(JSON.stringify(record.value));
    const tagsStr = escapeSqlString((record.tags ?? []).join(","));
    lines.push(
      `INSERT OR REPLACE INTO ${tableName} (key, value, createdAt, updatedAt, ttlMs, version, tags) VALUES (` +
        `'${escapeSqlString(record.key)}', ` +
        `'${valueJson}', ` +
        `'${escapeSqlString(record.createdAt)}', ` +
        `'${escapeSqlString(record.updatedAt)}', ` +
        `${record.ttlMs ?? "NULL"}, ` +
        `${record.version ?? 1}, ` +
        `'${tagsStr}'` +
        `);`
    );
  }

  // Relationships metadata
  lines.push("", `-- ── 5. Relationship Definitions ─────────────────────────────────────────────`);
  const rels = table.relationships ?? [];
  for (const rel of rels) {
    lines.push(
      `INSERT OR REPLACE INTO ${tableName}_relationships (id, sourceTable, sourceField, targetTable, targetField, relationType, onDelete, onUpdate, createdAt, updatedAt) VALUES (` +
        `'${escapeSqlString(rel.id)}', ` +
        `'${escapeSqlString(rel.sourceTable)}', ` +
        `'${escapeSqlString(rel.sourceField)}', ` +
        `'${escapeSqlString(rel.targetTable)}', ` +
        `'${escapeSqlString(rel.targetField)}', ` +
        `'${escapeSqlString(rel.relationType)}', ` +
        `'${escapeSqlString(rel.onDelete ?? "CASCADE")}', ` +
        `'${escapeSqlString(rel.onUpdate ?? "CASCADE")}', ` +
        `'${escapeSqlString(rel.createdAt)}', ` +
        `'${escapeSqlString(rel.updatedAt)}'` +
        `);`
    );
  }

  // Relations data
  lines.push("", `-- ── 6. Relation Links ────────────────────────────────────────────────────────`);
  const relationLinks = Object.values(table.relations ?? {});
  for (const link of relationLinks) {
    const metaJson = escapeSqlString(JSON.stringify(link.metadata ?? {}));
    lines.push(
      `INSERT OR REPLACE INTO ${tableName}_relations (id, recordKey, targetTable, targetKey, relationType, metadata, createdAt) VALUES (` +
        `'${escapeSqlString(link.id)}', ` +
        `'${escapeSqlString(link.recordKey)}', ` +
        `'${escapeSqlString(link.targetTable)}', ` +
        `'${escapeSqlString(link.targetKey)}', ` +
        `'${escapeSqlString(link.relationType)}', ` +
        `'${metaJson}', ` +
        `'${escapeSqlString(link.createdAt)}'` +
        `);`
    );
  }

  lines.push("");
  return lines.join("\n");
}

/**
 * Backward compatibility alias for serializeTableToDblc
 */
export const serializeTableToDbLc = serializeTableToDblc;

export interface ParsedDbLcResult {
  tableName: string;
  records: Record<string, LcLocalDbRecord>;
  relationships: LcLocalDbRelationship[];
  relations: Record<string, LcLocalDbRelationData>;
}

export type ParsedDblcResult = ParsedDbLcResult;

/**
 * Parses a {table-name}.dblc or {table-name}.db.lc SQL text string into structured table data
 */
export function parseDblcSql(sql: string, fallbackTableName?: string): ParsedDblcResult {
  // Try to detect tableName from header comment or CREATE TABLE statement
  let tableName = fallbackTableName ?? "";
  const headerMatch = /--\s*(?:LowCode\s*)?LocalDB Table:\s*([a-zA-Z0-9_-]+)/i.exec(sql);
  if (headerMatch) {
    tableName = headerMatch[1].trim();
  } else {
    const createTableMatch = /CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?([a-zA-Z0-9_-]+)\s*\(/i.exec(sql);
    if (createTableMatch) {
      const matchName = createTableMatch[1].trim();
      if (!matchName.endsWith("_relationships") && !matchName.endsWith("_relations")) {
        tableName = matchName;
      }
    }
  }

  const records: Record<string, LcLocalDbRecord> = {};
  const relationships: LcLocalDbRelationship[] = [];
  const relations: Record<string, LcLocalDbRelationData> = {};

  for (const line of sql.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed.startsWith("INSERT")) continue;
    const match = /^INSERT\s+(?:OR\s+REPLACE\s+)?INTO\s+([a-zA-Z0-9_-]+)\s*\([^)]+\)\s*VALUES\s*\((.*)\);?$/i.exec(trimmed);
    if (!match) continue;
    const target = match[1].trim();
    const rawValues = match[2];

    try {
      const vals = parseSqlValues(rawValues);

      if (target.endsWith("_relationships")) {
        // [id, sourceTable, sourceField, targetTable, targetField, relationType, onDelete, onUpdate, createdAt, updatedAt]
        if (vals.length >= 6) {
          const [id, sourceTable, sourceField, targetTable, targetField, relationType, onDelete, onUpdate, createdAt, updatedAt] = vals;
          const rel: LcLocalDbRelationship = {
            id: unescapeSqlString(id),
            sourceTable: unescapeSqlString(sourceTable),
            sourceField: unescapeSqlString(sourceField),
            targetTable: unescapeSqlString(targetTable),
            targetField: unescapeSqlString(targetField),
            relationType: unescapeSqlString(relationType) as LcLocalDbRelationship["relationType"],
            onDelete: onDelete ? (unescapeSqlString(onDelete) as LcLocalDbRelationship["onDelete"]) : "CASCADE",
            onUpdate: onUpdate ? (unescapeSqlString(onUpdate) as LcLocalDbRelationship["onUpdate"]) : "CASCADE",
            createdAt: createdAt ? unescapeSqlString(createdAt) : new Date().toISOString(),
            updatedAt: updatedAt ? unescapeSqlString(updatedAt) : new Date().toISOString(),
          };
          relationships.push(rel);
        }
      } else if (target.endsWith("_relations")) {
        // [id, recordKey, targetTable, targetKey, relationType, metadata, createdAt]
        if (vals.length >= 5) {
          const [id, recordKey, targetTable, targetKey, relationType, metadataRaw, createdAt] = vals;
          let metadata: unknown = {};
          if (metadataRaw) {
            try {
              metadata = JSON.parse(unescapeSqlString(metadataRaw));
            } catch {
              metadata = {};
            }
          }
          const relId = unescapeSqlString(id);
          const link: LcLocalDbRelationData = {
            id: relId,
            recordKey: unescapeSqlString(recordKey),
            targetTable: unescapeSqlString(targetTable),
            targetKey: unescapeSqlString(targetKey),
            relationType: unescapeSqlString(relationType),
            metadata,
            createdAt: createdAt ? unescapeSqlString(createdAt) : new Date().toISOString(),
          };
          relations[relId] = link;
        }
      } else {
        // Main table record
        if (!tableName) tableName = target;
        if (vals.length >= 4) {
          const [key, valueJson, createdAt, updatedAt, ttlMsRaw, versionRaw, tagsRaw] = vals;
          const keyStr = unescapeSqlString(key);
          const value = JSON.parse(unescapeSqlString(valueJson));
          const ttlMs = ttlMsRaw && ttlMsRaw !== "NULL" ? Number(ttlMsRaw) : null;
          const version = versionRaw ? Number(versionRaw) : 1;
          const rawTagStr = tagsRaw ? unescapeSqlString(tagsRaw) : "";
          const tags = rawTagStr ? rawTagStr.split(",") : undefined;

          records[keyStr] = {
            key: keyStr,
            namespace: target,
            value,
            createdAt: unescapeSqlString(createdAt),
            updatedAt: unescapeSqlString(updatedAt),
            ttlMs,
            version,
            tags,
          };
        }
      }
    } catch {
      // Skip malformed rows
    }
  }

  return {
    tableName: tableName || fallbackTableName || "unnamed_table",
    records,
    relationships,
    relations,
  };
}

/**
 * Backward compatibility alias for parseDblcSql
 */
export const parseDbLcSql = parseDblcSql;
