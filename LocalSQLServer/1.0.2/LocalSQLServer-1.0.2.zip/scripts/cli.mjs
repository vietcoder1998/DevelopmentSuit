#!/usr/bin/env node
/**
 * packages/LocalSQLServer/scripts/cli.mjs
 * CLI entry point — delegates to server.ts (which exports runCli) via tsx
 */
import { spawn } from "node:child_process";
import * as path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const serverTs = path.join(__dirname, "..", "server.ts");
const args = process.argv.slice(2);

const child = spawn("npx", ["tsx", serverTs, ...args], {
  stdio: "inherit",
  shell: true,
  cwd: path.join(__dirname, ".."),
});

child.on("exit", (code) => process.exit(code ?? 0));
