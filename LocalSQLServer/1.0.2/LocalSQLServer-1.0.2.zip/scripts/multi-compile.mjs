#!/usr/bin/env node
/**
 * packages/LocalSQLServer/scripts/multi-compile.mjs
 * ─────────────────────────────────────────────────────────────────────────────
 * Cross-platform multi-target compilation runner for LocalSQLServer.
 * Compiles production bundles targeting:
 *   - Linux (x64 / arm64) -> dist/linux/
 *   - Windows (win32 x64) -> dist/win32/
 *   - macOS (darwin x64 / arm64) -> dist/darwin/
 *
 * Usage:
 *   node scripts/multi-compile.mjs                      # compile for all platforms
 *   node scripts/multi-compile.mjs --target=linux      # compile for Linux only
 *   node scripts/multi-compile.mjs --target=win32      # compile for Windows only
 *   node scripts/multi-compile.mjs --target=darwin     # compile for macOS only
 *   node scripts/multi-compile.mjs --pack              # trigger cross-platform packaging
 * ─────────────────────────────────────────────────────────────────────────────
 */

import esbuild from "esbuild";
import * as fs from "node:fs";
import * as path from "node:path";
import * as process from "node:process";
import { fileURLToPath } from "node:url";
import { spawn } from "node:child_process";

const currentModulePath = fileURLToPath(import.meta.url);
const packageDirectory = path.resolve(path.dirname(currentModulePath), "..");
const workspaceRoot = path.resolve(packageDirectory, "../..");

const PLATFORMS = [
  { name: "linux", ext: "", scriptExt: ".sh" },
  { name: "win32", ext: ".cmd", scriptExt: ".cmd" },
  { name: "darwin", ext: "", scriptExt: ".sh" },
];

/**
 * Builds the standalone bundle for a target platform
 * @param {string} targetPlatform
 */
export async function compileForPlatform(targetPlatform) {
  const distDir = path.join(packageDirectory, "dist", targetPlatform);
  if (!fs.existsSync(distDir)) {
    fs.mkdirSync(distDir, { recursive: true });
  }

  const outfile = path.join(distDir, "server.cjs");
  console.log(`[multi-compile] Building LocalSQLServer for target: ${targetPlatform} -> ${outfile}`);

  await esbuild.build({
    entryPoints: [path.join(packageDirectory, "server.ts")],
    bundle: true,
    platform: "node",
    target: "node18",
    format: "cjs",
    outfile,
    external: ["@grpc/grpc-js", "@grpc/proto-loader"],
    sourcemap: true,
    banner: {
      js: `#!/usr/bin/env node\n// LocalSQLServer standalone bundle for ${targetPlatform}`,
    },
  });

  // Generate platform-specific launcher
  if (targetPlatform === "win32") {
    const cmdPath = path.join(distDir, "localsqlserver.cmd");
    fs.writeFileSync(cmdPath, `@echo off\r\nnode "%~dp0\\server.cjs" %*\r\n`, "utf8");
  } else {
    const shPath = path.join(distDir, "localsqlserver");
    fs.writeFileSync(shPath, `#!/bin/sh\nexec node "$(dirname "$0")/server.cjs" "$@"\n`, {
      encoding: "utf8",
      mode: 0o755,
    });
  }

  console.log(`[multi-compile] Successfully compiled LocalSQLServer for ${targetPlatform}`);
}

/**
 * Main execution
 */
async function main() {
  const args = process.argv.slice(2);
  let targetArg = "all";
  let shouldPack = false;

  for (const arg of args) {
    if (arg.startsWith("--target=")) {
      targetArg = arg.split("=")[1];
    } else if (arg === "--pack") {
      shouldPack = true;
    }
  }

  const targetsToBuild =
    targetArg === "all"
      ? PLATFORMS.map((p) => p.name)
      : PLATFORMS.filter((p) => p.name === targetArg).map((p) => p.name);

  if (targetsToBuild.length === 0) {
    console.error(`Unknown target platform: ${targetArg}. Supported: linux, win32, darwin, all`);
    process.exit(1);
  }

  for (const target of targetsToBuild) {
    await compileForPlatform(target);
  }

  // Also compile the universal root server.js
  console.log(`[multi-compile] Building root server.js bundle...`);
  await esbuild.build({
    entryPoints: [path.join(packageDirectory, "server.ts")],
    bundle: true,
    platform: "node",
    target: "node18",
    outfile: path.join(packageDirectory, "server.js"),
    external: ["@grpc/grpc-js", "@grpc/proto-loader"],
  });

  if (shouldPack) {
    console.log(`[multi-compile] Triggering cross-platform distribution packaging...`);
    const packScript = path.join(workspaceRoot, "scripts", "build-server-apps.mjs");
    const child = spawn("node", [packScript, "--sql"], {
      cwd: workspaceRoot,
      stdio: "inherit",
    });
    child.on("exit", (code) => {
      process.exit(code || 0);
    });
  }
}

main().catch((err) => {
  console.error("[multi-compile] Compilation failed:", err);
  process.exit(1);
});
