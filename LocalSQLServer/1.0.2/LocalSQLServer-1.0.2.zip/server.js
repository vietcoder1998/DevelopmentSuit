"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// packages/LocalSQLServer/server.ts
var server_exports = {};
__export(server_exports, {
  runCli: () => runCli,
  startLocalSqlServer: () => startLocalSqlServer,
  stopLocalSqlServer: () => stopLocalSqlServer
});
module.exports = __toCommonJS(server_exports);
var import_node_fs4 = __toESM(require("node:fs"));
var import_node_path2 = __toESM(require("node:path"));
var import_node_module = __toESM(require("node:module"));

// packages/LocalSQLServer/sources/server/http-server.ts
var import_node_http = __toESM(require("node:http"));
var import_node_fs2 = __toESM(require("node:fs"));
var import_node_url = require("node:url");

// packages/LocalSQLServer/sources/engine/lc-sql-serializer.ts
function escapeSqlString(str) {
  const safeStr = typeof str === "string" ? str : String(str ?? "");
  return safeStr.replace(/'/g, "''");
}
function unescapeSqlString(str) {
  return str.replace(/^'|'$/g, "").replace(/''/g, "'");
}
function parseSqlValues(raw) {
  const values = [];
  let current = "";
  let inStr = false;
  let i = 0;
  while (i < raw.length) {
    const ch = raw[i];
    if (ch === "'" && !inStr) {
      inStr = true;
      current += ch;
    } else if (ch === "'" && inStr) {
      if (raw[i + 1] === "'") {
        current += "''";
        i++;
      } else {
        inStr = false;
        current += ch;
      }
    } else if (ch === "," && !inStr) {
      values.push(current.trim());
      current = "";
    } else {
      current += ch;
    }
    i++;
  }
  if (current.trim()) values.push(current.trim());
  return values;
}
function serializeTableSchemaToDblc(table, engineVersion = "1.0.0") {
  const tableName = table.namespace;
  const now2 = (/* @__PURE__ */ new Date()).toISOString();
  const lines = [
    `-- =============================================================================`,
    `-- LocalDB Table Schema: ${tableName}`,
    `-- File: ${tableName}.dblc`,
    `-- Format: Standard SQL (DDL Schema)`,
    `-- Schema Version: ${engineVersion}`,
    `-- Exported At: ${now2}`,
    `-- =============================================================================`,
    "",
    `-- \u2500\u2500 1. Table Schema \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500`,
    `CREATE TABLE IF NOT EXISTS ${tableName} (`,
    `  key TEXT PRIMARY KEY,`,
    `  value JSON,`,
    `  createdAt TEXT NOT NULL,`,
    `  updatedAt TEXT NOT NULL,`,
    `  ttlMs INTEGER,`,
    `  version INTEGER DEFAULT 1,`,
    `  tags TEXT`,
    `);`,
    "",
    `CREATE INDEX IF NOT EXISTS idx_${tableName}_updatedAt ON ${tableName}(updatedAt);`,
    "",
    `-- \u2500\u2500 2. Relationship Schema \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500`,
    `CREATE TABLE IF NOT EXISTS ${tableName}_relationships (`,
    `  id TEXT PRIMARY KEY,`,
    `  sourceTable TEXT NOT NULL,`,
    `  sourceField TEXT NOT NULL,`,
    `  targetTable TEXT NOT NULL,`,
    `  targetField TEXT NOT NULL,`,
    `  relationType TEXT NOT NULL,`,
    `  onDelete TEXT DEFAULT 'CASCADE',`,
    `  onUpdate TEXT DEFAULT 'CASCADE',`,
    `  createdAt TEXT NOT NULL,`,
    `  updatedAt TEXT NOT NULL`,
    `);`,
    "",
    `-- \u2500\u2500 3. Relation Links Schema \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500`,
    `CREATE TABLE IF NOT EXISTS ${tableName}_relations (`,
    `  id TEXT PRIMARY KEY,`,
    `  recordKey TEXT NOT NULL,`,
    `  targetTable TEXT NOT NULL,`,
    `  targetKey TEXT NOT NULL,`,
    `  relationType TEXT NOT NULL,`,
    `  metadata JSON,`,
    `  createdAt TEXT NOT NULL`,
    `);`,
    ""
  ];
  return lines.join("\n");
}
function serializeTableValuesToDblc(table, engineVersion = "1.0.0") {
  const tableName = table.namespace;
  const now2 = (/* @__PURE__ */ new Date()).toISOString();
  const lines = [
    `-- =============================================================================`,
    `-- LocalDB Table Values: ${tableName}`,
    `-- File: ${tableName}.dblc`,
    `-- Format: Standard SQL (DML Values)`,
    `-- Schema Version: ${engineVersion}`,
    `-- Exported At: ${now2}`,
    `-- Records Count: ${Object.keys(table.records).length}`,
    `-- Relationships Count: ${table.relationships?.length ?? 0}`,
    `-- Relations Count: ${Object.keys(table.relations ?? {}).length}`,
    `-- =============================================================================`,
    "",
    `-- \u2500\u2500 4. Table Records \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500`
  ];
  const records = Object.values(table.records);
  for (const record of records) {
    const valueJson = escapeSqlString(JSON.stringify(record.value));
    const tagsStr = escapeSqlString((record.tags ?? []).join(","));
    lines.push(
      `INSERT OR REPLACE INTO ${tableName} (key, value, createdAt, updatedAt, ttlMs, version, tags) VALUES ('${escapeSqlString(record.key)}', '${valueJson}', '${escapeSqlString(record.createdAt)}', '${escapeSqlString(record.updatedAt)}', ${record.ttlMs ?? "NULL"}, ${record.version ?? 1}, '${tagsStr}');`
    );
  }
  lines.push("", `-- \u2500\u2500 5. Relationship Definitions \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500`);
  const rels = table.relationships ?? [];
  for (const rel of rels) {
    lines.push(
      `INSERT OR REPLACE INTO ${tableName}_relationships (id, sourceTable, sourceField, targetTable, targetField, relationType, onDelete, onUpdate, createdAt, updatedAt) VALUES ('${escapeSqlString(rel.id)}', '${escapeSqlString(rel.sourceTable)}', '${escapeSqlString(rel.sourceField)}', '${escapeSqlString(rel.targetTable)}', '${escapeSqlString(rel.targetField)}', '${escapeSqlString(rel.relationType)}', '${escapeSqlString(rel.onDelete ?? "CASCADE")}', '${escapeSqlString(rel.onUpdate ?? "CASCADE")}', '${escapeSqlString(rel.createdAt)}', '${escapeSqlString(rel.updatedAt)}');`
    );
  }
  lines.push("", `-- \u2500\u2500 6. Relation Links \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500`);
  const relationLinks = Object.values(table.relations ?? {});
  for (const link of relationLinks) {
    const metaJson = escapeSqlString(JSON.stringify(link.metadata ?? {}));
    lines.push(
      `INSERT OR REPLACE INTO ${tableName}_relations (id, recordKey, targetTable, targetKey, relationType, metadata, createdAt) VALUES ('${escapeSqlString(link.id)}', '${escapeSqlString(link.recordKey)}', '${escapeSqlString(link.targetTable)}', '${escapeSqlString(link.targetKey)}', '${escapeSqlString(link.relationType)}', '${metaJson}', '${escapeSqlString(link.createdAt)}');`
    );
  }
  lines.push("");
  return lines.join("\n");
}
function serializeTableToDblc(table, engineVersion = "1.0.0") {
  const tableName = table.namespace;
  const now2 = (/* @__PURE__ */ new Date()).toISOString();
  const lines = [
    `-- =============================================================================`,
    `-- LocalDB Table: ${tableName}`,
    `-- File: ${tableName}.dblc`,
    `-- Format: Standard SQL (DDL + DML)`,
    `-- Schema Version: ${engineVersion}`,
    `-- Exported At: ${now2}`,
    `-- Records Count: ${Object.keys(table.records).length}`,
    `-- Relationships Count: ${table.relationships?.length ?? 0}`,
    `-- Relations Count: ${Object.keys(table.relations ?? {}).length}`,
    `-- =============================================================================`,
    "",
    `-- \u2500\u2500 1. Table Schema \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500`,
    `CREATE TABLE IF NOT EXISTS ${tableName} (`,
    `  key TEXT PRIMARY KEY,`,
    `  value JSON,`,
    `  createdAt TEXT NOT NULL,`,
    `  updatedAt TEXT NOT NULL,`,
    `  ttlMs INTEGER,`,
    `  version INTEGER DEFAULT 1,`,
    `  tags TEXT`,
    `);`,
    "",
    `CREATE INDEX IF NOT EXISTS idx_${tableName}_updatedAt ON ${tableName}(updatedAt);`,
    "",
    `-- \u2500\u2500 2. Relationship Schema \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500`,
    `CREATE TABLE IF NOT EXISTS ${tableName}_relationships (`,
    `  id TEXT PRIMARY KEY,`,
    `  sourceTable TEXT NOT NULL,`,
    `  sourceField TEXT NOT NULL,`,
    `  targetTable TEXT NOT NULL,`,
    `  targetField TEXT NOT NULL,`,
    `  relationType TEXT NOT NULL,`,
    `  onDelete TEXT DEFAULT 'CASCADE',`,
    `  onUpdate TEXT DEFAULT 'CASCADE',`,
    `  createdAt TEXT NOT NULL,`,
    `  updatedAt TEXT NOT NULL`,
    `);`,
    "",
    `-- \u2500\u2500 3. Relation Links Schema \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500`,
    `CREATE TABLE IF NOT EXISTS ${tableName}_relations (`,
    `  id TEXT PRIMARY KEY,`,
    `  recordKey TEXT NOT NULL,`,
    `  targetTable TEXT NOT NULL,`,
    `  targetKey TEXT NOT NULL,`,
    `  relationType TEXT NOT NULL,`,
    `  metadata JSON,`,
    `  createdAt TEXT NOT NULL`,
    `);`,
    "",
    `-- \u2500\u2500 4. Table Records \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500`
  ];
  const records = Object.values(table.records);
  for (const record of records) {
    const valueJson = escapeSqlString(JSON.stringify(record.value));
    const tagsStr = escapeSqlString((record.tags ?? []).join(","));
    lines.push(
      `INSERT OR REPLACE INTO ${tableName} (key, value, createdAt, updatedAt, ttlMs, version, tags) VALUES ('${escapeSqlString(record.key)}', '${valueJson}', '${escapeSqlString(record.createdAt)}', '${escapeSqlString(record.updatedAt)}', ${record.ttlMs ?? "NULL"}, ${record.version ?? 1}, '${tagsStr}');`
    );
  }
  lines.push("", `-- \u2500\u2500 5. Relationship Definitions \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500`);
  const rels = table.relationships ?? [];
  for (const rel of rels) {
    lines.push(
      `INSERT OR REPLACE INTO ${tableName}_relationships (id, sourceTable, sourceField, targetTable, targetField, relationType, onDelete, onUpdate, createdAt, updatedAt) VALUES ('${escapeSqlString(rel.id)}', '${escapeSqlString(rel.sourceTable)}', '${escapeSqlString(rel.sourceField)}', '${escapeSqlString(rel.targetTable)}', '${escapeSqlString(rel.targetField)}', '${escapeSqlString(rel.relationType)}', '${escapeSqlString(rel.onDelete ?? "CASCADE")}', '${escapeSqlString(rel.onUpdate ?? "CASCADE")}', '${escapeSqlString(rel.createdAt)}', '${escapeSqlString(rel.updatedAt)}');`
    );
  }
  lines.push("", `-- \u2500\u2500 6. Relation Links \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500`);
  const relationLinks = Object.values(table.relations ?? {});
  for (const link of relationLinks) {
    const metaJson = escapeSqlString(JSON.stringify(link.metadata ?? {}));
    lines.push(
      `INSERT OR REPLACE INTO ${tableName}_relations (id, recordKey, targetTable, targetKey, relationType, metadata, createdAt) VALUES ('${escapeSqlString(link.id)}', '${escapeSqlString(link.recordKey)}', '${escapeSqlString(link.targetTable)}', '${escapeSqlString(link.targetKey)}', '${escapeSqlString(link.relationType)}', '${metaJson}', '${escapeSqlString(link.createdAt)}');`
    );
  }
  lines.push("");
  return lines.join("\n");
}
function parseDblcSql(sql, fallbackTableName) {
  let tableName = fallbackTableName ?? "";
  const headerMatch = /--\s*(?:LowCode\s*)?LocalDB Table:\s*([a-zA-Z0-9_-]+)/i.exec(sql);
  if (headerMatch) {
    tableName = headerMatch[1].trim();
  } else {
    const createTableMatch = /CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?([a-zA-Z0-9_-]+)\s*\(/i.exec(sql);
    if (createTableMatch) {
      const matchName = createTableMatch[1].trim();
      if (!matchName.endsWith("_relationships") && !matchName.endsWith("_relations")) {
        tableName = matchName;
      }
    }
  }
  const records = {};
  const relationships = [];
  const relations = {};
  for (const line of sql.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed.startsWith("INSERT")) continue;
    const match = /^INSERT\s+(?:OR\s+REPLACE\s+)?INTO\s+([a-zA-Z0-9_-]+)\s*\([^)]+\)\s*VALUES\s*\((.*)\);?$/i.exec(trimmed);
    if (!match) continue;
    const target = match[1].trim();
    const rawValues = match[2];
    try {
      const vals = parseSqlValues(rawValues);
      if (target.endsWith("_relationships")) {
        if (vals.length >= 6) {
          const [id, sourceTable, sourceField, targetTable, targetField, relationType, onDelete, onUpdate, createdAt, updatedAt] = vals;
          const rel = {
            id: unescapeSqlString(id),
            sourceTable: unescapeSqlString(sourceTable),
            sourceField: unescapeSqlString(sourceField),
            targetTable: unescapeSqlString(targetTable),
            targetField: unescapeSqlString(targetField),
            relationType: unescapeSqlString(relationType),
            onDelete: onDelete ? unescapeSqlString(onDelete) : "CASCADE",
            onUpdate: onUpdate ? unescapeSqlString(onUpdate) : "CASCADE",
            createdAt: createdAt ? unescapeSqlString(createdAt) : (/* @__PURE__ */ new Date()).toISOString(),
            updatedAt: updatedAt ? unescapeSqlString(updatedAt) : (/* @__PURE__ */ new Date()).toISOString()
          };
          relationships.push(rel);
        }
      } else if (target.endsWith("_relations")) {
        if (vals.length >= 5) {
          const [id, recordKey, targetTable, targetKey, relationType, metadataRaw, createdAt] = vals;
          let metadata = {};
          if (metadataRaw) {
            try {
              metadata = JSON.parse(unescapeSqlString(metadataRaw));
            } catch {
              metadata = {};
            }
          }
          const relId = unescapeSqlString(id);
          const link = {
            id: relId,
            recordKey: unescapeSqlString(recordKey),
            targetTable: unescapeSqlString(targetTable),
            targetKey: unescapeSqlString(targetKey),
            relationType: unescapeSqlString(relationType),
            metadata,
            createdAt: createdAt ? unescapeSqlString(createdAt) : (/* @__PURE__ */ new Date()).toISOString()
          };
          relations[relId] = link;
        }
      } else {
        if (!tableName) tableName = target;
        if (vals.length >= 4) {
          const [key, valueJson, createdAt, updatedAt, ttlMsRaw, versionRaw, tagsRaw] = vals;
          const keyStr = unescapeSqlString(key);
          const value = JSON.parse(unescapeSqlString(valueJson));
          const ttlMs = ttlMsRaw && ttlMsRaw !== "NULL" ? Number(ttlMsRaw) : null;
          const version = versionRaw ? Number(versionRaw) : 1;
          const rawTagStr = tagsRaw ? unescapeSqlString(tagsRaw) : "";
          const tags = rawTagStr ? rawTagStr.split(",") : void 0;
          records[keyStr] = {
            key: keyStr,
            namespace: target,
            value,
            createdAt: unescapeSqlString(createdAt),
            updatedAt: unescapeSqlString(updatedAt),
            ttlMs,
            version,
            tags
          };
        }
      }
    } catch {
    }
  }
  return {
    tableName: tableName || fallbackTableName || "unnamed_table",
    records,
    relationships,
    relations
  };
}

// packages/LocalSQLServer/sources/engine/lc-legacy-migrator.ts
var LEGACY_CACHE_FILE = ".Cache/localdb.json";
var LEGACY_LS_KEY = "_lc_localdb";
function isNodeEnv() {
  return typeof window === "undefined" && typeof process !== "undefined";
}
function isBrowserEnv() {
  return typeof window !== "undefined" && typeof localStorage !== "undefined";
}
function getFs() {
  return typeof require !== "undefined" ? require("node:fs") : null;
}
function getPath() {
  return typeof require !== "undefined" ? require("node:path") : null;
}
function mergeMemoryIntoStorage(storage, targetDbName = "default") {
  const mergedTables = [];
  let deletedMemoryDir = false;
  if (!isNodeEnv()) return { mergedTables, deletedMemoryDir };
  try {
    const fs5 = getFs();
    const path3 = getPath();
    if (!fs5 || !path3) return { mergedTables, deletedMemoryDir };
    const memoryDir = path3.resolve(process.cwd(), ":memory:");
    if (fs5.existsSync(memoryDir)) {
      const files = fs5.readdirSync(memoryDir);
      for (const file of files) {
        if (!file.endsWith(".dblc") && !file.endsWith(".db.lc")) continue;
        const tableName = file.replace(/\.(dblc|db\.lc)$/i, "");
        const memoryFilePath = path3.join(memoryDir, file);
        const memoryRaw = fs5.readFileSync(memoryFilePath, "utf8");
        const memoryParsed = parseDblcSql(memoryRaw, tableName);
        const existingTable = storage.loadTable(tableName, targetDbName);
        const mergedRecords = { ...existingTable?.records ?? {} };
        for (const [key, rec] of Object.entries(memoryParsed.records ?? {})) {
          if (!mergedRecords[key]) {
            mergedRecords[key] = rec;
          } else {
            const existingRec = mergedRecords[key];
            const memoryRec = rec;
            if ((memoryRec.version ?? 0) >= (existingRec.version ?? 0) || memoryRec.updatedAt && (!existingRec.updatedAt || memoryRec.updatedAt >= existingRec.updatedAt)) {
              mergedRecords[key] = memoryRec;
            }
          }
        }
        const mergedRelationships = [
          ...existingTable?.relationships ?? [],
          ...(memoryParsed.relationships ?? []).filter(
            (r) => !existingTable?.relationships?.some(
              (er) => er.sourceField === r.sourceField && er.targetTable === r.targetTable && er.targetField === r.targetField
            )
          )
        ];
        const mergedRelations = {
          ...existingTable?.relations ?? {},
          ...memoryParsed.relations ?? {}
        };
        const mergedTable = {
          namespace: tableName,
          records: mergedRecords,
          relationships: mergedRelationships,
          relations: mergedRelations,
          schema: existingTable?.schema,
          createdAt: existingTable?.createdAt ?? (/* @__PURE__ */ new Date()).toISOString()
        };
        storage.saveTable(mergedTable, targetDbName);
        mergedTables.push(tableName);
      }
      fs5.rmSync(memoryDir, { recursive: true, force: true });
      deletedMemoryDir = true;
    }
  } catch {
  }
  return { mergedTables, deletedMemoryDir };
}
function migrateLegacyCacheStore(storage) {
  if (isBrowserEnv()) {
    try {
      const raw = localStorage.getItem(LEGACY_LS_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        const migrated = {};
        for (const [ns, tbl] of Object.entries(parsed)) {
          const table = {
            namespace: ns,
            records: tbl.records ?? {},
            relationships: [],
            relations: {},
            createdAt: tbl.createdAt ?? (/* @__PURE__ */ new Date()).toISOString()
          };
          migrated[ns] = table;
          storage.saveTable(table);
        }
        return migrated;
      }
    } catch {
      return null;
    }
  }
  if (isNodeEnv()) {
    try {
      const fs5 = getFs();
      const path3 = getPath();
      if (!fs5 || !path3) return null;
      const legacyPath = path3.resolve(process.cwd(), LEGACY_CACHE_FILE);
      if (fs5.existsSync(legacyPath)) {
        const raw = fs5.readFileSync(legacyPath, "utf8");
        const parsed = JSON.parse(raw);
        const migrated = {};
        for (const [ns, tbl] of Object.entries(parsed)) {
          const normalizedRecords = {};
          for (const [recKey, rawRec] of Object.entries(tbl.records ?? {})) {
            const recObj = rawRec && typeof rawRec === "object" ? rawRec : { value: rawRec };
            const recKeyStr = String(recObj.key || recObj.id || recKey);
            normalizedRecords[recKeyStr] = {
              key: recKeyStr,
              namespace: ns,
              value: "value" in recObj ? recObj.value : recObj,
              createdAt: recObj.createdAt || (/* @__PURE__ */ new Date()).toISOString(),
              updatedAt: recObj.updatedAt || (/* @__PURE__ */ new Date()).toISOString(),
              ttlMs: recObj.ttlMs || null,
              version: recObj.version || 1,
              tags: Array.isArray(recObj.tags) ? recObj.tags : ["migrated-cache"]
            };
          }
          const table = {
            namespace: ns,
            records: normalizedRecords,
            relationships: [],
            relations: {},
            createdAt: tbl.createdAt ?? (/* @__PURE__ */ new Date()).toISOString()
          };
          migrated[ns] = table;
          storage.saveTable(table);
        }
        try {
          fs5.unlinkSync(legacyPath);
          const cacheDir = path3.dirname(legacyPath);
          if (fs5.existsSync(cacheDir)) {
            const remaining = fs5.readdirSync(cacheDir);
            if (remaining.length === 0) {
              fs5.rmdirSync(cacheDir);
            } else {
              fs5.rmSync(cacheDir, { recursive: true, force: true });
            }
          }
        } catch {
        }
        return migrated;
      }
    } catch {
      return null;
    }
  }
  return null;
}
function migrateDotCacheDirectoryToLocalSql(storage, baseDir = process.cwd()) {
  const result = {
    migratedKeysCount: 0,
    removedFiles: [],
    deletedCacheDir: false
  };
  if (!isNodeEnv()) return result;
  try {
    const fs5 = getFs();
    const path3 = getPath();
    if (!fs5 || !path3) return result;
    const cacheDir = path3.resolve(baseDir, ".Cache");
    if (!fs5.existsSync(cacheDir)) return result;
    const entries = fs5.readdirSync(cacheDir);
    for (const file of entries) {
      const fullPath = path3.join(cacheDir, file);
      try {
        const stat = fs5.statSync(fullPath);
        if (stat.isFile() && file.endsWith(".json")) {
          const content = fs5.readFileSync(fullPath, "utf8");
          const parsed = JSON.parse(content);
          if (typeof parsed === "object" && parsed !== null) {
            let isTableFormat = false;
            for (const v of Object.values(parsed)) {
              if (v && typeof v === "object" && ("records" in v || "namespace" in v)) {
                isTableFormat = true;
                break;
              }
            }
            if (isTableFormat) {
              for (const [ns, tbl] of Object.entries(parsed)) {
                const normalizedRecords = {};
                for (const [recKey, rawRec] of Object.entries(tbl.records ?? {})) {
                  const recObj = rawRec && typeof rawRec === "object" ? rawRec : { value: rawRec };
                  const recKeyStr = String(recObj.key || recObj.id || recKey);
                  normalizedRecords[recKeyStr] = {
                    key: recKeyStr,
                    namespace: ns,
                    value: "value" in recObj ? recObj.value : recObj,
                    createdAt: recObj.createdAt || (/* @__PURE__ */ new Date()).toISOString(),
                    updatedAt: recObj.updatedAt || (/* @__PURE__ */ new Date()).toISOString(),
                    ttlMs: recObj.ttlMs || null,
                    version: recObj.version || 1,
                    tags: Array.isArray(recObj.tags) ? recObj.tags : ["migrated-cache"]
                  };
                }
                const table = {
                  namespace: ns,
                  records: normalizedRecords,
                  relationships: [],
                  relations: {},
                  createdAt: tbl.createdAt ?? (/* @__PURE__ */ new Date()).toISOString()
                };
                storage.saveTable(table);
                result.migratedKeysCount += Object.keys(table.records).length;
              }
            } else {
              const cacheTable = storage.loadTable("lc_cache") || {
                namespace: "lc_cache",
                records: {},
                relationships: [],
                relations: {},
                createdAt: (/* @__PURE__ */ new Date()).toISOString()
              };
              for (const [key, val] of Object.entries(parsed)) {
                cacheTable.records[key] = {
                  key,
                  namespace: "lc_cache",
                  value: val,
                  createdAt: (/* @__PURE__ */ new Date()).toISOString(),
                  updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
                  ttlMs: null,
                  version: 1,
                  tags: ["migrated-cache"]
                };
                result.migratedKeysCount += 1;
              }
              storage.saveTable(cacheTable);
            }
          }
          fs5.unlinkSync(fullPath);
          result.removedFiles.push(file);
        } else if (stat.isFile()) {
          fs5.unlinkSync(fullPath);
          result.removedFiles.push(file);
        }
      } catch {
        try {
          if (fs5.existsSync(fullPath)) {
            fs5.unlinkSync(fullPath);
            result.removedFiles.push(file);
          }
        } catch {
        }
      }
    }
    if (fs5.existsSync(cacheDir)) {
      const remaining = fs5.readdirSync(cacheDir);
      if (remaining.length === 0) {
        fs5.rmdirSync(cacheDir);
        result.deletedCacheDir = true;
      } else {
        fs5.rmSync(cacheDir, { recursive: true, force: true });
        result.deletedCacheDir = true;
      }
    }
  } catch {
  }
  return result;
}
function syncLegacyLocalStorageStore(table) {
  if (!isBrowserEnv()) return;
  try {
    const raw = localStorage.getItem(LEGACY_LS_KEY);
    const parsed = raw ? JSON.parse(raw) : {};
    parsed[table.namespace] = table;
    localStorage.setItem(LEGACY_LS_KEY, JSON.stringify(parsed));
  } catch {
  }
}
function migrateAllDbLcToDblcFiles(storage, storageDir, dbName = "default") {
  const migrated = [];
  if (!isNodeEnv()) return migrated;
  try {
    const fs5 = getFs();
    const path3 = getPath();
    if (!fs5 || !path3) return migrated;
    const dbDir = storage.getDatabaseDir ? storage.getDatabaseDir(dbName) : path3.resolve(process.cwd(), storageDir, "schema", dbName);
    const dirsToCheck = [
      dbDir,
      path3.resolve(process.cwd(), storageDir, "schema", dbName),
      path3.resolve(process.cwd(), storageDir, "tables", dbName),
      path3.resolve(process.cwd(), storageDir, "schema", "databases", dbName),
      path3.resolve(process.cwd(), storageDir, "values", "databases", dbName),
      path3.resolve(process.cwd(), storageDir, "values", dbName)
    ];
    for (const d of dirsToCheck) {
      if (!fs5.existsSync(d)) continue;
      for (const file of fs5.readdirSync(d)) {
        if (file.endsWith(".db.lc")) {
          const cleanName = file.slice(0, -".db.lc".length);
          const legacyPath = path3.join(d, file);
          const raw = fs5.readFileSync(legacyPath, "utf8");
          const parsed = parseDblcSql(raw, cleanName);
          const table = {
            namespace: parsed.tableName || cleanName,
            records: parsed.records,
            relationships: parsed.relationships,
            relations: parsed.relations,
            createdAt: (/* @__PURE__ */ new Date()).toISOString()
          };
          storage.saveTable(table, dbName);
          try {
            fs5.unlinkSync(legacyPath);
          } catch {
          }
          if (!migrated.includes(cleanName)) migrated.push(cleanName);
        }
      }
    }
    if (dbName === "default") {
      const rootDir = path3.resolve(process.cwd(), storageDir);
      if (fs5.existsSync(rootDir)) {
        for (const file of fs5.readdirSync(rootDir)) {
          if (file.endsWith(".db.lc")) {
            const cleanName = file.slice(0, -".db.lc".length);
            const legacyPath = path3.join(rootDir, file);
            const raw = fs5.readFileSync(legacyPath, "utf8");
            const parsed = parseDblcSql(raw, cleanName);
            const table = {
              namespace: parsed.tableName || cleanName,
              records: parsed.records,
              relationships: parsed.relationships,
              relations: parsed.relations,
              createdAt: (/* @__PURE__ */ new Date()).toISOString()
            };
            storage.saveTable(table, "default");
            try {
              fs5.unlinkSync(legacyPath);
            } catch {
            }
            if (!migrated.includes(cleanName)) migrated.push(cleanName);
          }
        }
      }
    }
  } catch {
  }
  return migrated;
}

// packages/LocalSQLServer/sources/engine/lc-relationship-manager.ts
function now() {
  return (/* @__PURE__ */ new Date()).toISOString();
}
var RelationshipManager = class {
  /**
   * Define or update a relationship specification on a table
   */
  static defineRelationship(table, rel) {
    const id = rel.id ?? `rel-${rel.sourceTable}-${rel.sourceField}-${rel.targetTable}`;
    const ts = now();
    const existingIndex = table.relationships.findIndex((r) => r.id === id);
    const fullRel = {
      id,
      sourceTable: rel.sourceTable,
      sourceField: rel.sourceField,
      targetTable: rel.targetTable,
      targetField: rel.targetField,
      relationType: rel.relationType,
      onDelete: rel.onDelete ?? "CASCADE",
      onUpdate: rel.onUpdate ?? "CASCADE",
      createdAt: existingIndex >= 0 ? table.relationships[existingIndex].createdAt : ts,
      updatedAt: ts
    };
    if (existingIndex >= 0) {
      table.relationships[existingIndex] = fullRel;
    } else {
      table.relationships.push(fullRel);
    }
    return fullRel;
  }
  /**
   * Remove a relationship definition
   */
  static removeRelationship(table, relationshipId) {
    const idx = table.relationships.findIndex((r) => r.id === relationshipId);
    if (idx >= 0) {
      table.relationships.splice(idx, 1);
      return true;
    }
    return false;
  }
  /**
   * Link two records across tables
   */
  static linkRecords(table, recordKey, targetTable, targetKey, relationType = "1:N", metadata) {
    const id = `link-${table.namespace}-${recordKey}-${targetTable}-${targetKey}`;
    const link = {
      id,
      recordKey,
      targetTable,
      targetKey,
      relationType,
      metadata,
      createdAt: now()
    };
    table.relations[id] = link;
    return link;
  }
  /**
   * Unlink two records
   */
  static unlinkRecords(table, recordKey, targetTable, targetKey) {
    const id = `link-${table.namespace}-${recordKey}-${targetTable}-${targetKey}`;
    if (table.relations[id]) {
      delete table.relations[id];
      return true;
    }
    for (const [key, link] of Object.entries(table.relations)) {
      if (link.recordKey === recordKey && link.targetTable === targetTable && link.targetKey === targetKey) {
        delete table.relations[key];
        return true;
      }
    }
    return false;
  }
  /**
   * Query related records for a given record in source table
   */
  static getRelatedRecords(table, recordKey, getRecordFn, targetTableFilter) {
    const results = [];
    for (const link of Object.values(table.relations)) {
      if (link.recordKey !== recordKey) continue;
      if (targetTableFilter && link.targetTable !== targetTableFilter) continue;
      const targetRecord = getRecordFn(link.targetTable, link.targetKey);
      results.push({
        relation: link,
        targetRecord
      });
    }
    return results;
  }
  /**
   * Automatically detect foreign key patterns in records and propose relationships
   */
  static autoDetectRelationships(tableName, records, knownTables) {
    const detected = /* @__PURE__ */ new Map();
    const tableKeysLower = new Map(knownTables.map((t) => [t.toLowerCase().replace(/^(lc_|tbl_)/, ""), t]));
    for (const record of Object.values(records)) {
      if (!record.value || typeof record.value !== "object") continue;
      const obj = record.value;
      for (const fieldName of Object.keys(obj)) {
        if (fieldName.endsWith("Id") && fieldName.length > 2 && fieldName !== "id") {
          const baseName = fieldName.slice(0, -2).toLowerCase();
          const matchedTarget = tableKeysLower.get(baseName) || tableKeysLower.get(`${baseName}s`) || knownTables.find((t) => t.toLowerCase().includes(baseName));
          if (matchedTarget) {
            const relId = `rel-${tableName}-${fieldName}-${matchedTarget}`;
            if (!detected.has(relId)) {
              detected.set(relId, {
                id: relId,
                sourceTable: tableName,
                sourceField: fieldName,
                targetTable: matchedTarget,
                targetField: "key",
                relationType: "1:N",
                onDelete: "CASCADE",
                onUpdate: "CASCADE",
                createdAt: now(),
                updatedAt: now()
              });
            }
          }
        }
      }
    }
    return Array.from(detected.values());
  }
};

// packages/LocalSQLServer/sources/engine/hydroelectric-engine.ts
var import_node_fs = __toESM(require("node:fs"));
var import_node_readline = __toESM(require("node:readline"));
var DEFAULT_HYDROELECTRIC_CONFIG = {
  engine: "HydroelectricEngine",
  version: "1.0.0",
  mode: "STREAMING_PIPELINE",
  bufferSize: 1024 * 1024,
  // 1 MB rolling intake buffer
  chunkSizeBytes: 64 * 1024,
  // 64 KB intake chunk
  highWaterMarkBytes: 2 * 1024 * 1024,
  // 2 MB backpressure high-water mark
  largeFileThresholdBytes: 50 * 1024 * 1024,
  // 50 MB threshold (automatically activates for >10GB)
  tenGigabytesBenchmarkBytes: 10 * 1024 * 1024 * 1024,
  // 10 GB benchmark reference
  timeComplexity: "O(n)",
  spaceComplexity: "O(1)",
  backpressureEnabled: true,
  memorySafetyThresholdMb: 512,
  spillwayDrainTimeoutMs: 3e4,
  maxConcurrentStreams: 8,
  encoding: "utf-8"
};
var HydroelectricEngine = class _HydroelectricEngine {
  static singletonInstance = null;
  fileSystem;
  logger;
  config;
  totalStreamsExecuted = 0;
  totalBytesStreamed = 0;
  activeStreamsCount = 0;
  lastStreamDurationMs = 0;
  lastStreamThroughputMbPerSec = 0;
  constructor(dependencies) {
    this.fileSystem = dependencies?.fileSystem ?? import_node_fs.default;
    this.logger = dependencies?.logger ?? console;
    this.config = { ...DEFAULT_HYDROELECTRIC_CONFIG };
  }
  static getInstance(dependencies) {
    if (!_HydroelectricEngine.singletonInstance) {
      _HydroelectricEngine.singletonInstance = new _HydroelectricEngine(dependencies);
    }
    return _HydroelectricEngine.singletonInstance;
  }
  static resetInstance() {
    _HydroelectricEngine.singletonInstance = null;
  }
  static setInstanceForTesting(instance) {
    _HydroelectricEngine.singletonInstance = instance;
  }
  getConfig() {
    return { ...this.config };
  }
  updateConfig(overrides) {
    this.config = { ...this.config, ...overrides };
  }
  /**
   * Fast O(1) check if a target table file exceeds the large file threshold (e.g. > 50MB, or > 10GB).
   * Checks file metadata via statSync without loading any file bytes into memory.
   */
  isLargeFile(filePath, customThresholdBytes) {
    if (!filePath || typeof filePath !== "string") {
      return false;
    }
    try {
      if (!this.fileSystem.existsSync(filePath)) {
        return false;
      }
      const stat = this.fileSystem.statSync(filePath);
      const threshold = customThresholdBytes ?? this.config.largeFileThresholdBytes;
      return stat.size >= threshold;
    } catch {
      return false;
    }
  }
  /**
   * Fast O(1) check of file size in bytes via statSync.
   */
  getFileSize(filePath) {
    try {
      if (!this.fileSystem.existsSync(filePath)) {
        return 0;
      }
      const stat = this.fileSystem.statSync(filePath);
      return stat.size;
    } catch {
      return 0;
    }
  }
  /**
   * Extracts table name from SQL CREATE statement or header comment in O(1) time
   * by reading only the first chunk of the file stream without loading the rest.
   */
  async streamReadTableMetadata(filePath) {
    return new Promise((resolve, reject) => {
      if (!this.fileSystem.existsSync(filePath)) {
        resolve({ tableName: "unknown", schemaSql: "" });
        return;
      }
      const stream = this.fileSystem.createReadStream(filePath, {
        encoding: "utf-8",
        highWaterMark: 64 * 1024
      });
      let accumulatedChunk = "";
      let foundTableName = "unknown";
      let schemaSql = "";
      stream.on("data", (chunk) => {
        accumulatedChunk += typeof chunk === "string" ? chunk : chunk.toString("utf-8");
        const headerMatch = /--\s*(?:LowCode\s*)?LocalDB Table:\s*([a-zA-Z0-9_-]+)/i.exec(accumulatedChunk);
        if (headerMatch) {
          foundTableName = headerMatch[1].trim();
        }
        const createTableMatch = /CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?([a-zA-Z0-9_-]+)\s*\(([\s\S]*?)\);/i.exec(accumulatedChunk);
        if (createTableMatch) {
          if (foundTableName === "unknown") {
            foundTableName = createTableMatch[1].trim();
          }
          schemaSql = createTableMatch[0];
          stream.destroy();
          resolve({ tableName: foundTableName, schemaSql });
        }
        if (accumulatedChunk.length > 256 * 1024) {
          stream.destroy();
          resolve({ tableName: foundTableName, schemaSql });
        }
      });
      stream.on("error", (err) => {
        reject(err);
      });
      stream.on("close", () => {
        resolve({ tableName: foundTableName, schemaSql });
      });
    });
  }
  /**
   * Parses a single SQL INSERT line into a LcLocalDbRecord with zero string duplication.
   */
  parseInsertLine(line, fallbackTableName) {
    const trimmed = line.trim();
    if (!trimmed.startsWith("INSERT")) {
      return null;
    }
    const insertMatch = /^INSERT\s+(?:OR\s+REPLACE\s+)?INTO\s+([a-zA-Z0-9_-]+)\s*\([^)]+\)\s*VALUES\s*\((.*)\);?$/i.exec(trimmed);
    if (!insertMatch) {
      return null;
    }
    const targetTable = insertMatch[1].trim();
    if (targetTable.endsWith("_relationships") || targetTable.endsWith("_relations")) {
      return null;
    }
    const rawValuesString = insertMatch[2];
    const parsedValues = parseSqlValues(rawValuesString);
    if (parsedValues.length < 2) {
      return null;
    }
    const recordKey = unescapeSqlString(parsedValues[0]);
    const rawJsonPayload = unescapeSqlString(parsedValues[1]);
    let parsedValueObject;
    try {
      parsedValueObject = JSON.parse(rawJsonPayload);
    } catch {
      parsedValueObject = { raw: rawJsonPayload };
    }
    const createdAt = parsedValues[2] ? unescapeSqlString(parsedValues[2]) : (/* @__PURE__ */ new Date()).toISOString();
    const updatedAt = parsedValues[3] ? unescapeSqlString(parsedValues[3]) : createdAt;
    const ttlMsRaw = parsedValues[4]?.trim();
    const ttlMs = ttlMsRaw && ttlMsRaw !== "NULL" ? Number(ttlMsRaw) : null;
    const versionRaw = parsedValues[5]?.trim();
    const version = versionRaw ? Number(versionRaw) : 1;
    const tagsRaw = parsedValues[6] ? unescapeSqlString(parsedValues[6]) : "";
    const tags = tagsRaw ? tagsRaw.split(",").filter((t) => t.length > 0) : [];
    const resolvedTable = targetTable || fallbackTableName || "default_table";
    const record = {
      key: recordKey,
      namespace: resolvedTable,
      value: parsedValueObject,
      createdAt,
      updatedAt,
      ttlMs,
      version,
      tags
    };
    return { targetTable: resolvedTable, record };
  }
  /**
   * Synchronously streams and scans a table file using chunked buffers (default 64KB)
   * without ever allocating a large string or exceeding V8 string limits.
   * Can safely parse files > 10 GB in strict O(n) time and O(1) buffer space.
   */
  syncStreamScanFile(filePath, options) {
    if (!this.fileSystem.existsSync(filePath)) {
      return {
        tableName: "unknown",
        totalRecordsScanned: 0,
        matchedRecords: 0,
        totalBytesScanned: 0,
        records: {}
      };
    }
    const chunkSize = options?.chunkSizeBytes || this.config.chunkSizeBytes;
    const fd = this.fileSystem.openSync(filePath, "r");
    const buffer = Buffer.allocUnsafe(chunkSize);
    let remainder = "";
    let detectedTableName = "unknown";
    let totalRecordsScanned = 0;
    let matchedRecords = 0;
    let totalBytesScanned = 0;
    const recordsMap = {};
    const offset = options?.offset || 0;
    const maxRecords = options?.maxRecords || Infinity;
    try {
      let bytesRead = 0;
      while ((bytesRead = this.fileSystem.readSync(fd, buffer, 0, chunkSize, null)) > 0) {
        totalBytesScanned += bytesRead;
        const chunkString = remainder + buffer.toString("utf-8", 0, bytesRead);
        const lines = chunkString.split(/\r?\n/);
        remainder = lines.pop() || "";
        for (const line of lines) {
          if (detectedTableName === "unknown" && line.startsWith("--")) {
            const headerMatch = /--\s*(?:LowCode\s*)?LocalDB Table:\s*([a-zA-Z0-9_-]+)/i.exec(line);
            if (headerMatch) {
              detectedTableName = headerMatch[1].trim();
            }
          }
          const parsed = this.parseInsertLine(line, detectedTableName);
          if (!parsed) {
            continue;
          }
          if (detectedTableName === "unknown") {
            detectedTableName = parsed.targetTable;
          }
          totalRecordsScanned += 1;
          if (totalRecordsScanned <= offset) {
            continue;
          }
          if (options?.whereClause && !options.whereClause(parsed.record)) {
            continue;
          }
          matchedRecords += 1;
          if (options?.onRecord) {
            const shouldContinue = options.onRecord(parsed.record, matchedRecords);
            if (shouldContinue === false) {
              return {
                tableName: detectedTableName,
                totalRecordsScanned,
                matchedRecords,
                totalBytesScanned,
                records: recordsMap
              };
            }
          } else {
            recordsMap[parsed.record.key] = parsed.record;
          }
          if (matchedRecords >= maxRecords) {
            return {
              tableName: detectedTableName,
              totalRecordsScanned,
              matchedRecords,
              totalBytesScanned,
              records: recordsMap
            };
          }
        }
      }
      if (remainder.trim()) {
        const parsed = this.parseInsertLine(remainder, detectedTableName);
        if (parsed) {
          totalRecordsScanned += 1;
          if (totalRecordsScanned > offset && (!options?.whereClause || options.whereClause(parsed.record))) {
            matchedRecords += 1;
            if (options?.onRecord) {
              options.onRecord(parsed.record, matchedRecords);
            } else {
              recordsMap[parsed.record.key] = parsed.record;
            }
          }
        }
      }
    } finally {
      this.fileSystem.closeSync(fd);
    }
    return {
      tableName: detectedTableName,
      totalRecordsScanned,
      matchedRecords,
      totalBytesScanned,
      records: recordsMap
    };
  }
  /**
   * Async iterator yielding records one-by-one from a large SQL / .dblc file (> 10 GB scale).
   * Operates strictly in linear O(n) time with O(1) buffer memory.
   */
  async *streamRecordIterator(filePath, options) {
    if (!this.fileSystem.existsSync(filePath)) {
      return;
    }
    const highWaterMark = options?.highWaterMarkBytes || this.config.highWaterMarkBytes;
    const fileStream = this.fileSystem.createReadStream(filePath, {
      encoding: "utf-8",
      highWaterMark
    });
    const lineReader = import_node_readline.default.createInterface({
      input: fileStream,
      crlfDelay: Infinity
    });
    let recordIndex = 0;
    let matchedCount = 0;
    const offset = options?.offset || 0;
    const maxRecords = options?.maxRecords || Infinity;
    try {
      for await (const line of lineReader) {
        if (options?.signal?.aborted) {
          break;
        }
        const parsed = this.parseInsertLine(line);
        if (!parsed) {
          continue;
        }
        recordIndex += 1;
        if (recordIndex <= offset) {
          continue;
        }
        if (options?.whereClause && !options.whereClause(parsed.record)) {
          continue;
        }
        matchedCount += 1;
        yield parsed.record;
        if (matchedCount >= maxRecords) {
          break;
        }
      }
    } finally {
      lineReader.close();
      fileStream.destroy();
    }
  }
  /**
   * Streams and scans an entire table file (any size up to >10 GB), invoking a visitor
   * callback per record with backpressure support and reporting comprehensive metrics.
   */
  async streamScanRecords(filePath, options) {
    const startTime = Date.now();
    const startMemoryMb = process.memoryUsage().heapUsed / (1024 * 1024);
    let peakMemoryMb = startMemoryMb;
    this.activeStreamsCount += 1;
    this.totalStreamsExecuted += 1;
    let fileSizeBytes = 0;
    try {
      const stat = this.fileSystem.statSync(filePath);
      fileSizeBytes = stat.size;
    } catch {
      fileSizeBytes = 0;
    }
    const highWaterMark = options?.highWaterMarkBytes || this.config.highWaterMarkBytes;
    const fileStream = this.fileSystem.createReadStream(filePath, {
      encoding: "utf-8",
      highWaterMark
    });
    const lineReader = import_node_readline.default.createInterface({
      input: fileStream,
      crlfDelay: Infinity
    });
    let detectedTableName = "unknown";
    let totalBytesScanned = 0;
    let totalRecordsScanned = 0;
    let matchedRecords = 0;
    const offset = options?.offset || 0;
    const maxRecords = options?.maxRecords || Infinity;
    try {
      for await (const line of lineReader) {
        if (options?.signal?.aborted) {
          break;
        }
        totalBytesScanned += Buffer.byteLength(line, "utf-8") + 1;
        if (detectedTableName === "unknown" && line.startsWith("--")) {
          const headerMatch = /--\s*(?:LowCode\s*)?LocalDB Table:\s*([a-zA-Z0-9_-]+)/i.exec(line);
          if (headerMatch) {
            detectedTableName = headerMatch[1].trim();
          }
        }
        const parsed = this.parseInsertLine(line, detectedTableName);
        if (!parsed) {
          continue;
        }
        if (detectedTableName === "unknown") {
          detectedTableName = parsed.targetTable;
        }
        totalRecordsScanned += 1;
        if (totalRecordsScanned % 1e4 === 0) {
          const currentMemMb = process.memoryUsage().heapUsed / (1024 * 1024);
          if (currentMemMb > peakMemoryMb) {
            peakMemoryMb = currentMemMb;
          }
        }
        if (totalRecordsScanned <= offset) {
          continue;
        }
        if (options?.whereClause && !options.whereClause(parsed.record)) {
          continue;
        }
        matchedRecords += 1;
        if (options?.onRecord) {
          const res = options.onRecord(parsed.record, matchedRecords);
          if (res instanceof Promise) {
            await res;
          }
        }
        if (matchedRecords >= maxRecords) {
          break;
        }
      }
    } finally {
      lineReader.close();
      fileStream.destroy();
      this.activeStreamsCount = Math.max(0, this.activeStreamsCount - 1);
    }
    const durationMs = Math.max(1, Date.now() - startTime);
    const durationSeconds = durationMs / 1e3;
    const throughputMbPerSec = Number((totalBytesScanned / (1024 * 1024) / durationSeconds).toFixed(2));
    const recordsPerSec = Number((totalRecordsScanned / durationSeconds).toFixed(0));
    this.totalBytesStreamed += totalBytesScanned;
    this.lastStreamDurationMs = durationMs;
    this.lastStreamThroughputMbPerSec = throughputMbPerSec;
    return {
      tableName: detectedTableName,
      filePath,
      fileSizeBytes,
      totalBytesScanned,
      totalRecordsScanned,
      matchedRecords,
      durationMs,
      throughputMbPerSec,
      recordsPerSec,
      memoryPeakMb: Number(peakMemoryMb.toFixed(2))
    };
  }
  /**
   * Streams a query directly against a large table file with WHERE filter, offset, and limit.
   * Returns only matching records without ever loading the full table into memory.
   */
  async streamQuery(filePath, filter) {
    const matchedRecords = [];
    const limit = filter.limit && filter.limit > 0 ? filter.limit : 500;
    const stats = await this.streamScanRecords(filePath, {
      offset: filter.offset || 0,
      maxRecords: limit,
      whereClause: filter.where,
      signal: filter.signal,
      onRecord: (record) => {
        matchedRecords.push(record);
      }
    });
    return { records: matchedRecords, stats };
  }
  /**
   * Streams records from an existing table or generator out to a destination file
   * respecting stream backpressure (write + drain) to ensure safe memory bounds.
   */
  async streamWriteTable(table, targetFilePath, options) {
    const startTime = Date.now();
    const writeStream = this.fileSystem.createWriteStream(targetFilePath, {
      flags: "w",
      encoding: "utf-8",
      highWaterMark: this.config.highWaterMarkBytes
    });
    const tableName = table.namespace;
    const now2 = (/* @__PURE__ */ new Date()).toISOString();
    const writeWithBackpressure = async (content) => {
      if (options?.signal?.aborted) {
        return;
      }
      const canContinue = writeStream.write(content);
      if (!canContinue) {
        await new Promise((resolve) => {
          writeStream.once("drain", resolve);
        });
      }
    };
    await writeWithBackpressure(
      `-- =============================================================================
-- LocalDB Table: ${tableName}
-- Format: Hydroelectric Stream SQL
-- Exported At: ${now2}
-- =============================================================================

CREATE TABLE IF NOT EXISTS ${tableName} (
  key TEXT PRIMARY KEY,
  value JSON,
  createdAt TEXT NOT NULL,
  updatedAt TEXT NOT NULL,
  ttlMs INTEGER,
  version INTEGER DEFAULT 1,
  tags TEXT
);

`
    );
    let recordsCount = 0;
    const recordsList = Object.values(table.records || {});
    for (const record of recordsList) {
      if (options?.signal?.aborted) {
        break;
      }
      const valJson = JSON.stringify(record.value || {}).replace(/'/g, "''");
      const tagsStr = (record.tags || []).join(",").replace(/'/g, "''");
      const keySafe = String(record.key || "").replace(/'/g, "''");
      const createdSafe = String(record.createdAt || now2).replace(/'/g, "''");
      const updatedSafe = String(record.updatedAt || now2).replace(/'/g, "''");
      const ttlVal = record.ttlMs !== null && record.ttlMs !== void 0 ? String(record.ttlMs) : "NULL";
      const verVal = record.version || 1;
      const insertSql = `INSERT OR REPLACE INTO ${tableName} (key, value, createdAt, updatedAt, ttlMs, version, tags) VALUES ('${keySafe}', '${valJson}', '${createdSafe}', '${updatedSafe}', ${ttlVal}, ${verVal}, '${tagsStr}');
`;
      await writeWithBackpressure(insertSql);
      recordsCount += 1;
    }
    await new Promise((resolve, reject) => {
      writeStream.end(() => {
        resolve();
      });
      writeStream.on("error", reject);
    });
    const durationMs = Date.now() - startTime;
    const stat = this.fileSystem.statSync(targetFilePath);
    return {
      bytesWritten: stat.size,
      recordsCount,
      durationMs
    };
  }
  /**
   * Streams table rows directly as newline-delimited JSON (NDJSON) or JSON array chunks
   * to a writable HTTP stream without intermediate buffering.
   */
  async streamPipeToHttp(filePath, writable, options) {
    const startTime = Date.now();
    const format = options?.format || "json";
    let isFirst = true;
    let recordsStreamed = 0;
    const writeAsync = async (chunk) => {
      const ok = writable.write(chunk);
      if (!ok) {
        await new Promise((resolve) => {
          writable.once("drain", resolve);
        });
      }
    };
    if (format === "json") {
      await writeAsync(`{"success":true,"streaming":true,"data":[`);
    }
    await this.streamScanRecords(filePath, {
      offset: options?.offset || 0,
      maxRecords: options?.limit || Infinity,
      signal: options?.signal,
      onRecord: async (rec) => {
        recordsStreamed += 1;
        if (format === "ndjson") {
          await writeAsync(JSON.stringify(rec) + "\n");
        } else {
          const prefix = isFirst ? "" : ",";
          isFirst = false;
          await writeAsync(prefix + JSON.stringify(rec));
        }
      }
    });
    if (format === "json") {
      const durationMs = Date.now() - startTime;
      await writeAsync(`],"meta":{"recordsStreamed":${recordsStreamed},"durationMs":${durationMs}}}`);
    }
    writable.end();
    return { recordsStreamed, durationMs: Date.now() - startTime };
  }
  /**
   * Retrieves operational metrics for the Hydroelectric streaming engine.
   */
  getMetrics() {
    const heapUsedMb = Number((process.memoryUsage().heapUsed / (1024 * 1024)).toFixed(2));
    const totalGb = Number((this.totalBytesStreamed / (1024 * 1024 * 1024)).toFixed(3));
    return {
      totalStreamsExecuted: this.totalStreamsExecuted,
      totalGigabytesStreamed: totalGb,
      activeStreamsCount: this.activeStreamsCount,
      lastStreamDurationMs: this.lastStreamDurationMs,
      lastStreamThroughputMbPerSec: this.lastStreamThroughputMbPerSec,
      currentHeapUsedMb: heapUsedMb
    };
  }
};
var hydroelectricEngine = HydroelectricEngine.getInstance();

// packages/LocalSQLServer/sources/engine/lc-storage-adapter.ts
function getOs() {
  return typeof require !== "undefined" ? require("node:os") : null;
}
function resolveTildePath(inputPath) {
  if (!inputPath) {
    return inputPath;
  }
  const trimmedPath = inputPath.trim();
  if (trimmedPath === "~") {
    const nodeOsModule = getOs();
    return nodeOsModule ? nodeOsModule.homedir() : process.env.HOME || process.env.USERPROFILE || "~";
  }
  if (trimmedPath.startsWith("~/") || trimmedPath.startsWith("~\\")) {
    const nodeOsModule = getOs();
    const nodePathModule = getPath2();
    const homeDirectory = nodeOsModule ? nodeOsModule.homedir() : process.env.HOME || process.env.USERPROFILE || "";
    if (homeDirectory) {
      const pathSuffix = trimmedPath.slice(2);
      return nodePathModule ? nodePathModule.join(homeDirectory, pathSuffix) : `${homeDirectory}/${pathSuffix}`;
    }
  }
  return trimmedPath;
}
var DEFAULT_LOCAL_DB_PATH = "~/.2tek/LocalDB";
function resolveLocalDbStorageDir() {
  try {
    if (typeof process !== "undefined") {
      const explicitEnvValue = process.env?.LOCAL_DB_PATH || process.env?.LOCAL_DB || process.env?.LOCALDB_PATH;
      if (explicitEnvValue && explicitEnvValue.trim() !== "") {
        return explicitEnvValue.trim();
      }
    }
    const nodeFileSystem = getFs2();
    const nodePathModule = getPath2();
    if (nodeFileSystem && nodePathModule && typeof process !== "undefined" && process.cwd) {
      const currentWorkingDirectory = process.cwd();
      const possibleEnvironmentPaths = [
        nodePathModule.resolve(currentWorkingDirectory, ".env"),
        nodePathModule.resolve(currentWorkingDirectory, "..", ".env"),
        nodePathModule.resolve(currentWorkingDirectory, "../..", ".env")
      ];
      for (let pathIndex = 0; pathIndex < possibleEnvironmentPaths.length; pathIndex += 1) {
        const environmentFilePath = possibleEnvironmentPaths[pathIndex];
        if (nodeFileSystem.existsSync(environmentFilePath)) {
          const fileContent = nodeFileSystem.readFileSync(environmentFilePath, "utf-8");
          const environmentMatch = fileContent.match(/^\s*LOCAL_DB_PATH\s*=\s*(.*)$/m) || fileContent.match(/^\s*LOCAL_DB\s*=\s*(.*)$/m) || fileContent.match(/^\s*LOCALDB_PATH\s*=\s*(.*)$/m);
          if (environmentMatch && environmentMatch[1]) {
            const rawExtractedValue = environmentMatch[1].trim();
            const cleanedPathValue = rawExtractedValue.replace(/^["']|["']$/g, "").trim();
            if (cleanedPathValue !== "") {
              return cleanedPathValue;
            }
          }
        }
      }
    }
  } catch {
  }
  return DEFAULT_LOCAL_DB_PATH;
}
var DEFAULT_STORAGE_DIR = resolveLocalDbStorageDir();
var LS_KEY_PREFIX = "_lc_localdb_";
function isNode() {
  return typeof window === "undefined" && typeof process !== "undefined";
}
function isBrowser() {
  return typeof window !== "undefined" && typeof localStorage !== "undefined";
}
function getFs2() {
  return typeof require !== "undefined" ? require("node:fs") : null;
}
function getPath2() {
  return typeof require !== "undefined" ? require("node:path") : null;
}
var StorageAdapter = class {
  _storageDir;
  _databaseName;
  _isMemoryOnly = false;
  _backend = "memory";
  _memoryTables = /* @__PURE__ */ new Map();
  _knownDatabases = /* @__PURE__ */ new Set(["default"]);
  constructor(storageDir, databaseName = "default") {
    const rawTargetDir = storageDir || this.resolveConfiguredStorageDir();
    if (rawTargetDir === ":memory:") {
      this._isMemoryOnly = true;
      this._storageDir = resolveLocalDbStorageDir();
      this._backend = "memory";
    } else {
      const targetDir = resolveTildePath(rawTargetDir);
      this._storageDir = targetDir;
      this._isMemoryOnly = false;
      const nodeFileSystem = getFs2();
      const effectiveStorageDirectory = this.getEffectiveStorageDir();
      if (nodeFileSystem && effectiveStorageDirectory && !nodeFileSystem.existsSync(effectiveStorageDirectory)) {
        try {
          nodeFileSystem.mkdirSync(effectiveStorageDirectory, { recursive: true });
        } catch {
        }
      }
    }
    this._databaseName = databaseName || "default";
  }
  resolveConfiguredStorageDir() {
    try {
      const configuredPath = resolveLocalDbStorageDir();
      const expandedPath = resolveTildePath(configuredPath);
      const nodePathModule = getPath2();
      const nodeFileSystem = getFs2();
      if (nodePathModule && nodeFileSystem && typeof process !== "undefined" && process.cwd) {
        const currentWorkingDirectory = process.cwd();
        const resolvedPath = nodePathModule.isAbsolute(expandedPath) ? expandedPath : nodePathModule.resolve(currentWorkingDirectory, expandedPath);
        if (!nodeFileSystem.existsSync(resolvedPath)) {
          try {
            nodeFileSystem.mkdirSync(resolvedPath, { recursive: true });
          } catch {
          }
        }
        return resolvedPath;
      }
      return expandedPath;
    } catch {
    }
    return resolveTildePath(resolveLocalDbStorageDir());
  }
  getEffectiveStorageDir() {
    const expandedDir = resolveTildePath(this._storageDir);
    const nodePathModule = getPath2();
    if (!nodePathModule) return expandedDir;
    const currentWorkingDirectory = typeof process !== "undefined" && process.cwd ? process.cwd() : "";
    return nodePathModule.isAbsolute(expandedDir) ? expandedDir : nodePathModule.resolve(currentWorkingDirectory, expandedDir);
  }
  get storageDir() {
    return this._isMemoryOnly ? ":memory:" : this._storageDir;
  }
  set storageDir(dir) {
    if (dir === ":memory:") {
      this._isMemoryOnly = true;
      this._storageDir = resolveLocalDbStorageDir();
      this._backend = "memory";
    } else {
      this._isMemoryOnly = false;
      this._storageDir = resolveTildePath(dir);
      const nodeFileSystem = getFs2();
      const effectiveStorageDirectory = this.getEffectiveStorageDir();
      if (nodeFileSystem && effectiveStorageDirectory && !nodeFileSystem.existsSync(effectiveStorageDirectory)) {
        try {
          nodeFileSystem.mkdirSync(effectiveStorageDirectory, { recursive: true });
        } catch {
        }
      }
    }
  }
  get databaseName() {
    return this._databaseName;
  }
  set databaseName(name) {
    this._databaseName = name || "default";
  }
  get currentDatabase() {
    return this._databaseName;
  }
  useDatabase(name) {
    this._databaseName = name || "default";
    return this._databaseName;
  }
  get isMemoryOnly() {
    return this._isMemoryOnly;
  }
  get backend() {
    return this._backend;
  }
  detectBackend() {
    if (this._isMemoryOnly) this._backend = "memory";
    else if (isBrowser()) this._backend = "localStorage";
    else if (isNode()) this._backend = "file";
    else this._backend = "memory";
    return this._backend;
  }
  getDatabaseSchemaDir(dbName) {
    const path3 = getPath2();
    const db = dbName || this._databaseName || "default";
    const dir = this.getEffectiveStorageDir();
    return path3 ? path3.resolve(dir, "schema", db) : `${dir}/schema/${db}`;
  }
  getDatabaseTablesDir(dbName) {
    const path3 = getPath2();
    const db = dbName || this._databaseName || "default";
    const dir = this.getEffectiveStorageDir();
    return path3 ? path3.resolve(dir, "tables", db) : `${dir}/tables/${db}`;
  }
  getDatabaseValuesDir(dbName) {
    return this.getDatabaseTablesDir(dbName);
  }
  getLegacyDatabaseSchemaDir(dbName) {
    const path3 = getPath2();
    const db = dbName || this._databaseName || "default";
    const dir = this.getEffectiveStorageDir();
    return path3 ? path3.resolve(dir, "schema", "databases", db) : `${dir}/schema/databases/${db}`;
  }
  getLegacyDatabaseValuesDir(dbName) {
    const path3 = getPath2();
    const db = dbName || this._databaseName || "default";
    const dir = this.getEffectiveStorageDir();
    return path3 ? path3.resolve(dir, "values", "databases", db) : `${dir}/values/databases/${db}`;
  }
  getLegacyValuesDir(dbName) {
    const path3 = getPath2();
    const db = dbName || this._databaseName || "default";
    const dir = this.getEffectiveStorageDir();
    return path3 ? path3.resolve(dir, "values", db) : `${dir}/values/${db}`;
  }
  getDatabaseDir(dbName) {
    return this.getDatabaseSchemaDir(dbName);
  }
  normalizeTableName(name) {
    return name.replace(/\.(dblc|db\.lc)$/i, "");
  }
  getTableSchemaPath(tableName, dbName) {
    const path3 = getPath2();
    const cleanName = this.normalizeTableName(tableName);
    const fileName = `${cleanName}.dblc`;
    return path3 ? path3.join(this.getDatabaseSchemaDir(dbName), fileName) : `${this.getDatabaseSchemaDir(dbName)}/${fileName}`;
  }
  getTableTablesPath(tableName, dbName) {
    const path3 = getPath2();
    const cleanName = this.normalizeTableName(tableName);
    const fileName = `${cleanName}.dblc`;
    return path3 ? path3.join(this.getDatabaseTablesDir(dbName), fileName) : `${this.getDatabaseTablesDir(dbName)}/${fileName}`;
  }
  getTableValuesPath(tableName, dbName) {
    return this.getTableTablesPath(tableName, dbName);
  }
  getLegacyTableSchemaPath(tableName, dbName) {
    const path3 = getPath2();
    const cleanName = this.normalizeTableName(tableName);
    return path3 ? path3.join(this.getLegacyDatabaseSchemaDir(dbName), `${cleanName}.dblc`) : `${this.getLegacyDatabaseSchemaDir(dbName)}/${cleanName}.dblc`;
  }
  getLegacyTableValuesPath(tableName, dbName) {
    const path3 = getPath2();
    const cleanName = this.normalizeTableName(tableName);
    return path3 ? path3.join(this.getLegacyDatabaseValuesDir(dbName), `${cleanName}.dblc`) : `${this.getLegacyDatabaseValuesDir(dbName)}/${cleanName}.dblc`;
  }
  getTableDisplaySchemaPath(tableName, dbName) {
    const db = dbName || this._databaseName || "default";
    const cleanName = this.normalizeTableName(tableName);
    return `/schema/${db}/${cleanName}`;
  }
  getTableDisplayTablesPath(tableName, dbName) {
    const db = dbName || this._databaseName || "default";
    const cleanName = this.normalizeTableName(tableName);
    return `/tables/${db}/${cleanName}`;
  }
  getTableDisplayValuesPath(tableName, dbName) {
    return this.getTableDisplayTablesPath(tableName, dbName);
  }
  getTablePath(tableName, dbName) {
    return this.getTableSchemaPath(tableName, dbName);
  }
  getLegacyTablePath(tableName, ext = ".dblc") {
    const path3 = getPath2();
    const cleanName = this.normalizeTableName(tableName);
    const fileName = `${cleanName}${ext}`;
    const dir = this.getEffectiveStorageDir();
    return path3 ? path3.resolve(dir, fileName) : `${dir}/${fileName}`;
  }
  /**
   * Save a single table to:
   * 1. Schema file: .localdb/schema/{db}/{tableName}.dblc (DDL schema)
   * 2. Tables file: .localdb/tables/{db}/{tableName}.dblc (DML records/values)
   * Section 651: Zero .dblc files in root .localdb/. Clean any legacy root or legacy folders.
   */
  saveTable(table, dbName) {
    const targetDb = dbName || this._databaseName || "default";
    const schemaSql = serializeTableSchemaToDblc(table);
    const valuesSql = serializeTableValuesToDblc(table);
    const cleanName = this.normalizeTableName(table.namespace);
    if (this._isMemoryOnly) {
      this._memoryTables.set(`${targetDb}:${cleanName}`, table);
      return schemaSql;
    }
    if (isBrowser()) {
      try {
        localStorage.setItem(`${LS_KEY_PREFIX}schema_db_${targetDb}_${cleanName}.dblc`, schemaSql);
        localStorage.setItem(`${LS_KEY_PREFIX}tables_db_${targetDb}_${cleanName}.dblc`, valuesSql);
        localStorage.setItem(`${LS_KEY_PREFIX}values_db_${targetDb}_${cleanName}.dblc`, valuesSql);
        localStorage.removeItem(`${LS_KEY_PREFIX}db_${targetDb}_${cleanName}.dblc`);
        localStorage.removeItem(`${LS_KEY_PREFIX}db_${targetDb}_${cleanName}.db.lc`);
        if (targetDb === "default") {
          localStorage.removeItem(`${LS_KEY_PREFIX}${cleanName}.dblc`);
          localStorage.removeItem(`${LS_KEY_PREFIX}${cleanName}.db.lc`);
          localStorage.removeItem(`${LS_KEY_PREFIX}${cleanName}`);
        }
      } catch {
      }
      return schemaSql;
    }
    if (isNode()) {
      try {
        const fs5 = getFs2();
        const path3 = getPath2();
        if (!fs5 || !path3) return schemaSql;
        const schemaDir = this.getDatabaseSchemaDir(targetDb);
        if (!fs5.existsSync(schemaDir)) fs5.mkdirSync(schemaDir, { recursive: true });
        const schemaPath = this.getTableSchemaPath(cleanName, targetDb);
        const schemaTmp = `${schemaPath}.tmp.${Date.now()}`;
        fs5.writeFileSync(schemaTmp, schemaSql, "utf8");
        fs5.renameSync(schemaTmp, schemaPath);
        const tablesDir = this.getDatabaseTablesDir(targetDb);
        if (!fs5.existsSync(tablesDir)) fs5.mkdirSync(tablesDir, { recursive: true });
        const tablesPath = this.getTableTablesPath(cleanName, targetDb);
        const tablesTmp = `${tablesPath}.tmp.${Date.now()}`;
        fs5.writeFileSync(tablesTmp, valuesSql, "utf8");
        fs5.renameSync(tablesTmp, tablesPath);
        const rootDblc = this.getLegacyTablePath(cleanName, ".dblc");
        if (fs5.existsSync(rootDblc)) {
          try {
            fs5.unlinkSync(rootDblc);
          } catch {
          }
        }
        const rootDbLc = this.getLegacyTablePath(cleanName, ".db.lc");
        if (fs5.existsSync(rootDbLc)) {
          try {
            fs5.unlinkSync(rootDbLc);
          } catch {
          }
        }
        const legacySchema = this.getLegacyTableSchemaPath(cleanName, targetDb);
        if (fs5.existsSync(legacySchema)) {
          try {
            fs5.unlinkSync(legacySchema);
          } catch {
          }
        }
        const legacyValues = this.getLegacyTableValuesPath(cleanName, targetDb);
        if (fs5.existsSync(legacyValues)) {
          try {
            fs5.unlinkSync(legacyValues);
          } catch {
          }
        }
        const legacyValuesFlat = path3.join(this.getLegacyValuesDir(targetDb), `${cleanName}.dblc`);
        if (fs5.existsSync(legacyValuesFlat)) {
          try {
            fs5.unlinkSync(legacyValuesFlat);
          } catch {
          }
        }
        const schemaDbLc = path3.join(schemaDir, `${cleanName}.db.lc`);
        if (fs5.existsSync(schemaDbLc)) {
          try {
            fs5.unlinkSync(schemaDbLc);
          } catch {
          }
        }
        const tablesDbLc = path3.join(tablesDir, `${cleanName}.db.lc`);
        if (fs5.existsSync(tablesDbLc)) {
          try {
            fs5.unlinkSync(tablesDbLc);
          } catch {
          }
        }
        const legacySchemaDbLc = path3.join(this.getLegacyDatabaseSchemaDir(targetDb), `${cleanName}.db.lc`);
        if (fs5.existsSync(legacySchemaDbLc)) {
          try {
            fs5.unlinkSync(legacySchemaDbLc);
          } catch {
          }
        }
        const legacyValuesDbLc = path3.join(this.getLegacyDatabaseValuesDir(targetDb), `${cleanName}.db.lc`);
        if (fs5.existsSync(legacyValuesDbLc)) {
          try {
            fs5.unlinkSync(legacyValuesDbLc);
          } catch {
          }
        }
        const legacyValuesFlatDbLc = path3.join(this.getLegacyValuesDir(targetDb), `${cleanName}.db.lc`);
        if (fs5.existsSync(legacyValuesFlatDbLc)) {
          try {
            fs5.unlinkSync(legacyValuesFlatDbLc);
          } catch {
          }
        }
        return schemaPath;
      } catch {
      }
    }
    return schemaSql;
  }
  /**
   * Load a single table with primary lookup in schema/{db}/ and tables/{db}/
   * and fallback lookup in legacy paths (schema/databases/{db}/, values/databases/{db}/, values/{db}/, or root .localdb/ for "default").
   * Automatically materializes tables (values) file if schema has records and tables file was missing.
   * Automatically migrates any legacy file to the new schema/{db} and tables/{db} structure and cleans up legacy files.
   */
  loadTable(tableName, dbName) {
    const targetDb = dbName || this._databaseName || "default";
    const cleanName = this.normalizeTableName(tableName);
    if (this._isMemoryOnly) {
      return this._memoryTables.get(`${targetDb}:${cleanName}`) ?? (targetDb === "default" ? this._memoryTables.get(cleanName) : void 0) ?? null;
    }
    if (isBrowser()) {
      try {
        const schemaRaw = localStorage.getItem(`${LS_KEY_PREFIX}schema_db_${targetDb}_${cleanName}.dblc`) ?? localStorage.getItem(`${LS_KEY_PREFIX}db_${targetDb}_${cleanName}.dblc`) ?? localStorage.getItem(`${LS_KEY_PREFIX}db_${targetDb}_${cleanName}.db.lc`) ?? (targetDb === "default" ? localStorage.getItem(`${LS_KEY_PREFIX}${cleanName}.dblc`) ?? localStorage.getItem(`${LS_KEY_PREFIX}${cleanName}.db.lc`) ?? localStorage.getItem(`${LS_KEY_PREFIX}${cleanName}`) : null);
        const valuesRaw = localStorage.getItem(`${LS_KEY_PREFIX}tables_db_${targetDb}_${cleanName}.dblc`) ?? localStorage.getItem(`${LS_KEY_PREFIX}values_db_${targetDb}_${cleanName}.dblc`);
        if (schemaRaw || valuesRaw) {
          const parsedSchema = schemaRaw ? parseDblcSql(schemaRaw, cleanName) : null;
          const parsedValues = valuesRaw ? parseDblcSql(valuesRaw, cleanName) : null;
          const combinedRecords = parsedValues && Object.keys(parsedValues.records).length > 0 ? parsedValues.records : parsedSchema ? parsedSchema.records : {};
          const combinedRelationships = [
            ...parsedSchema?.relationships || [],
            ...parsedValues?.relationships || []
          ];
          const combinedRelations = parsedValues && Object.keys(parsedValues.relations).length > 0 ? parsedValues.relations : parsedSchema ? parsedSchema.relations : {};
          return {
            namespace: parsedSchema?.tableName || parsedValues?.tableName || cleanName,
            records: combinedRecords,
            relationships: combinedRelationships,
            relations: combinedRelations,
            createdAt: (/* @__PURE__ */ new Date()).toISOString()
          };
        }
      } catch {
        return null;
      }
    }
    if (isNode()) {
      try {
        const fs5 = getFs2();
        const path3 = getPath2();
        if (!fs5) return null;
        const schemaPath = this.getTableSchemaPath(cleanName, targetDb);
        const tablesPath = this.getTableTablesPath(cleanName, targetDb);
        const hasSchema = fs5.existsSync(schemaPath);
        const hasTables = fs5.existsSync(tablesPath);
        let rawSchema = null;
        if (hasSchema) {
          try {
            rawSchema = fs5.readFileSync(schemaPath, "utf8");
          } catch {
            rawSchema = null;
          }
        }
        let rawValues = null;
        let parsedValuesFromHydroelectric = null;
        if (hasTables) {
          if (hydroelectricEngine.isLargeFile(tablesPath)) {
            const hydroScan = hydroelectricEngine.syncStreamScanFile(tablesPath);
            parsedValuesFromHydroelectric = hydroScan.records;
          } else {
            try {
              rawValues = fs5.readFileSync(tablesPath, "utf8");
            } catch {
              const hydroScan = hydroelectricEngine.syncStreamScanFile(tablesPath);
              parsedValuesFromHydroelectric = hydroScan.records;
            }
          }
        }
        let needsSave = false;
        if (!rawValues && !parsedValuesFromHydroelectric && path3) {
          const legacyValuesFlat = path3.join(this.getLegacyValuesDir(targetDb), `${cleanName}.dblc`);
          if (fs5.existsSync(legacyValuesFlat)) {
            if (hydroelectricEngine.isLargeFile(legacyValuesFlat)) {
              const hydroScan = hydroelectricEngine.syncStreamScanFile(legacyValuesFlat);
              parsedValuesFromHydroelectric = hydroScan.records;
            } else {
              try {
                rawValues = fs5.readFileSync(legacyValuesFlat, "utf8");
              } catch {
                const hydroScan = hydroelectricEngine.syncStreamScanFile(legacyValuesFlat);
                parsedValuesFromHydroelectric = hydroScan.records;
              }
            }
            needsSave = true;
          }
        }
        if (!rawSchema) {
          const legacySchemaPath = this.getLegacyTableSchemaPath(cleanName, targetDb);
          if (fs5.existsSync(legacySchemaPath)) {
            rawSchema = fs5.readFileSync(legacySchemaPath, "utf8");
            needsSave = true;
          }
        }
        if (!rawValues && !parsedValuesFromHydroelectric) {
          const legacyValuesPath = this.getLegacyTableValuesPath(cleanName, targetDb);
          if (fs5.existsSync(legacyValuesPath)) {
            if (hydroelectricEngine.isLargeFile(legacyValuesPath)) {
              const hydroScan = hydroelectricEngine.syncStreamScanFile(legacyValuesPath);
              parsedValuesFromHydroelectric = hydroScan.records;
            } else {
              try {
                rawValues = fs5.readFileSync(legacyValuesPath, "utf8");
              } catch {
                const hydroScan = hydroelectricEngine.syncStreamScanFile(legacyValuesPath);
                parsedValuesFromHydroelectric = hydroScan.records;
              }
            }
            needsSave = true;
          }
        }
        if (!rawSchema && path3) {
          const schemaDir = this.getDatabaseSchemaDir(targetDb);
          const legacyDbLc = path3.join(schemaDir, `${cleanName}.db.lc`);
          if (fs5.existsSync(legacyDbLc)) {
            rawSchema = fs5.readFileSync(legacyDbLc, "utf8");
            needsSave = true;
          }
          const legacySchemaDir = this.getLegacyDatabaseSchemaDir(targetDb);
          const legacySchemaDbLc = path3.join(legacySchemaDir, `${cleanName}.db.lc`);
          if (!rawSchema && fs5.existsSync(legacySchemaDbLc)) {
            rawSchema = fs5.readFileSync(legacySchemaDbLc, "utf8");
            needsSave = true;
          }
        }
        if ((!rawSchema || !rawValues && !parsedValuesFromHydroelectric) && targetDb === "default") {
          const rootDblcPath = this.getLegacyTablePath(cleanName, ".dblc");
          if (fs5.existsSync(rootDblcPath)) {
            if (hydroelectricEngine.isLargeFile(rootDblcPath)) {
              const hydroScan = hydroelectricEngine.syncStreamScanFile(rootDblcPath);
              parsedValuesFromHydroelectric = hydroScan.records;
            } else {
              try {
                const rootRaw = fs5.readFileSync(rootDblcPath, "utf8");
                if (!rawSchema) rawSchema = rootRaw;
                if (!rawValues) rawValues = rootRaw;
              } catch {
                const hydroScan = hydroelectricEngine.syncStreamScanFile(rootDblcPath);
                parsedValuesFromHydroelectric = hydroScan.records;
              }
            }
            needsSave = true;
          } else {
            const rootDbLcPath = this.getLegacyTablePath(cleanName, ".db.lc");
            if (fs5.existsSync(rootDbLcPath)) {
              if (hydroelectricEngine.isLargeFile(rootDbLcPath)) {
                const hydroScan = hydroelectricEngine.syncStreamScanFile(rootDbLcPath);
                parsedValuesFromHydroelectric = hydroScan.records;
              } else {
                try {
                  const rootRaw = fs5.readFileSync(rootDbLcPath, "utf8");
                  if (!rawSchema) rawSchema = rootRaw;
                  if (!rawValues) rawValues = rootRaw;
                } catch {
                  const hydroScan = hydroelectricEngine.syncStreamScanFile(rootDbLcPath);
                  parsedValuesFromHydroelectric = hydroScan.records;
                }
              }
              needsSave = true;
            }
          }
        }
        if (rawSchema || rawValues || parsedValuesFromHydroelectric) {
          const parsedSchema = rawSchema ? parseDblcSql(rawSchema, cleanName) : null;
          const parsedValues = parsedValuesFromHydroelectric ? { tableName: cleanName, records: parsedValuesFromHydroelectric, relationships: [], relations: {} } : rawValues ? parseDblcSql(rawValues, cleanName) : null;
          const combinedRecords = parsedValues && Object.keys(parsedValues.records).length > 0 ? parsedValues.records : parsedSchema ? parsedSchema.records : {};
          const combinedRelationships = [
            ...parsedSchema?.relationships || [],
            ...parsedValues?.relationships || []
          ];
          const combinedRelations = parsedValues && Object.keys(parsedValues.relations).length > 0 ? parsedValues.relations : parsedSchema ? parsedSchema.relations : {};
          const table = {
            namespace: cleanName || parsedSchema?.tableName || parsedValues?.tableName || tableName,
            records: combinedRecords,
            relationships: combinedRelationships,
            relations: combinedRelations,
            createdAt: (/* @__PURE__ */ new Date()).toISOString()
          };
          if (!hasTables && Object.keys(combinedRecords).length > 0) {
            needsSave = true;
          }
          if (needsSave || !hasSchema || !hasTables) {
            this.saveTable(table, targetDb);
          }
          return table;
        }
      } catch {
        return null;
      }
    }
    return null;
  }
  /**
   * Check if a table schema file exists in storage
   */
  hasTableSchemaFile(tableName, dbName) {
    const targetDb = dbName || this._databaseName || "default";
    const cleanName = this.normalizeTableName(tableName);
    if (this._isMemoryOnly) {
      return this._memoryTables.has(`${targetDb}:${cleanName}`) || targetDb === "default" && this._memoryTables.has(cleanName);
    }
    if (isBrowser()) {
      return localStorage.getItem(`${LS_KEY_PREFIX}schema_db_${targetDb}_${cleanName}.dblc`) !== null || localStorage.getItem(`${LS_KEY_PREFIX}db_${targetDb}_${cleanName}.dblc`) !== null || localStorage.getItem(`${LS_KEY_PREFIX}db_${targetDb}_${cleanName}.db.lc`) !== null || targetDb === "default" && (localStorage.getItem(`${LS_KEY_PREFIX}${cleanName}.dblc`) !== null || localStorage.getItem(`${LS_KEY_PREFIX}${cleanName}.db.lc`) !== null);
    }
    if (isNode()) {
      const fs5 = getFs2();
      const path3 = getPath2();
      if (!fs5) return false;
      if (fs5.existsSync(this.getTableSchemaPath(cleanName, targetDb))) return true;
      if (fs5.existsSync(this.getLegacyTableSchemaPath(cleanName, targetDb))) return true;
      const dbDir = this.getDatabaseSchemaDir(targetDb);
      const legacyDbLcPath = path3 ? path3.join(dbDir, `${cleanName}.db.lc`) : `${dbDir}/${cleanName}.db.lc`;
      if (fs5.existsSync(legacyDbLcPath)) return true;
      if (targetDb === "default") {
        if (fs5.existsSync(this.getLegacyTablePath(cleanName, ".dblc"))) return true;
        if (fs5.existsSync(this.getLegacyTablePath(cleanName, ".db.lc"))) return true;
      }
    }
    return false;
  }
  /**
   * Check if a table tables (values) file exists in storage
   */
  hasTableTablesFile(tableName, dbName) {
    const targetDb = dbName || this._databaseName || "default";
    const cleanName = this.normalizeTableName(tableName);
    if (this._isMemoryOnly) {
      return this._memoryTables.has(`${targetDb}:${cleanName}`) || targetDb === "default" && this._memoryTables.has(cleanName);
    }
    if (isBrowser()) {
      return localStorage.getItem(`${LS_KEY_PREFIX}tables_db_${targetDb}_${cleanName}.dblc`) !== null || localStorage.getItem(`${LS_KEY_PREFIX}values_db_${targetDb}_${cleanName}.dblc`) !== null;
    }
    if (isNode()) {
      const fs5 = getFs2();
      const path3 = getPath2();
      if (!fs5) return false;
      if (fs5.existsSync(this.getTableTablesPath(cleanName, targetDb))) return true;
      if (fs5.existsSync(this.getLegacyTableValuesPath(cleanName, targetDb))) return true;
      if (path3 && fs5.existsSync(path3.join(this.getLegacyValuesDir(targetDb), `${cleanName}.dblc`))) return true;
    }
    return false;
  }
  hasTableValuesFile(tableName, dbName) {
    return this.hasTableTablesFile(tableName, dbName);
  }
  /**
   * Check if any table file (schema or tables or legacy) exists in storage
   */
  hasTableFile(tableName, dbName) {
    return this.hasTableSchemaFile(tableName, dbName) || this.hasTableTablesFile(tableName, dbName);
  }
  /**
   * Delete table files (both schema and tables) and backups from storage completely
   */
  deleteTable(tableName, dbName) {
    const targetDb = dbName || this._databaseName || "default";
    const cleanName = this.normalizeTableName(tableName);
    let deleted = false;
    if (this._isMemoryOnly) {
      if (this._memoryTables.delete(`${targetDb}:${cleanName}`)) deleted = true;
      if (targetDb === "default" && this._memoryTables.delete(cleanName)) deleted = true;
      return deleted;
    }
    if (isBrowser()) {
      try {
        const keysToRemove = [
          `${LS_KEY_PREFIX}schema_db_${targetDb}_${cleanName}.dblc`,
          `${LS_KEY_PREFIX}tables_db_${targetDb}_${cleanName}.dblc`,
          `${LS_KEY_PREFIX}values_db_${targetDb}_${cleanName}.dblc`,
          `${LS_KEY_PREFIX}db_${targetDb}_${cleanName}.dblc`,
          `${LS_KEY_PREFIX}db_${targetDb}_${cleanName}.db.lc`
        ];
        if (targetDb === "default") {
          keysToRemove.push(
            `${LS_KEY_PREFIX}${cleanName}.dblc`,
            `${LS_KEY_PREFIX}${cleanName}.db.lc`,
            `${LS_KEY_PREFIX}${cleanName}`
          );
        }
        for (const k of keysToRemove) {
          if (localStorage.getItem(k) !== null) {
            localStorage.removeItem(k);
            deleted = true;
          }
        }
      } catch {
      }
    }
    if (isNode()) {
      try {
        const fs5 = getFs2();
        const path3 = getPath2();
        if (fs5) {
          const filesToDelete = [
            this.getTableSchemaPath(cleanName, targetDb),
            this.getTableTablesPath(cleanName, targetDb),
            this.getLegacyTableSchemaPath(cleanName, targetDb),
            this.getLegacyTableValuesPath(cleanName, targetDb),
            path3 ? path3.join(this.getLegacyValuesDir(targetDb), `${cleanName}.dblc`) : "",
            path3 ? path3.join(this.getDatabaseSchemaDir(targetDb), `${cleanName}.db.lc`) : "",
            path3 ? path3.join(this.getDatabaseTablesDir(targetDb), `${cleanName}.db.lc`) : ""
          ];
          if (targetDb === "default") {
            filesToDelete.push(
              this.getLegacyTablePath(cleanName, ".dblc"),
              this.getLegacyTablePath(cleanName, ".db.lc")
            );
          }
          for (const f of filesToDelete) {
            if (f && fs5.existsSync(f)) {
              fs5.unlinkSync(f);
              deleted = true;
            }
          }
        }
      } catch {
      }
    }
    return deleted;
  }
  /**
   * List all table names available in database (.dblc and .db.lc across schema and tables dirs)
   */
  listTableNames(dbName) {
    const targetDb = dbName || this._databaseName || "default";
    const tableNames = /* @__PURE__ */ new Set();
    if (this._isMemoryOnly) {
      const prefix = `${targetDb}:`;
      for (const key of Array.from(this._memoryTables.keys())) {
        if (key.startsWith(prefix)) tableNames.add(this.normalizeTableName(key.slice(prefix.length)));
        else if (targetDb === "default" && !key.includes(":")) tableNames.add(this.normalizeTableName(key));
      }
      return Array.from(tableNames);
    }
    if (isBrowser()) {
      try {
        const schemaPrefix = `${LS_KEY_PREFIX}schema_db_${targetDb}_`;
        const tablesPrefix = `${LS_KEY_PREFIX}tables_db_${targetDb}_`;
        const valuesPrefix = `${LS_KEY_PREFIX}values_db_${targetDb}_`;
        const dbPrefix = `${LS_KEY_PREFIX}db_${targetDb}_`;
        for (let i = 0; i < localStorage.length; i++) {
          const key = localStorage.key(i);
          if (key?.startsWith(schemaPrefix)) {
            tableNames.add(this.normalizeTableName(key.slice(schemaPrefix.length)));
          } else if (key?.startsWith(tablesPrefix)) {
            tableNames.add(this.normalizeTableName(key.slice(tablesPrefix.length)));
          } else if (key?.startsWith(valuesPrefix)) {
            tableNames.add(this.normalizeTableName(key.slice(valuesPrefix.length)));
          } else if (key?.startsWith(dbPrefix)) {
            tableNames.add(this.normalizeTableName(key.slice(dbPrefix.length)));
          } else if (targetDb === "default" && key?.startsWith(LS_KEY_PREFIX) && !key.startsWith(`${LS_KEY_PREFIX}db_`) && !key.startsWith(`${LS_KEY_PREFIX}schema_`) && !key.startsWith(`${LS_KEY_PREFIX}tables_`) && !key.startsWith(`${LS_KEY_PREFIX}values_`)) {
            tableNames.add(this.normalizeTableName(key.slice(LS_KEY_PREFIX.length)));
          }
        }
      } catch {
      }
    }
    if (isNode()) {
      try {
        const fs5 = getFs2();
        const path3 = getPath2();
        if (fs5) {
          const schemaDir = this.getDatabaseSchemaDir(targetDb);
          if (fs5.existsSync(schemaDir)) {
            for (const file of fs5.readdirSync(schemaDir)) {
              if (file.endsWith(".dblc")) tableNames.add(file.slice(0, -".dblc".length));
              else if (file.endsWith(".db.lc")) tableNames.add(file.slice(0, -".db.lc".length));
            }
          }
          const tablesDir = this.getDatabaseTablesDir(targetDb);
          if (fs5.existsSync(tablesDir)) {
            for (const file of fs5.readdirSync(tablesDir)) {
              if (file.endsWith(".dblc")) tableNames.add(file.slice(0, -".dblc".length));
              else if (file.endsWith(".db.lc")) tableNames.add(file.slice(0, -".db.lc".length));
            }
          }
          const legacySchemaDir = this.getLegacyDatabaseSchemaDir(targetDb);
          if (fs5.existsSync(legacySchemaDir)) {
            for (const file of fs5.readdirSync(legacySchemaDir)) {
              if (file.endsWith(".dblc")) tableNames.add(file.slice(0, -".dblc".length));
              else if (file.endsWith(".db.lc")) tableNames.add(file.slice(0, -".db.lc".length));
            }
          }
          const legacyValuesDir = this.getLegacyDatabaseValuesDir(targetDb);
          if (fs5.existsSync(legacyValuesDir)) {
            for (const file of fs5.readdirSync(legacyValuesDir)) {
              if (file.endsWith(".dblc")) tableNames.add(file.slice(0, -".dblc".length));
              else if (file.endsWith(".db.lc")) tableNames.add(file.slice(0, -".db.lc".length));
            }
          }
          const legacyValuesFlatDir = this.getLegacyValuesDir(targetDb);
          if (fs5.existsSync(legacyValuesFlatDir)) {
            for (const file of fs5.readdirSync(legacyValuesFlatDir)) {
              if (file.endsWith(".dblc")) tableNames.add(file.slice(0, -".dblc".length));
              else if (file.endsWith(".db.lc")) tableNames.add(file.slice(0, -".db.lc".length));
            }
          }
          if (targetDb === "default" && path3) {
            const rootDir = this.getEffectiveStorageDir();
            if (fs5.existsSync(rootDir)) {
              for (const file of fs5.readdirSync(rootDir)) {
                if (file.endsWith(".dblc")) tableNames.add(file.slice(0, -".dblc".length));
                else if (file.endsWith(".db.lc")) tableNames.add(file.slice(0, -".db.lc".length));
              }
            }
          }
        }
      } catch {
      }
    }
    return Array.from(tableNames);
  }
  /**
   * List all database table files with both schema and tables file paths and presence
   */
  listDatabaseFiles(dbName) {
    const targetDb = dbName || this._databaseName || "default";
    const tableNames = this.listTableNames(targetDb);
    const result = [];
    for (const tableName of tableNames) {
      result.push({
        tableName,
        schemaPath: this.getTableSchemaPath(tableName, targetDb),
        tablesPath: this.getTableTablesPath(tableName, targetDb),
        valuesPath: this.getTableValuesPath(tableName, targetDb),
        hasSchemaFile: this.hasTableSchemaFile(tableName, targetDb),
        hasTablesFile: this.hasTableTablesFile(tableName, targetDb),
        hasValuesFile: this.hasTableValuesFile(tableName, targetDb),
        displaySchemaPath: this.getTableDisplaySchemaPath(tableName, targetDb),
        displayTablesPath: this.getTableDisplayTablesPath(tableName, targetDb),
        displayValuesPath: this.getTableDisplayValuesPath(tableName, targetDb)
      });
    }
    return result;
  }
  /**
   * List all database names available in storage across schema and tables directories
   */
  listDatabases() {
    const dbs = /* @__PURE__ */ new Set(["default", ...Array.from(this._knownDatabases)]);
    if (this._isMemoryOnly) {
      for (const key of Array.from(this._memoryTables.keys())) {
        const colonIdx = key.indexOf(":");
        if (colonIdx > 0) dbs.add(key.slice(0, colonIdx));
      }
      return Array.from(dbs);
    }
    if (isBrowser()) {
      try {
        const prefixes = [
          `${LS_KEY_PREFIX}tables_db_`,
          `${LS_KEY_PREFIX}values_db_`,
          `${LS_KEY_PREFIX}schema_db_`,
          `${LS_KEY_PREFIX}db_`
        ];
        for (let i = 0; i < localStorage.length; i++) {
          const key = localStorage.key(i);
          if (!key) continue;
          for (const prefix of prefixes) {
            if (key.startsWith(prefix)) {
              const parts = key.slice(prefix.length).split("_");
              if (parts.length > 1) dbs.add(parts[0]);
            }
          }
        }
      } catch {
      }
    }
    if (isNode()) {
      try {
        const fs5 = getFs2();
        const path3 = getPath2();
        if (fs5 && path3) {
          const schemaDir = path3.resolve(this.getEffectiveStorageDir(), "schema");
          if (fs5.existsSync(schemaDir)) {
            const entries = fs5.readdirSync(schemaDir, { withFileTypes: true });
            for (const entry of entries) {
              if (entry.isDirectory() && !entry.name.startsWith(".") && entry.name !== "databases") {
                dbs.add(entry.name);
              }
            }
          }
          const tablesDir = path3.resolve(this.getEffectiveStorageDir(), "tables");
          if (fs5.existsSync(tablesDir)) {
            const entries = fs5.readdirSync(tablesDir, { withFileTypes: true });
            for (const entry of entries) {
              if (entry.isDirectory() && !entry.name.startsWith(".") && entry.name !== "databases") {
                dbs.add(entry.name);
              }
            }
          }
          const legacySchemaDatabasesDir = path3.resolve(this.getEffectiveStorageDir(), "schema", "databases");
          if (fs5.existsSync(legacySchemaDatabasesDir)) {
            const entries = fs5.readdirSync(legacySchemaDatabasesDir, { withFileTypes: true });
            for (const entry of entries) {
              if (entry.isDirectory() && !entry.name.startsWith(".")) dbs.add(entry.name);
            }
          }
          const legacyValuesDatabasesDir = path3.resolve(this.getEffectiveStorageDir(), "values", "databases");
          if (fs5.existsSync(legacyValuesDatabasesDir)) {
            const entries = fs5.readdirSync(legacyValuesDatabasesDir, { withFileTypes: true });
            for (const entry of entries) {
              if (entry.isDirectory() && !entry.name.startsWith(".")) dbs.add(entry.name);
            }
          }
          const legacyValuesDir = path3.resolve(this.getEffectiveStorageDir(), "values");
          if (fs5.existsSync(legacyValuesDir)) {
            const entries = fs5.readdirSync(legacyValuesDir, { withFileTypes: true });
            for (const entry of entries) {
              if (entry.isDirectory() && !entry.name.startsWith(".") && entry.name !== "databases") {
                dbs.add(entry.name);
              }
            }
          }
        }
      } catch {
      }
    }
    return Array.from(dbs);
  }
  createDatabase(name) {
    if (!name || typeof name !== "string" || !/^[a-zA-Z0-9_-]+$/.test(name)) return false;
    this._knownDatabases.add(name);
    if (this._isMemoryOnly) return true;
    if (isNode()) {
      try {
        const fs5 = getFs2();
        if (fs5) {
          const schemaDir = this.getDatabaseSchemaDir(name);
          const tablesDir = this.getDatabaseTablesDir(name);
          if (!fs5.existsSync(schemaDir)) fs5.mkdirSync(schemaDir, { recursive: true });
          if (!fs5.existsSync(tablesDir)) fs5.mkdirSync(tablesDir, { recursive: true });
          return true;
        }
      } catch {
        return false;
      }
    }
    return true;
  }
  dropDatabase(name) {
    if (name === "default") return false;
    this._knownDatabases.delete(name);
    if (this._isMemoryOnly) {
      const prefix = `${name}:`;
      for (const key of Array.from(this._memoryTables.keys())) {
        if (key.startsWith(prefix)) this._memoryTables.delete(key);
      }
      return true;
    }
    if (isNode()) {
      try {
        const fs5 = getFs2();
        if (fs5) {
          const schemaDir = this.getDatabaseSchemaDir(name);
          const tablesDir = this.getDatabaseTablesDir(name);
          const legacySchemaDir = this.getLegacyDatabaseSchemaDir(name);
          const legacyValuesDir = this.getLegacyDatabaseValuesDir(name);
          const legacyValuesFlat = this.getLegacyValuesDir(name);
          for (const d of [schemaDir, tablesDir, legacySchemaDir, legacyValuesDir, legacyValuesFlat]) {
            if (fs5.existsSync(d)) {
              fs5.rmSync(d, { recursive: true, force: true });
            }
          }
          return true;
        }
      } catch {
        return false;
      }
    }
    return false;
  }
  /**
   * Merge tables from physical :memory: directory into .localdb and delete :memory: folder
   */
  mergeMemoryIntoLocalDb(targetDbName = "default") {
    return mergeMemoryIntoStorage(this, targetDbName);
  }
  /**
   * Section 651: Clean all root .localdb/*.dblc, .db.lc and .tmp.* files.
   * Migrates any table data into schema/default/ and tables/default/ before deleting root files.
   */
  cleanRootDblcFiles() {
    const migrated = [];
    const removed = [];
    if (!isNode()) return { migrated, removed };
    try {
      const fs5 = getFs2();
      const path3 = getPath2();
      if (!fs5 || !path3) return { migrated, removed };
      const rootDir = this.getEffectiveStorageDir();
      if (!fs5.existsSync(rootDir)) return { migrated, removed };
      const entries = fs5.readdirSync(rootDir, { withFileTypes: true });
      for (const entry of entries) {
        if (entry.isDirectory()) continue;
        const fileName = entry.name;
        const fullPath = path3.join(rootDir, fileName);
        if (fileName.includes(".tmp.") || fileName.endsWith(".tmp")) {
          try {
            fs5.unlinkSync(fullPath);
            removed.push(fileName);
          } catch {
          }
          continue;
        }
        if (fileName.endsWith(".dblc") || fileName.endsWith(".db.lc")) {
          const tableName = this.normalizeTableName(fileName);
          try {
            const raw = fs5.readFileSync(fullPath, "utf8");
            const parsed = parseDblcSql(raw, tableName);
            const table = {
              namespace: parsed.tableName || tableName,
              records: parsed.records,
              relationships: parsed.relationships,
              relations: parsed.relations,
              createdAt: (/* @__PURE__ */ new Date()).toISOString()
            };
            this.saveTable(table, "default");
            migrated.push(tableName);
            if (fs5.existsSync(fullPath)) {
              fs5.unlinkSync(fullPath);
              removed.push(fileName);
            }
          } catch {
            try {
              fs5.unlinkSync(fullPath);
              removed.push(fileName);
            } catch {
            }
          }
        }
      }
    } catch {
    }
    return { migrated, removed };
  }
  /**
   * Section 651: Migrate legacy schema/databases/{db} and values/databases/{db} directories
   * to schema/{db} and tables/{db}.
   */
  migrateLegacyDatabasesDirectories() {
    const migratedDatabases = [];
    const tablesMigrated = [];
    if (!isNode()) return { migratedDatabases, tablesMigrated };
    try {
      const fs5 = getFs2();
      const path3 = getPath2();
      if (!fs5 || !path3) return { migratedDatabases, tablesMigrated };
      const legacySchemaDatabasesDir = path3.resolve(this.getEffectiveStorageDir(), "schema", "databases");
      if (fs5.existsSync(legacySchemaDatabasesDir)) {
        const dbEntries = fs5.readdirSync(legacySchemaDatabasesDir, { withFileTypes: true });
        for (const dbEntry of dbEntries) {
          if (!dbEntry.isDirectory() || dbEntry.name.startsWith(".")) continue;
          const dbName = dbEntry.name;
          if (!migratedDatabases.includes(dbName)) migratedDatabases.push(dbName);
          const legacyDbDir = path3.join(legacySchemaDatabasesDir, dbName);
          const targetSchemaDir = this.getDatabaseSchemaDir(dbName);
          if (!fs5.existsSync(targetSchemaDir)) fs5.mkdirSync(targetSchemaDir, { recursive: true });
          const files = fs5.readdirSync(legacyDbDir);
          for (const file of files) {
            const src = path3.join(legacyDbDir, file);
            if (file.includes(".tmp.") || file.endsWith(".tmp")) {
              try {
                fs5.unlinkSync(src);
              } catch {
              }
              continue;
            }
            if (file.endsWith(".dblc") || file.endsWith(".db.lc")) {
              const targetFile = file.endsWith(".db.lc") ? `${file.slice(0, -".db.lc".length)}.dblc` : file;
              const dest = path3.join(targetSchemaDir, targetFile);
              try {
                fs5.copyFileSync(src, dest);
                fs5.unlinkSync(src);
                tablesMigrated.push(`schema:${dbName}:${file}`);
              } catch {
              }
            }
          }
          try {
            fs5.rmdirSync(legacyDbDir);
          } catch {
          }
        }
        try {
          fs5.rmdirSync(legacySchemaDatabasesDir);
        } catch {
        }
      }
      const legacyValuesDatabasesDir = path3.resolve(this.getEffectiveStorageDir(), "values", "databases");
      if (fs5.existsSync(legacyValuesDatabasesDir)) {
        const dbEntries = fs5.readdirSync(legacyValuesDatabasesDir, { withFileTypes: true });
        for (const dbEntry of dbEntries) {
          if (!dbEntry.isDirectory() || dbEntry.name.startsWith(".")) continue;
          const dbName = dbEntry.name;
          if (!migratedDatabases.includes(dbName)) migratedDatabases.push(dbName);
          const legacyDbDir = path3.join(legacyValuesDatabasesDir, dbName);
          const targetTablesDir = this.getDatabaseTablesDir(dbName);
          if (!fs5.existsSync(targetTablesDir)) fs5.mkdirSync(targetTablesDir, { recursive: true });
          const files = fs5.readdirSync(legacyDbDir);
          for (const file of files) {
            const src = path3.join(legacyDbDir, file);
            if (file.includes(".tmp.") || file.endsWith(".tmp")) {
              try {
                fs5.unlinkSync(src);
              } catch {
              }
              continue;
            }
            if (file.endsWith(".dblc") || file.endsWith(".db.lc")) {
              const targetFile = file.endsWith(".db.lc") ? `${file.slice(0, -".db.lc".length)}.dblc` : file;
              const dest = path3.join(targetTablesDir, targetFile);
              try {
                fs5.copyFileSync(src, dest);
                fs5.unlinkSync(src);
                tablesMigrated.push(`tables:${dbName}:${file}`);
              } catch {
              }
            }
          }
          try {
            fs5.rmdirSync(legacyDbDir);
          } catch {
          }
        }
        try {
          fs5.rmdirSync(legacyValuesDatabasesDir);
        } catch {
        }
      }
      const legacyValuesDir = path3.resolve(this.getEffectiveStorageDir(), "values");
      if (fs5.existsSync(legacyValuesDir)) {
        const entries = fs5.readdirSync(legacyValuesDir, { withFileTypes: true });
        for (const entry of entries) {
          if (entry.isDirectory() && !entry.name.startsWith(".")) {
            const dbName = entry.name;
            const subDir = path3.join(legacyValuesDir, dbName);
            const targetTablesDir = this.getDatabaseTablesDir(dbName);
            if (!fs5.existsSync(targetTablesDir)) fs5.mkdirSync(targetTablesDir, { recursive: true });
            const files = fs5.readdirSync(subDir);
            for (const file of files) {
              const src = path3.join(subDir, file);
              if (file.endsWith(".dblc") || file.endsWith(".db.lc")) {
                const targetFile = file.endsWith(".db.lc") ? `${file.slice(0, -".db.lc".length)}.dblc` : file;
                const dest = path3.join(targetTablesDir, targetFile);
                try {
                  fs5.copyFileSync(src, dest);
                  fs5.unlinkSync(src);
                  tablesMigrated.push(`tables:${dbName}:${file}`);
                } catch {
                }
              } else {
                try {
                  fs5.unlinkSync(src);
                } catch {
                }
              }
            }
            try {
              fs5.rmdirSync(subDir);
            } catch {
            }
          }
        }
        try {
          fs5.rmdirSync(legacyValuesDir);
        } catch {
        }
      }
    } catch {
    }
    return { migratedDatabases, tablesMigrated };
  }
  /**
   * Sync existing root .localdb tables into schema/default/ and tables/default/ and clean root files
   */
  syncRootTablesToDefaultDatabase() {
    const { migrated } = this.cleanRootDblcFiles();
    return migrated;
  }
  /**
   * Migrate any existing legacy .db.lc files in storage to .dblc format
   */
  migrateAllDbLcToDblc(dbName) {
    return migrateAllDbLcToDblcFiles(this, this.getEffectiveStorageDir(), dbName || this._databaseName || "default");
  }
  /**
   * Load all tables from storage or migrate from legacy store
   */
  loadAllTables(dbName) {
    this.detectBackend();
    const targetDb = dbName || this._databaseName || "default";
    const result = {};
    const tableNames = this.listTableNames(targetDb);
    for (const name of tableNames) {
      const table = this.loadTable(name, targetDb);
      if (table) result[name] = table;
    }
    if (targetDb === "default") {
      if (Object.keys(result).length === 0) {
        const legacyTables = this.migrateFromLegacy();
        if (legacyTables) Object.assign(result, legacyTables);
      }
      this.migrateDotCache();
    }
    return result;
  }
  /**
   * Auto-migrate from legacy .Cache/localdb.json or _lc_localdb localStorage
   */
  migrateFromLegacy() {
    return migrateLegacyCacheStore(this);
  }
  /**
   * Auto-migrate and clean up any .Cache directory into LocalSQLServer
   */
  migrateDotCache(baseDir) {
    return migrateDotCacheDirectoryToLocalSql(this, baseDir);
  }
  // ── HydroelectricEngine Integration ──────────────────────────────────────
  getHydroelectricEngine() {
    return hydroelectricEngine;
  }
  isTableFileLarge(tableName, dbName, thresholdBytes) {
    const targetDb = dbName || this._databaseName || "default";
    const cleanName = this.normalizeTableName(tableName);
    const tablesPath = this.getTableTablesPath(cleanName, targetDb);
    return hydroelectricEngine.isLargeFile(tablesPath, thresholdBytes);
  }
  getTableFileSizeBytes(tableName, dbName) {
    const targetDb = dbName || this._databaseName || "default";
    const cleanName = this.normalizeTableName(tableName);
    const tablesPath = this.getTableTablesPath(cleanName, targetDb);
    return hydroelectricEngine.getFileSize(tablesPath);
  }
  async streamScanTable(tableName, options, dbName) {
    const targetDb = dbName || this._databaseName || "default";
    const cleanName = this.normalizeTableName(tableName);
    const tablesPath = this.getTableTablesPath(cleanName, targetDb);
    return hydroelectricEngine.streamScanRecords(tablesPath, options);
  }
  async streamQueryTable(tableName, filter, dbName) {
    const targetDb = dbName || this._databaseName || "default";
    const cleanName = this.normalizeTableName(tableName);
    const tablesPath = this.getTableTablesPath(cleanName, targetDb);
    return hydroelectricEngine.streamQuery(tablesPath, filter);
  }
  _syncLegacyLocalStorage(table) {
    syncLegacyLocalStorageStore(table);
  }
};

// packages/LocalSQLServer/sources/engine/lc-types.ts
var LC_LOCAL_DB_DEFAULT_NAMESPACES = [
  "lc_defaults",
  "lc_projects",
  "lc_workspaces",
  "lc_ui",
  "lc_services",
  "lc_cache",
  "lc_enums",
  "lc_code",
  "lc_project_files",
  "lc_conversations"
];
var LC_LOCAL_DB_NAMESPACES = [...LC_LOCAL_DB_DEFAULT_NAMESPACES];
function nowIso() {
  return (/* @__PURE__ */ new Date()).toISOString();
}
function isExpired(record) {
  if (record.ttlMs == null) return false;
  return Date.now() >= new Date(record.createdAt).getTime() + record.ttlMs;
}
function deepGet(obj, path3) {
  return path3.split(".").reduce((acc, part) => {
    if (acc != null && typeof acc === "object") return acc[part];
    return void 0;
  }, obj);
}
function matchesWhere(record, where) {
  return Object.entries(where).every(([path3, expected]) => deepGet(record, path3) === expected);
}
function estimateSizeBytes(obj) {
  try {
    return new Blob([JSON.stringify(obj)]).size;
  } catch {
    return JSON.stringify(obj).length * 2;
  }
}

// packages/LocalSQLServer/sources/engine/lc-local-db-engine.ts
var ENGINE_VERSION = "1.0.0";
var LcLocalDbEngine = class {
  _db;
  _initialized = false;
  _storage;
  _lastVacuumedAt = null;
  constructor(storageDirOrAdapter, databaseName = "default") {
    if (storageDirOrAdapter instanceof StorageAdapter) {
      this._storage = storageDirOrAdapter;
    } else {
      this._storage = new StorageAdapter(storageDirOrAdapter, databaseName);
    }
    this._db = {};
    if (isNode() && !this._storage.isMemoryOnly) {
      this._storage.mergeMemoryIntoLocalDb();
      this._storage.migrateLegacyDatabasesDirectories();
      this._storage.cleanRootDblcFiles();
    }
  }
  // ── Storage Configuration ──────────────────────────────────────────────────
  get storageAdapter() {
    return this._storage;
  }
  get storageDir() {
    return this._storage.storageDir;
  }
  set storageDir(dir) {
    this._storage.storageDir = dir;
  }
  // ── Multi-Database Management (Section 566) ────────────────────────────────
  get currentDatabase() {
    return this._storage.currentDatabase;
  }
  get databaseName() {
    return this._storage.databaseName;
  }
  set databaseName(name) {
    this._storage.databaseName = name;
  }
  useDatabase(name) {
    this._storage.useDatabase(name);
    this._loadFromStorage();
    return this;
  }
  listDatabases() {
    return this._storage.listDatabases();
  }
  createDatabase(name) {
    return this._storage.createDatabase(name);
  }
  dropDatabase(name) {
    if (name === this._storage.currentDatabase) this.useDatabase("default");
    return this._storage.dropDatabase(name);
  }
  mergeMemoryIntoLocalDb(targetDbName) {
    return this._storage.mergeMemoryIntoLocalDb(targetDbName);
  }
  syncRootTablesToDefaultDatabase() {
    return this._storage.syncRootTablesToDefaultDatabase();
  }
  // ── Lifecycle ──────────────────────────────────────────────────────────────
  async init() {
    if (this._initialized) return;
    this._loadFromStorage();
    this._initialized = true;
  }
  _loadFromStorage() {
    const ts = nowIso();
    const newDb = {};
    const loaded = this._storage.loadAllTables();
    for (const [ns, table] of Object.entries(loaded)) {
      newDb[ns] = {
        namespace: ns,
        records: { ...table.records || {} },
        relationships: [...table.relationships ?? []],
        relations: { ...table.relations ?? {} },
        createdAt: table.createdAt || ts,
        schema: table.schema
      };
    }
    this._db = newDb;
  }
  resolveTableName(name) {
    const cleanName = this._storage.normalizeTableName(name).replace(/[`"']/g, "").trim();
    if (this._db[cleanName]) return cleanName;
    const lower = cleanName.toLowerCase();
    for (const k of Object.keys(this._db)) {
      if (k.toLowerCase() === lower) return k;
    }
    const storageTables = this._storage.listTableNames(this._storage.databaseName);
    for (const st of storageTables) {
      if (st.toLowerCase() === lower) return st;
    }
    return cleanName;
  }
  _ensureTable(tableName) {
    const cleanName = this.resolveTableName(tableName);
    if (!this._db[cleanName]) {
      const loaded = this._storage.loadTable(cleanName);
      if (loaded) {
        this._db[cleanName] = loaded;
        return loaded;
      }
      this._db[cleanName] = {
        namespace: cleanName,
        records: {},
        relationships: [],
        relations: {},
        createdAt: nowIso()
      };
    }
    return this._db[cleanName];
  }
  _persistTable(tableName) {
    const cleanName = this.resolveTableName(tableName);
    const table = this._db[cleanName];
    if (table) {
      this._storage.saveTable(table);
    }
  }
  _persistAll() {
    for (const table of Object.values(this._db)) {
      this._storage.saveTable(table);
    }
  }
  // ── Table Management ───────────────────────────────────────────────────────
  createTable(name, schema) {
    const cleanName = this._storage.normalizeTableName(name);
    if (this._db[cleanName]) {
      if (schema && !this._db[cleanName].schema) {
        this._db[cleanName].schema = { tableName: cleanName, columns: schema.columns ?? {}, ...schema };
        this._persistTable(cleanName);
      }
      return false;
    }
    this._db[cleanName] = {
      namespace: cleanName,
      records: {},
      relationships: schema?.relationships ?? [],
      relations: {},
      schema: schema ? { tableName: cleanName, columns: schema.columns ?? {}, ...schema } : void 0,
      createdAt: nowIso()
    };
    this._persistTable(cleanName);
    return true;
  }
  dropTable(name) {
    const cleanName = this._storage.normalizeTableName(name);
    const inMem = Boolean(this._db[cleanName]);
    const inStorage = this._storage.hasTableFile(cleanName);
    if (!inMem && !inStorage) return false;
    delete this._db[cleanName];
    this._storage.deleteTable(cleanName);
    return true;
  }
  renameTable(oldName, newName) {
    const cleanOld = this._storage.normalizeTableName(oldName);
    const cleanNew = this._storage.normalizeTableName(newName);
    if (!this.hasTable(cleanOld) || this.hasTable(cleanNew)) {
      return false;
    }
    const table = this._ensureTable(cleanOld);
    const updatedRecords = {};
    for (const [k, rec] of Object.entries(table.records)) {
      updatedRecords[k] = { ...rec, namespace: cleanNew };
    }
    this._db[cleanNew] = {
      ...table,
      namespace: cleanNew,
      records: updatedRecords,
      schema: table.schema ? { ...table.schema, tableName: cleanNew } : void 0
    };
    this._storage.saveTable(this._db[cleanNew]);
    this.dropTable(cleanOld);
    return true;
  }
  getTableNames(dbName) {
    const targetDb = dbName || this.databaseName || "default";
    if (dbName && dbName !== this.databaseName) {
      this.useDatabase(dbName);
    }
    const fromStorage = this._storage.listTableNames(targetDb);
    const tableNamesSet = new Set(fromStorage);
    for (const [rawName, table] of Object.entries(this._db)) {
      const cleanName = this._storage.normalizeTableName(rawName);
      const hasSchema = Boolean(table?.schema);
      const hasRecords = Object.keys(table?.records || {}).length > 0;
      if (hasSchema || hasRecords || fromStorage.includes(cleanName)) {
        tableNamesSet.add(cleanName);
      }
    }
    return Array.from(tableNamesSet);
  }
  hasTable(name) {
    const cleanName = this.resolveTableName(name);
    if (this._db[cleanName]) {
      const targetTable = this._db[cleanName];
      if (targetTable.schema || Object.keys(targetTable.records || {}).length > 0 || this._storage.hasTableFile(cleanName)) {
        return true;
      }
    }
    const loaded = this._storage.loadTable(cleanName);
    if (loaded) {
      this._db[cleanName] = loaded;
      return true;
    }
    return false;
  }
  // ── Core CRUD ─────────────────────────────────────────────────────────────
  set(namespace, key, value, opts = {}) {
    const table = this._ensureTable(namespace);
    const existing = table.records[key];
    const ts = nowIso();
    const record = {
      key,
      namespace,
      value,
      createdAt: existing?.createdAt ?? ts,
      updatedAt: ts,
      ttlMs: opts.ttlMs !== void 0 ? opts.ttlMs : existing?.ttlMs ?? null,
      version: (existing?.version ?? 0) + 1,
      tags: opts.tags ?? existing?.tags
    };
    table.records[key] = record;
    this._persistTable(namespace);
    return record;
  }
  get(namespace, key) {
    const table = this._ensureTable(namespace);
    const record = table.records[key];
    if (!record || isExpired(record)) return null;
    return record.value;
  }
  getRecord(namespace, key) {
    const table = this._ensureTable(namespace);
    const record = table.records[key];
    if (!record || isExpired(record)) return null;
    return record;
  }
  getAll(namespace, opts = {}) {
    const table = this._ensureTable(namespace);
    return Object.values(table.records).filter(
      (r) => opts.includeExpired || !isExpired(r)
    );
  }
  /**
   * Alias for getAll, providing backwards compatibility for consumers expecting a list() method
   */
  list(namespace, opts = {}) {
    return this.getAll(namespace, opts);
  }
  query(namespace, options = {}) {
    let records = this.getAll(namespace, { includeExpired: options.includeExpired });
    if (options.where && Object.keys(options.where).length > 0) {
      records = records.filter((r) => matchesWhere(r, options.where));
    }
    if (options.tags && options.tags.length > 0) {
      records = records.filter(
        (r) => r.tags && options.tags.some((tag) => r.tags.includes(tag))
      );
    }
    if (options.orderBy) {
      const { field, direction = "asc" } = options.orderBy;
      records = [...records].sort((a, b) => {
        const aVal = String(deepGet(a, field) ?? "");
        const bVal = String(deepGet(b, field) ?? "");
        return direction === "asc" ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
      });
    }
    const offset = options.offset ?? 0;
    const sliced = records.slice(offset);
    return options.limit != null ? sliced.slice(0, options.limit) : sliced;
  }
  has(namespace, key) {
    return this.get(namespace, key) !== null;
  }
  keys(namespace) {
    return this.getAll(namespace).map((r) => r.key);
  }
  count(namespace) {
    if (namespace) return this.getAll(namespace).length;
    return Object.keys(this._db).reduce((sum, ns) => sum + this.getAll(ns).length, 0);
  }
  delete(namespace, key) {
    const table = this._db[namespace];
    if (!table || !table.records[key]) return false;
    delete table.records[key];
    this._persistTable(namespace);
    return true;
  }
  clear(namespace) {
    if (namespace) {
      if (this._db[namespace]) {
        this._db[namespace].records = {};
        this._persistTable(namespace);
      }
    } else {
      for (const ns of Object.keys(this._db)) {
        this._db[ns].records = {};
      }
      this._persistAll();
    }
  }
  transaction(fn) {
    fn(this);
    this._persistAll();
  }
  vacuum() {
    let removed = 0;
    for (const ns of Object.keys(this._db)) {
      const table = this._db[ns];
      let tableChanged = false;
      for (const key of Object.keys(table.records)) {
        if (isExpired(table.records[key])) {
          delete table.records[key];
          removed++;
          tableChanged = true;
        }
      }
      if (tableChanged) this._persistTable(ns);
    }
    this._lastVacuumedAt = nowIso();
    return removed;
  }
  // ── Relationships & Link Data API ──────────────────────────────────────────
  defineRelationship(rel) {
    const table = this._ensureTable(rel.sourceTable);
    const created = RelationshipManager.defineRelationship(table, rel);
    this._persistTable(rel.sourceTable);
    return created;
  }
  getRelationships(tableName) {
    if (tableName) {
      return this._db[tableName]?.relationships ?? [];
    }
    const all = [];
    for (const tbl of Object.values(this._db)) {
      if (tbl.relationships) all.push(...tbl.relationships);
    }
    return all;
  }
  removeRelationship(relationshipId, tableName) {
    if (tableName) {
      const table = this._db[tableName];
      if (!table) return false;
      const res = RelationshipManager.removeRelationship(table, relationshipId);
      if (res) this._persistTable(tableName);
      return res;
    }
    for (const tbl of Object.values(this._db)) {
      if (RelationshipManager.removeRelationship(tbl, relationshipId)) {
        this._persistTable(tbl.namespace);
        return true;
      }
    }
    return false;
  }
  linkRecords(sourceTable, recordKey, targetTable, targetKey, relationType = "1:N", metadata) {
    const table = this._ensureTable(sourceTable);
    const link = RelationshipManager.linkRecords(
      table,
      recordKey,
      targetTable,
      targetKey,
      relationType,
      metadata
    );
    this._persistTable(sourceTable);
    return link;
  }
  unlinkRecords(sourceTable, recordKey, targetTable, targetKey) {
    const table = this._db[sourceTable];
    if (!table) return false;
    const res = RelationshipManager.unlinkRecords(table, recordKey, targetTable, targetKey);
    if (res) this._persistTable(sourceTable);
    return res;
  }
  getRelatedRecords(sourceTable, recordKey, targetTable) {
    const table = this._db[sourceTable];
    if (!table) return [];
    return RelationshipManager.getRelatedRecords(
      table,
      recordKey,
      (tbl, key) => this.getRecord(tbl, key),
      targetTable
    );
  }
  autoDetectRelationships(tableName) {
    const known = this.getTableNames();
    if (tableName) {
      const clean = this._storage.normalizeTableName(tableName);
      const table = this._db[clean] ?? this._storage.loadTable(clean);
      if (!table) return [];
      return RelationshipManager.autoDetectRelationships(clean, table.records, known);
    }
    const detected = [];
    for (const name of known) {
      const tbl = this._db[name] ?? this._storage.loadTable(name);
      if (tbl) {
        detected.push(...RelationshipManager.autoDetectRelationships(name, tbl.records, known));
      }
    }
    return detected;
  }
  // ── {table-name}.dblc File I/O ───────────────────────────────────────────
  serializeTableToDblc(tableName) {
    return serializeTableToDblc(this._ensureTable(this._storage.normalizeTableName(tableName)), ENGINE_VERSION);
  }
  serializeTableToDbLc(tableName) {
    return this.serializeTableToDblc(tableName);
  }
  parseDblcSql(sql, fallbackTableName) {
    return parseDblcSql(sql, fallbackTableName);
  }
  parseDbLcSql(sql, fallbackTableName) {
    return parseDblcSql(sql, fallbackTableName);
  }
  saveTable(tableName) {
    return this._storage.saveTable(this._ensureTable(this._storage.normalizeTableName(tableName)));
  }
  loadTable(tableName) {
    const cleanName = this._storage.normalizeTableName(tableName);
    const loaded = this._storage.loadTable(cleanName);
    if (!loaded) return false;
    this._db[cleanName] = loaded;
    return true;
  }
  saveAll() {
    const paths = [];
    for (const tbl of Object.values(this._db)) {
      paths.push(this._storage.saveTable(tbl));
    }
    return paths;
  }
  saveToStorage() {
    return this.saveAll();
  }
  loadAll() {
    this._loadFromStorage();
    return Object.keys(this._db);
  }
  exportTableDblc(tableName) {
    return this.serializeTableToDblc(tableName);
  }
  exportTableDbLc(tableName) {
    return this.serializeTableToDblc(tableName);
  }
  exportTableSchemaDblc(tableName) {
    const table = this._ensureTable(tableName);
    return serializeTableSchemaToDblc(table);
  }
  exportTableValuesDblc(tableName) {
    const table = this._ensureTable(tableName);
    return serializeTableValuesToDblc(table);
  }
  migrateAllToDblc(dbName) {
    return this._storage.migrateAllDbLcToDblc(dbName);
  }
  getTablePath(tableName, dbName) {
    return this._storage.getTablePath(tableName, dbName);
  }
  getTableSchemaPath(tableName, dbName) {
    return this._storage.getTableSchemaPath(tableName, dbName);
  }
  getTableTablesPath(tableName, dbName) {
    return this._storage.getTableTablesPath(tableName, dbName);
  }
  getTableValuesPath(tableName, dbName) {
    return this._storage.getTableValuesPath(tableName, dbName);
  }
  getTableDisplaySchemaPath(tableName, dbName) {
    return this._storage.getTableDisplaySchemaPath(tableName, dbName);
  }
  getTableDisplayTablesPath(tableName, dbName) {
    return this._storage.getTableDisplayTablesPath(tableName, dbName);
  }
  getTableDisplayValuesPath(tableName, dbName) {
    return this._storage.getTableDisplayValuesPath(tableName, dbName);
  }
  hasTableSchemaFile(tableName, dbName) {
    return this._storage.hasTableSchemaFile(tableName, dbName);
  }
  hasTableTablesFile(tableName, dbName) {
    return this._storage.hasTableTablesFile(tableName, dbName);
  }
  hasTableValuesFile(tableName, dbName) {
    return this._storage.hasTableValuesFile(tableName, dbName);
  }
  listDatabaseFiles(dbName) {
    return this._storage.listDatabaseFiles(dbName);
  }
  cleanRootDblcFiles() {
    return this._storage.cleanRootDblcFiles();
  }
  migrateLegacyDatabasesDirectories() {
    return this._storage.migrateLegacyDatabasesDirectories();
  }
  syncAllDatabaseValues(dbName) {
    const targetDb = dbName || this._storage.currentDatabase;
    const tableNames = this._storage.listTableNames(targetDb);
    const syncedTables = [];
    for (const tableName of tableNames) {
      const table = this._storage.loadTable(tableName, targetDb);
      if (table) {
        this._storage.saveTable(table, targetDb);
        syncedTables.push(tableName);
      }
    }
    return syncedTables;
  }
  importTableDblc(sql) {
    const parsed = parseDblcSql(sql);
    const table = this._ensureTable(parsed.tableName);
    const recordCount = Object.keys(parsed.records).length;
    table.records = { ...table.records, ...parsed.records };
    const relCount = parsed.relationships.length;
    for (const rel of parsed.relationships) {
      RelationshipManager.defineRelationship(table, rel);
    }
    const linksCount = Object.keys(parsed.relations).length;
    table.relations = { ...table.relations, ...parsed.relations };
    this._persistTable(parsed.tableName);
    return {
      tableName: parsed.tableName,
      importedRecords: recordCount,
      importedRelationships: relCount,
      importedRelations: linksCount
    };
  }
  importTableDbLc(sql) {
    return this.importTableDblc(sql);
  }
  // ── Global Dump / Restore / SQL ────────────────────────────────────────────
  dump() {
    const tables = Object.fromEntries(
      Object.entries(this._db).map(([ns, tbl]) => [ns, { ...tbl }])
    );
    const totalRecords = Object.values(this._db).reduce(
      (sum, tbl) => sum + Object.keys(tbl.records).length,
      0
    );
    return {
      version: 1,
      exportedAt: nowIso(),
      engineVersion: ENGINE_VERSION,
      tables,
      totalRecords,
      totalSizeBytes: estimateSizeBytes(this._db)
    };
  }
  restore(dump) {
    if (!dump?.tables) return;
    for (const [ns, tbl] of Object.entries(dump.tables)) {
      this._db[ns] = {
        namespace: ns,
        records: tbl.records ?? {},
        relationships: tbl.relationships ?? [],
        relations: tbl.relations ?? {},
        schema: tbl.schema,
        createdAt: tbl.createdAt || nowIso()
      };
    }
    this._persistAll();
  }
  exportSql() {
    const lines = [
      `-- LcLocalDb SQL Multi-Table Bundle v${ENGINE_VERSION}`,
      `-- Exported at: ${nowIso()}`,
      `-- Tables: ${Object.keys(this._db).join(", ")}`,
      ""
    ];
    for (const tableName of Object.keys(this._db)) {
      lines.push(this.serializeTableToDbLc(tableName));
    }
    return lines.join("\n");
  }
  importSql(sql) {
    let imported = 0;
    const insertRe = /INSERT\s+(?:OR\s+REPLACE\s+)?INTO\s+([a-zA-Z0-9_-]+)\s*\([^)]+\)\s*VALUES\s*\(([^;]+)\);/gi;
    let match;
    while ((match = insertRe.exec(sql)) !== null) {
      const target = match[1].trim();
      if (target.endsWith("_relationships") || target.endsWith("_relations")) {
        continue;
      }
      const vals = parseSqlValues(match[2]);
      if (vals.length < 4) continue;
      try {
        const [key, valueJson, createdAt, updatedAt, ttlMsRaw, versionRaw, tagsRaw] = vals;
        const keyStr = key.replace(/^'|'$/g, "").replace(/''/g, "'");
        const value = JSON.parse(valueJson.replace(/^'|'$/g, "").replace(/''/g, "'"));
        const ttlMs = ttlMsRaw === "NULL" ? null : Number(ttlMsRaw);
        const version = Number(versionRaw || 1);
        const tags = tagsRaw && tagsRaw !== "NULL" ? tagsRaw.replace(/^'|'$/g, "").split(",") : void 0;
        this.set(target, keyStr, value, { ttlMs, tags });
        if (version > 1) {
          const r = this.getRecord(target, keyStr);
          if (r) r.version = version;
        }
        imported++;
      } catch {
      }
    }
    return imported;
  }
  getCurrentDatabase() {
    return this._storage.databaseName;
  }
  getTableSchema(tableName) {
    const cleanName = this.resolveTableName(tableName);
    const table = this._ensureTable(cleanName);
    return table.schema;
  }
  executeSql(sql) {
    const trimmed = sql.trim();
    if (!trimmed) {
      return [];
    }
    const statements = trimmed.split(/;\s*(?=(?:[^']*'[^']*')*[^']*$)/).map((s) => s.trim()).filter(Boolean);
    let lastResult = [];
    for (const stmt of statements) {
      const upper = stmt.toUpperCase();
      const useMatch = stmt.match(/^USE\s+([a-zA-Z0-9_-]+)/i);
      if (useMatch) {
        const dbName = useMatch[1].trim();
        this.useDatabase(dbName);
        lastResult = [{ database: dbName, status: "switched" }];
        continue;
      }
      const createDbMatch = stmt.match(/^CREATE\s+DATABASE(?:\s+IF\s+NOT\s+EXISTS)?\s+([a-zA-Z0-9_-]+)/i);
      if (createDbMatch) {
        const dbName = createDbMatch[1].trim();
        const created = this.createDatabase(dbName);
        lastResult = [{ database: dbName, created }];
        continue;
      }
      const dropDbMatch = stmt.match(/^DROP\s+DATABASE(?:\s+IF\s+EXISTS)?\s+([a-zA-Z0-9_-]+)/i);
      if (dropDbMatch) {
        const dbName = dropDbMatch[1].trim();
        const dropped = this.dropDatabase(dbName);
        lastResult = [{ database: dbName, dropped }];
        continue;
      }
      if (upper === "SHOW TABLES" || upper.startsWith("SHOW TABLES")) {
        lastResult = this.getTableNames().map((name) => ({ table_name: name }));
        continue;
      }
      if (upper === "SHOW DATABASES" || upper.startsWith("SHOW DATABASES")) {
        lastResult = this.listDatabases().map((name) => ({ database_name: name }));
        continue;
      }
      const createTableMatch = stmt.match(
        /^CREATE\s+TABLE(?:\s+IF\s+NOT\s+EXISTS)?\s+([a-zA-Z0-9_-]+)\s*\(([\s\S]+)\)/i
      );
      if (createTableMatch) {
        const tableName = createTableMatch[1].trim();
        const columnsRaw = createTableMatch[2].trim();
        const columnsDef = {};
        const colLines = columnsRaw.split(/,\s*(?=(?:[^']*'[^']*')*[^']*$)/);
        for (const colLine of colLines) {
          const parts = colLine.trim().split(/\s+/);
          if (parts.length >= 2) {
            const colName = parts[0].replace(/[`"']/g, "");
            const colType = parts[1].toUpperCase();
            const isPk = colLine.toUpperCase().includes("PRIMARY KEY");
            const isNotNull = colLine.toUpperCase().includes("NOT NULL");
            columnsDef[colName] = {
              type: colType,
              primaryKey: isPk,
              notNull: isNotNull
            };
          }
        }
        const created = this.createTable(tableName, {
          tableName,
          columns: columnsDef
        });
        lastResult = [{ table: tableName, created }];
        continue;
      }
      const dropTableMatch = stmt.match(/^DROP\s+TABLE(?:\s+IF\s+EXISTS)?\s+([a-zA-Z0-9_-]+)/i);
      if (dropTableMatch) {
        const tableName = dropTableMatch[1].trim();
        const dropped = this.dropTable(tableName);
        lastResult = [{ table: tableName, dropped }];
        continue;
      }
      const alterRenameMatch = stmt.match(
        /^ALTER\s+TABLE\s+([a-zA-Z0-9_-]+)\s+RENAME\s+TO\s+([a-zA-Z0-9_-]+)/i
      );
      if (alterRenameMatch) {
        const oldName = alterRenameMatch[1].trim();
        const newName = alterRenameMatch[2].trim();
        const renamed = this.renameTable(oldName, newName);
        lastResult = [{ table: newName, oldName, renamed }];
        continue;
      }
      const insertMatch = stmt.match(
        /^INSERT\s+(?:OR\s+REPLACE\s+)?INTO\s+[`"']?([a-zA-Z0-9_-]+)[`"']?(?:\s*\(([^)]+)\))?\s*VALUES\s*\(([^)]+)\)/i
      );
      if (insertMatch) {
        const rawTableName = insertMatch[1].trim();
        const tableName = this.resolveTableName(rawTableName);
        const isOrReplace = /INSERT\s+OR\s+REPLACE\s+INTO/i.test(stmt);
        const colsRaw = insertMatch[2]?.trim();
        const valsRaw = insertMatch[3].trim();
        const vals = valsRaw.split(/,\s*(?=(?:[^']*'[^']*')*[^']*$)/).map((v) => {
          const t = v.trim();
          if (t.startsWith("'") && t.endsWith("'") || t.startsWith('"') && t.endsWith('"')) {
            return t.slice(1, -1);
          }
          if (!isNaN(Number(t))) {
            return Number(t);
          }
          if (t.toLowerCase() === "true") return true;
          if (t.toLowerCase() === "false") return false;
          if (t.toLowerCase() === "null") return null;
          return t;
        });
        const recordData = {};
        if (colsRaw) {
          const cols = colsRaw.split(",").map((c) => c.trim().replace(/[`"']/g, ""));
          cols.forEach((col, idx) => {
            recordData[col] = vals[idx] !== void 0 ? vals[idx] : null;
          });
        } else {
          vals.forEach((val, idx) => {
            recordData[`col_${idx}`] = val;
          });
        }
        const tableSchema = this.getTableSchema(tableName);
        let primaryKeyName = "id";
        if (tableSchema && typeof tableSchema === "object" && "columns" in tableSchema) {
          const colsMap = tableSchema.columns || {};
          for (const [colName, colDef] of Object.entries(colsMap)) {
            if (typeof colDef === "object" && colDef !== null && colDef.primaryKey) {
              primaryKeyName = colName;
              break;
            }
          }
        } else {
          primaryKeyName = Object.keys(recordData)[0] || "id";
        }
        const primaryKeyValue = String(recordData[primaryKeyName] || recordData["id"] || `rec_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`);
        if (this.has(tableName, primaryKeyValue)) {
          if (!isOrReplace) {
            throw new Error(`Duplicate primary key: record '${primaryKeyValue}' already exists in table '${tableName}'`);
          }
          const existingRec = this.getRecord(tableName, primaryKeyValue);
          const baseVal = existingRec && existingRec.value && typeof existingRec.value === "object" ? existingRec.value : {};
          const mergedData = { ...baseVal, ...recordData };
          this.set(tableName, primaryKeyValue, mergedData);
          lastResult = [{ inserted: 1, updated: 1, key: primaryKeyValue }];
          continue;
        }
        this.set(tableName, primaryKeyValue, recordData);
        lastResult = [{ inserted: 1, key: primaryKeyValue }];
        continue;
      }
      const updateMatch = stmt.match(
        /^UPDATE\s+[`"']?([a-zA-Z0-9_-]+)[`"']?\s+SET\s+([^W]+)(?:\s+WHERE\s+(.+))?/i
      );
      if (updateMatch) {
        const rawTableName = updateMatch[1].trim();
        const tableName = this.resolveTableName(rawTableName);
        const setClause = updateMatch[2].trim();
        const whereClause = updateMatch[3]?.trim();
        const setPairs = setClause.split(/,\s*(?=(?:[^']*'[^']*')*[^']*$)/);
        const updates = {};
        for (const pair of setPairs) {
          const eqIdx = pair.indexOf("=");
          if (eqIdx > 0) {
            const field = pair.slice(0, eqIdx).trim().replace(/[`"']/g, "");
            const valStr = pair.slice(eqIdx + 1).trim();
            if (valStr.startsWith("'") && valStr.endsWith("'") || valStr.startsWith('"') && valStr.endsWith('"')) {
              updates[field] = valStr.slice(1, -1);
            } else if (!isNaN(Number(valStr))) {
              updates[field] = Number(valStr);
            } else if (valStr.toLowerCase() === "true") {
              updates[field] = true;
            } else if (valStr.toLowerCase() === "false") {
              updates[field] = false;
            } else if (valStr.toLowerCase() === "null") {
              updates[field] = null;
            } else {
              updates[field] = valStr;
            }
          }
        }
        const allRecords = Object.values(this._ensureTable(tableName).records);
        let updatedCount = 0;
        for (const rec of allRecords) {
          const rowVal = rec.value && typeof rec.value === "object" ? rec.value : { id: rec.key, value: rec.value };
          let matchesWhere2 = true;
          if (whereClause) {
            const whereEq = whereClause.match(/([a-zA-Z0-9_]+)\s*=\s*(.+)/i);
            if (whereEq) {
              const fld = whereEq[1].trim();
              const val = whereEq[2].trim().replace(/^['"]|['"]$/g, "");
              matchesWhere2 = String(rowVal[fld]) === val || rec.key === val;
            }
          }
          if (matchesWhere2) {
            const merged = { ...rowVal, ...updates };
            this.set(tableName, rec.key, merged);
            updatedCount += 1;
          }
        }
        lastResult = [{ updated: updatedCount }];
        continue;
      }
      const deleteMatch = stmt.match(
        /^DELETE\s+FROM\s+[`"']?([a-zA-Z0-9_-]+)[`"']?(?:\s+WHERE\s+(.+))?/i
      );
      if (deleteMatch) {
        const rawTableName = deleteMatch[1].trim();
        const tableName = this.resolveTableName(rawTableName);
        const whereClause = deleteMatch[2]?.trim();
        const allRecords = Object.values(this._ensureTable(tableName).records);
        let deletedCount = 0;
        for (const rec of allRecords) {
          const rowVal = rec.value && typeof rec.value === "object" ? rec.value : { id: rec.key, value: rec.value };
          let matchesWhere2 = true;
          if (whereClause) {
            const whereIn = whereClause.match(/([a-zA-Z0-9_]+)\s+IN\s*\(([^)]+)\)/i);
            const whereEq = whereClause.match(/([a-zA-Z0-9_]+)\s*=\s*(.+)/i);
            if (whereIn) {
              const fld = whereIn[1].trim();
              const inVals = whereIn[2].split(",").map((v) => v.trim().replace(/^['"]|['"]$/g, ""));
              matchesWhere2 = inVals.includes(String(rowVal[fld])) || inVals.includes(rec.key);
            } else if (whereEq) {
              const fld = whereEq[1].trim();
              const val = whereEq[2].trim().replace(/^['"]|['"]$/g, "");
              matchesWhere2 = String(rowVal[fld]) === val || rec.key === val;
            }
          }
          if (matchesWhere2) {
            this.delete(tableName, rec.key);
            deletedCount += 1;
          }
        }
        lastResult = [{ deleted: deletedCount }];
        continue;
      }
      const joinMatch = stmt.match(
        /^SELECT\s+([\s\S]+?)\s+FROM\s+([a-zA-Z0-9_-]+)\s+JOIN\s+([a-zA-Z0-9_-]+)\s+ON\s+([a-zA-Z0-9_.-]+)\s*=\s*([a-zA-Z0-9_.-]+)(?:\s+WHERE\s+(.+?))?(?:\s+LIMIT\s+(\d+))?$/i
      );
      if (joinMatch) {
        const fieldsRaw = joinMatch[1].trim();
        const t1Name = this._storage.normalizeTableName(joinMatch[2].trim());
        const t2Name = this._storage.normalizeTableName(joinMatch[3].trim());
        const onLeft = joinMatch[4].trim();
        const onRight = joinMatch[5].trim();
        const limitCount = joinMatch[7] ? Number(joinMatch[7]) : void 0;
        const table1 = this._ensureTable(t1Name);
        const table2 = this._ensureTable(t2Name);
        const records1 = Object.values(table1.records);
        const records2 = Object.values(table2.records);
        const leftField = onLeft.includes(".") ? onLeft.split(".")[1] : onLeft;
        const rightField = onRight.includes(".") ? onRight.split(".")[1] : onRight;
        const joinedRows = [];
        for (const r1 of records1) {
          const row1 = r1.value && typeof r1.value === "object" ? r1.value : { id: r1.key, value: r1.value };
          for (const r2 of records2) {
            const row2 = r2.value && typeof r2.value === "object" ? r2.value : { id: r2.key, value: r2.value };
            if (String(row1[leftField]) === String(row2[rightField]) || String(row1[rightField]) === String(row2[leftField])) {
              const merged = { ...row1, ...row2 };
              joinedRows.push(merged);
            }
          }
        }
        const limitedRows = limitCount !== void 0 ? joinedRows.slice(0, limitCount) : joinedRows;
        if (fieldsRaw === "*") {
          lastResult = limitedRows;
        } else {
          const requestedFields = fieldsRaw.split(",").map((f) => f.trim().replace(/[`"']/g, ""));
          lastResult = limitedRows.map((row) => {
            const projected = {};
            for (const f of requestedFields) {
              const cleanF = f.includes(".") ? f.split(".")[1] : f;
              projected[f] = row[cleanF] !== void 0 ? row[cleanF] : row[f] !== void 0 ? row[f] : null;
            }
            return projected;
          });
        }
        continue;
      }
      const selectMatch = stmt.match(
        /^SELECT\s+([\s\S]+?)\s+FROM\s+([`"']?[a-zA-Z0-9_.-]+[`"']?)(?:\s+WHERE\s+(.+?))?(?:\s+ORDER\s+BY\s+([a-zA-Z0-9_]+)(?:\s+(ASC|DESC))?)?(?:\s+LIMIT\s+(\d+))?$/i
      );
      if (selectMatch) {
        const fieldsRaw = selectMatch[1].trim();
        const rawTableName = selectMatch[2].replace(/[`"']/g, "").trim();
        const cleanTableName = rawTableName.includes(".") ? rawTableName.split(".").pop() : rawTableName;
        const tableName = this.resolveTableName(cleanTableName);
        const whereClause = selectMatch[3]?.trim();
        const orderByCol = selectMatch[4]?.trim();
        const orderDir = (selectMatch[5] || "ASC").toUpperCase();
        const limitCount = selectMatch[6] ? Number(selectMatch[6]) : void 0;
        const table = this._ensureTable(tableName);
        const allRecords = Object.values(table.records);
        const matchedRows = [];
        for (const rec of allRecords) {
          const rowVal = rec.value && typeof rec.value === "object" ? rec.value : { id: rec.key, value: rec.value };
          let matches = true;
          if (whereClause) {
            const whereComp = whereClause.match(
              /([a-zA-Z0-9_]+)\s*(<=|>=|!=|<>|<|>|=)\s*(.+)/i
            );
            if (whereComp) {
              const fld = whereComp[1].trim();
              const op = whereComp[2].trim();
              const val = whereComp[3].trim().replace(/^['"]|['"]$/g, "");
              const actual = rowVal[fld] !== void 0 ? rowVal[fld] : fld === "id" ? rec.key : void 0;
              if (typeof actual === "number" && !isNaN(Number(val))) {
                const targetNum = Number(val);
                if (op === "=") matches = actual === targetNum;
                else if (op === "!=" || op === "<>") matches = actual !== targetNum;
                else if (op === ">") matches = actual > targetNum;
                else if (op === "<") matches = actual < targetNum;
                else if (op === ">=") matches = actual >= targetNum;
                else if (op === "<=") matches = actual <= targetNum;
              } else {
                const strActual = String(actual !== void 0 ? actual : rec.key);
                if (op === "=") matches = strActual === val || rec.key === val;
                else if (op === "!=" || op === "<>") matches = strActual !== val;
                else if (op === ">") matches = strActual > val;
                else if (op === "<") matches = strActual < val;
                else if (op === ">=") matches = strActual >= val;
                else if (op === "<=") matches = strActual <= val;
              }
            }
          }
          if (matches) {
            matchedRows.push(rowVal);
          }
        }
        if (orderByCol) {
          matchedRows.sort((a, b) => {
            const valA = a[orderByCol];
            const valB = b[orderByCol];
            if (valA === valB) return 0;
            if (valA === void 0 || valA === null) return 1;
            if (valB === void 0 || valB === null) return -1;
            const diff = valA < valB ? -1 : 1;
            return orderDir === "DESC" ? -diff : diff;
          });
        }
        const limitedRows = limitCount !== void 0 ? matchedRows.slice(0, limitCount) : matchedRows;
        if (fieldsRaw.toUpperCase().includes("COUNT(")) {
          lastResult = [{ count: matchedRows.length }];
          continue;
        }
        if (fieldsRaw === "*") {
          lastResult = limitedRows;
        } else {
          const requestedFields = fieldsRaw.split(",").map((f) => f.trim().replace(/[`"']/g, ""));
          lastResult = limitedRows.map((row) => {
            const projected = {};
            for (const f of requestedFields) {
              projected[f] = row[f] !== void 0 ? row[f] : null;
            }
            return projected;
          });
        }
        continue;
      }
      throw new Error(`SQL syntax error or unsupported command: ${stmt}`);
    }
    return lastResult;
  }
  // ── Stats ─────────────────────────────────────────────────────────────────
  getStats() {
    const tableStats = {};
    let totalRecords = 0;
    let totalSizeBytes = 0;
    for (const [ns, table] of Object.entries(this._db)) {
      const records = Object.values(table.records);
      const alive = records.filter((r) => !isExpired(r));
      const sizeBytes = estimateSizeBytes(table.records);
      const lastUpdated = alive.reduce((max, r) => {
        if (!max) return r.updatedAt;
        return r.updatedAt > max ? r.updatedAt : max;
      }, null);
      tableStats[ns] = {
        recordCount: alive.length,
        sizeBytes,
        lastUpdated,
        relationshipCount: table.relationships?.length ?? 0,
        relationLinksCount: Object.keys(table.relations ?? {}).length
      };
      totalRecords += alive.length;
      totalSizeBytes += sizeBytes;
    }
    return {
      totalRecords,
      totalSizeBytes,
      tableStats,
      backend: this._storage.detectBackend(),
      lastVacuumedAt: this._lastVacuumedAt,
      engineVersion: ENGINE_VERSION
    };
  }
  // ── Convenience Shortcuts ──────────────────────────────────────────────────
  setDefault(key, value, opts) {
    return this.set("lc_defaults", key, value, opts);
  }
  getDefault(key) {
    return this.get("lc_defaults", key);
  }
  setProject(projectId, data, opts) {
    return this.set("lc_projects", projectId, data, opts);
  }
  getProject(projectId) {
    return this.get("lc_projects", projectId);
  }
  setUiState(key, value, opts) {
    return this.set("lc_ui", key, value, opts);
  }
  getUiState(key) {
    return this.get("lc_ui", key);
  }
  setCache(key, value, ttlMs) {
    return this.set("lc_cache", key, value, { ttlMs });
  }
  getCache(key) {
    return this.get("lc_cache", key);
  }
  getCacheRecord(key) {
    return this.getRecord("lc_cache", key);
  }
  hasCache(key) {
    return this.getCache(key) !== null;
  }
  deleteCache(key) {
    return this.delete("lc_cache", key);
  }
  clearCache() {
    const table = this._db["lc_cache"];
    const count = table ? Object.keys(table.records).length : 0;
    this.clear("lc_cache");
    return count;
  }
  getAllCache() {
    const records = this.getAll("lc_cache");
    return records.map((r) => ({
      key: r.key,
      value: r.value,
      createdAt: r.createdAt,
      updatedAt: r.updatedAt,
      ttlMs: r.ttlMs
    }));
  }
  migrateLegacyDotCache(baseDir) {
    return this._storage.migrateDotCache(baseDir);
  }
  setCode(projectId, filePath, content, fileType, opts) {
    const key = `${projectId}:${filePath}`;
    return this.set("lc_code", key, {
      projectId,
      filePath,
      content,
      fileType: fileType || "plaintext",
      sizeBytes: content.length,
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    }, { ...opts, tags: ["code", projectId, ...opts?.tags || []] });
  }
  getCode(projectId, filePath) {
    const key = `${projectId}:${filePath}`;
    const rec = this.get("lc_code", key);
    return rec?.content ?? null;
  }
  getProjectCodeFiles(projectId) {
    const records = this.getAll("lc_code");
    const result = {};
    for (const r of records) {
      const val = (r && r.value ? r.value : r) || {};
      if (val && val.projectId === projectId && val.filePath) {
        result[val.filePath] = val.content;
      }
    }
    return result;
  }
  setService(serviceId, serviceData, opts) {
    return this.set("lc_services", serviceId, serviceData, opts);
  }
  getService(serviceId) {
    return this.get("lc_services", serviceId);
  }
  getAllServices() {
    const records = this.getAll("lc_services");
    return records.map((r) => r && r.value ? r.value : r).filter(Boolean);
  }
  // ── HydroelectricEngine Integration ──────────────────────────────────────
  getHydroelectricEngine() {
    return hydroelectricEngine;
  }
  isTableLarge(tableName, thresholdBytes) {
    return this._storage.isTableFileLarge(tableName, this.currentDatabase, thresholdBytes);
  }
  getTableSizeBytes(tableName) {
    return this._storage.getTableFileSizeBytes(tableName, this.currentDatabase);
  }
  async streamScanTable(tableName, options) {
    return this._storage.streamScanTable(tableName, options, this.currentDatabase);
  }
  async streamQueryTable(tableName, filter) {
    return this._storage.streamQueryTable(tableName, filter, this.currentDatabase);
  }
  async streamPipeTableToHttp(tableName, writable, options) {
    const cleanName = this.resolveTableName(tableName);
    const tablesPath = this._storage.getTableTablesPath(cleanName, this.currentDatabase);
    return hydroelectricEngine.streamPipeToHttp(tablesPath, writable, options);
  }
};
var lcLocalDbEngine = new LcLocalDbEngine();
lcLocalDbEngine.init();

// packages/LocalSQLServer/sources/monitor/lc-performance-monitor.ts
var import_node_os = __toESM(require("node:os"));
var import_node_process = __toESM(require("node:process"));
var LcPerformanceMonitor = class _LcPerformanceMonitor {
  static instance = null;
  startTime = Date.now();
  totalQueries = 0;
  readsCount = 0;
  writesCount = 0;
  activeHttpConnections = 0;
  activeGrpcConnections = 0;
  activeLocalConnections = 0;
  // Circular buffer for latency tracking (last 1000 queries)
  latencySamples = [];
  maxSamples = 1e3;
  // Windowed QPS tracking
  recentQueryTimestamps = [];
  constructor() {
  }
  static getInstance() {
    if (!_LcPerformanceMonitor.instance) {
      _LcPerformanceMonitor.instance = new _LcPerformanceMonitor();
    }
    return _LcPerformanceMonitor.instance;
  }
  recordQuery(durationMs, sqlQueryText) {
    this.totalQueries += 1;
    const now2 = Date.now();
    this.recentQueryTimestamps.push(now2);
    const cutoff = now2 - 5e3;
    this.recentQueryTimestamps = this.recentQueryTimestamps.filter(
      (ts) => ts >= cutoff
    );
    if (this.latencySamples.length >= this.maxSamples) {
      this.latencySamples.shift();
    }
    this.latencySamples.push(durationMs);
    const trimmedSql = sqlQueryText.trim().toUpperCase();
    if (trimmedSql.startsWith("SELECT") || trimmedSql.startsWith("SHOW") || trimmedSql.startsWith("DESCRIBE") || trimmedSql.startsWith("EXPLAIN")) {
      this.readsCount += 1;
    } else {
      this.writesCount += 1;
    }
  }
  trackHttpConnectionChange(delta) {
    this.activeHttpConnections = Math.max(0, this.activeHttpConnections + delta);
  }
  trackGrpcConnectionChange(delta) {
    this.activeGrpcConnections = Math.max(0, this.activeGrpcConnections + delta);
  }
  trackLocalConnectionChange(delta) {
    this.activeLocalConnections = Math.max(0, this.activeLocalConnections + delta);
  }
  calculateLatencyStats() {
    if (this.latencySamples.length === 0) {
      return {
        minMs: 0,
        maxMs: 0,
        avgMs: 0,
        p50Ms: 0,
        p95Ms: 0,
        p99Ms: 0
      };
    }
    const sorted = [...this.latencySamples].sort(
      (first, second) => first - second
    );
    const count = sorted.length;
    const sum = sorted.reduce(
      (acc, val) => acc + val,
      0
    );
    const avg = Number((sum / count).toFixed(3));
    const min = sorted[0];
    const max = sorted[count - 1];
    const getPercentile = (pct) => {
      const idx = Math.min(
        count - 1,
        Math.floor(pct / 100 * count)
      );
      return sorted[idx];
    };
    return {
      minMs: min,
      maxMs: max,
      avgMs: avg,
      p50Ms: getPercentile(50),
      p95Ms: getPercentile(95),
      p99Ms: getPercentile(99)
    };
  }
  getMemoryStats() {
    const memoryUsage = import_node_process.default.memoryUsage();
    const toMb = (bytes) => Number((bytes / (1024 * 1024)).toFixed(2));
    return {
      heapUsedMb: toMb(memoryUsage.heapUsed),
      heapTotalMb: toMb(memoryUsage.heapTotal),
      rssMb: toMb(memoryUsage.rss),
      externalMb: toMb(memoryUsage.external),
      systemTotalMb: toMb(import_node_os.default.totalmem()),
      systemFreeMb: toMb(import_node_os.default.freemem())
    };
  }
  getQueriesPerSecond() {
    const now2 = Date.now();
    const cutoff = now2 - 1e3;
    const countInLastSecond = this.recentQueryTimestamps.filter(
      (ts) => ts >= cutoff
    ).length;
    return countInLastSecond;
  }
  getMetrics() {
    const now2 = Date.now();
    const uptimeSeconds = Number(
      ((now2 - this.startTime) / 1e3).toFixed(1)
    );
    const latency = this.calculateLatencyStats();
    const memory = this.getMemoryStats();
    const qps = this.getQueriesPerSecond();
    return {
      uptimeSeconds,
      totalQueries: this.totalQueries,
      readsCount: this.readsCount,
      writesCount: this.writesCount,
      queriesPerSecond: qps,
      latency,
      memory,
      activeConnections: {
        http: this.activeHttpConnections,
        grpc: this.activeGrpcConnections,
        local: this.activeLocalConnections,
        total: this.activeHttpConnections + this.activeGrpcConnections + this.activeLocalConnections
      },
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    };
  }
  resetMetrics() {
    this.totalQueries = 0;
    this.readsCount = 0;
    this.writesCount = 0;
    this.latencySamples.length = 0;
    this.recentQueryTimestamps.length = 0;
  }
};
var lcPerformanceMonitor = LcPerformanceMonitor.getInstance();

// packages/LocalSQLServer/sources/server/http-server.ts
var DEFAULT_HTTP_HOST = process.env.LOCAL_SQL_HOST || "0.0.0.0";
var DEFAULT_HTTP_PORT = Number(process.env.LOCAL_SQL_HTTP_PORT || 3110);
var LocalSqlHttpServer = class {
  server = null;
  config;
  engine;
  constructor(config, customEngine) {
    this.config = {
      host: config?.host || DEFAULT_HTTP_HOST,
      port: config?.port !== void 0 ? config.port : DEFAULT_HTTP_PORT
    };
    this.engine = customEngine || lcLocalDbEngine;
  }
  async start() {
    if (this.server) {
      return;
    }
    this.server = import_node_http.default.createServer(
      async (req, res) => {
        lcPerformanceMonitor.trackHttpConnectionChange(1);
        res.on("finish", () => {
          lcPerformanceMonitor.trackHttpConnectionChange(-1);
        });
        res.setHeader("Access-Control-Allow-Origin", "*");
        res.setHeader(
          "Access-Control-Allow-Methods",
          "GET, POST, PUT, DELETE, OPTIONS"
        );
        res.setHeader(
          "Access-Control-Allow-Headers",
          "Content-Type, Authorization, X-Requested-With"
        );
        if (req.method === "OPTIONS") {
          res.writeHead(204);
          res.end();
          return;
        }
        try {
          await this.handleRequest(req, res);
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : String(error);
          this.sendJson(res, 500, {
            success: false,
            error: errorMessage,
            timestamp: (/* @__PURE__ */ new Date()).toISOString()
          });
        }
      }
    );
    return new Promise((resolve, reject) => {
      this.server?.listen(this.config.port, this.config.host, () => {
        resolve();
      });
      this.server?.on("error", (err) => {
        reject(err);
      });
    });
  }
  async stop() {
    if (!this.server) {
      return;
    }
    return new Promise((resolve) => {
      this.server?.close(() => {
        this.server = null;
        resolve();
      });
    });
  }
  getPort() {
    if (this.server) {
      const addr = this.server.address();
      if (addr && typeof addr === "object") {
        return addr.port;
      }
    }
    return this.config.port;
  }
  getHost() {
    return this.config.host;
  }
  isListening() {
    return this.server !== null && this.server.listening;
  }
  async handleRequest(req, res) {
    const rawUrl = req.url || "/";
    const parsedUrl = new import_node_url.URL(rawUrl, `http://${req.headers.host || "localhost"}`);
    const pathname = parsedUrl.pathname;
    const method = req.method || "GET";
    if ((pathname === "/health" || pathname === "/api/health") && method === "GET") {
      this.sendJson(res, 200, {
        status: "ok",
        service: "LocalSQLServer",
        version: "1.0.0",
        host: this.config.host,
        port: this.config.port,
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      });
      return;
    }
    if ((pathname === "/api/metrics" || pathname === "/api/performance") && method === "GET") {
      const metrics = lcPerformanceMonitor.getMetrics();
      this.sendJson(res, 200, {
        success: true,
        metrics
      });
      return;
    }
    if (pathname === "/api/status" && method === "GET") {
      const targetDbQuery = parsedUrl.searchParams.get("db") || parsedUrl.searchParams.get("database");
      if (targetDbQuery && targetDbQuery !== this.engine.getCurrentDatabase()) {
        this.engine.useDatabase(targetDbQuery);
      }
      const currentDb = this.engine.getCurrentDatabase();
      const tables = this.engine.getTableNames(currentDb);
      const databases = this.engine.listDatabases();
      const metrics = lcPerformanceMonitor.getMetrics();
      this.sendJson(res, 200, {
        success: true,
        service: "LocalSQLServer",
        activeDatabase: currentDb,
        tablesCount: tables.length,
        databasesCount: databases.length,
        databases,
        metrics
      });
      return;
    }
    if (pathname === "/api/databases") {
      if (method === "GET") {
        const databases = this.engine.listDatabases();
        this.sendJson(res, 200, {
          success: true,
          databases,
          current: this.engine.getCurrentDatabase()
        });
        return;
      }
      if (method === "POST") {
        const body = await this.readJsonBody(req);
        const dbName = String(body.name || "").trim();
        if (!dbName) {
          this.sendJson(res, 400, { success: false, error: "Database name is required" });
          return;
        }
        const created = this.engine.createDatabase(dbName);
        this.sendJson(res, 200, { success: created, database: dbName });
        return;
      }
    }
    if (pathname.startsWith("/api/databases/") && method === "DELETE") {
      const targetDb = pathname.replace("/api/databases/", "").trim();
      if (!targetDb) {
        this.sendJson(res, 400, { success: false, error: "Database name is required" });
        return;
      }
      const dropped = this.engine.dropDatabase(targetDb);
      this.sendJson(res, 200, { success: dropped, database: targetDb });
      return;
    }
    if (pathname === "/api/tables" && method === "GET") {
      const targetDbQuery = parsedUrl.searchParams.get("db") || parsedUrl.searchParams.get("database");
      if (targetDbQuery && targetDbQuery !== this.engine.getCurrentDatabase()) {
        this.engine.useDatabase(targetDbQuery);
      }
      const activeDatabaseName = this.engine.getCurrentDatabase();
      const tableNames = this.engine.getTableNames(activeDatabaseName);
      const tablesList = tableNames.map((tblName) => {
        const rawRecords = this.engine.getAll(tblName);
        const rows = rawRecords.map((rec) => {
          return this.unwrapRecord(rec);
        });
        const rawSchema = this.engine.getTableSchema(tblName);
        const { columns } = this.deriveTableColumnsAndSchema(
          tblName,
          rawSchema,
          rows
        );
        return {
          name: tblName,
          rowCount: rows.length,
          columnCount: columns.length,
          columns
        };
      });
      this.sendJson(res, 200, {
        success: true,
        database: activeDatabaseName,
        tables: tablesList
      });
      return;
    }
    if (pathname.startsWith("/api/tables/") && method === "GET") {
      const rawTableName = pathname.replace("/api/tables/", "").trim();
      const targetDbQuery = parsedUrl.searchParams.get("db") || parsedUrl.searchParams.get("database");
      if (targetDbQuery && targetDbQuery !== this.engine.getCurrentDatabase()) {
        this.engine.useDatabase(targetDbQuery);
      }
      const cleanTableName = rawTableName.replace(/[`"']/g, "").trim();
      if (!this.engine.hasTable(cleanTableName) && !this.engine.getTableNames().includes(cleanTableName)) {
        this.sendJson(res, 404, {
          success: false,
          error: `Table '${cleanTableName}' not found in database '${this.engine.getCurrentDatabase()}'`
        });
        return;
      }
      let rows = [];
      let totalRowsCount = 0;
      if (this.engine.isTableLarge(cleanTableName)) {
        const queryRes = await this.engine.streamQueryTable(cleanTableName, { limit: 500 });
        rows = queryRes.records.map((rec) => this.unwrapRecord(rec));
        totalRowsCount = queryRes.stats.totalRecordsScanned;
      } else {
        const rawRecords = this.engine.getAll(cleanTableName);
        rows = rawRecords.map((rec) => {
          return this.unwrapRecord(rec);
        });
        totalRowsCount = rows.length;
      }
      const rawSchema = this.engine.getTableSchema(cleanTableName);
      const { schema } = this.deriveTableColumnsAndSchema(
        cleanTableName,
        rawSchema,
        rows
      );
      this.sendJson(res, 200, {
        success: true,
        database: this.engine.getCurrentDatabase(),
        tableName: cleanTableName,
        table: cleanTableName,
        schema,
        rowsCount: totalRowsCount,
        rowsAffected: rows.length,
        rows: rows.slice(0, 500),
        data: rows.slice(0, 500)
      });
      return;
    }
    if (pathname.startsWith("/api/tables/") && !pathname.endsWith("/delete-rows") && method === "DELETE") {
      const rawTableName = pathname.replace("/api/tables/", "").trim();
      const targetDbQuery = parsedUrl.searchParams.get("db") || parsedUrl.searchParams.get("database");
      if (targetDbQuery && targetDbQuery !== this.engine.getCurrentDatabase()) {
        this.engine.useDatabase(targetDbQuery);
      }
      const cleanTableName = rawTableName.replace(/[`"']/g, "").trim();
      const dropped = this.engine.dropTable(cleanTableName);
      this.sendJson(res, 200, {
        success: dropped,
        database: this.engine.getCurrentDatabase(),
        tableName: cleanTableName,
        dropped
      });
      return;
    }
    if (pathname.startsWith("/api/tables/") && (method === "PUT" || method === "PATCH")) {
      const rawTableName = pathname.replace("/api/tables/", "").trim();
      const targetDbQuery = parsedUrl.searchParams.get("db") || parsedUrl.searchParams.get("database");
      if (targetDbQuery && targetDbQuery !== this.engine.getCurrentDatabase()) {
        this.engine.useDatabase(targetDbQuery);
      }
      const cleanTableName = rawTableName.replace(/[`"']/g, "").trim();
      const body = await this.readJsonBody(req);
      const newName = String(body.newName || body.name || "").trim().replace(/[`"']/g, "");
      if (!newName) {
        this.sendJson(res, 400, { success: false, error: "New table name is required" });
        return;
      }
      const renamed = this.engine.renameTable(cleanTableName, newName);
      this.sendJson(res, 200, {
        success: renamed,
        database: this.engine.getCurrentDatabase(),
        oldName: cleanTableName,
        newName,
        renamed
      });
      return;
    }
    if (pathname.startsWith("/api/tables/") && pathname.endsWith("/delete-rows") && method === "POST") {
      const rawTableName = pathname.replace("/api/tables/", "").replace("/delete-rows", "").trim();
      const targetDbQuery = parsedUrl.searchParams.get("db") || parsedUrl.searchParams.get("database");
      if (targetDbQuery && targetDbQuery !== this.engine.getCurrentDatabase()) {
        this.engine.useDatabase(targetDbQuery);
      }
      const cleanTableName = rawTableName.replace(/[`"']/g, "").trim();
      const body = await this.readJsonBody(req);
      const rawIds = Array.isArray(body.ids) ? body.ids : Array.isArray(body.keys) ? body.keys : Array.isArray(body.rowKeys) ? body.rowKeys : [];
      let deletedCount = 0;
      const targetKeysSet = new Set(rawIds.map((id) => String(id)));
      const rawRecords = this.engine.getAll(cleanTableName);
      for (const rec of rawRecords) {
        const unwrapped = this.unwrapRecord(rec);
        const matches = targetKeysSet.has(rec.key) || unwrapped.id !== void 0 && targetKeysSet.has(String(unwrapped.id)) || unwrapped.key !== void 0 && targetKeysSet.has(String(unwrapped.key));
        if (matches) {
          const deleted = this.engine.delete(cleanTableName, rec.key);
          if (deleted) {
            deletedCount += 1;
          }
        }
      }
      this.sendJson(res, 200, {
        success: true,
        database: this.engine.getCurrentDatabase(),
        tableName: cleanTableName,
        deletedCount
      });
      return;
    }
    if (pathname === "/api/query" && (method === "POST" || method === "GET")) {
      let sqlQueryText = "";
      let targetDb = void 0;
      if (method === "POST") {
        const body = await this.readJsonBody(req);
        sqlQueryText = String(body.sql || body.query || "").trim();
        targetDb = typeof body.database === "string" ? body.database : typeof body.db === "string" ? body.db : void 0;
      } else {
        sqlQueryText = String(parsedUrl.searchParams.get("sql") || parsedUrl.searchParams.get("q") || "").trim();
        const dbParam = parsedUrl.searchParams.get("db") || parsedUrl.searchParams.get("database");
        if (dbParam) {
          targetDb = dbParam.trim();
        }
      }
      if (!sqlQueryText) {
        this.sendJson(res, 400, { success: false, error: "SQL query is required" });
        return;
      }
      if (targetDb && targetDb !== this.engine.getCurrentDatabase()) {
        this.engine.useDatabase(targetDb);
      }
      const startHrTime = process.hrtime.bigint();
      try {
        const queryResult = this.engine.executeSql(sqlQueryText);
        const endHrTime = process.hrtime.bigint();
        const durationMs = Number(endHrTime - startHrTime) / 1e6;
        lcPerformanceMonitor.recordQuery(durationMs, sqlQueryText);
        const rowsAffected = Array.isArray(queryResult) ? queryResult.length : 1;
        let tableSchemaResult = null;
        const selectFromMatch = sqlQueryText.match(
          /^SELECT\s+[\s\S]+?\s+FROM\s+([`"']?[a-zA-Z0-9_.-]+[`"']?)/i
        );
        if (selectFromMatch) {
          const rawTable = selectFromMatch[1].replace(/[`"']/g, "").trim();
          tableSchemaResult = this.engine.getTableSchema(rawTable);
        }
        this.sendJson(res, 200, {
          success: true,
          database: this.engine.getCurrentDatabase(),
          data: queryResult,
          rows: queryResult,
          schema: tableSchemaResult,
          rowsAffected,
          executionTimeMs: Number(durationMs.toFixed(3)),
          timestamp: (/* @__PURE__ */ new Date()).toISOString()
        });
      } catch (queryError) {
        const endHrTime = process.hrtime.bigint();
        const durationMs = Number(endHrTime - startHrTime) / 1e6;
        lcPerformanceMonitor.recordQuery(durationMs, sqlQueryText);
        const errMsg = queryError instanceof Error ? queryError.message : String(queryError);
        this.sendJson(res, 400, {
          success: false,
          error: errMsg,
          executionTimeMs: Number(durationMs.toFixed(3)),
          timestamp: (/* @__PURE__ */ new Date()).toISOString()
        });
      }
      return;
    }
    if (pathname === "/api/cache" || pathname.startsWith("/api/cache/")) {
      if (pathname === "/api/cache" && method === "GET") {
        const items = this.engine.getAllCache();
        this.sendJson(res, 200, {
          success: true,
          database: this.engine.getCurrentDatabase(),
          count: items.length,
          items
        });
        return;
      }
      if (pathname.startsWith("/api/cache/") && method === "GET") {
        const rawKey = pathname.replace("/api/cache/", "").trim();
        const key = decodeURIComponent(rawKey);
        const record = this.engine.getCacheRecord(key);
        if (!record) {
          this.sendJson(res, 404, {
            success: false,
            error: `Cache key '${key}' not found or expired`
          });
          return;
        }
        this.sendJson(res, 200, {
          success: true,
          key,
          value: record.value,
          record
        });
        return;
      }
      if (pathname === "/api/cache" && method === "POST") {
        const body = await this.readJsonBody(req);
        const key = String(body.key || "").trim();
        if (!key) {
          this.sendJson(res, 400, { success: false, error: "Cache key is required" });
          return;
        }
        const ttlMs = typeof body.ttlMs === "number" && body.ttlMs > 0 ? body.ttlMs : void 0;
        const record = this.engine.setCache(key, body.value, ttlMs);
        this.sendJson(res, 200, {
          success: true,
          key,
          record
        });
        return;
      }
      if (pathname.startsWith("/api/cache/") && method === "DELETE") {
        const rawKey = pathname.replace("/api/cache/", "").trim();
        const key = decodeURIComponent(rawKey);
        const deleted = this.engine.deleteCache(key);
        this.sendJson(res, 200, {
          success: true,
          key,
          deleted
        });
        return;
      }
      if (pathname === "/api/cache" && method === "DELETE") {
        const clearedCount = this.engine.clearCache();
        this.sendJson(res, 200, {
          success: true,
          clearedCount
        });
        return;
      }
    }
    if ((pathname === "/api/hydroelectric/status" || pathname === "/api/hydroelectric/config") && method === "GET") {
      const metrics = hydroelectricEngine.getMetrics();
      const config = hydroelectricEngine.getConfig();
      this.sendJson(res, 200, {
        success: true,
        service: "LocalSQLServer",
        engine: "HydroelectricEngine",
        config,
        metrics,
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      });
      return;
    }
    if (pathname === "/api/hydroelectric/read-file" && method === "POST") {
      const body = await this.readJsonBody(req);
      const filePath = String(body.filePath || body.path || "").trim();
      if (!filePath) {
        this.sendJson(res, 400, { success: false, error: "filePath is required" });
        return;
      }
      if (!import_node_fs2.default.existsSync(filePath)) {
        this.sendJson(res, 404, { success: false, error: `File not found: ${filePath}` });
        return;
      }
      const limit = typeof body.limit === "number" && body.limit > 0 ? body.limit : 50;
      const offset = typeof body.offset === "number" && body.offset >= 0 ? body.offset : 0;
      const queryRes = await hydroelectricEngine.streamQuery(filePath, { limit, offset });
      this.sendJson(res, 200, {
        success: true,
        service: "LocalSQLServer",
        engine: "HydroelectricEngine",
        stats: queryRes.stats,
        sampleRecords: queryRes.records.slice(0, 10),
        recordsCount: queryRes.records.length,
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      });
      return;
    }
    if (pathname.startsWith("/api/stream/tables/") && method === "GET") {
      const rawTableName = pathname.replace("/api/stream/tables/", "").trim();
      const targetDbQuery = parsedUrl.searchParams.get("db") || parsedUrl.searchParams.get("database");
      if (targetDbQuery && targetDbQuery !== this.engine.getCurrentDatabase()) {
        this.engine.useDatabase(targetDbQuery);
      }
      const cleanTableName = rawTableName.replace(/[`"']/g, "").trim();
      const format = parsedUrl.searchParams.get("format") === "ndjson" ? "ndjson" : "json";
      const limit = parseInt(parsedUrl.searchParams.get("limit") || "1000", 10);
      const offset = parseInt(parsedUrl.searchParams.get("offset") || "0", 10);
      res.writeHead(200, {
        "Content-Type": format === "ndjson" ? "application/x-ndjson; charset=utf-8" : "application/json; charset=utf-8",
        "Transfer-Encoding": "chunked",
        "X-Hydroelectric-Stream": "true"
      });
      await this.engine.streamPipeTableToHttp(cleanTableName, res, { format, limit, offset });
      return;
    }
    if (pathname === "/api/stream/query" && method === "POST") {
      const body = await this.readJsonBody(req);
      const tableName = String(body.table || body.tableName || "").replace(/[`"']/g, "").trim();
      const targetDb = typeof body.db === "string" ? body.db : typeof body.database === "string" ? body.database : void 0;
      if (!tableName) {
        this.sendJson(res, 400, { success: false, error: "table name is required for streaming query" });
        return;
      }
      if (targetDb && targetDb !== this.engine.getCurrentDatabase()) {
        this.engine.useDatabase(targetDb);
      }
      const limit = typeof body.limit === "number" && body.limit > 0 ? body.limit : 500;
      const offset = typeof body.offset === "number" && body.offset >= 0 ? body.offset : 0;
      const whereFilter = (rec) => {
        if (!body.where || typeof body.where !== "object") return true;
        const unwrapped = this.unwrapRecord(rec);
        const whereObj = body.where;
        for (const [k, v] of Object.entries(whereObj)) {
          if (unwrapped[k] !== v) return false;
        }
        return true;
      };
      const result = await this.engine.streamQueryTable(tableName, {
        where: whereFilter,
        limit,
        offset
      });
      this.sendJson(res, 200, {
        success: true,
        database: this.engine.getCurrentDatabase(),
        tableName,
        rowsAffected: result.records.length,
        rows: result.records.map((r) => this.unwrapRecord(r)),
        stats: result.stats,
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      });
      return;
    }
    this.sendJson(res, 404, {
      success: false,
      error: `Endpoint not found: ${method} ${pathname}`,
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    });
  }
  sendJson(res, statusCode, payload) {
    const jsonString = JSON.stringify(payload);
    res.writeHead(statusCode, {
      "Content-Type": "application/json; charset=utf-8",
      "Content-Length": Buffer.byteLength(jsonString)
    });
    res.end(jsonString);
  }
  async readJsonBody(req) {
    return new Promise(
      (resolve, reject) => {
        const chunks = [];
        req.on("data", (chunk) => {
          chunks.push(chunk);
        });
        req.on("end", () => {
          try {
            const bodyString = Buffer.concat(chunks).toString("utf8");
            if (!bodyString.trim()) {
              resolve({});
              return;
            }
            const parsed = JSON.parse(bodyString);
            if (typeof parsed === "object" && parsed !== null) {
              resolve(parsed);
            } else {
              resolve({});
            }
          } catch (err) {
            reject(new Error(`Invalid JSON body: ${String(err)}`));
          }
        });
        req.on("error", (err) => {
          reject(err);
        });
      }
    );
  }
  unwrapRecord(rec) {
    if (!rec || typeof rec !== "object") {
      return { value: rec };
    }
    let parsedValue = rec.value;
    if (typeof rec.value === "string" && (rec.value.trim().startsWith("{") || rec.value.trim().startsWith("["))) {
      try {
        parsedValue = JSON.parse(rec.value);
      } catch {
        parsedValue = rec.value;
      }
    }
    if (parsedValue && typeof parsedValue === "object" && !Array.isArray(parsedValue)) {
      const rowVal = { ...parsedValue };
      if (rowVal.id === void 0 && rec.key !== void 0) {
        rowVal.id = rec.key;
      }
      return rowVal;
    }
    return { id: rec.key, value: parsedValue ?? rec.value };
  }
  deriveTableColumnsAndSchema(tableName, rawSchema, rows) {
    const genericStorageSet = /* @__PURE__ */ new Set([
      "key",
      "value",
      "namespace",
      "createdAt",
      "updatedAt",
      "ttlMs",
      "version",
      "tags"
    ]);
    let schemaCols = [];
    if (rawSchema && typeof rawSchema === "object" && "columns" in rawSchema) {
      const colsObj = rawSchema.columns || {};
      schemaCols = Object.keys(colsObj);
    }
    const isGeneric = schemaCols.length > 0 && schemaCols.every((c) => genericStorageSet.has(c));
    if (schemaCols.length > 0 && !isGeneric) {
      return { columns: schemaCols, schema: rawSchema };
    }
    if (rows.length > 0) {
      const keysSet = /* @__PURE__ */ new Set();
      const derivedColDefs = {};
      for (const row of rows.slice(0, 100)) {
        for (const [k, v] of Object.entries(row)) {
          keysSet.add(k);
          if (!derivedColDefs[k]) {
            let colType = "VARCHAR";
            if (typeof v === "number") {
              colType = Number.isInteger(v) ? "INTEGER" : "REAL";
            } else if (typeof v === "boolean") {
              colType = "BOOLEAN";
            } else if (typeof v === "object" && v !== null) {
              colType = "JSON";
            }
            derivedColDefs[k] = {
              type: colType,
              primaryKey: k === "id" || k === "key",
              nullable: v === null || v === void 0
            };
          }
        }
      }
      const allKeys = Array.from(keysSet);
      const idKeys = allKeys.filter((k) => k === "id" || k === "key" || k === "_id");
      const metaKeys = allKeys.filter((k) => genericStorageSet.has(k));
      const domainKeys = allKeys.filter(
        (k) => !idKeys.includes(k) && !metaKeys.includes(k)
      );
      const sortedCols = [...idKeys, ...domainKeys, ...metaKeys];
      return {
        columns: sortedCols,
        schema: {
          tableName,
          columns: derivedColDefs
        }
      };
    }
    return {
      columns: schemaCols,
      schema: rawSchema || { tableName, columns: {} }
    };
  }
};

// packages/LocalSQLServer/sources/server/grpc-server.ts
var import_node_fs3 = __toESM(require("node:fs"));
var import_node_path = __toESM(require("node:path"));
var import_node_process2 = __toESM(require("node:process"));
var grpc = null;
var protoLoader = null;
try {
  const dynamicRequire = eval("require");
  grpc = dynamicRequire("@grpc/grpc-js");
  protoLoader = dynamicRequire("@grpc/proto-loader");
} catch {
}
var DEFAULT_GRPC_HOST = import_node_process2.default.env.LOCAL_SQL_GRPC_HOST || "0.0.0.0";
var DEFAULT_GRPC_PORT = Number(import_node_process2.default.env.LOCAL_SQL_GRPC_PORT || 50055);
var LocalSqlGrpcServer = class {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  server = null;
  config;
  engine;
  isRunning = false;
  constructor(config, customEngine) {
    this.config = {
      host: config?.host || DEFAULT_GRPC_HOST,
      port: config?.port || DEFAULT_GRPC_PORT
    };
    this.engine = customEngine || lcLocalDbEngine;
  }
  resolveProtoFilePath() {
    const candidatePaths = [
      import_node_path.default.resolve(__dirname, "../../proto/local_sql.proto"),
      import_node_path.default.resolve(import_node_process2.default.cwd(), "proto/local_sql.proto"),
      import_node_path.default.resolve(import_node_process2.default.cwd(), "packages/LocalSQLServer/proto/local_sql.proto")
    ];
    for (const cand of candidatePaths) {
      if (import_node_fs3.default.existsSync(cand)) {
        return cand;
      }
    }
    return candidatePaths[0];
  }
  async start() {
    if (this.isRunning && this.server) {
      return this.config.port;
    }
    if (!grpc || !protoLoader) {
      console.warn("[LocalSQLServer] Optional @grpc/grpc-js not available. gRPC server disabled.");
      return this.config.port;
    }
    const protoPath = this.resolveProtoFilePath();
    if (!import_node_fs3.default.existsSync(protoPath)) {
      throw new Error(`Proto file not found at: ${protoPath}`);
    }
    const packageDefinition = protoLoader.loadSync(
      protoPath,
      {
        keepCase: true,
        longs: String,
        enums: String,
        defaults: true,
        oneofs: true
      }
    );
    const protoDescriptor = grpc.loadPackageDefinition(packageDefinition);
    const vtekPackage = protoDescriptor.vtek;
    const localsqlPackage = vtekPackage?.localsql;
    const grpcPackage = localsqlPackage?.grpc;
    if (!grpcPackage || !grpcPackage.LocalSqlService) {
      throw new Error("LocalSqlService not found in loaded protobuf descriptor");
    }
    const serviceConstructor = grpcPackage.LocalSqlService;
    this.server = new grpc.Server();
    this.server.addService(serviceConstructor.service, {
      ExecuteSql: this.handleExecuteSql.bind(this),
      GetTables: this.handleGetTables.bind(this),
      GetTableSchema: this.handleGetTableSchema.bind(this),
      GetPerformanceMetrics: this.handleGetPerformanceMetrics.bind(this),
      Ping: this.handlePing.bind(this)
    });
    const bindAddress = `${this.config.host}:${this.config.port}`;
    return new Promise((resolve, reject) => {
      this.server?.bindAsync(
        bindAddress,
        grpc.ServerCredentials.createInsecure(),
        (bindError, boundPort) => {
          if (bindError) {
            reject(bindError);
            return;
          }
          if (boundPort === 0) {
            reject(new Error(`Failed to bind LocalSqlService on ${bindAddress}: Port already in use`));
            return;
          }
          this.isRunning = true;
          resolve(boundPort);
        }
      );
    });
  }
  async stop() {
    if (!this.server || !this.isRunning) {
      return;
    }
    return new Promise((resolve) => {
      this.server?.tryShutdown(() => {
        this.isRunning = false;
        this.server = null;
        resolve();
      });
    });
  }
  isServerRunning() {
    return this.isRunning;
  }
  getPort() {
    return this.config.port;
  }
  handleExecuteSql(call, callback) {
    lcPerformanceMonitor.trackGrpcConnectionChange(1);
    const sqlText = String(call.request.query || "").trim();
    const targetDb = call.request.database?.trim();
    if (!sqlText) {
      lcPerformanceMonitor.trackGrpcConnectionChange(-1);
      callback(null, {
        success: false,
        data_json: "[]",
        rows_affected: 0,
        execution_time_ms: 0,
        error_message: "Query cannot be empty",
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      });
      return;
    }
    if (targetDb && targetDb !== this.engine.getCurrentDatabase()) {
      this.engine.useDatabase(targetDb);
    }
    const startHr = import_node_process2.default.hrtime.bigint();
    try {
      const result = this.engine.executeSql(sqlText);
      const endHr = import_node_process2.default.hrtime.bigint();
      const durationMs = Number(endHr - startHr) / 1e6;
      lcPerformanceMonitor.recordQuery(durationMs, sqlText);
      lcPerformanceMonitor.trackGrpcConnectionChange(-1);
      const rowsCount = Array.isArray(result) ? result.length : 1;
      callback(null, {
        success: true,
        data_json: JSON.stringify(result),
        rows_affected: rowsCount,
        execution_time_ms: Number(durationMs.toFixed(3)),
        error_message: "",
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      });
    } catch (err) {
      const endHr = import_node_process2.default.hrtime.bigint();
      const durationMs = Number(endHr - startHr) / 1e6;
      lcPerformanceMonitor.recordQuery(durationMs, sqlText);
      lcPerformanceMonitor.trackGrpcConnectionChange(-1);
      const message = err instanceof Error ? err.message : String(err);
      callback(null, {
        success: false,
        data_json: "[]",
        rows_affected: 0,
        execution_time_ms: Number(durationMs.toFixed(3)),
        error_message: message,
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      });
    }
  }
  handleGetTables(call, callback) {
    const targetDb = call.request.database?.trim() || this.engine.getCurrentDatabase();
    if (targetDb !== this.engine.getCurrentDatabase()) {
      this.engine.useDatabase(targetDb);
    }
    try {
      const tableNames = this.engine.getTableNames();
      const tablesList = tableNames.map((name) => {
        const rows = this.engine.getAll(name);
        const schema = this.engine.getTableSchema(name);
        const colCount = schema && typeof schema === "object" && "columns" in schema ? Object.keys(schema.columns || {}).length : rows.length > 0 && typeof rows[0] === "object" && rows[0] !== null ? Object.keys(rows[0]).length : 0;
        return {
          name,
          row_count: rows.length,
          column_count: colCount,
          size_bytes: JSON.stringify(rows).length,
          database: targetDb
        };
      });
      callback(null, {
        success: true,
        tables: tablesList,
        database: targetDb,
        error_message: ""
      });
    } catch (err) {
      callback(null, {
        success: false,
        tables: [],
        database: targetDb,
        error_message: err instanceof Error ? err.message : String(err)
      });
    }
  }
  handleGetTableSchema(call, callback) {
    const tableName = String(call.request.table_name || "").trim();
    const targetDb = call.request.database?.trim() || this.engine.getCurrentDatabase();
    if (!tableName) {
      callback(null, {
        success: false,
        table_name: "",
        database: targetDb,
        columns: [],
        error_message: "Table name is required"
      });
      return;
    }
    try {
      const schema = this.engine.getTableSchema(tableName);
      const columnsList = [];
      if (schema && typeof schema === "object" && "columns" in schema) {
        const cols = schema.columns || {};
        for (const [colName, colDef] of Object.entries(cols)) {
          columnsList.push({
            name: colName,
            data_type: colDef?.type || "TEXT",
            is_primary_key: Boolean(colDef?.primaryKey),
            is_nullable: Boolean(colDef?.nullable ?? true),
            default_value: colDef?.defaultValue !== void 0 ? String(colDef.defaultValue) : ""
          });
        }
      }
      callback(null, {
        success: true,
        table_name: tableName,
        database: targetDb,
        columns: columnsList,
        error_message: ""
      });
    } catch (err) {
      callback(null, {
        success: false,
        table_name: tableName,
        database: targetDb,
        columns: [],
        error_message: err instanceof Error ? err.message : String(err)
      });
    }
  }
  handleGetPerformanceMetrics(_call, callback) {
    const metrics = lcPerformanceMonitor.getMetrics();
    callback(null, {
      success: true,
      uptime_seconds: metrics.uptimeSeconds,
      total_queries: metrics.totalQueries,
      reads_count: metrics.readsCount,
      writes_count: metrics.writesCount,
      queries_per_second: metrics.queriesPerSecond,
      latency: {
        min_ms: metrics.latency.minMs,
        max_ms: metrics.latency.maxMs,
        avg_ms: metrics.latency.avgMs,
        p50_ms: metrics.latency.p50Ms,
        p95_ms: metrics.latency.p95Ms,
        p99_ms: metrics.latency.p99Ms
      },
      memory: {
        heap_used_mb: metrics.memory.heapUsedMb,
        heap_total_mb: metrics.memory.heapTotalMb,
        rss_mb: metrics.memory.rssMb,
        external_mb: metrics.memory.externalMb
      },
      timestamp: metrics.timestamp
    });
  }
  handlePing(call, callback) {
    const message = call.request.message || "ping";
    callback(null, {
      success: true,
      reply: `pong: ${message}`,
      version: "1.0.0",
      timestamp_ms: Date.now()
    });
  }
};

// packages/LocalSQLServer/server.ts
var candidateNodeModulesPaths = [
  import_node_path2.default.join(__dirname, "node_modules"),
  import_node_path2.default.join(__dirname, "..", "node_modules"),
  import_node_path2.default.join(__dirname, "..", "..", "node_modules"),
  import_node_path2.default.join(__dirname, "..", "..", "..", "node_modules"),
  import_node_path2.default.join(process.cwd(), "node_modules"),
  process.env.WORKSPACE_ROOT ? import_node_path2.default.join(process.env.WORKSPACE_ROOT, "node_modules") : null
].filter((p) => typeof p === "string" && p.length > 0 && import_node_fs4.default.existsSync(p));
if (candidateNodeModulesPaths.length > 0) {
  process.env.NODE_PATH = candidateNodeModulesPaths.join(import_node_path2.default.delimiter);
  if (typeof import_node_module.default._initPaths === "function") {
    import_node_module.default._initPaths();
  }
}
var activeServers = null;
async function startLocalSqlServer(options) {
  if (activeServers) {
    return activeServers;
  }
  lcLocalDbEngine.init();
  const httpServer = new LocalSqlHttpServer({
    host: options?.httpHost || DEFAULT_HTTP_HOST,
    port: options?.httpPort || DEFAULT_HTTP_PORT
  });
  await httpServer.start();
  const grpcServer = new LocalSqlGrpcServer({
    host: options?.grpcHost || DEFAULT_GRPC_HOST,
    port: options?.grpcPort || DEFAULT_GRPC_PORT
  });
  try {
    await grpcServer.start();
  } catch (grpcErr) {
    console.warn(`[LocalSQLServer] gRPC server warning: ${String(grpcErr)}`);
  }
  activeServers = { httpServer, grpcServer };
  console.log(
    `[LocalSQLServer] Started successfully:
  - Local/LAN HTTP: http://${httpServer.getHost()}:${httpServer.getPort()}
  - gRPC Service:  ${grpcServer.getPort()}
  - Active DB:     ${lcLocalDbEngine.getCurrentDatabase()}`
  );
  return activeServers;
}
async function stopLocalSqlServer() {
  if (!activeServers) {
    return;
  }
  try {
    await activeServers.httpServer.stop();
  } catch {
  }
  try {
    await activeServers.grpcServer.stop();
  } catch {
  }
  activeServers = null;
  console.log("[LocalSQLServer] Stopped successfully.");
}
async function runCli(argv = process.argv.slice(2)) {
  let httpPort = DEFAULT_HTTP_PORT;
  let httpHost = DEFAULT_HTTP_HOST;
  let grpcPort = DEFAULT_GRPC_PORT;
  let targetDatabase = "default";
  let outputJson = false;
  let command = "start";
  let sqlText = "";
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (arg === "--help" || arg === "-h" || arg === "help") {
      printHelp();
      return;
    }
    if (arg === "--version" || arg === "-v" || arg === "version") {
      console.log("LocalSQLServer v1.0.2");
      return;
    }
    if (arg === "--json") {
      outputJson = true;
      continue;
    }
    if (arg === "--port" || arg === "-p") {
      const nextArg = argv[++i];
      if (nextArg) {
        httpPort = parseInt(nextArg, 10);
      }
      continue;
    }
    if (arg.startsWith("--port=")) {
      httpPort = parseInt(arg.split("=")[1], 10);
      continue;
    }
    if (arg === "--host") {
      const nextArg = argv[++i];
      if (nextArg) {
        httpHost = nextArg;
      }
      continue;
    }
    if (arg === "--grpc-port") {
      const nextArg = argv[++i];
      if (nextArg) {
        grpcPort = parseInt(nextArg, 10);
      }
      continue;
    }
    if (arg === "--db") {
      const nextArg = argv[++i];
      if (nextArg) {
        targetDatabase = nextArg;
      }
      continue;
    }
    if (!arg.startsWith("-")) {
      if (command === "start" && (arg === "status" || arg === "query" || arg === "tables" || arg === "databases" || arg === "hydroelectric" || arg === "stream" || arg === "start")) {
        command = arg;
      } else if (command === "query" && !sqlText) {
        sqlText = arg;
      }
    }
  }
  const effectiveHost = httpHost === "0.0.0.0" ? "127.0.0.1" : httpHost;
  const baseUrl = `http://${effectiveHost}:${httpPort}`;
  if (command === "status") {
    try {
      const response = await fetch(`${baseUrl}/api/status`, { signal: AbortSignal.timeout(2e3) });
      if (response.ok) {
        const data = await response.json();
        if (outputJson) {
          console.log(JSON.stringify(data, null, 2));
        } else {
          const statusObj = data;
          console.log(`[LocalSQLServer] Status: ONLINE`);
          console.log(`  - URL:             ${baseUrl}`);
          console.log(`  - Active Database: ${statusObj.activeDatabase || "default"}`);
          console.log(`  - Databases Count: ${statusObj.databasesCount ?? 0}`);
          console.log(`  - Tables Count:    ${statusObj.tablesCount ?? 0}`);
          if (statusObj.metrics) {
            console.log(`  - Uptime:          ${statusObj.metrics.uptimeSeconds ?? 0}s`);
            console.log(`  - Total Queries:   ${statusObj.metrics.totalQueries ?? 0}`);
            const memMb = ((statusObj.metrics.memoryHeapUsedBytes || 0) / 1024 / 1024).toFixed(1);
            console.log(`  - Memory Used:     ${memMb} MB`);
          }
        }
        return;
      }
    } catch {
    }
    lcLocalDbEngine.init();
    if (outputJson) {
      console.log(JSON.stringify({ status: "offline", activeDatabase: lcLocalDbEngine.getCurrentDatabase(), databases: lcLocalDbEngine.listDatabases() }, null, 2));
    } else {
      console.log(`[LocalSQLServer] Status: OFFLINE (HTTP server not reachable on ${baseUrl})`);
      console.log(`  - Active Database:   ${lcLocalDbEngine.getCurrentDatabase()}`);
      console.log(`  - Local Databases:   ${lcLocalDbEngine.listDatabases().join(", ") || "(none)"}`);
    }
    return;
  }
  if (command === "tables") {
    try {
      const response = await fetch(`${baseUrl}/api/tables?db=${targetDatabase}`, { signal: AbortSignal.timeout(2e3) });
      if (response.ok) {
        const data = await response.json();
        if (outputJson) {
          console.log(JSON.stringify(data, null, 2));
        } else {
          const result = data;
          console.log(`[LocalSQLServer] Tables in '${targetDatabase}':`);
          if (result.tables && result.tables.length > 0) {
            for (const tbl of result.tables) {
              console.log(`  \u2022 ${tbl.name} (${tbl.rowCount} rows)`);
            }
          } else {
            console.log("  (no tables found)");
          }
        }
        return;
      }
    } catch {
    }
    lcLocalDbEngine.init();
    lcLocalDbEngine.useDatabase(targetDatabase);
    const tableNames = lcLocalDbEngine.getTableNames();
    if (outputJson) {
      console.log(JSON.stringify({ database: targetDatabase, tables: tableNames }, null, 2));
    } else {
      console.log(`[LocalSQLServer] Tables in '${targetDatabase}' (in-process):`);
      if (tableNames.length > 0) {
        for (const name of tableNames) {
          console.log(`  \u2022 ${name}`);
        }
      } else {
        console.log("  (no tables found)");
      }
    }
    return;
  }
  if (command === "databases") {
    try {
      const response = await fetch(`${baseUrl}/api/databases`, { signal: AbortSignal.timeout(2e3) });
      if (response.ok) {
        const data = await response.json();
        if (outputJson) {
          console.log(JSON.stringify(data, null, 2));
        } else {
          const result = data;
          console.log(`[LocalSQLServer] Databases:`);
          for (const db of result.databases || []) {
            const isCurrent = db === result.current;
            console.log(`  ${isCurrent ? "\u2794" : " "} ${db}${isCurrent ? " (active)" : ""}`);
          }
        }
        return;
      }
    } catch {
    }
    lcLocalDbEngine.init();
    const dbs = lcLocalDbEngine.listDatabases();
    const currentDb = lcLocalDbEngine.getCurrentDatabase();
    if (outputJson) {
      console.log(JSON.stringify({ databases: dbs, current: currentDb }, null, 2));
    } else {
      console.log(`[LocalSQLServer] Databases (in-process):`);
      for (const db of dbs) {
        const isCurrent = db === currentDb;
        console.log(`  ${isCurrent ? "\u2794" : " "} ${db}${isCurrent ? " (active)" : ""}`);
      }
    }
    return;
  }
  if (command === "query") {
    if (!sqlText) {
      console.error("Error: SQL query text is required. Example: localsqlserver query 'SELECT 1'");
      process.exitCode = 1;
      return;
    }
    try {
      const response = await fetch(`${baseUrl}/api/query`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sql: sqlText, database: targetDatabase }),
        signal: AbortSignal.timeout(5e3)
      });
      if (response.ok) {
        const data = await response.json();
        if (outputJson) {
          console.log(JSON.stringify(data, null, 2));
        } else {
          const resObj = data;
          if (resObj.success) {
            console.log(`[LocalSQLServer] Query executed in ${resObj.executionTimeMs?.toFixed(2) || 0}ms (${resObj.rowCount || 0} rows):`);
            console.log(JSON.stringify(resObj.rows || [], null, 2));
          } else {
            console.error(`[LocalSQLServer] Query error: ${resObj.error || "Unknown error"}`);
            process.exitCode = 1;
          }
        }
        return;
      }
    } catch {
    }
    lcLocalDbEngine.init();
    lcLocalDbEngine.useDatabase(targetDatabase);
    try {
      const startTime = Date.now();
      const rows = lcLocalDbEngine.query(sqlText);
      const elapsedMs = Date.now() - startTime;
      if (outputJson) {
        console.log(JSON.stringify({ success: true, database: targetDatabase, rowCount: rows.length, rows, executionTimeMs: elapsedMs }, null, 2));
      } else {
        console.log(`[LocalSQLServer] In-process query executed in ${elapsedMs}ms (${rows.length} rows):`);
        console.log(JSON.stringify(rows, null, 2));
      }
    } catch (queryErr) {
      const errorMsg = queryErr instanceof Error ? queryErr.message : String(queryErr);
      console.error(`[LocalSQLServer] In-process query error: ${errorMsg}`);
      process.exitCode = 1;
    }
    return;
  }
  if (command === "hydroelectric" || command === "stream") {
    try {
      const response = await fetch(`${baseUrl}/api/hydroelectric/status`, { signal: AbortSignal.timeout(2e3) });
      if (response.ok) {
        const data = await response.json();
        if (outputJson) {
          console.log(JSON.stringify(data, null, 2));
        } else {
          const resObj = data;
          console.log(`[LocalSQLServer] HydroelectricEngine: ACTIVE`);
          console.log(`  - Mode:               ${resObj.config?.mode || "STREAMING_PIPELINE"}`);
          console.log(`  - Time Complexity:    ${resObj.config?.timeComplexity || "O(n)"}`);
          console.log(`  - Space Complexity:   ${resObj.config?.spaceComplexity || "O(1)"}`);
          console.log(`  - Large File Barrier: ${(Number(resObj.config?.largeFileThresholdBytes || 0) / 1024 / 1024).toFixed(0)} MB (> 10 GB safe streaming)`);
          console.log(`  - Total Streams:      ${resObj.metrics?.totalStreamsExecuted || 0}`);
          console.log(`  - Total Streamed:     ${resObj.metrics?.totalGigabytesStreamed || 0} GB`);
          console.log(`  - Heap Usage:         ${resObj.metrics?.currentHeapUsedMb || 0} MB`);
        }
        return;
      }
    } catch {
    }
    const metrics = hydroelectricEngine.getMetrics();
    const config = hydroelectricEngine.getConfig();
    if (outputJson) {
      console.log(JSON.stringify({ config, metrics }, null, 2));
    } else {
      console.log(`[LocalSQLServer] HydroelectricEngine (Local In-Process): ACTIVE`);
      console.log(`  - Mode:               ${config.mode}`);
      console.log(`  - Time Complexity:    ${config.timeComplexity}`);
      console.log(`  - Space Complexity:   ${config.spaceComplexity}`);
      console.log(`  - Large File Barrier: ${(config.largeFileThresholdBytes / 1024 / 1024).toFixed(0)} MB (> 10 GB safe streaming)`);
      console.log(`  - Total Streams:      ${metrics.totalStreamsExecuted}`);
      console.log(`  - Total Streamed:     ${metrics.totalGigabytesStreamed} GB`);
      console.log(`  - Heap Usage:         ${metrics.currentHeapUsedMb} MB`);
    }
    return;
  }
  await startLocalSqlServer({
    httpHost,
    httpPort,
    grpcHost: "0.0.0.0",
    grpcPort
  });
  const handleShutdown = async () => {
    await stopLocalSqlServer();
    process.exit(0);
  };
  process.on("SIGINT", handleShutdown);
  process.on("SIGTERM", handleShutdown);
}
function printHelp() {
  console.log(`
LocalSQLServer \u2014 High-performance Local & LAN Database Engine

Usage:
  localsqlserver [command] [options]

Commands:
  start                  Start HTTP REST and gRPC servers (default)
  status                 Check server status and connectivity
  query <sql>            Execute SQL query on database
  tables                 List tables in active database
  databases              List available databases
  hydroelectric, stream  Inspect Hydroelectric streaming engine status & metrics
  version, -v            Show version information
  help, -h               Show this help message

Options:
  --port, -p <port>      HTTP port (default: 3110)
  --host <host>          HTTP host (default: 0.0.0.0)
  --grpc-port <port>     gRPC port (default: 50055)
  --db <name>            Database name (default: default)
  --json                 Output raw JSON
`);
}
var isDirectRun = typeof require !== "undefined" ? require.main === module : process.argv[1]?.endsWith("server.ts") || process.argv[1]?.endsWith("server.js") || false;
if (isDirectRun) {
  runCli().catch((err) => {
    console.error("[LocalSQLServer] Fatal CLI error:", err);
    process.exit(1);
  });
  process.on("uncaughtException", (err) => {
    console.error("[LocalSQLServer] Uncaught exception:", err);
  });
  process.on("unhandledRejection", (reason) => {
    console.error("[LocalSQLServer] Unhandled rejection:", reason);
  });
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  runCli,
  startLocalSqlServer,
  stopLocalSqlServer
});
