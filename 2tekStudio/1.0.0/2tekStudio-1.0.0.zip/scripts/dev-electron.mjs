/**
 * packages/2tekStudio/scripts/dev-electron.mjs
 * ─────────────────────────────────────────────────────────────────────────────
 * 2-TEK Studio — Dev Runner with Native Electron Window
 * Starts Next.js dev server on port 3038, waits for HTTP readiness,
 * and launches the Electron desktop application window.
 * ─────────────────────────────────────────────────────────────────────────────
 */

import http from "node:http";
import { spawn } from "node:child_process";
import * as path from "node:path";
import * as fs from "node:fs";
import { fileURLToPath } from "node:url";

const currentModulePath = fileURLToPath(import.meta.url);
const currentModuleDir = path.dirname(currentModulePath);
const appDirectory = path.resolve(currentModuleDir, "..");
const workspaceRootDirectory = path.resolve(appDirectory, "..", "..");

function resolvePortFromEnv() {
  try {
    if (typeof process !== "undefined" && process.env) {
      if (process.env.PORT) {
        const parsed = parseInt(process.env.PORT, 10);
        if (!Number.isNaN(parsed) && parsed > 0) return parsed;
      }
      if (process.env.STUDIO_PORT) {
        const parsed = parseInt(process.env.STUDIO_PORT, 10);
        if (!Number.isNaN(parsed) && parsed > 0) return parsed;
      }
    }
  } catch {
    // Ignore
  }
  return 3038;
}

const TARGET_PORT = resolvePortFromEnv();
const DEV_SERVER_URL = `http://localhost:${TARGET_PORT}`;
const DEV_FALLBACK_URL = `http://127.0.0.1:${TARGET_PORT}`;
const MAXIMUM_POLL_ATTEMPTS = 60;
const POLL_INTERVAL_MS = 500;

let nextServerProcess = null;
let electronChildProcess = null;
let isCleanExit = false;

function checkServerReady(targetUrl = DEV_SERVER_URL) {
  return new Promise((resolve) => {
    const req = http.get(targetUrl, (res) => {
      resolve(true);
      res.resume();
    });

    req.on("error", () => {
      if (targetUrl.includes("localhost:")) {
        const fallbackReq = http.get(DEV_FALLBACK_URL, (res) => {
          resolve(true);
          res.resume();
        });
        fallbackReq.on("error", () => resolve(false));
        fallbackReq.setTimeout(800, () => {
          fallbackReq.destroy();
          resolve(false);
        });
      } else {
        resolve(false);
      }
    });

    req.setTimeout(800, () => {
      req.destroy();
      resolve(false);
    });
  });
}

async function waitForServer(targetUrl = DEV_SERVER_URL) {
  console.log(`[2tekStudio Runner] Waiting for dev server at ${targetUrl}...`);
  for (let attempt = 1; attempt <= MAXIMUM_POLL_ATTEMPTS; attempt++) {
    const isReady = await checkServerReady(targetUrl);
    if (isReady) {
      console.log(`[2tekStudio Runner] Dev server is ready at ${targetUrl} (attempt ${attempt})`);
      return true;
    }
    await new Promise((resolve) => setTimeout(resolve, POLL_INTERVAL_MS));
  }
  console.warn(`[2tekStudio Runner] Server did not respond within timeout, launching Electron anyway.`);
  return false;
}

function resolveElectronBinary() {
  const isWindows = process.platform === "win32";
  const binaryName = isWindows ? "electron.exe" : "electron";
  const cmdName = isWindows ? "electron.cmd" : "electron";

  const candidates = [
    path.join(appDirectory, "node_modules", "electron", "dist", binaryName),
    path.join(workspaceRootDirectory, "node_modules", "electron", "dist", binaryName),
    path.join(appDirectory, "node_modules", ".bin", cmdName),
    path.join(workspaceRootDirectory, "node_modules", ".bin", cmdName),
  ];

  for (const candidate of candidates) {
    if (fs.existsSync(candidate)) {
      return candidate;
    }
  }

  return isWindows ? "electron.cmd" : "electron";
}

function cleanupProcesses() {
  if (isCleanExit) return;
  isCleanExit = true;

  if (electronChildProcess && !electronChildProcess.killed) {
    try {
      electronChildProcess.kill("SIGTERM");
    } catch {
      // Ignore
    }
  }

  if (nextServerProcess && !nextServerProcess.killed) {
    try {
      console.log("[2tekStudio Runner] Stopping Next.js dev server...");
      nextServerProcess.kill("SIGTERM");
    } catch {
      // Ignore
    }
  }
}

async function startDevElectron() {
  const alreadyRunning = await checkServerReady(DEV_SERVER_URL);

  if (alreadyRunning) {
    console.log(`[2tekStudio Runner] Existing dev server detected at ${DEV_SERVER_URL}. Reusing it.`);
  } else {
    console.log(`[2tekStudio Runner] Starting Next.js dev server on port ${TARGET_PORT}...`);
    nextServerProcess = spawn("npx", ["next", "dev", "-p", String(TARGET_PORT)], {
      cwd: appDirectory,
      stdio: "inherit",
      shell: true,
      env: {
        ...process.env,
        PORT: String(TARGET_PORT),
      },
    });

    nextServerProcess.on("error", (err) => {
      console.error("[2tekStudio Runner] Next.js dev server error:", err);
    });

    nextServerProcess.on("exit", (code) => {
      if (!isCleanExit) {
        console.log(`[2tekStudio Runner] Next.js server exited with code ${code}`);
        cleanupProcesses();
        process.exit(code ?? 0);
      }
    });

    await waitForServer(DEV_SERVER_URL);
  }

  const electronBin = resolveElectronBinary();
  const electronMainScript = path.join(appDirectory, "electron", "main.js");

  console.log(`[2tekStudio Runner] Launching Electron window with ${electronBin}...`);
  electronChildProcess = spawn(electronBin, [electronMainScript], {
    cwd: appDirectory,
    stdio: "inherit",
    shell: false,
    env: {
      ...process.env,
      ELECTRON_IS_DEV: "1",
      DEV_URL: DEV_SERVER_URL,
      PORT: String(TARGET_PORT),
    },
  });

  electronChildProcess.on("error", (err) => {
    console.error("[2tekStudio Runner] Electron launch error:", err);
    cleanupProcesses();
    process.exit(1);
  });

  electronChildProcess.on("exit", (code) => {
    console.log(`[2tekStudio Runner] Electron window closed (exit code: ${code}).`);
    cleanupProcesses();
    process.exit(code ?? 0);
  });

  process.on("SIGINT", () => {
    console.log("\n[2tekStudio Runner] Received SIGINT, shutting down...");
    cleanupProcesses();
    process.exit(0);
  });

  process.on("SIGTERM", () => {
    console.log("\n[2tekStudio Runner] Received SIGTERM, shutting down...");
    cleanupProcesses();
    process.exit(0);
  });

  process.on("exit", () => {
    cleanupProcesses();
  });
}

startDevElectron().catch((err) => {
  console.error("[2tekStudio Runner] Fatal startup error:", err);
  cleanupProcesses();
  process.exit(1);
});
