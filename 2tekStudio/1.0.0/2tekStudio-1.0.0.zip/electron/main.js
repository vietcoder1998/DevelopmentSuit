/**
 * packages/2tekStudio/electron/main.js
 * ─────────────────────────────────────────────────────────────────────────────
 * 2-TEK Studio — Electron Main Process
 * Cross-platform VS Code-grade IDE with integrated Checker VCS, Monaco editor,
 * in-code diagnostics, Prettier formatter, Terminal, and AI Copilot.
 * ─────────────────────────────────────────────────────────────────────────────
 */

const { app, BrowserWindow, shell, Menu, ipcMain } = require("electron");
const path = require("path");

const DEV_PORT = process.env.PORT || "3038";
const DEV_URL = process.env.DEV_URL || `http://localhost:${DEV_PORT}`;
const WINDOW_TITLE = "2-TEK Studio — Next-Gen Code Editor & VCS IDE";

let mainWindow = null;
let retryTimer = null;

function createMainWindow() {
  mainWindow = new BrowserWindow({
    width: 1560,
    height: 980,
    minWidth: 1080,
    minHeight: 720,
    title: WINDOW_TITLE,
    backgroundColor: "#070a13",
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: true,
    },
    show: false,
    autoHideMenuBar: false,
    titleBarStyle: process.platform === "darwin" ? "hiddenInset" : "default",
  });

  mainWindow.loadURL(DEV_URL);

  mainWindow.once("ready-to-show", () => {
    mainWindow.show();
    mainWindow.focus();
  });

  mainWindow.webContents.on("did-fail-load", (_event, errorCode, errorDescription) => {
    if (errorCode === -3) return; // Ignore aborted requests
    console.warn(`[2tekStudio Electron] Dev server loading (${errorCode}: ${errorDescription}). Retrying in 1s...`);
    if (retryTimer) clearTimeout(retryTimer);
    retryTimer = setTimeout(() => {
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.loadURL(DEV_URL);
      }
    }, 1000);
  });

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith("http:") || url.startsWith("https:")) {
      shell.openExternal(url);
    }
    return { action: "deny" };
  });

  mainWindow.on("closed", () => {
    if (retryTimer) clearTimeout(retryTimer);
    mainWindow = null;
  });
}

function buildStudioAppMenu() {
  const isMac = process.platform === "darwin";
  const template = [
    ...(isMac
      ? [
          {
            label: "2-TEK Studio",
            submenu: [
              { role: "about" },
              { type: "separator" },
              { role: "services" },
              { type: "separator" },
              { role: "hide" },
              { role: "hideOthers" },
              { role: "unhide" },
              { type: "separator" },
              { role: "quit" },
            ],
          },
        ]
      : []),
    {
      label: "File",
      submenu: [
        {
          label: "New File",
          accelerator: "CmdOrCtrl+N",
          click: () => mainWindow?.webContents.send("menu-action", "new-file"),
        },
        {
          label: "Save File",
          accelerator: "CmdOrCtrl+S",
          click: () => mainWindow?.webContents.send("menu-action", "save-file"),
        },
        { type: "separator" },
        {
          label: "Quick Open...",
          accelerator: "CmdOrCtrl+P",
          click: () => mainWindow?.webContents.send("menu-action", "quick-open"),
        },
        { type: "separator" },
        isMac ? { role: "close" } : { role: "quit" },
      ],
    },
    {
      label: "Edit",
      submenu: [
        { role: "undo" },
        { role: "redo" },
        { type: "separator" },
        { role: "cut" },
        { role: "copy" },
        { role: "paste" },
        { role: "selectAll" },
        { type: "separator" },
        {
          label: "Format Document (Prettier)",
          accelerator: "Shift+Alt+F",
          click: () => mainWindow?.webContents.send("menu-action", "format-document"),
        },
      ],
    },
    {
      label: "Checker VCS",
      submenu: [
        {
          label: "Pull Code via Checker",
          accelerator: "CmdOrCtrl+Shift+P",
          click: () => mainWindow?.webContents.send("menu-action", "checker-pull"),
        },
        {
          label: "Commit Staged Changes",
          accelerator: "CmdOrCtrl+Enter",
          click: () => mainWindow?.webContents.send("menu-action", "checker-commit"),
        },
        {
          label: "Refresh Status",
          accelerator: "CmdOrCtrl+R",
          click: () => mainWindow?.webContents.send("menu-action", "checker-refresh"),
        },
        {
          label: "Export .chr Patch...",
          click: () => mainWindow?.webContents.send("menu-action", "checker-export-patch"),
        },
      ],
    },
    {
      label: "View",
      submenu: [
        { role: "reload" },
        { role: "forceReload" },
        { role: "toggleDevTools" },
        { type: "separator" },
        { role: "resetZoom" },
        { role: "zoomIn" },
        { role: "zoomOut" },
        { type: "separator" },
        { role: "togglefullscreen" },
      ],
    },
    {
      label: "Terminal",
      submenu: [
        {
          label: "Toggle Integrated Terminal",
          accelerator: "CmdOrCtrl+`",
          click: () => mainWindow?.webContents.send("menu-action", "toggle-terminal"),
        },
        {
          label: "Clear Terminal",
          click: () => mainWindow?.webContents.send("menu-action", "clear-terminal"),
        },
      ],
    },
    {
      label: "Help",
      submenu: [
        {
          label: "2-TEK Studio Documentation",
          click: async () => {
            await shell.openExternal("https://github.com/tranduyviet/VtekDevelopmentSuit");
          },
        },
        {
          label: "Checker VCS Protocol (.chr)",
          click: async () => {
            await shell.openExternal("http://localhost:3035");
          },
        },
      ],
    },
  ];

  const menu = Menu.buildFromTemplate(template);
  Menu.setApplicationMenu(menu);
}

app.whenReady().then(() => {
  buildStudioAppMenu();
  createMainWindow();

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createMainWindow();
    }
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") {
    app.quit();
  }
});
