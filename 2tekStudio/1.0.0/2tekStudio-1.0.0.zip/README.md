# 2-TEK Studio (@2-tek/studio)

**2-TEK Studio** is a next-generation, cross-platform Code Editor & IDE modeled after VS Code and modern developer workspaces. It comes out of the box with native **Electron** desktop integration, **Checker VCS** source control, **Monaco Editor** syntax engine, **in-code diagnostics & warnings**, **Prettier formatter**, **integrated terminal**, **debug console**, and **context-aware AI Copilot**.

---

## Key Features

1. **VS Code-Grade Monaco Editor Engine**
   - High-fidelity Monaco Editor instance with full syntax coloring across 20+ languages.
   - Built-in multi-cursor, bracket pair colorization, folding, minimap, and smooth scrolling.
   - Dynamic tab management with unsaved dirty tracking (`●`).

2. **In-Code Suggestions & Warnings (Diagnostics)**
   - Contextual IntelliSense suggestions for 2-TEK SDK and Checker VCS functions.
   - Real-time in-code syntax validation with squiggly error/warning lines and gutter icons.
   - Integrated **Problems** tab with direct jump-to-line navigation.

3. **Checker VCS (Version Control System) Integration**
   - Native integration with `@2-tek/checker` repository engine.
   - Visual branch switcher & creation.
   - Stage, unstage, and commit with message shortcuts (`Cmd+Enter`).
   - Side-by-side or unified **Diff Viewer** comparing working changes against Checker HEAD.
   - **Pull Code via Checker**: Pulls from LocalSQLServer or applies `.chr` patch records.
   - **Export & Apply .chr Change Records**: Portable snapshot patch files.

4. **Prettier Code Formatter**
   - Standard Prettier v3 engine built-in.
   - One-click format document or keyboard shortcut (`Shift+Alt+F`).
   - Format-on-Save support in user preferences.
   - Live configuration of semicolons, single quotes, tab width, and trailing commas.

5. **Profile & Settings Sync**
   - Synchronize preferences with **LocalSQLServer** or local JSON config.
   - Switch themes on the fly: *Dark Modern*, *Cyberpunk*, *Monokai Pro*, *Cobalt Slate*.
   - Export and import profile configurations.

6. **Context-Aware AI Copilot Chat**
   - Built-in AI assistance panel supporting Gemini 2.0 Flash/Pro, Claude 3.5 Sonnet, GPT-4o, and Local Models.
   - Quick code actions: *Explain Selection*, *Refactor Code*, *Fix In-Code Warnings*, *Generate Unit Tests*.
   - Direct "Insert into Editor" and code copy controls.

7. **Integrated Terminal & Output Console**
   - Interactive bash shell command runner.
   - Quick action chips for common developer commands (`npm run dev`, `checker status`, `npx prettier`, etc.).
   - Multi-channel **Output** tab (Checker VCS, Prettier, AI Copilot, System Tasks).

8. **Interactive Debug Console**
   - Built-in JavaScript evaluation REPL for rapid scripting and inspection.

9. **Cross-Platform Native Desktop (Electron)**
   - Runs as desktop application on Linux, macOS, and Windows.
   - Packaged seamlessly into deb, exe, dmg, and portable zip via `scripts/build-development-suit.ts`.

---

## Getting Started

### Development Mode (Electron Desktop)
```bash
npm --workspace=packages/2tekStudio run dev
# or
npm run dev:2tekstudio
```

### Web Mode
```bash
npm --workspace=packages/2tekStudio run dev:web
# Launches on http://localhost:3038
```

### Packaging & Distribution
```bash
node scripts/build-development-suit.mjs --package 2tekStudio
```
