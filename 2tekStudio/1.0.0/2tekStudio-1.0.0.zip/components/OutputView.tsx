"use client";

import React, { useState, useRef, useEffect } from "react";
import { Trash2, Copy, Check } from "lucide-react";

export interface OutputLogItem {
  id: string;
  channel: string;
  message: string;
  timestamp: string;
  level?: "info" | "warn" | "error";
}

interface Props {
  logs: OutputLogItem[];
  onClear: (channel: string) => void;
}

export function OutputView({ logs, onClear }: Props) {
  const [selectedChannel, setSelectedChannel] = useState("Checker VCS");
  const [copied, setCopied] = useState(false);
  const logEndRef = useRef<HTMLDivElement>(null);

  const channels = ["Checker VCS", "Prettier Formatter", "AI Copilot", "Tasks", "System"];

  const filteredLogs = logs.filter((l) => l.channel === selectedChannel);

  useEffect(() => {
    logEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [filteredLogs]);

  const handleCopyLogs = () => {
    const text = filteredLogs.map((l) => `[${l.timestamp}] ${l.message}`).join("\n");
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div id="output-view" className="h-full flex flex-col font-mono text-xs select-none">
      {/* Channel toolbar */}
      <div className="flex items-center justify-between px-3 py-1.5 border-b border-white/5 bg-[#080c16]">
        <div className="flex items-center gap-2">
          <span className="text-[11px] text-slate-500">Channel:</span>
          <select
            id="output-channel-select"
            value={selectedChannel}
            onChange={(e) => setSelectedChannel(e.target.value)}
            className="bg-[#12192c] border border-white/10 rounded px-2 py-0.5 text-xs text-cyan-300 outline-none"
          >
            {channels.map((ch) => (
              <option key={ch} value={ch}>
                {ch}
              </option>
            ))}
          </select>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopyLogs}
            title="Copy logs"
            className="p-1 text-slate-400 hover:text-white rounded hover:bg-white/5 flex items-center gap-1 text-[11px]"
          >
            {copied ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
            <span>{copied ? "Copied" : "Copy"}</span>
          </button>
          <button
            onClick={() => onClear(selectedChannel)}
            title="Clear output"
            className="p-1 text-slate-400 hover:text-rose-400 rounded hover:bg-white/5 flex items-center gap-1 text-[11px]"
          >
            <Trash2 size={12} />
            <span>Clear</span>
          </button>
        </div>
      </div>

      {/* Log Content */}
      <div className="flex-1 overflow-y-auto p-3 space-y-1 bg-[#070a14] select-text">
        {filteredLogs.length === 0 ? (
          <div className="text-slate-600 italic">No output in channel &quot;{selectedChannel}&quot;.</div>
        ) : (
          filteredLogs.map((item) => (
            <div
              key={item.id}
              className={`leading-relaxed ${
                item.level === "error"
                  ? "text-rose-400"
                  : item.level === "warn"
                  ? "text-amber-400"
                  : "text-slate-300"
              }`}
            >
              <span className="text-slate-600 text-[10px] mr-2">[{item.timestamp}]</span>
              <span>{item.message}</span>
            </div>
          ))
        )}
        <div ref={logEndRef} />
      </div>
    </div>
  );
}
