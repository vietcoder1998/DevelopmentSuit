"use client";

import React, { useRef, useEffect, useState, useCallback } from "react";
import dynamic from "next/dynamic";
import { EditorTab, ProblemItem, PrettierConfig } from "./types";
import {
  FileCode,
  X,
  Plus,
  Zap,
  Save,
  Split,
  ChevronRight,
  GitCompare,
  AlertCircle,
  AlertTriangle,
  Paintbrush,
  Sparkles,
} from "lucide-react";

// Dynamically import Monaco Editor to avoid SSR issues
const MonacoEditor = dynamic(() => import("@monaco-editor/react"), {
  ssr: false,
  loading: () => (
    <div className="h-full flex items-center justify-center bg-[#090d18] text-slate-500 font-mono text-xs">
      Loading Monaco Editor core...
    </div>
  ),
});

const MonacoDiffEditor = dynamic(
  () => import("@monaco-editor/react").then((mod) => mod.DiffEditor),
  {
    ssr: false,
    loading: () => (
      <div className="h-full flex items-center justify-center bg-[#090d18] text-slate-500 font-mono text-xs">
        Loading Diff Viewer...
      </div>
    ),
  }
);

interface Props {
  tabs: EditorTab[];
  activeTabId: string | null;
  onSelectTab: (tabId: string) => void;
  onCloseTab: (tabId: string) => void;
  onNewScratchTab: () => void;
  onChangeContent: (tabId: string, content: string) => void;
  onSaveFile: (tab: EditorTab) => Promise<void>;
  onFormatDocument: () => Promise<void>;
  prettierConfig: PrettierConfig;
  formatOnSave: boolean;
  fontSize: number;
  tabSize: number;
  minimap: boolean;
  theme: string;
  onDiagnosticsChange: (problems: ProblemItem[]) => void;
  diffMode?: {
    isOpen: boolean;
    original: string;
    modified: string;
    filePath: string;
  } | null;
  onCloseDiff?: () => void;
}

export function EditorArea({
  tabs,
  activeTabId,
  onSelectTab,
  onCloseTab,
  onNewScratchTab,
  onChangeContent,
  onSaveFile,
  onFormatDocument,
  prettierConfig,
  formatOnSave,
  fontSize,
  tabSize,
  minimap,
  theme,
  onDiagnosticsChange,
  diffMode,
  onCloseDiff,
}: Props) {
  const editorRef = useRef<any>(null);
  const monacoRef = useRef<any>(null);
  const activeTab = tabs.find((t) => t.id === activeTabId);

  // Set up Monaco custom completion provider for "suggestion in Code"
  const handleEditorDidMount = (editor: any, monaco: any) => {
    editorRef.current = editor;
    monacoRef.current = monaco;

    // Define custom 2-TEK Studio Dark Theme
    monaco.editor.defineTheme("2tek-dark", {
      base: "vs-dark",
      inherit: true,
      rules: [
        { token: "comment", foreground: "64748b", fontStyle: "italic" },
        { token: "keyword", foreground: "38bdf8", fontStyle: "bold" },
        { token: "string", foreground: "34d399" },
        { token: "number", foreground: "f59e0b" },
        { token: "type", foreground: "a78bfa" },
        { token: "function", foreground: "60a5fa" },
        { token: "variable", foreground: "e2e8f0" },
      ],
      colors: {
        "editor.background": "#090d18",
        "editor.foreground": "#f8fafc",
        "editorCursor.foreground": "#06b6d4",
        "editor.lineHighlightBackground": "#12192c40",
        "editorLineNumber.foreground": "#334155",
        "editorLineNumber.activeForeground": "#38bdf8",
        "editorIndentGuide.background": "#1e293b",
        "editorIndentGuide.activeBackground": "#0ea5e9",
        "editor.selectionBackground": "#0284c740",
        "editorGutter.background": "#090d18",
      },
    });

    monaco.editor.setTheme("2tek-dark");

    // Register 2-TEK Autocomplete Suggestions
    try {
      monaco.languages.registerCompletionItemProvider("typescript", {
        provideCompletionItems: (model: any, position: any) => {
          const suggestions = [
            {
              label: "Repository",
              kind: monaco.languages.CompletionItemKind.Class,
              insertText: "Repository",
              detail: "@2-tek/checker Repository class",
              documentation: "Main Checker VCS repository management class.",
            },
            {
              label: "repo.getStatus",
              kind: monaco.languages.CompletionItemKind.Method,
              insertText: "repo.getStatus()",
              detail: "Get repository staging and diff status",
            },
            {
              label: "repo.exportChrPatch",
              kind: monaco.languages.CompletionItemKind.Method,
              insertText: "repo.exportChrPatch({\n  message: \"${1:patch message}\",\n})",
              insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
              detail: "Export changes to .chr patch file",
            },
            {
              label: "repo.applyChrPatch",
              kind: monaco.languages.CompletionItemKind.Method,
              insertText: "repo.applyChrPatch(${1:patchContent})",
              insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
              detail: "Apply .chr patch to workspace",
            },
            {
              label: "formatChrFile",
              kind: monaco.languages.CompletionItemKind.Function,
              insertText: "formatChrFile({ diffs: ${1:[]}, message: \"${2}\" })",
              insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
              detail: "Serialize diffs to CHR format",
            },
            {
              label: "LocalSQLServerClient",
              kind: monaco.languages.CompletionItemKind.Class,
              insertText: "LocalSQLServerClient",
              detail: "2-TEK Database Engine Client",
            },
          ];
          return { suggestions };
        },
      });
    } catch {}

    // Register Document Formatter with Prettier
    try {
      const formatDocumentAction = {
        id: "2tek.prettier.format",
        label: "Format Document with Prettier",
        keybindings: [monaco.KeyMod.Shift | monaco.KeyMod.Alt | monaco.KeyCode.KeyF],
        run: async () => {
          await onFormatDocument();
        },
      };
      editor.addAction(formatDocumentAction);
    } catch {}

    // Add Ctrl+S / Cmd+S save shortcut
    editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyS, async () => {
      if (activeTab) {
        if (formatOnSave) {
          await onFormatDocument();
        }
        await onSaveFile(activeTab);
      }
    });

    runCodeDiagnostics(editor.getValue(), activeTab);
  };

  // Run in-code warnings, syntax validation, and diagnostics
  const runCodeDiagnostics = useCallback(
    (code: string, tab?: EditorTab) => {
      if (!tab || !monacoRef.current || !editorRef.current) return;
      const monaco = monacoRef.current;
      const model = editorRef.current.getModel();
      if (!model) return;

      const markers: any[] = [];
      const problemItems: ProblemItem[] = [];

      // 1. JSON parsing check
      if (tab.language === "json") {
        try {
          JSON.parse(code);
        } catch (err: any) {
          const match = err.message.match(/line (\d+) column (\d+)/);
          const line = match ? parseInt(match[1], 10) : 1;
          const col = match ? parseInt(match[2], 10) : 1;

          markers.push({
            startLineNumber: line,
            startColumn: col,
            endLineNumber: line,
            endColumn: col + 5,
            message: `JSON Syntax: ${err.message}`,
            severity: monaco.MarkerSeverity.Error,
          });

          problemItems.push({
            id: `prob_${Date.now()}_1`,
            file: tab.path,
            message: `Invalid JSON syntax: ${err.message}`,
            severity: "error",
            line,
            column: col,
            rule: "json-syntax",
          });
        }
      }

      // 2. TypeScript / JS linting heuristics & warnings
      if (tab.language === "typescript" || tab.language === "javascript") {
        const lines = code.split("\n");
        lines.forEach((lineText, idx) => {
          const lineNum = idx + 1;

          // Check console.log warning
          if (lineText.includes("console.log(")) {
            const col = lineText.indexOf("console.log(") + 1;
            markers.push({
              startLineNumber: lineNum,
              startColumn: col,
              endLineNumber: lineNum,
              endColumn: col + 11,
              message: "Avoid leaving console.log in production code (warning)",
              severity: monaco.MarkerSeverity.Warning,
            });

            problemItems.push({
              id: `prob_${tab.path}_${lineNum}`,
              file: tab.path,
              message: "Unexpected console.log statement found",
              severity: "warning",
              line: lineNum,
              column: col,
              rule: "no-console",
            });
          }

          // Check debugger statement
          if (lineText.trim() === "debugger;" || lineText.trim() === "debugger") {
            const col = lineText.indexOf("debugger") + 1;
            markers.push({
              startLineNumber: lineNum,
              startColumn: col,
              endLineNumber: lineNum,
              endColumn: col + 8,
              message: "Unexpected debugger statement",
              severity: monaco.MarkerSeverity.Error,
            });

            problemItems.push({
              id: `prob_${tab.path}_debug_${lineNum}`,
              file: tab.path,
              message: "Debugger statement should be removed",
              severity: "error",
              line: lineNum,
              column: col,
              rule: "no-debugger",
            });
          }

          // Check for 'any' types in typescript
          if (tab.language === "typescript" && lineText.includes(": any") && !lineText.includes("//")) {
            const col = lineText.indexOf(": any") + 1;
            markers.push({
              startLineNumber: lineNum,
              startColumn: col,
              endLineNumber: lineNum,
              endColumn: col + 5,
              message: "Use explicit typing instead of 'any'",
              severity: monaco.MarkerSeverity.Info,
            });

            problemItems.push({
              id: `prob_${tab.path}_any_${lineNum}`,
              file: tab.path,
              message: "Explicit type preferred over 'any'",
              severity: "info",
              line: lineNum,
              column: col,
              rule: "no-explicit-any",
            });
          }
        });
      }

      monaco.editor.setModelMarkers(model, "2tek-diagnostics", markers);
      onDiagnosticsChange(problemItems);
    },
    [onDiagnosticsChange]
  );

  useEffect(() => {
    if (activeTab && editorRef.current) {
      runCodeDiagnostics(activeTab.content, activeTab);
    }
  }, [activeTab, runCodeDiagnostics]);

  return (
    <div id="editor-area-container" className="h-full flex flex-col bg-[#090d18] overflow-hidden select-none font-sans">
      {/* Tabs Header */}
      <div className="flex items-center justify-between bg-[#060810] border-b border-white/10 select-none">
        <div className="flex items-center overflow-x-auto">
          {tabs.map((tab) => {
            const isActive = tab.id === activeTabId;
            return (
              <div
                key={tab.id}
                onClick={() => onSelectTab(tab.id)}
                className={`group flex items-center gap-2 px-3 py-2 border-r border-white/5 cursor-pointer text-xs font-mono transition border-t-2 ${
                  isActive
                    ? "bg-[#090d18] text-cyan-300 border-t-cyan-400 font-semibold"
                    : "bg-[#070912] text-slate-400 border-t-transparent hover:bg-white/5 hover:text-slate-200"
                }`}
              >
                <FileCode size={13} className={isActive ? "text-cyan-400" : "text-slate-500"} />
                <span className="truncate max-w-[140px]">{tab.name}</span>

                {tab.isDirty && (
                  <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" title="Unsaved changes" />
                )}

                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onCloseTab(tab.id);
                  }}
                  className="opacity-0 group-hover:opacity-100 p-0.5 text-slate-500 hover:text-white rounded hover:bg-white/10"
                >
                  <X size={12} />
                </button>
              </div>
            );
          })}

          <button
            id="editor-new-tab-btn"
            title="New Scratch File"
            onClick={onNewScratchTab}
            className="p-2 text-slate-500 hover:text-cyan-400 hover:bg-white/5 transition"
          >
            <Plus size={14} />
          </button>
        </div>

        {/* Action icons on tab bar */}
        <div className="flex items-center gap-1 px-3">
          {activeTab && (
            <button
              onClick={() => onSaveFile(activeTab)}
              title="Save File (Cmd+S)"
              className="p-1 text-slate-400 hover:text-cyan-400 rounded hover:bg-white/5 flex items-center gap-1 text-[11px] font-mono"
            >
              <Save size={13} />
              <span>Save</span>
            </button>
          )}
          <button
            id="editor-format-doc-btn"
            onClick={onFormatDocument}
            title="Format Document with Prettier (Shift+Alt+F)"
            className="p-1 text-slate-400 hover:text-pink-400 rounded hover:bg-white/5 flex items-center gap-1 text-[11px] font-mono"
          >
            <Paintbrush size={13} />
            <span>Prettier</span>
          </button>
        </div>
      </div>

      {/* Breadcrumbs Trail */}
      {activeTab && !diffMode?.isOpen && (
        <div className="flex items-center justify-between px-3 py-1 bg-[#070912] border-b border-white/5 text-[11px] font-mono text-slate-500 select-none">
          <div className="flex items-center gap-1 truncate">
            {activeTab.path.split("/").map((part, index, arr) => (
              <React.Fragment key={index}>
                <span className={index === arr.length - 1 ? "text-slate-300 font-semibold" : ""}>
                  {part}
                </span>
                {index < arr.length - 1 && <ChevronRight size={11} className="text-slate-600" />}
              </React.Fragment>
            ))}
          </div>

          <div className="flex items-center gap-3">
            <span className="text-[10px] text-cyan-400 uppercase font-semibold">
              {activeTab.language}
            </span>
            <span className="text-[10px] text-slate-500">UTF-8</span>
            <span className="text-[10px] text-slate-500">Spaces: {tabSize}</span>
          </div>
        </div>
      )}

      {/* Diff Mode View */}
      {diffMode?.isOpen ? (
        <div className="flex-1 flex flex-col overflow-hidden">
          <div className="flex items-center justify-between px-3 py-1.5 bg-[#0a0f1e] border-b border-white/10 text-xs font-mono text-cyan-300">
            <div className="flex items-center gap-2">
              <GitCompare size={14} className="text-cyan-400" />
              <span>Diff View (Checker HEAD ↔ Working Tree): {diffMode.filePath}</span>
            </div>
            {onCloseDiff && (
              <button
                onClick={onCloseDiff}
                className="px-2 py-0.5 rounded bg-white/10 hover:bg-white/15 text-slate-300 text-xs"
              >
                Close Diff
              </button>
            )}
          </div>
          <div className="flex-1 overflow-hidden">
            <MonacoDiffEditor
              original={diffMode.original}
              modified={diffMode.modified}
              language="typescript"
              theme="vs-dark"
              options={{
                readOnly: false,
                renderSideBySide: true,
                fontSize,
                minimap: { enabled: minimap },
                scrollBeyondLastLine: false,
              }}
            />
          </div>
        </div>
      ) : activeTab ? (
        /* Regular Monaco Editor View */
        <div className="flex-1 overflow-hidden">
          <MonacoEditor
            height="100%"
            language={activeTab.language}
            value={activeTab.content}
            theme="vs-dark"
            onMount={handleEditorDidMount}
            onChange={(val) => {
              const newContent = val ?? "";
              onChangeContent(activeTab.id, newContent);
              runCodeDiagnostics(newContent, activeTab);
            }}
            options={{
              fontSize,
              tabSize,
              minimap: { enabled: minimap },
              scrollBeyondLastLine: false,
              wordWrap: "on",
              automaticLayout: true,
              bracketPairColorization: { enabled: true },
              suggestOnTriggerCharacters: true,
              quickSuggestions: true,
              formatOnType: true,
              formatOnPaste: true,
              glyphMargin: true,
              cursorBlinking: "smooth",
              smoothScrolling: true,
              renderLineHighlight: "all",
            }}
          />
        </div>
      ) : (
        /* Empty Workspace State */
        <div className="flex-1 flex flex-col items-center justify-center text-center p-8 bg-[#090d18] text-slate-400 select-none">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-cyan-500/20 to-purple-500/20 border border-white/10 flex items-center justify-center mb-4 shadow-xl">
            <FileCode size={32} className="text-cyan-400" />
          </div>
          <h2 className="text-lg font-bold text-slate-100">2-TEK Studio IDE</h2>
          <p className="text-xs text-slate-400 mt-1 max-w-md">
            Open a file from the Explorer on the left, or use the shortcuts below:
          </p>

          <div className="grid grid-cols-2 gap-3 mt-6 text-xs font-mono max-w-sm w-full">
            <div className="p-2.5 rounded-lg bg-[#0e1424] border border-white/5 flex items-center justify-between">
              <span className="text-slate-400">Quick Open</span>
              <kbd className="px-1.5 py-0.5 rounded bg-white/10 text-cyan-300 font-bold">Cmd+P</kbd>
            </div>
            <div className="p-2.5 rounded-lg bg-[#0e1424] border border-white/5 flex items-center justify-between">
              <span className="text-slate-400">Prettier Format</span>
              <kbd className="px-1.5 py-0.5 rounded bg-white/10 text-pink-300 font-bold">Shift+Alt+F</kbd>
            </div>
            <div className="p-2.5 rounded-lg bg-[#0e1424] border border-white/5 flex items-center justify-between">
              <span className="text-slate-400">Checker Pull</span>
              <kbd className="px-1.5 py-0.5 rounded bg-white/10 text-emerald-300 font-bold">Pull Code</kbd>
            </div>
            <div className="p-2.5 rounded-lg bg-[#0e1424] border border-white/5 flex items-center justify-between">
              <span className="text-slate-400">Terminal</span>
              <kbd className="px-1.5 py-0.5 rounded bg-white/10 text-amber-300 font-bold">Cmd+`</kbd>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
