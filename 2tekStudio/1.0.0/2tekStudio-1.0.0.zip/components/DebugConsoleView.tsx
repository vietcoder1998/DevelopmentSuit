"use client";

import React, { useState, useRef, useEffect } from "react";
import { Play, Trash2, Terminal, CornerDownLeft } from "lucide-react";

interface EvalLog {
  id: string;
  expression: string;
  result: string;
  type: string;
  logs?: string[];
  isError: boolean;
}

interface Props {
  onClear: () => void;
}

export function DebugConsoleView({ onClear }: Props) {
  const [expression, setExpression] = useState("");
  const [evalLogs, setEvalLogs] = useState<EvalLog[]>([]);
  const [isEvaluating, setIsEvaluating] = useState(false);
  const consoleEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    consoleEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [evalLogs]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!expression.trim() || isEvaluating) return;

    const expr = expression.trim();
    setExpression("");
    setIsEvaluating(true);

    try {
      const res = await fetch("/api/debug", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ expression: expr }),
      });
      const data = await res.json();

      setEvalLogs((prev) => [
        ...prev,
        {
          id: `eval_${Date.now()}`,
          expression: expr,
          result: data.result || data.error || "undefined",
          type: data.type || "unknown",
          logs: data.logs,
          isError: !data.success,
        },
      ]);
    } catch (err: any) {
      setEvalLogs((prev) => [
        ...prev,
        {
          id: `eval_${Date.now()}`,
          expression: expr,
          result: err.message,
          type: "error",
          isError: true,
        },
      ]);
    } finally {
      setIsEvaluating(false);
    }
  };

  const handleClearAll = () => {
    setEvalLogs([]);
    onClear();
  };

  return (
    <div
      id="debug-console-view"
      className="h-full flex flex-col font-mono text-xs bg-[#070a14] select-text"
      onClick={() => inputRef.current?.focus()}
    >
      {/* Top Header */}
      <div className="flex items-center justify-between px-3 py-1.5 border-b border-white/5 bg-[#05070e] text-[11px] select-none">
        <span className="text-slate-500">JavaScript Interactive REPL</span>
        <button
          onClick={handleClearAll}
          className="p-1 text-slate-400 hover:text-rose-400 rounded flex items-center gap-1"
        >
          <Trash2 size={12} />
          <span>Clear</span>
        </button>
      </div>

      {/* REPL History */}
      <div className="flex-1 overflow-y-auto p-3 space-y-2 leading-relaxed">
        {evalLogs.length === 0 && (
          <div className="text-slate-600 italic select-none">
            Evaluate JavaScript expressions (e.g. `2 + 2`, `Math.PI * 4`, `process.platform`, `new Date().toISOString()`)
          </div>
        )}

        {evalLogs.map((item) => (
          <div key={item.id} className="space-y-1">
            <div className="flex items-center gap-2 text-cyan-300">
              <span className="text-cyan-500 font-bold">&gt;</span>
              <span>{item.expression}</span>
            </div>

            {item.logs && item.logs.length > 0 && (
              <div className="pl-4 text-slate-400 text-[11px]">
                {item.logs.map((l, idx) => (
                  <div key={idx}>{l}</div>
                ))}
              </div>
            )}

            <div
              className={`pl-4 ${
                item.isError ? "text-rose-400" : "text-emerald-300"
              } whitespace-pre-wrap`}
            >
              <span className="text-slate-600 text-[10px] mr-1.5">&larr;</span>
              <span>{item.result}</span>
            </div>
          </div>
        ))}

        <div ref={consoleEndRef} />
      </div>

      {/* Input */}
      <form
        onSubmit={handleSubmit}
        className="flex items-center gap-2 px-3 py-2 border-t border-white/5 bg-[#05070e]"
      >
        <span className="text-cyan-500 font-bold shrink-0">&gt;</span>
        <input
          ref={inputRef}
          id="debug-console-input"
          type="text"
          value={expression}
          onChange={(e) => setExpression(e.target.value)}
          placeholder="Evaluate expression..."
          className="flex-1 bg-transparent text-slate-100 outline-none text-xs font-mono"
        />
        <button
          type="submit"
          disabled={!expression.trim() || isEvaluating}
          className="p-1 text-slate-400 hover:text-cyan-400 disabled:opacity-30"
        >
          <CornerDownLeft size={13} />
        </button>
      </form>
    </div>
  );
}
