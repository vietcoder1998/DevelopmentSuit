"use client";

import React, { useState } from "react";
import { ProblemItem, ProblemSeverity } from "./types";
import { AlertCircle, AlertTriangle, Info, CheckCircle2, Filter } from "lucide-react";

interface Props {
  problems: ProblemItem[];
  onSelectProblem: (file: string, line: number, column: number) => void;
}

export function ProblemsView({ problems, onSelectProblem }: Props) {
  const [filter, setFilter] = useState<ProblemSeverity | "all">("all");

  const errors = problems.filter((p) => p.severity === "error");
  const warnings = problems.filter((p) => p.severity === "warning");
  const infos = problems.filter((p) => p.severity === "info");

  const filtered =
    filter === "all" ? problems : problems.filter((p) => p.severity === filter);

  const renderIcon = (severity: ProblemSeverity) => {
    switch (severity) {
      case "error":
        return <AlertCircle size={14} className="text-rose-400 shrink-0" />;
      case "warning":
        return <AlertTriangle size={14} className="text-amber-400 shrink-0" />;
      case "info":
        return <Info size={14} className="text-cyan-400 shrink-0" />;
    }
  };

  return (
    <div id="problems-view" className="h-full flex flex-col font-mono text-xs select-none">
      {/* Filter toolbar */}
      <div className="flex items-center gap-2 px-3 py-1.5 border-b border-white/5 bg-[#080c16] text-[11px]">
        <Filter size={12} className="text-slate-500" />
        <button
          onClick={() => setFilter("all")}
          className={`px-2 py-0.5 rounded transition ${
            filter === "all"
              ? "bg-white/10 text-slate-100 font-semibold"
              : "text-slate-400 hover:text-slate-200"
          }`}
        >
          All ({problems.length})
        </button>
        <button
          onClick={() => setFilter("error")}
          className={`flex items-center gap-1 px-2 py-0.5 rounded transition ${
            filter === "error"
              ? "bg-rose-950/70 text-rose-300 border border-rose-800 font-semibold"
              : "text-rose-400/80 hover:text-rose-300"
          }`}
        >
          <AlertCircle size={11} />
          <span>Errors ({errors.length})</span>
        </button>
        <button
          onClick={() => setFilter("warning")}
          className={`flex items-center gap-1 px-2 py-0.5 rounded transition ${
            filter === "warning"
              ? "bg-amber-950/70 text-amber-300 border border-amber-800 font-semibold"
              : "text-amber-400/80 hover:text-amber-300"
          }`}
        >
          <AlertTriangle size={11} />
          <span>Warnings ({warnings.length})</span>
        </button>
        <button
          onClick={() => setFilter("info")}
          className={`flex items-center gap-1 px-2 py-0.5 rounded transition ${
            filter === "info"
              ? "bg-cyan-950/70 text-cyan-300 border border-cyan-800 font-semibold"
              : "text-cyan-400/80 hover:text-cyan-300"
          }`}
        >
          <Info size={11} />
          <span>Info ({infos.length})</span>
        </button>
      </div>

      {/* Problems List */}
      <div className="flex-1 overflow-y-auto p-1">
        {filtered.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-500">
            <CheckCircle2 size={24} className="text-emerald-500/50 mb-2" />
            <p className="text-xs text-slate-400">No problems detected in the workspace.</p>
            <p className="text-[11px] text-slate-600 mt-0.5">
              Code diagnostics and syntax warnings will appear here.
            </p>
          </div>
        ) : (
          filtered.map((item) => (
            <div
              key={item.id}
              onClick={() => onSelectProblem(item.file, item.line, item.column)}
              className="flex items-center justify-between px-3 py-1.5 rounded hover:bg-white/5 cursor-pointer text-slate-300 transition group"
            >
              <div className="flex items-center gap-2 min-w-0">
                {renderIcon(item.severity)}
                <span className="text-slate-200 font-medium truncate">{item.message}</span>
                {item.rule && (
                  <span className="text-[10px] text-slate-500 bg-white/5 px-1 rounded">
                    {item.rule}
                  </span>
                )}
              </div>

              <div className="flex items-center gap-2 text-slate-500 text-[11px] shrink-0 ml-4">
                <span className="text-slate-400 group-hover:text-cyan-400 truncate max-w-xs">
                  {item.file.split("/").pop()}
                </span>
                <span>
                  [{item.line}:{item.column}]
                </span>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
