"use client";

import React, { useState, useEffect, useCallback } from "react";
import {
  EditorTab,
  FileTreeNode,
  ProblemItem,
  CheckerStatusSummary,
  TerminalEntry,
  UserProfileConfig,
  PrettierConfig,
  StudioNotification,
  AiChatMessage,
  EditorLanguage,
} from "./types";
import { SidebarExplorer } from "./SidebarExplorer";
import { SidebarChecker } from "./SidebarChecker";
import { SidebarProfile } from "./SidebarProfile";
import { SidebarPrettier } from "./SidebarPrettier";
import { EditorArea } from "./EditorArea";
import { BottomPanel, BottomTabType } from "./BottomPanel";
import { OutputLogItem } from "./OutputView";
import { AiChatPanel } from "./AiChatPanel";
import { NotificationDrawer } from "./NotificationDrawer";
import { QuickOpenModal } from "./QuickOpenModal";
import {
  Files,
  GitBranch,
  UserCheck,
  Paintbrush,
  AlertTriangle,
  Sparkles,
  Terminal as TerminalIcon,
  Play,
  Bell,
  Search,
  Check,
  ChevronRight,
  Layout,
  Code2,
  FolderOpen,
} from "lucide-react";

export function StudioLayout() {
  // Activity bar active mode
  const [sidebarMode, setSidebarMode] = useState<
    "explorer" | "checker" | "profile" | "prettier" | null
  >("explorer");

  // Right AI Copilot panel
  const [isAiOpen, setIsAiOpen] = useState(false);

  // Bottom dock panel
  const [isBottomOpen, setIsBottomOpen] = useState(true);
  const [bottomTab, setBottomTab] = useState<BottomTabType>("terminal");

  // Notification drawer & Quick open modal
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isQuickOpenOpen, setIsQuickOpenOpen] = useState(false);

  // File tree & tabs state
  const [fileTree, setFileTree] = useState<FileTreeNode[]>([]);
  const [allFilePaths, setAllFilePaths] = useState<string[]>([]);
  const [tabs, setTabs] = useState<EditorTab[]>([]);
  const [activeTabId, setActiveTabId] = useState<string | null>(null);

  // Diff mode state
  const [diffMode, setDiffMode] = useState<{
    isOpen: boolean;
    original: string;
    modified: string;
    filePath: string;
  } | null>(null);

  // Checker VCS state
  const [checkerStatus, setCheckerStatus] = useState<CheckerStatusSummary | null>(null);
  const [branches, setBranches] = useState<Array<{ name: string; isCurrent: boolean }>>([]);

  // In-code warnings & problems
  const [problems, setProblems] = useState<ProblemItem[]>([]);

  // Logs & Terminal state
  const [outputLogs, setOutputLogs] = useState<OutputLogItem[]>([
    {
      id: "log_1",
      channel: "Checker VCS",
      message: "Initialized 2-TEK Studio VCS engine with Checker repository protocol.",
      timestamp: new Date().toLocaleTimeString(),
      level: "info",
    },
    {
      id: "log_2",
      channel: "Prettier Formatter",
      message: "Prettier v3.9.9 integrated with Monaco editor and TypeScript parser.",
      timestamp: new Date().toLocaleTimeString(),
      level: "info",
    },
  ]);
  const [terminalHistory, setTerminalHistory] = useState<TerminalEntry[]>([]);
  const [isTerminalRunning, setIsTerminalRunning] = useState(false);

  // Notifications
  const [notifications, setNotifications] = useState<StudioNotification[]>([
    {
      id: "notif_welcome",
      type: "info",
      title: "Welcome to 2-TEK Studio",
      message: "Next-gen VS Code-grade IDE with Checker VCS, Prettier, and AI Copilot.",
      timestamp: new Date().toLocaleTimeString(),
    },
  ]);

  // Profile config
  const [profile, setProfile] = useState<UserProfileConfig>({
    id: "profile_1",
    name: "2-TEK Senior Developer",
    theme: "dark-modern",
    fontSize: 14,
    tabSize: 2,
    formatOnSave: true,
    minimap: true,
    wordWrap: true,
    aiModel: "Gemini 2.0 Flash",
    lastSynced: new Date().toISOString(),
    syncSource: "localsqlserver",
  });

  // Prettier config
  const [prettierConfig, setPrettierConfig] = useState<PrettierConfig>({
    semi: true,
    singleQuote: false,
    tabWidth: 2,
    trailingComma: "es5",
    printWidth: 100,
  });

  const [lastFormatDuration, setLastFormatDuration] = useState<number | undefined>();
  const [lastFormatTime, setLastFormatTime] = useState<string | undefined>();

  // AI Chat state
  const [aiMessages, setAiMessages] = useState<AiChatMessage[]>([
    {
      id: "msg_init",
      role: "assistant",
      content:
        "Hello! I am your **2-TEK Studio AI Copilot**. I can explain code, refactor functions, fix in-code diagnostics, write Vitest tests, or assist with Checker VCS commands. How can I help you today?",
      timestamp: new Date().toLocaleTimeString(),
    },
  ]);

  const addNotification = useCallback(
    (type: "info" | "success" | "warning" | "error", title: string, message: string) => {
      const item: StudioNotification = {
        id: `notif_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        type,
        title,
        message,
        timestamp: new Date().toLocaleTimeString(),
      };
      setNotifications((prev) => [item, ...prev]);
    },
    []
  );

  const addOutputLog = useCallback(
    (channel: string, message: string, level: "info" | "warn" | "error" = "info") => {
      setOutputLogs((prev) => [
        ...prev,
        {
          id: `log_${Date.now()}`,
          channel,
          message,
          timestamp: new Date().toLocaleTimeString(),
          level,
        },
      ]);
    },
    []
  );

  // Flatten tree to get list of file paths
  const extractFilePaths = (nodes: FileTreeNode[]): string[] => {
    const list: string[] = [];
    const traverse = (items: FileTreeNode[]) => {
      for (const item of items) {
        if (item.isDirectory && item.children) {
          traverse(item.children);
        } else if (!item.isDirectory) {
          list.push(item.path);
        }
      }
    };
    traverse(nodes);
    return list;
  };

  // Fetch file tree
  const refreshFileTree = useCallback(async () => {
    try {
      const res = await fetch("/api/files?action=tree");
      const data = await res.json();
      if (data.success && Array.isArray(data.tree)) {
        setFileTree(data.tree);
        setAllFilePaths(extractFilePaths(data.tree));
      }
    } catch (err: any) {
      console.error("Failed to load file tree:", err);
    }
  }, []);

  // Fetch Checker status
  const refreshCheckerStatus = useCallback(async () => {
    try {
      const stRes = await fetch("/api/checker/status");
      const stData = await stRes.json();
      if (stData.success) {
        setCheckerStatus(stData);
      }

      const brRes = await fetch("/api/checker/branches");
      const brData = await brRes.json();
      if (brData.success && Array.isArray(brData.branches)) {
        setBranches(brData.branches);
      }
    } catch (err: any) {
      console.error("Failed to load checker status:", err);
    }
  }, []);

  // Fetch saved profile
  const loadSavedProfile = useCallback(async () => {
    try {
      const res = await fetch("/api/profile");
      const data = await res.json();
      if (data.success && data.profile) {
        setProfile(data.profile);
      }
    } catch {}
  }, []);

  useEffect(() => {
    refreshFileTree();
    refreshCheckerStatus();
    loadSavedProfile();

    // Default open package.json or README
    openFile("package.json");
  }, [refreshFileTree, refreshCheckerStatus, loadSavedProfile]);

  // Open file in tab
  const openFile = async (filePath: string) => {
    // If already open, switch to it
    const existing = tabs.find((t) => t.path === filePath);
    if (existing) {
      setActiveTabId(existing.id);
      return;
    }

    try {
      const res = await fetch(`/api/files?action=read&path=${encodeURIComponent(filePath)}`);
      const data = await res.json();

      if (!data.success) {
        addNotification("error", "Failed to Open File", data.error || "File read error");
        return;
      }

      const ext = filePath.split(".").pop()?.toLowerCase();
      let language: EditorLanguage = "plaintext";
      if (ext === "ts" || ext === "tsx") language = "typescript";
      else if (ext === "js" || ext === "jsx" || ext === "mjs") language = "javascript";
      else if (ext === "json") language = "json";
      else if (ext === "css") language = "css";
      else if (ext === "html") language = "html";
      else if (ext === "sql") language = "sql";
      else if (ext === "md") language = "markdown";
      else if (ext === "yaml" || ext === "yml") language = "yaml";
      else if (ext === "sh") language = "shell";

      const newTab: EditorTab = {
        id: `tab_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        name: filePath.split("/").pop() || filePath,
        path: filePath,
        content: data.content,
        originalContent: data.content,
        isDirty: false,
        language,
      };

      setTabs((prev) => [...prev, newTab]);
      setActiveTabId(newTab.id);
    } catch (err: any) {
      addNotification("error", "Error Opening File", err.message);
    }
  };

  // Save active file
  const saveFile = async (tab: EditorTab) => {
    try {
      const res = await fetch("/api/files", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "write",
          filePath: tab.path,
          content: tab.content,
        }),
      });
      const data = await res.json();

      if (data.success) {
        setTabs((prev) =>
          prev.map((t) => (t.id === tab.id ? { ...t, isDirty: false, originalContent: t.content } : t))
        );
        addNotification("success", "File Saved", `Saved ${tab.name} successfully.`);
        addOutputLog("Checker VCS", `Working file ${tab.path} saved.`, "info");
        refreshCheckerStatus();
      } else {
        addNotification("error", "Save Failed", data.error);
      }
    } catch (err: any) {
      addNotification("error", "Save Error", err.message);
    }
  };

  // Format with Prettier
  const formatDocument = async () => {
    const activeTab = tabs.find((t) => t.id === activeTabId);
    if (!activeTab) return;

    try {
      const res = await fetch("/api/prettier", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          code: activeTab.content,
          filepath: activeTab.path,
          options: prettierConfig,
        }),
      });
      const data = await res.json();

      if (data.success) {
        setTabs((prev) =>
          prev.map((t) =>
            t.id === activeTab.id
              ? {
                  ...t,
                  content: data.formatted,
                  isDirty: data.formatted !== t.originalContent,
                }
              : t
          )
        );

        setLastFormatDuration(data.durationMs);
        setLastFormatTime(new Date().toLocaleTimeString());

        addNotification(
          "success",
          "Prettier Format",
          `Formatted ${activeTab.name} in ${data.durationMs}ms.`
        );
        addOutputLog(
          "Prettier Formatter",
          `Formatted ${activeTab.path} with parser "${data.parser}" (${data.durationMs}ms).`
        );
      } else {
        addNotification("warning", "Prettier Syntax Warning", data.error);
        addOutputLog("Prettier Formatter", `Formatting error: ${data.error}`, "warn");
      }
    } catch (err: any) {
      addNotification("error", "Formatting Failed", err.message);
    }
  };

  // Checker commit
  const handleCheckerCommit = async (message: string) => {
    try {
      const res = await fetch("/api/checker/commit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message,
          stageAll: true,
        }),
      });
      const data = await res.json();

      if (data.success) {
        addNotification("success", "Checker Commit Created", data.message);
        addOutputLog(
          "Checker VCS",
          `Commit created [${data.commit.hash.slice(0, 7)}]: ${data.commit.message}`,
          "info"
        );
        refreshCheckerStatus();
      } else {
        addNotification("error", "Commit Failed", data.error);
      }
    } catch (err: any) {
      addNotification("error", "Commit Error", err.message);
    }
  };

  // Checker pull code
  const handleCheckerPull = async () => {
    try {
      addOutputLog("Checker VCS", "Pulling latest code and synchronizing via Checker...", "info");
      const res = await fetch("/api/checker/pull", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });
      const data = await res.json();

      if (data.success) {
        addNotification("success", "Checker Code Pulled", data.message);
        addOutputLog("Checker VCS", data.message, "info");
        refreshCheckerStatus();
        refreshFileTree();
      } else {
        addNotification("error", "Pull Failed", data.error);
      }
    } catch (err: any) {
      addNotification("error", "Pull Error", err.message);
    }
  };

  // Checker view diff
  const handleSelectFileDiff = async (file: string) => {
    try {
      const res = await fetch(`/api/checker/diff?file=${encodeURIComponent(file)}`);
      const data = await res.json();

      if (data.success && data.diffs && data.diffs.length > 0) {
        const diff = data.diffs[0];
        // Load working file content
        const fileRes = await fetch(`/api/files?action=read&path=${encodeURIComponent(file)}`);
        const fileData = await fileRes.json();

        setDiffMode({
          isOpen: true,
          original: `// Checker HEAD version of ${file}\n// Raw unified diff:\n${diff.rawUnified}`,
          modified: fileData.content || "",
          filePath: file,
        });
      } else {
        addNotification("info", "Diff Info", `No uncommitted changes in ${file}`);
      }
    } catch (err: any) {
      addNotification("error", "Diff Error", err.message);
    }
  };

  // Terminal run command
  const handleRunTerminalCommand = async (command: string) => {
    setIsTerminalRunning(true);
    addOutputLog("Tasks", `Executing: ${command}`, "info");

    try {
      const res = await fetch("/api/terminal", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ command }),
      });
      const data = await res.json();

      const entry: TerminalEntry = {
        id: `term_${Date.now()}`,
        command,
        output: data.output || (data.success ? "Done." : data.error),
        exitCode: data.exitCode,
        timestamp: new Date().toLocaleTimeString(),
        isError: !data.success,
      };

      setTerminalHistory((prev) => [...prev, entry]);
      addOutputLog("Tasks", `Completed with exit code ${data.exitCode} (${data.durationMs}ms).`);

      if (command.includes("checker") || command.includes("git")) {
        refreshCheckerStatus();
      }
    } catch (err: any) {
      setTerminalHistory((prev) => [
        ...prev,
        {
          id: `term_${Date.now()}`,
          command,
          output: err.message,
          exitCode: 1,
          timestamp: new Date().toLocaleTimeString(),
          isError: true,
        },
      ]);
    } finally {
      setIsTerminalRunning(false);
    }
  };

  // AI chat send
  const handleAiSendMessage = async (prompt: string, action?: string) => {
    const activeTab = tabs.find((t) => t.id === activeTabId);

    if (prompt) {
      setAiMessages((prev) => [
        ...prev,
        {
          id: `usr_${Date.now()}`,
          role: "user",
          content: prompt,
          timestamp: new Date().toLocaleTimeString(),
        },
      ]);
    }

    try {
      const res = await fetch("/api/ai", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt,
          action,
          activeFile: activeTab,
          diagnostics: problems,
          model: profile.aiModel,
        }),
      });
      const data = await res.json();

      if (data.success) {
        setAiMessages((prev) => [
          ...prev,
          {
            id: `ai_${Date.now()}`,
            role: "assistant",
            content: data.reply,
            codeSnippets: data.codeSnippets,
            timestamp: data.timestamp || new Date().toLocaleTimeString(),
          },
        ]);
        addOutputLog("AI Copilot", `AI generated response (${profile.aiModel}).`);
      }
    } catch (err: any) {
      addNotification("error", "AI Copilot Error", err.message);
    }
  };

  // Profile sync
  const handleSyncProfile = async (target: "local" | "localsqlserver" | "cloud") => {
    try {
      const res = await fetch("/api/profile", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ profile, syncTarget: target }),
      });
      const data = await res.json();
      if (data.success) {
        setProfile(data.profile);
        addNotification("success", "Profile Synced", data.message);
        addOutputLog("System", `Profile synced to ${target}.`);
      }
    } catch (err: any) {
      addNotification("error", "Sync Failed", err.message);
    }
  };

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "p") {
        e.preventDefault();
        setIsQuickOpenOpen((prev) => !prev);
      } else if ((e.metaKey || e.ctrlKey) && e.key === "b") {
        e.preventDefault();
        setSidebarMode((prev) => (prev ? null : "explorer"));
      } else if ((e.metaKey || e.ctrlKey) && e.key === "`") {
        e.preventDefault();
        setIsBottomOpen((prev) => !prev);
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  const activeTab = tabs.find((t) => t.id === activeTabId);

  return (
    <div
      id="studio-root"
      data-theme={profile.theme}
      className="w-screen h-screen flex flex-col bg-[#080b14] text-slate-100 overflow-hidden select-none font-sans"
    >
      {/* 1. Main Title Bar */}
      <header
        id="studio-titlebar"
        className="h-9 bg-[#070912] border-b border-white/10 flex items-center justify-between px-3 shrink-0"
      >
        {/* Left Window Dots & Logo */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 mr-1">
            <div className="w-3 h-3 rounded-full bg-rose-500/80 hover:bg-rose-500 cursor-pointer" />
            <div className="w-3 h-3 rounded-full bg-amber-500/80 hover:bg-amber-500 cursor-pointer" />
            <div className="w-3 h-3 rounded-full bg-emerald-500/80 hover:bg-emerald-500 cursor-pointer" />
          </div>

          <div className="flex items-center gap-1.5 font-bold text-xs tracking-wide">
            <div className="w-4 h-4 rounded bg-gradient-to-tr from-cyan-400 to-blue-600 flex items-center justify-center text-[10px] text-black font-extrabold shadow-sm">
              2
            </div>
            <span className="bg-gradient-to-r from-slate-100 via-cyan-200 to-blue-400 bg-clip-text text-transparent">
              2-TEK Studio
            </span>
          </div>

          {/* Breadcrumb Workspace name */}
          <div className="hidden md:flex items-center gap-1 text-[11px] text-slate-400 font-mono bg-white/5 px-2 py-0.5 rounded-full border border-white/5">
            <FolderOpen size={11} className="text-cyan-400" />
            <span>2tek-developement-packs</span>
          </div>
        </div>

        {/* Center: Command Search / Quick Open trigger */}
        <button
          id="titlebar-quick-open-btn"
          onClick={() => setIsQuickOpenOpen(true)}
          className="flex items-center justify-between w-64 md:w-96 px-3 py-1 rounded-lg bg-[#0e1424] border border-white/5 hover:border-cyan-500/40 text-xs text-slate-400 font-mono transition"
        >
          <div className="flex items-center gap-2">
            <Search size={13} className="text-cyan-400" />
            <span className="text-[11px] truncate">Quick Open files (Cmd+P)</span>
          </div>
          <kbd className="text-[10px] px-1 py-0.2 rounded bg-white/10 text-slate-300">⌘P</kbd>
        </button>

        {/* Right Action Icons */}
        <div className="flex items-center gap-1">
          {/* Prettier format quick trigger */}
          <button
            id="titlebar-format-btn"
            onClick={formatDocument}
            title="Format Document with Prettier (Shift+Alt+F)"
            className="p-1.5 text-slate-400 hover:text-pink-400 rounded hover:bg-white/5 transition"
          >
            <Paintbrush size={14} />
          </button>

          {/* Toggle Terminal Bottom Dock */}
          <button
            id="titlebar-toggle-terminal-btn"
            onClick={() => {
              setIsBottomOpen((prev) => !prev);
              setBottomTab("terminal");
            }}
            title="Toggle Terminal Dock (Cmd+`)"
            className={`p-1.5 rounded hover:bg-white/5 transition ${
              isBottomOpen && bottomTab === "terminal" ? "text-cyan-400" : "text-slate-400"
            }`}
          >
            <TerminalIcon size={14} />
          </button>

          {/* Toggle AI Copilot */}
          <button
            id="titlebar-toggle-ai-btn"
            onClick={() => setIsAiOpen((prev) => !prev)}
            title="Toggle 2-TEK AI Copilot"
            className={`flex items-center gap-1 px-2 py-1 rounded text-xs transition ${
              isAiOpen
                ? "bg-purple-950 text-purple-300 border border-purple-800"
                : "text-slate-300 hover:bg-white/5"
            }`}
          >
            <Sparkles size={13} className="text-cyan-400" />
            <span className="font-semibold text-[11px]">AI Copilot</span>
          </button>

          {/* Notifications Icon with Badge */}
          <button
            id="titlebar-notifications-btn"
            onClick={() => setIsNotificationsOpen(true)}
            title="Notifications"
            className="p-1.5 text-slate-400 hover:text-cyan-400 rounded hover:bg-white/5 relative transition"
          >
            <Bell size={14} />
            {notifications.length > 0 && (
              <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
            )}
          </button>
        </div>
      </header>

      {/* 2. Middle Body (Activity Bar + Sidebar + Editor + AI Panel) */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Activity Bar */}
        <aside
          id="activity-bar"
          className="w-12 bg-[#060810] border-r border-white/10 flex flex-col items-center py-2 shrink-0 select-none space-y-3"
        >
          {/* Explorer Tab */}
          <button
            id="activity-explorer-btn"
            title="Explorer (Files)"
            onClick={() =>
              setSidebarMode((prev) => (prev === "explorer" ? null : "explorer"))
            }
            className={`p-2.5 rounded-xl transition ${
              sidebarMode === "explorer"
                ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/30"
                : "text-slate-400 hover:text-slate-200 hover:bg-white/5"
            }`}
          >
            <Files size={18} />
          </button>

          {/* Checker VCS Tab */}
          <button
            id="activity-checker-btn"
            title="Checker Source Control"
            onClick={() =>
              setSidebarMode((prev) => (prev === "checker" ? null : "checker"))
            }
            className={`p-2.5 rounded-xl transition relative ${
              sidebarMode === "checker"
                ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/30"
                : "text-slate-400 hover:text-slate-200 hover:bg-white/5"
            }`}
          >
            <GitBranch size={18} />
            {checkerStatus && (checkerStatus.unstagedFiles.length > 0 || checkerStatus.stagedFiles.length > 0) && (
              <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-cyan-500 text-black text-[9px] font-bold flex items-center justify-center">
                {checkerStatus.unstagedFiles.length + checkerStatus.stagedFiles.length}
              </span>
            )}
          </button>

          {/* Profile & Sync Tab */}
          <button
            id="activity-profile-btn"
            title="Profile & Sync"
            onClick={() =>
              setSidebarMode((prev) => (prev === "profile" ? null : "profile"))
            }
            className={`p-2.5 rounded-xl transition ${
              sidebarMode === "profile"
                ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/30"
                : "text-slate-400 hover:text-slate-200 hover:bg-white/5"
            }`}
          >
            <UserCheck size={18} />
          </button>

          {/* Prettier Formatter Tab */}
          <button
            id="activity-prettier-btn"
            title="Prettier Formatter Settings"
            onClick={() =>
              setSidebarMode((prev) => (prev === "prettier" ? null : "prettier"))
            }
            className={`p-2.5 rounded-xl transition ${
              sidebarMode === "prettier"
                ? "bg-pink-500/20 text-pink-300 border border-pink-500/30"
                : "text-slate-400 hover:text-slate-200 hover:bg-white/5"
            }`}
          >
            <Paintbrush size={18} />
          </button>

          {/* Diagnostics / Problems shortcut */}
          <button
            id="activity-problems-btn"
            title="Toggle Problems View"
            onClick={() => {
              setIsBottomOpen(true);
              setBottomTab("problems");
            }}
            className="p-2.5 rounded-xl text-slate-400 hover:text-amber-400 hover:bg-white/5 transition relative mt-auto"
          >
            <AlertTriangle size={18} />
            {problems.length > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-amber-500 text-black text-[9px] font-bold flex items-center justify-center">
                {problems.length}
              </span>
            )}
          </button>
        </aside>

        {/* Primary Sidebar Content */}
        {sidebarMode && (
          <aside className="w-64 md:w-72 h-full flex flex-col shrink-0">
            {sidebarMode === "explorer" && (
              <SidebarExplorer
                tree={fileTree}
                activeFilePath={activeTab?.path}
                onOpenFile={openFile}
                onRefresh={refreshFileTree}
                onCreateFile={async (parent, name, isDir) => {
                  const full = parent ? `${parent}/${name}` : name;
                  await fetch("/api/files", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                      action: "create",
                      filePath: full,
                      isDirectory: isDir,
                    }),
                  });
                  refreshFileTree();
                  if (!isDir) openFile(full);
                }}
                onDeleteFile={async (path) => {
                  await fetch("/api/files", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ action: "delete", filePath: path }),
                  });
                  refreshFileTree();
                }}
              />
            )}

            {sidebarMode === "checker" && (
              <SidebarChecker
                status={checkerStatus}
                branches={branches}
                onCommit={handleCheckerCommit}
                onPullCode={handleCheckerPull}
                onRefresh={refreshCheckerStatus}
                onSelectFileDiff={handleSelectFileDiff}
                onExportChrPatch={() => {
                  // Export .chr patch
                  fetch("/api/checker/chr", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                      action: "export",
                      message: "Export .chr snapshot from 2-TEK Studio",
                    }),
                  })
                    .then((r) => r.json())
                    .then((res) => {
                      if (res.success) {
                        addNotification("success", "Exported .chr Patch", `Saved to ${res.savedPath}`);
                        refreshFileTree();
                      }
                    });
                }}
                onApplyChrPatch={() => {
                  handleCheckerPull();
                }}
                onSwitchBranch={async (b) => {
                  await fetch("/api/checker/branches", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ action: "switch", branchName: b }),
                  });
                  refreshCheckerStatus();
                }}
                onCreateBranch={async (b) => {
                  await fetch("/api/checker/branches", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ action: "create", branchName: b }),
                  });
                  refreshCheckerStatus();
                }}
              />
            )}

            {sidebarMode === "profile" && (
              <SidebarProfile
                profile={profile}
                onUpdateProfile={(up) => setProfile((prev) => ({ ...prev, ...up }))}
                onSyncProfile={handleSyncProfile}
              />
            )}

            {sidebarMode === "prettier" && (
              <SidebarPrettier
                config={prettierConfig}
                onUpdateConfig={(up) => setPrettierConfig((prev) => ({ ...prev, ...up }))}
                onFormatActiveFile={formatDocument}
                onFormatAllFiles={async () => {
                  addNotification("info", "Prettier", "Formatting workspace files...");
                  await handleRunTerminalCommand("npx prettier --write .");
                }}
                formatDurationMs={lastFormatDuration}
                lastFormattedTime={lastFormatTime}
              />
            )}
          </aside>
        )}

        {/* Center Main Editor Area + Bottom Dock */}
        <main className="flex-1 flex flex-col overflow-hidden bg-[#090d18]">
          <div className="flex-1 overflow-hidden">
            <EditorArea
              tabs={tabs}
              activeTabId={activeTabId}
              onSelectTab={(id) => {
                setActiveTabId(id);
                setDiffMode(null);
              }}
              onCloseTab={(id) => {
                setTabs((prev) => prev.filter((t) => t.id !== id));
                if (activeTabId === id) {
                  const remaining = tabs.filter((t) => t.id !== id);
                  setActiveTabId(remaining.length > 0 ? remaining[remaining.length - 1].id : null);
                }
              }}
              onNewScratchTab={() => {
                const scratchId = `scratch_${Date.now()}`;
                const newTab: EditorTab = {
                  id: scratchId,
                  name: `Untitled-${tabs.length + 1}.ts`,
                  path: `scratch/untitled-${tabs.length + 1}.ts`,
                  content: `// 2-TEK Studio Scratchpad\nexport function sampleTask() {\n  console.log("Hello from 2-TEK Studio!");\n}\n`,
                  originalContent: "",
                  isDirty: true,
                  language: "typescript",
                };
                setTabs((prev) => [...prev, newTab]);
                setActiveTabId(newTab.id);
              }}
              onChangeContent={(id, content) => {
                setTabs((prev) =>
                  prev.map((t) =>
                    t.id === id
                      ? { ...t, content, isDirty: content !== t.originalContent }
                      : t
                  )
                );
              }}
              onSaveFile={saveFile}
              onFormatDocument={formatDocument}
              prettierConfig={prettierConfig}
              formatOnSave={profile.formatOnSave}
              fontSize={profile.fontSize}
              tabSize={profile.tabSize}
              minimap={profile.minimap}
              theme={profile.theme}
              onDiagnosticsChange={(newProbs) => setProblems(newProbs)}
              diffMode={diffMode}
              onCloseDiff={() => setDiffMode(null)}
            />
          </div>

          {/* Bottom Dock Panel (Problems, Output, Terminal, Debug Console) */}
          <BottomPanel
            isOpen={isBottomOpen}
            onToggleOpen={() => setIsBottomOpen((prev) => !prev)}
            activeTab={bottomTab}
            onChangeTab={setBottomTab}
            problems={problems}
            onSelectProblem={(file, line, col) => {
              openFile(file);
              // Focus editor
            }}
            outputLogs={outputLogs}
            onClearOutput={(ch) =>
              setOutputLogs((prev) => prev.filter((l) => l.channel !== ch))
            }
            terminalHistory={terminalHistory}
            onRunTerminalCommand={handleRunTerminalCommand}
            onClearTerminal={() => setTerminalHistory([])}
            isTerminalExecuting={isTerminalRunning}
          />
        </main>

        {/* Right AI Copilot Chat Panel */}
        {isAiOpen && (
          <aside className="w-80 md:w-96 h-full flex flex-col shrink-0">
            <AiChatPanel
              messages={aiMessages}
              onSendMessage={handleAiSendMessage}
              activeFileName={activeTab?.name}
              selectedCode={activeTab?.content.slice(0, 300)}
              diagnostics={problems}
              currentModel={profile.aiModel}
              onSelectModel={(m) => setProfile((prev) => ({ ...prev, aiModel: m }))}
              onApplyCodeToEditor={(code) => {
                if (activeTab) {
                  setTabs((prev) =>
                    prev.map((t) =>
                      t.id === activeTab.id
                        ? { ...t, content: t.content + "\n" + code, isDirty: true }
                        : t
                    )
                  );
                  addNotification("info", "AI Code Inserted", "Added code snippet to editor.");
                }
              }}
              onClose={() => setIsAiOpen(false)}
            />
          </aside>
        )}
      </div>

      {/* 3. Bottom Status Bar */}
      <footer
        id="studio-statusbar"
        className="h-6 bg-[#05070e] border-t border-white/10 flex items-center justify-between px-3 text-[11px] font-mono text-slate-400 select-none shrink-0"
      >
        {/* Left indicators */}
        <div className="flex items-center gap-3">
          {/* Branch indicator */}
          <button
            onClick={() => setSidebarMode("checker")}
            className="flex items-center gap-1 text-cyan-400 hover:text-cyan-300 transition"
          >
            <GitBranch size={11} />
            <span>{checkerStatus?.branch || "main"}</span>
          </button>

          {/* Sync status */}
          <button
            onClick={handleCheckerPull}
            className="flex items-center gap-1 hover:text-slate-200 transition"
          >
            <span>↓0 ↑0</span>
          </button>

          {/* Problems counter */}
          <button
            onClick={() => {
              setIsBottomOpen(true);
              setBottomTab("problems");
            }}
            className="flex items-center gap-1.5 hover:text-slate-200 transition"
          >
            <span className="flex items-center gap-0.5 text-rose-400">
              ⊗ {problems.filter((p) => p.severity === "error").length}
            </span>
            <span className="flex items-center gap-0.5 text-amber-400">
              ⚠ {problems.filter((p) => p.severity === "warning").length}
            </span>
          </button>
        </div>

        {/* Right indicators */}
        <div className="flex items-center gap-3">
          <span>Ln 1, Col 1</span>
          <span>Spaces: {profile.tabSize}</span>
          <span>UTF-8</span>
          <span className="text-cyan-400 font-semibold">{activeTab?.language || "Plain Text"}</span>
          <button
            onClick={formatDocument}
            className="flex items-center gap-1 text-pink-400 hover:text-pink-300"
          >
            <Paintbrush size={10} />
            <span>Prettier</span>
          </button>
          <button
            onClick={() => setSidebarMode("profile")}
            className="hover:text-cyan-300"
          >
            {profile.name}
          </button>
          <button
            onClick={() => setIsNotificationsOpen(true)}
            className="hover:text-cyan-300"
          >
            <Bell size={11} />
          </button>
        </div>
      </footer>

      {/* Floating Modals and Drawers */}
      <NotificationDrawer
        notifications={notifications}
        isOpen={isNotificationsOpen}
        onClose={() => setIsNotificationsOpen(false)}
        onDismiss={(id) => setNotifications((prev) => prev.filter((n) => n.id !== id))}
        onClearAll={() => setNotifications([])}
      />

      <QuickOpenModal
        isOpen={isQuickOpenOpen}
        onClose={() => setIsQuickOpenOpen(false)}
        files={allFilePaths}
        onSelectFile={openFile}
      />
    </div>
  );
}
