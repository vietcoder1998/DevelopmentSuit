"use client";

import React from "react";
import { StudioNotification } from "./types";
import { CheckCircle2, AlertTriangle, AlertCircle, Info, X, Trash2, Bell } from "lucide-react";

interface Props {
  notifications: StudioNotification[];
  isOpen: boolean;
  onClose: () => void;
  onDismiss: (id: string) => void;
  onClearAll: () => void;
}

export function NotificationDrawer({
  notifications,
  isOpen,
  onClose,
  onDismiss,
  onClearAll,
}: Props) {
  if (!isOpen) return null;

  const renderIcon = (type: string) => {
    switch (type) {
      case "success":
        return <CheckCircle2 size={16} className="text-emerald-400" />;
      case "warning":
        return <AlertTriangle size={16} className="text-amber-400" />;
      case "error":
        return <AlertCircle size={16} className="text-rose-400" />;
      default:
        return <Info size={16} className="text-cyan-400" />;
    }
  };

  return (
    <div
      id="notification-drawer-backdrop"
      className="fixed inset-0 z-50 flex justify-end bg-black/50 backdrop-blur-sm animate-fade-in"
      onClick={onClose}
    >
      <div
        id="notification-drawer"
        className="w-96 h-full bg-[#0d1222] border-l border-white/10 flex flex-col shadow-2xl animate-slide-up"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-white/10 bg-[#080c18]">
          <div className="flex items-center gap-2">
            <Bell size={16} className="text-cyan-400" />
            <span className="font-semibold text-sm text-slate-100">Notifications</span>
            <span className="text-xs px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-400 border border-cyan-800">
              {notifications.length}
            </span>
          </div>
          <div className="flex items-center gap-1">
            {notifications.length > 0 && (
              <button
                id="clear-all-notifications-btn"
                onClick={onClearAll}
                title="Clear all notifications"
                className="p-1.5 text-slate-400 hover:text-rose-400 rounded hover:bg-white/5 transition"
              >
                <Trash2 size={15} />
              </button>
            )}
            <button
              id="close-notifications-btn"
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded hover:bg-white/5 transition"
            >
              <X size={16} />
            </button>
          </div>
        </div>

        {/* List */}
        <div className="flex-1 overflow-y-auto p-3 space-y-2.5">
          {notifications.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-500">
              <Bell size={32} className="mb-2 opacity-30" />
              <p className="text-sm">No notifications yet</p>
              <p className="text-xs text-slate-600 mt-1">
                Checker VCS, Prettier, and system events will appear here.
              </p>
            </div>
          ) : (
            notifications.map((item) => (
              <div
                key={item.id}
                className="p-3 rounded-lg border border-white/5 bg-[#12192c] hover:border-white/10 transition group relative"
              >
                <div className="flex items-start gap-2.5">
                  <div className="mt-0.5">{renderIcon(item.type)}</div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <h4 className="text-xs font-semibold text-slate-200">{item.title}</h4>
                      <span className="text-[10px] text-slate-500">{item.timestamp}</span>
                    </div>
                    <p className="text-xs text-slate-400 mt-1 leading-relaxed break-words">
                      {item.message}
                    </p>
                  </div>
                  <button
                    onClick={() => onDismiss(item.id)}
                    className="opacity-0 group-hover:opacity-100 text-slate-500 hover:text-slate-300 transition"
                  >
                    <X size={13} />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
