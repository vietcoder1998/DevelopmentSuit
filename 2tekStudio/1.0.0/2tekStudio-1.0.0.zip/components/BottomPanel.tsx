"use client";

import React, { useState } from "react";
import { ProblemsView } from "./ProblemsView";
import { OutputView, OutputLogItem } from "./OutputView";
import { TerminalView } from "./TerminalView";
import { DebugConsoleView } from "./DebugConsoleView";
import { ProblemItem, TerminalEntry } from "./types";
import {
  AlertTriangle,
  Terminal as TerminalIcon,
  FileText,
  Cpu,
  ChevronUp,
  ChevronDown,
  X,
  Maximize2,
  Minimize2,
} from "lucide-react";

export type BottomTabType = "problems" | "output" | "terminal" | "debug";

interface Props {
  isOpen: boolean;
  onToggleOpen: () => void;
  activeTab: BottomTabType;
  onChangeTab: (tab: BottomTabType) => void;
  problems: ProblemItem[];
  onSelectProblem: (file: string, line: number, column: number) => void;
  outputLogs: OutputLogItem[];
  onClearOutput: (channel: string) => void;
  terminalHistory: TerminalEntry[];
  onRunTerminalCommand: (command: string) => Promise<void>;
  onClearTerminal: () => void;
  isTerminalExecuting?: boolean;
}

export function BottomPanel({
  isOpen,
  onToggleOpen,
  activeTab,
  onChangeTab,
  problems,
  onSelectProblem,
  outputLogs,
  onClearOutput,
  terminalHistory,
  onRunTerminalCommand,
  onClearTerminal,
  isTerminalExecuting,
}: Props) {
  const [isMaximized, setIsMaximized] = useState(false);

  if (!isOpen) return null;

  const errorCount = problems.filter((p) => p.severity === "error").length;
  const warningCount = problems.filter((p) => p.severity === "warning").length;

  return (
    <div
      id="bottom-dock-panel"
      className={`border-t border-white/10 bg-[#090d18] flex flex-col transition-all duration-150 ${
        isMaximized ? "h-[80vh]" : "h-64"
      }`}
    >
      {/* Tabs Header */}
      <div className="flex items-center justify-between px-3 border-b border-white/10 bg-[#070912] select-none text-xs">
        <div className="flex items-center gap-1">
          {/* Problems Tab */}
          <button
            id="tab-problems-btn"
            onClick={() => onChangeTab("problems")}
            className={`flex items-center gap-1.5 px-3 py-2 border-b-2 font-medium transition ${
              activeTab === "problems"
                ? "border-cyan-400 text-cyan-300 bg-white/5"
                : "border-transparent text-slate-400 hover:text-slate-200"
            }`}
          >
            <AlertTriangle size={13} className={errorCount > 0 ? "text-rose-400" : "text-amber-400"} />
            <span>Problems</span>
            {(errorCount > 0 || warningCount > 0) && (
              <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-white/10 font-mono">
                {errorCount}E {warningCount}W
              </span>
            )}
          </button>

          {/* Output Tab */}
          <button
            id="tab-output-btn"
            onClick={() => onChangeTab("output")}
            className={`flex items-center gap-1.5 px-3 py-2 border-b-2 font-medium transition ${
              activeTab === "output"
                ? "border-cyan-400 text-cyan-300 bg-white/5"
                : "border-transparent text-slate-400 hover:text-slate-200"
            }`}
          >
            <FileText size={13} />
            <span>Output</span>
          </button>

          {/* Terminal Tab */}
          <button
            id="tab-terminal-btn"
            onClick={() => onChangeTab("terminal")}
            className={`flex items-center gap-1.5 px-3 py-2 border-b-2 font-medium transition ${
              activeTab === "terminal"
                ? "border-cyan-400 text-cyan-300 bg-white/5"
                : "border-transparent text-slate-400 hover:text-slate-200"
            }`}
          >
            <TerminalIcon size={13} />
            <span>Terminal</span>
          </button>

          {/* Debug Console Tab */}
          <button
            id="tab-debug-btn"
            onClick={() => onChangeTab("debug")}
            className={`flex items-center gap-1.5 px-3 py-2 border-b-2 font-medium transition ${
              activeTab === "debug"
                ? "border-cyan-400 text-cyan-300 bg-white/5"
                : "border-transparent text-slate-400 hover:text-slate-200"
            }`}
          >
            <Cpu size={13} />
            <span>Debug Console</span>
          </button>
        </div>

        {/* Panel controls */}
        <div className="flex items-center gap-1">
          <button
            onClick={() => setIsMaximized((prev) => !prev)}
            title={isMaximized ? "Restore panel size" : "Maximize panel"}
            className="p-1 text-slate-400 hover:text-white rounded hover:bg-white/5"
          >
            {isMaximized ? <Minimize2 size={13} /> : <Maximize2 size={13} />}
          </button>
          <button
            onClick={onToggleOpen}
            title="Close panel"
            className="p-1 text-slate-400 hover:text-white rounded hover:bg-white/5"
          >
            <X size={14} />
          </button>
        </div>
      </div>

      {/* Tab Panels Content */}
      <div className="flex-1 overflow-hidden">
        {activeTab === "problems" && (
          <ProblemsView problems={problems} onSelectProblem={onSelectProblem} />
        )}
        {activeTab === "output" && (
          <OutputView logs={outputLogs} onClear={onClearOutput} />
        )}
        {activeTab === "terminal" && (
          <TerminalView
            history={terminalHistory}
            onRunCommand={onRunTerminalCommand}
            onClear={onClearTerminal}
            isExecuting={isTerminalExecuting}
          />
        )}
        {activeTab === "debug" && <DebugConsoleView onClear={() => {}} />}
      </div>
    </div>
  );
}
