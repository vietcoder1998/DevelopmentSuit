"use client";

import React, { useState } from "react";
import { PrettierConfig } from "./types";
import { Paintbrush, Check, FileCheck, Sliders, Zap, Clock } from "lucide-react";

interface Props {
  config: PrettierConfig;
  onUpdateConfig: (updated: Partial<PrettierConfig>) => void;
  onFormatActiveFile: () => Promise<void>;
  onFormatAllFiles: () => Promise<void>;
  lastFormattedTime?: string;
  formatDurationMs?: number;
}

export function SidebarPrettier({
  config,
  onUpdateConfig,
  onFormatActiveFile,
  onFormatAllFiles,
  lastFormattedTime,
  formatDurationMs,
}: Props) {
  const [isFormatting, setIsFormatting] = useState(false);

  const handleFormatFile = async () => {
    setIsFormatting(true);
    try {
      await onFormatActiveFile();
    } finally {
      setIsFormatting(false);
    }
  };

  return (
    <div id="sidebar-prettier" className="h-full flex flex-col bg-[#0b0f1d] border-r border-white/5 select-none text-xs font-mono">
      {/* Header */}
      <div className="flex items-center justify-between px-3 py-2 border-b border-white/10 text-xs font-semibold uppercase tracking-wider text-slate-400">
        <div className="flex items-center gap-1.5">
          <Paintbrush size={14} className="text-pink-400" />
          <span>Prettier Formatter</span>
        </div>
        <span className="text-[10px] px-1.5 py-0.5 rounded bg-pink-950/80 text-pink-300 border border-pink-800/60">
          v3.9.9
        </span>
      </div>

      <div className="flex-1 overflow-y-auto p-3 space-y-4 font-sans">
        {/* Quick Format Action */}
        <div className="p-3 rounded-xl bg-gradient-to-br from-[#1b1226] to-[#0f1124] border border-pink-500/20 space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="font-semibold text-slate-200 text-xs">Code Beautifier</span>
            <span className="text-[10px] text-pink-400 font-mono">Shift+Alt+F</span>
          </div>

          <button
            id="prettier-format-active-btn"
            onClick={handleFormatFile}
            disabled={isFormatting}
            className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-lg text-xs font-semibold bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500 text-white transition shadow-lg shadow-pink-950/40"
          >
            <Zap size={14} />
            <span>{isFormatting ? "Formatting..." : "Format Active File"}</span>
          </button>

          {formatDurationMs !== undefined && (
            <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono pt-1">
              <span className="flex items-center gap-1">
                <Clock size={11} /> {formatDurationMs}ms
              </span>
              <span>{lastFormattedTime || "Clean"}</span>
            </div>
          )}
        </div>

        {/* Configuration rules */}
        <div className="space-y-2">
          <label className="text-slate-400 font-semibold flex items-center gap-1.5 text-[11px]">
            <Sliders size={13} className="text-pink-400" />
            <span>Prettier Code Style Rules</span>
          </label>

          <div className="space-y-2.5 bg-[#0e1424] p-3 rounded-lg border border-white/5 text-xs font-mono">
            {/* Semicolons */}
            <div className="flex items-center justify-between">
              <span className="text-slate-300">Semicolons (semi)</span>
              <input
                id="prettier-semi-toggle"
                type="checkbox"
                checked={config.semi}
                onChange={(e) => onUpdateConfig({ semi: e.target.checked })}
                className="w-4 h-4 rounded accent-pink-500 cursor-pointer"
              />
            </div>

            {/* Single Quote */}
            <div className="flex items-center justify-between">
              <span className="text-slate-300">Single Quotes</span>
              <input
                id="prettier-single-quote-toggle"
                type="checkbox"
                checked={config.singleQuote}
                onChange={(e) => onUpdateConfig({ singleQuote: e.target.checked })}
                className="w-4 h-4 rounded accent-pink-500 cursor-pointer"
              />
            </div>

            {/* Tab Width */}
            <div className="flex items-center justify-between">
              <span className="text-slate-300">Tab Width</span>
              <select
                value={config.tabWidth}
                onChange={(e) => onUpdateConfig({ tabWidth: Number(e.target.value) })}
                className="bg-[#172038] border border-white/10 rounded px-2 py-0.5 text-slate-200 outline-none text-xs"
              >
                <option value={2}>2 Spaces</option>
                <option value={4}>4 Spaces</option>
              </select>
            </div>

            {/* Trailing Comma */}
            <div className="flex items-center justify-between">
              <span className="text-slate-300">Trailing Comma</span>
              <select
                value={config.trailingComma}
                onChange={(e) => onUpdateConfig({ trailingComma: e.target.value as any })}
                className="bg-[#172038] border border-white/10 rounded px-2 py-0.5 text-slate-200 outline-none text-xs"
              >
                <option value="es5">ES5</option>
                <option value="all">All</option>
                <option value="none">None</option>
              </select>
            </div>

            {/* Print Width */}
            <div className="flex items-center justify-between">
              <span className="text-slate-300">Print Width</span>
              <select
                value={config.printWidth}
                onChange={(e) => onUpdateConfig({ printWidth: Number(e.target.value) })}
                className="bg-[#172038] border border-white/10 rounded px-2 py-0.5 text-slate-200 outline-none text-xs"
              >
                <option value={80}>80 cols</option>
                <option value={100}>100 cols</option>
                <option value={120}>120 cols</option>
              </select>
            </div>
          </div>
        </div>

        {/* Supported Languages */}
        <div className="p-3 bg-[#0a0e1c] rounded-lg border border-white/5 space-y-1.5 text-slate-400 text-[11px]">
          <span className="font-semibold text-slate-300 block">Supported Languages:</span>
          <div className="flex flex-wrap gap-1 font-mono text-[10px]">
            {["TypeScript", "TSX", "JavaScript", "JSON", "CSS", "HTML", "Markdown", "YAML"].map((lang) => (
              <span key={lang} className="px-1.5 py-0.5 rounded bg-white/5 text-slate-300">
                {lang}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
