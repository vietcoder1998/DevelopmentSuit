export type EditorLanguage =
  | "typescript"
  | "javascript"
  | "json"
  | "css"
  | "html"
  | "sql"
  | "markdown"
  | "yaml"
  | "shell"
  | "plaintext";

export interface EditorTab {
  id: string;
  name: string;
  path: string;
  content: string;
  originalContent: string;
  isDirty: boolean;
  language: EditorLanguage;
  icon?: string;
}

export type ProblemSeverity = "error" | "warning" | "info";

export interface ProblemItem {
  id: string;
  file: string;
  message: string;
  severity: ProblemSeverity;
  line: number;
  column: number;
  rule?: string;
  source?: string;
}

export interface CheckerStatusSummary {
  isRepository: boolean;
  repoPath: string;
  branch: string;
  stagedFiles: string[];
  unstagedFiles: string[];
  untrackedFiles: string[];
  modifiedFiles: string[];
  ahead: number;
  behind: number;
  lastCommitHash?: string;
  lastCommitMessage?: string;
}

export interface CheckerFileDiff {
  filePath: string;
  additions: number;
  deletions: number;
  rawUnified: string;
}

export interface TerminalEntry {
  id: string;
  command: string;
  output: string;
  exitCode: number;
  timestamp: string;
  isError: boolean;
  cwd?: string;
}

export type StudioTheme = "dark-modern" | "cyberpunk" | "monokai" | "cobalt";

export interface UserProfileConfig {
  id: string;
  name: string;
  theme: StudioTheme;
  fontSize: number;
  tabSize: number;
  formatOnSave: boolean;
  minimap: boolean;
  wordWrap: boolean;
  aiModel: string;
  lastSynced?: string;
  syncSource?: "local" | "localsqlserver" | "cloud";
}

export interface PrettierConfig {
  semi: boolean;
  singleQuote: boolean;
  tabWidth: number;
  trailingComma: "all" | "es5" | "none";
  printWidth: number;
}

export type NotificationType = "info" | "success" | "warning" | "error";

export interface StudioNotification {
  id: string;
  type: NotificationType;
  title: string;
  message: string;
  timestamp: string;
  actionLabel?: string;
  actionPayload?: string;
}

export interface AiChatMessage {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
  codeSnippets?: Array<{
    language: string;
    code: string;
    fileName?: string;
  }>;
  timestamp: string;
}

export interface FileTreeNode {
  name: string;
  path: string;
  isDirectory: boolean;
  sizeBytes?: number;
  children?: FileTreeNode[];
}
