"use client";

import React, { useState } from "react";
import { CheckerStatusSummary } from "./types";
import {
  GitBranch,
  GitCommit,
  GitPullRequest,
  Check,
  Plus,
  Minus,
  RefreshCw,
  Download,
  Upload,
  FileCode,
  FilePlus,
  FileMinus,
  FileEdit,
  ArrowDownLeft,
  Sparkles,
} from "lucide-react";

interface Props {
  status: CheckerStatusSummary | null;
  onCommit: (message: string) => Promise<void>;
  onPullCode: () => Promise<void>;
  onRefresh: () => void;
  onSelectFileDiff: (path: string) => void;
  onExportChrPatch: () => void;
  onApplyChrPatch: () => void;
  onSwitchBranch: (branch: string) => void;
  onCreateBranch: (branch: string) => void;
  branches: Array<{ name: string; isCurrent: boolean }>;
}

export function SidebarChecker({
  status,
  onCommit,
  onPullCode,
  onRefresh,
  onSelectFileDiff,
  onExportChrPatch,
  onApplyChrPatch,
  onSwitchBranch,
  onCreateBranch,
  branches,
}: Props) {
  const [commitMessage, setCommitMessage] = useState("");
  const [isCommitting, setIsCommitting] = useState(false);
  const [isPulling, setIsPulling] = useState(false);
  const [isBranchModalOpen, setIsBranchModalOpen] = useState(false);
  const [newBranchName, setNewBranchName] = useState("");

  const handleCommitSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!commitMessage.trim() || isCommitting) return;
    setIsCommitting(true);
    try {
      await onCommit(commitMessage.trim());
      setCommitMessage("");
    } finally {
      setIsCommitting(false);
    }
  };

  const handlePullClick = async () => {
    setIsPulling(true);
    try {
      await onPullCode();
    } finally {
      setIsPulling(false);
    }
  };

  const totalChanges =
    (status?.stagedFiles.length || 0) +
    (status?.unstagedFiles.length || 0) +
    (status?.untrackedFiles.length || 0);

  return (
    <div id="sidebar-checker" className="h-full flex flex-col bg-[#0b0f1d] border-r border-white/5 select-none font-mono">
      {/* Header */}
      <div className="flex items-center justify-between px-3 py-2 border-b border-white/10 text-xs font-semibold uppercase tracking-wider text-slate-400">
        <div className="flex items-center gap-1.5">
          <GitBranch size={14} className="text-cyan-400" />
          <span>Checker Source Control</span>
        </div>
        <div className="flex items-center gap-1">
          <button
            id="checker-pull-btn"
            title="Pull Code via Checker"
            onClick={handlePullClick}
            disabled={isPulling}
            className="p-1 text-slate-400 hover:text-cyan-400 rounded hover:bg-white/5 transition flex items-center gap-1 text-[11px]"
          >
            <Download size={13} className={isPulling ? "animate-bounce" : ""} />
          </button>
          <button
            id="checker-refresh-btn"
            title="Refresh Status"
            onClick={onRefresh}
            className="p-1 text-slate-400 hover:text-cyan-400 rounded hover:bg-white/5"
          >
            <RefreshCw size={13} />
          </button>
        </div>
      </div>

      {/* Branch selector & Actions */}
      <div className="p-3 border-b border-white/5 bg-[#090d18] space-y-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-[11px] text-slate-400">Branch:</span>
            <select
              id="checker-branch-select"
              value={status?.branch || "main"}
              onChange={(e) => onSwitchBranch(e.target.value)}
              className="bg-[#131b2e] border border-white/10 rounded px-2 py-0.5 text-xs text-cyan-300 font-mono outline-none"
            >
              {branches.length > 0 ? (
                branches.map((b) => (
                  <option key={b.name} value={b.name}>
                    {b.name} {b.isCurrent ? "✓" : ""}
                  </option>
                ))
              ) : (
                <option value={status?.branch || "main"}>{status?.branch || "main"}</option>
              )}
            </select>
          </div>

          <button
            id="create-branch-toggle-btn"
            onClick={() => setIsBranchModalOpen(true)}
            title="Create new branch"
            className="text-[11px] text-cyan-400 hover:text-cyan-300 flex items-center gap-1 bg-cyan-950/60 px-1.5 py-0.5 rounded border border-cyan-800/50"
          >
            <Plus size={11} /> New
          </button>
        </div>

        {/* Action Buttons: Pull Code & .chr Patch */}
        <div className="grid grid-cols-2 gap-1.5 pt-1">
          <button
            id="pull-code-action-btn"
            onClick={handlePullClick}
            disabled={isPulling}
            className="flex items-center justify-center gap-1 px-2 py-1 rounded text-[11px] bg-cyan-950/70 hover:bg-cyan-900/90 text-cyan-300 border border-cyan-700/50 transition font-sans"
          >
            <ArrowDownLeft size={13} />
            <span>{isPulling ? "Pulling..." : "Pull Code"}</span>
          </button>

          <button
            id="export-chr-patch-btn"
            onClick={onExportChrPatch}
            className="flex items-center justify-center gap-1 px-2 py-1 rounded text-[11px] bg-purple-950/60 hover:bg-purple-900/80 text-purple-300 border border-purple-800/50 transition font-sans"
          >
            <Upload size={12} />
            <span>Export .chr</span>
          </button>
        </div>
      </div>

      {/* Commit Box */}
      <form onSubmit={handleCommitSubmit} className="p-3 border-b border-white/5 space-y-2">
        <textarea
          id="checker-commit-message-input"
          placeholder="Message (Cmd+Enter to commit to Checker)"
          rows={3}
          value={commitMessage}
          onChange={(e) => setCommitMessage(e.target.value)}
          onKeyDown={(e) => {
            if ((e.metaKey || e.ctrlKey) && e.key === "Enter") {
              handleCommitSubmit(e);
            }
          }}
          className="w-full bg-[#111728] border border-white/10 rounded-lg p-2 text-xs text-slate-100 placeholder-slate-500 outline-none focus:border-cyan-500/50 resize-none font-mono"
        />

        <button
          id="checker-commit-submit-btn"
          type="submit"
          disabled={!commitMessage.trim() || isCommitting || totalChanges === 0}
          className="w-full flex items-center justify-center gap-1.5 py-1.5 px-3 rounded-lg text-xs font-semibold bg-cyan-600 hover:bg-cyan-500 disabled:opacity-40 disabled:hover:bg-cyan-600 text-white transition font-sans shadow-lg shadow-cyan-950/40"
        >
          <GitCommit size={14} />
          <span>{isCommitting ? "Committing..." : `Commit (${totalChanges} changes)`}</span>
        </button>
      </form>

      {/* Changes list */}
      <div className="flex-1 overflow-y-auto p-2 space-y-3">
        {/* Staged Changes */}
        {status?.stagedFiles && status.stagedFiles.length > 0 && (
          <div>
            <div className="flex items-center justify-between text-[11px] font-semibold text-emerald-400 px-1 mb-1">
              <span>STAGED CHANGES ({status.stagedFiles.length})</span>
            </div>
            <div className="space-y-0.5">
              {status.stagedFiles.map((file) => (
                <div
                  key={file}
                  onClick={() => onSelectFileDiff(file)}
                  className="flex items-center justify-between px-2 py-1 rounded text-xs hover:bg-white/5 cursor-pointer text-slate-300 transition group"
                >
                  <div className="flex items-center gap-1.5 truncate">
                    <FileEdit size={13} className="text-emerald-400 shrink-0" />
                    <span className="truncate">{file}</span>
                  </div>
                  <span className="text-[10px] text-emerald-400 font-bold">S</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Unstaged Changes */}
        <div>
          <div className="flex items-center justify-between text-[11px] font-semibold text-amber-400 px-1 mb-1">
            <span>CHANGES ({status?.unstagedFiles.length || 0})</span>
          </div>
          {status?.unstagedFiles && status.unstagedFiles.length > 0 ? (
            <div className="space-y-0.5">
              {status.unstagedFiles.map((file) => (
                <div
                  key={file}
                  onClick={() => onSelectFileDiff(file)}
                  className="flex items-center justify-between px-2 py-1 rounded text-xs hover:bg-white/5 cursor-pointer text-slate-300 transition group"
                >
                  <div className="flex items-center gap-1.5 truncate">
                    <FileEdit size={13} className="text-amber-400 shrink-0" />
                    <span className="truncate">{file}</span>
                  </div>
                  <span className="text-[10px] text-amber-400 font-bold">M</span>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-[11px] text-slate-600 px-2 py-1">No modified files</div>
          )}
        </div>

        {/* Untracked files */}
        {status?.untrackedFiles && status.untrackedFiles.length > 0 && (
          <div>
            <div className="flex items-center justify-between text-[11px] font-semibold text-cyan-400 px-1 mb-1">
              <span>UNTRACKED ({status.untrackedFiles.length})</span>
            </div>
            <div className="space-y-0.5">
              {status.untrackedFiles.map((file) => (
                <div
                  key={file}
                  onClick={() => onSelectFileDiff(file)}
                  className="flex items-center justify-between px-2 py-1 rounded text-xs hover:bg-white/5 cursor-pointer text-slate-400 transition group"
                >
                  <div className="flex items-center gap-1.5 truncate">
                    <FilePlus size={13} className="text-cyan-400 shrink-0" />
                    <span className="truncate">{file}</span>
                  </div>
                  <span className="text-[10px] text-cyan-400 font-bold">U</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* New Branch Modal */}
      {isBranchModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm bg-[#0e1424] border border-cyan-500/40 rounded-xl p-4 shadow-2xl space-y-3 font-sans">
            <h3 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
              <GitBranch size={16} className="text-cyan-400" />
              Create Checker Branch
            </h3>
            <input
              type="text"
              autoFocus
              placeholder="e.g. feature/ai-editor-upgrade"
              value={newBranchName}
              onChange={(e) => setNewBranchName(e.target.value)}
              className="w-full bg-[#161d31] border border-white/10 rounded-lg px-3 py-2 text-xs text-slate-100 outline-none font-mono"
            />
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => {
                  setIsBranchModalOpen(false);
                  setNewBranchName("");
                }}
                className="px-3 py-1.5 text-xs text-slate-400 hover:text-white rounded"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  if (newBranchName.trim()) {
                    onCreateBranch(newBranchName.trim());
                    setIsBranchModalOpen(false);
                    setNewBranchName("");
                  }
                }}
                className="px-3 py-1.5 text-xs bg-cyan-600 hover:bg-cyan-500 text-white rounded font-medium"
              >
                Create & Switch
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
