"use client";

import React, { useState } from "react";
import { FileTreeNode } from "./types";
import {
  ChevronRight,
  ChevronDown,
  Folder,
  FolderOpen,
  FileCode,
  FileText,
  FileJson,
  FileSpreadsheet,
  File,
  Plus,
  RefreshCw,
  Trash2,
  GitBranch,
} from "lucide-react";

interface Props {
  tree: FileTreeNode[];
  activeFilePath?: string;
  onOpenFile: (path: string) => void;
  onRefresh: () => void;
  onCreateFile: (parentPath: string, name: string, isDir: boolean) => void;
  onDeleteFile: (path: string) => void;
}

export function SidebarExplorer({
  tree,
  activeFilePath,
  onOpenFile,
  onRefresh,
  onCreateFile,
  onDeleteFile,
}: Props) {
  const [collapsedPaths, setCollapsedPaths] = useState<Set<string>>(new Set());
  const [isCreating, setIsCreating] = useState<{ parentPath: string; isDir: boolean } | null>(null);
  const [newItemName, setNewItemName] = useState("");

  const toggleFolder = (folderPath: string) => {
    setCollapsedPaths((prev) => {
      const next = new Set(prev);
      if (next.has(folderPath)) {
        next.delete(folderPath);
      } else {
        next.add(folderPath);
      }
      return next;
    });
  };

  const renderFileIcon = (fileName: string) => {
    const ext = fileName.split(".").pop()?.toLowerCase();
    switch (ext) {
      case "ts":
      case "tsx":
        return <FileCode size={14} className="text-blue-400 shrink-0" />;
      case "js":
      case "jsx":
      case "mjs":
        return <FileCode size={14} className="text-amber-400 shrink-0" />;
      case "json":
        return <FileJson size={14} className="text-yellow-500 shrink-0" />;
      case "css":
        return <FileText size={14} className="text-cyan-400 shrink-0" />;
      case "chr":
        return <GitBranch size={14} className="text-emerald-400 shrink-0" />;
      case "md":
        return <FileText size={14} className="text-purple-400 shrink-0" />;
      case "sql":
        return <FileSpreadsheet size={14} className="text-rose-400 shrink-0" />;
      default:
        return <File size={14} className="text-slate-400 shrink-0" />;
    }
  };

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItemName.trim() || !isCreating) return;
    onCreateFile(isCreating.parentPath, newItemName.trim(), isCreating.isDir);
    setIsCreating(null);
    setNewItemName("");
  };

  const renderNode = (node: FileTreeNode, depth = 0) => {
    const isCollapsed = collapsedPaths.has(node.path);
    const isActive = activeFilePath === node.path;
    const paddingLeft = `${depth * 14 + 10}px`;

    if (node.isDirectory) {
      return (
        <div key={node.path}>
          <div
            onClick={() => toggleFolder(node.path)}
            style={{ paddingLeft }}
            className="flex items-center justify-between py-1 px-2 hover:bg-white/5 cursor-pointer rounded text-xs text-slate-300 font-mono transition group"
          >
            <div className="flex items-center gap-1.5 min-w-0">
              {isCollapsed ? (
                <ChevronRight size={13} className="text-slate-500 shrink-0" />
              ) : (
                <ChevronDown size={13} className="text-slate-500 shrink-0" />
              )}
              {isCollapsed ? (
                <Folder size={14} className="text-amber-400/80 shrink-0" />
              ) : (
                <FolderOpen size={14} className="text-amber-400 shrink-0" />
              )}
              <span className="truncate font-medium">{node.name}</span>
            </div>

            <div className="opacity-0 group-hover:opacity-100 flex items-center gap-1">
              <button
                title="New file inside folder"
                onClick={(e) => {
                  e.stopPropagation();
                  setIsCreating({ parentPath: node.path, isDir: false });
                }}
                className="p-0.5 text-slate-400 hover:text-cyan-300 rounded"
              >
                <Plus size={12} />
              </button>
            </div>
          </div>

          {!isCollapsed && node.children && (
            <div>
              {node.children.map((child) => renderNode(child, depth + 1))}
              {isCreating && isCreating.parentPath === node.path && (
                <form
                  onSubmit={handleCreateSubmit}
                  style={{ paddingLeft: `${(depth + 1) * 14 + 10}px` }}
                  className="py-1 pr-2"
                >
                  <input
                    autoFocus
                    type="text"
                    placeholder={isCreating.isDir ? "Folder name..." : "File name..."}
                    value={newItemName}
                    onChange={(e) => setNewItemName(e.target.value)}
                    onBlur={() => setIsCreating(null)}
                    className="w-full bg-[#161d31] border border-cyan-500/50 rounded px-1.5 py-0.5 text-xs text-slate-100 outline-none font-mono"
                  />
                </form>
              )}
            </div>
          )}
        </div>
      );
    }

    return (
      <div
        key={node.path}
        onClick={() => onOpenFile(node.path)}
        style={{ paddingLeft }}
        className={`flex items-center justify-between py-1 px-2 cursor-pointer rounded text-xs font-mono transition group ${
          isActive
            ? "bg-cyan-500/15 text-cyan-200 border-l-2 border-cyan-400"
            : "text-slate-400 hover:bg-white/5 hover:text-slate-200"
        }`}
      >
        <div className="flex items-center gap-1.5 min-w-0">
          <span className="w-3" />
          {renderFileIcon(node.name)}
          <span className="truncate">{node.name}</span>
        </div>

        <button
          title="Delete file"
          onClick={(e) => {
            e.stopPropagation();
            if (confirm(`Delete ${node.name}?`)) {
              onDeleteFile(node.path);
            }
          }}
          className="opacity-0 group-hover:opacity-100 p-0.5 text-slate-500 hover:text-rose-400 rounded transition"
        >
          <Trash2 size={12} />
        </button>
      </div>
    );
  };

  return (
    <div id="sidebar-explorer" className="h-full flex flex-col bg-[#0b0f1d] border-r border-white/5 select-none">
      {/* Top Header */}
      <div className="flex items-center justify-between px-3 py-2 border-b border-white/10 text-xs font-semibold uppercase tracking-wider text-slate-400">
        <span className="truncate">Workspace Explorer</span>
        <div className="flex items-center gap-1">
          <button
            id="explorer-new-file-btn"
            title="New File in Root"
            onClick={() => setIsCreating({ parentPath: "", isDir: false })}
            className="p-1 text-slate-400 hover:text-cyan-400 rounded hover:bg-white/5"
          >
            <Plus size={14} />
          </button>
          <button
            id="explorer-refresh-btn"
            title="Refresh Files"
            onClick={onRefresh}
            className="p-1 text-slate-400 hover:text-cyan-400 rounded hover:bg-white/5"
          >
            <RefreshCw size={13} />
          </button>
        </div>
      </div>

      {/* Tree Content */}
      <div className="flex-1 overflow-y-auto p-1 py-2">
        {isCreating && isCreating.parentPath === "" && (
          <form onSubmit={handleCreateSubmit} className="px-2 py-1">
            <input
              autoFocus
              type="text"
              placeholder={isCreating.isDir ? "Folder name..." : "File name..."}
              value={newItemName}
              onChange={(e) => setNewItemName(e.target.value)}
              onBlur={() => setIsCreating(null)}
              className="w-full bg-[#161d31] border border-cyan-500/50 rounded px-1.5 py-0.5 text-xs text-slate-100 outline-none font-mono"
            />
          </form>
        )}

        {tree.length === 0 ? (
          <div className="p-4 text-center text-xs text-slate-500">
            No files in workspace or loading...
          </div>
        ) : (
          tree.map((node) => renderNode(node))
        )}
      </div>
    </div>
  );
}
