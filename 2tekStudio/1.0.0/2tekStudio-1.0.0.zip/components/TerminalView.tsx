"use client";

import React, { useState, useRef, useEffect } from "react";
import { TerminalEntry } from "./types";
import { Terminal as TerminalIcon, Play, Trash2, CheckCircle2, XCircle } from "lucide-react";

interface Props {
  history: TerminalEntry[];
  onRunCommand: (command: string) => Promise<void>;
  onClear: () => void;
  isExecuting?: boolean;
}

export function TerminalView({ history, onRunCommand, onClear, isExecuting }: Props) {
  const [inputCommand, setInputCommand] = useState("");
  const terminalEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    terminalEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [history, isExecuting]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputCommand.trim() || isExecuting) return;
    const cmd = inputCommand.trim();
    setInputCommand("");
    onRunCommand(cmd);
  };

  const quickCommands = [
    { label: "checker status", cmd: "node packages/checker/bin/checker.mjs status" },
    { label: "checker diff", cmd: "node packages/checker/bin/checker.mjs diff" },
    { label: "checker log", cmd: "node packages/checker/bin/checker.mjs log --max 5" },
    { label: "prettier check", cmd: "npx prettier --check ." },
    { label: "npm run dev", cmd: "npm run dev" },
    { label: "git status", cmd: "git status -s" },
  ];

  return (
    <div
      id="terminal-view"
      className="h-full flex flex-col font-mono text-xs bg-[#080c16] select-text"
      onClick={() => inputRef.current?.focus()}
    >
      {/* Top Quick Actions Bar */}
      <div className="flex items-center justify-between px-3 py-1.5 border-b border-white/5 bg-[#060810] text-[11px] select-none">
        <div className="flex items-center gap-1.5 overflow-x-auto py-0.5">
          <span className="text-slate-500 text-[10px] uppercase font-bold tracking-wider shrink-0">
            Quick Run:
          </span>
          {quickCommands.map((qc) => (
            <button
              key={qc.label}
              onClick={(e) => {
                e.stopPropagation();
                onRunCommand(qc.cmd);
              }}
              disabled={isExecuting}
              className="px-2 py-0.5 rounded bg-white/5 hover:bg-cyan-950 hover:text-cyan-300 text-slate-400 border border-white/5 transition shrink-0"
            >
              {qc.label}
            </button>
          ))}
        </div>

        <button
          onClick={(e) => {
            e.stopPropagation();
            onClear();
          }}
          className="p-1 text-slate-400 hover:text-rose-400 rounded flex items-center gap-1 shrink-0 ml-2"
        >
          <Trash2 size={12} />
          <span>Clear</span>
        </button>
      </div>

      {/* Terminal History */}
      <div className="flex-1 overflow-y-auto p-3 space-y-3 font-mono leading-relaxed">
        {history.length === 0 && (
          <div className="text-slate-500 italic select-none">
            2-TEK Studio Interactive Terminal. Type commands or click quick actions above.
          </div>
        )}

        {history.map((entry) => (
          <div key={entry.id} className="space-y-1">
            {/* Command Header */}
            <div className="flex items-center gap-2 text-cyan-400">
              <span className="text-emerald-400 font-bold">2tek-studio:~$</span>
              <span className="text-slate-100 font-semibold">{entry.command}</span>
              <span className="text-[10px] text-slate-500 ml-auto">[{entry.timestamp}]</span>
              {entry.exitCode === 0 ? (
                <CheckCircle2 size={12} className="text-emerald-400" />
              ) : (
                <XCircle size={12} className="text-rose-400" />
              )}
            </div>

            {/* Output */}
            {entry.output && (
              <pre
                className={`p-2 rounded bg-black/40 border border-white/5 overflow-x-auto whitespace-pre-wrap ${
                  entry.isError ? "text-rose-300" : "text-slate-300"
                }`}
              >
                {entry.output}
              </pre>
            )}
          </div>
        ))}

        {isExecuting && (
          <div className="flex items-center gap-2 text-cyan-400 animate-pulse">
            <span className="text-emerald-400 font-bold">2tek-studio:~$</span>
            <span>Running command...</span>
          </div>
        )}

        <div ref={terminalEndRef} />
      </div>

      {/* Terminal Prompt Input Form */}
      <form
        onSubmit={handleSubmit}
        className="flex items-center gap-2 px-3 py-2 border-t border-white/5 bg-[#060810]"
      >
        <span className="text-emerald-400 font-bold shrink-0">2tek-studio:~$</span>
        <input
          ref={inputRef}
          id="terminal-input-prompt"
          type="text"
          value={inputCommand}
          onChange={(e) => setInputCommand(e.target.value)}
          placeholder="Enter bash / npm / checker command..."
          className="flex-1 bg-transparent text-slate-100 outline-none text-xs font-mono"
        />
        <button
          type="submit"
          disabled={!inputCommand.trim() || isExecuting}
          className="p-1 text-slate-400 hover:text-cyan-400 disabled:opacity-30"
        >
          <Play size={13} />
        </button>
      </form>
    </div>
  );
}
