"use client";

import React, { useState } from "react";
import { UserProfileConfig, StudioTheme } from "./types";
import {
  UserCheck,
  Palette,
  Sliders,
  Database,
  Cloud,
  Download,
  Upload,
  RotateCcw,
  Check,
  Sparkles,
  Bot,
} from "lucide-react";

interface Props {
  profile: UserProfileConfig;
  onUpdateProfile: (updated: Partial<UserProfileConfig>) => void;
  onSyncProfile: (target: "local" | "localsqlserver" | "cloud") => Promise<void>;
}

export function SidebarProfile({ profile, onUpdateProfile, onSyncProfile }: Props) {
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncSuccessMsg, setSyncSuccessMsg] = useState("");

  const handleSync = async (target: "local" | "localsqlserver" | "cloud") => {
    setIsSyncing(true);
    setSyncSuccessMsg("");
    try {
      await onSyncProfile(target);
      setSyncSuccessMsg(`Profile synced to ${target.toUpperCase()}!`);
      setTimeout(() => setSyncSuccessMsg(""), 3500);
    } finally {
      setIsSyncing(false);
    }
  };

  const handleExportJson = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(profile, null, 2));
    const downloadAnchor = document.createElement("a");
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `2tek-profile-${profile.theme}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleImportJson = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        onUpdateProfile(parsed);
      } catch (err) {
        alert("Invalid profile JSON file");
      }
    };
    reader.readAsText(file);
  };

  return (
    <div id="sidebar-profile" className="h-full flex flex-col bg-[#0b0f1d] border-r border-white/5 select-none text-xs">
      {/* Header */}
      <div className="flex items-center justify-between px-3 py-2 border-b border-white/10 text-xs font-semibold uppercase tracking-wider text-slate-400">
        <div className="flex items-center gap-1.5">
          <UserCheck size={14} className="text-cyan-400" />
          <span>Profile & Sync</span>
        </div>
        <span className="text-[10px] px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800">
          {profile.syncSource || "LocalSQLServer"}
        </span>
      </div>

      <div className="flex-1 overflow-y-auto p-3 space-y-4">
        {/* Profile Card */}
        <div className="p-3 rounded-xl bg-gradient-to-br from-[#12192c] to-[#0d1322] border border-white/10 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-slate-400 text-[11px]">Active Profile</span>
            <span className="text-[10px] text-emerald-400 flex items-center gap-1">
              <Check size={11} /> Active
            </span>
          </div>
          <input
            id="profile-name-input"
            type="text"
            value={profile.name}
            onChange={(e) => onUpdateProfile({ name: e.target.value })}
            className="w-full bg-[#172038] border border-white/10 rounded-lg px-2.5 py-1.5 font-semibold text-slate-100 outline-none focus:border-cyan-500/50"
          />
          <div className="text-[11px] text-slate-500">
            Last Synced: {profile.lastSynced ? new Date(profile.lastSynced).toLocaleTimeString() : "Just now"}
          </div>
        </div>

        {/* Sync Status Banner */}
        {syncSuccessMsg && (
          <div className="p-2 rounded-lg bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2 animate-slide-down">
            <Check size={14} />
            <span>{syncSuccessMsg}</span>
          </div>
        )}

        {/* Theme Settings */}
        <div className="space-y-2">
          <label className="text-slate-400 font-semibold flex items-center gap-1.5 text-[11px]">
            <Palette size={13} className="text-cyan-400" />
            <span>Studio Theme</span>
          </label>
          <div className="grid grid-cols-2 gap-1.5">
            {[
              { id: "dark-modern", name: "Dark Modern", color: "#080b14" },
              { id: "cyberpunk", name: "Cyberpunk", color: "#070611" },
              { id: "monokai", name: "Monokai Pro", color: "#19181a" },
              { id: "cobalt", name: "Cobalt Slate", color: "#001529" },
            ].map((th) => (
              <button
                key={th.id}
                onClick={() => onUpdateProfile({ theme: th.id as StudioTheme })}
                className={`flex items-center gap-2 p-2 rounded-lg border text-left transition ${
                  profile.theme === th.id
                    ? "bg-cyan-950/50 border-cyan-400/60 text-cyan-200"
                    : "bg-[#101626] border-white/5 text-slate-300 hover:border-white/10"
                }`}
              >
                <div
                  className="w-3.5 h-3.5 rounded-full border border-white/20"
                  style={{ backgroundColor: th.color }}
                />
                <span className="truncate">{th.name}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Editor Options */}
        <div className="space-y-2.5">
          <label className="text-slate-400 font-semibold flex items-center gap-1.5 text-[11px]">
            <Sliders size={13} className="text-cyan-400" />
            <span>Editor Settings</span>
          </label>

          <div className="space-y-2 bg-[#0e1424] p-3 rounded-lg border border-white/5">
            {/* Font Size */}
            <div className="flex items-center justify-between">
              <span className="text-slate-300">Font Size ({profile.fontSize}px)</span>
              <div className="flex items-center gap-1">
                <button
                  onClick={() => onUpdateProfile({ fontSize: Math.max(10, profile.fontSize - 1) })}
                  className="w-6 h-6 rounded bg-[#172038] hover:bg-[#1f2b4a] text-slate-300 flex items-center justify-center font-bold"
                >
                  -
                </button>
                <button
                  onClick={() => onUpdateProfile({ fontSize: Math.min(24, profile.fontSize + 1) })}
                  className="w-6 h-6 rounded bg-[#172038] hover:bg-[#1f2b4a] text-slate-300 flex items-center justify-center font-bold"
                >
                  +
                </button>
              </div>
            </div>

            {/* Tab Size */}
            <div className="flex items-center justify-between">
              <span className="text-slate-300">Tab Size</span>
              <select
                value={profile.tabSize}
                onChange={(e) => onUpdateProfile({ tabSize: Number(e.target.value) })}
                className="bg-[#172038] border border-white/10 rounded px-2 py-0.5 text-slate-200 outline-none"
              >
                <option value={2}>2 Spaces</option>
                <option value={4}>4 Spaces</option>
              </select>
            </div>

            {/* Format on save */}
            <div className="flex items-center justify-between">
              <span className="text-slate-300">Format on Save (Prettier)</span>
              <input
                id="profile-format-on-save-toggle"
                type="checkbox"
                checked={profile.formatOnSave}
                onChange={(e) => onUpdateProfile({ formatOnSave: e.target.checked })}
                className="w-4 h-4 rounded accent-cyan-500 cursor-pointer"
              />
            </div>

            {/* Minimap */}
            <div className="flex items-center justify-between">
              <span className="text-slate-300">Monaco Minimap</span>
              <input
                id="profile-minimap-toggle"
                type="checkbox"
                checked={profile.minimap}
                onChange={(e) => onUpdateProfile({ minimap: e.target.checked })}
                className="w-4 h-4 rounded accent-cyan-500 cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* AI Assistant Preferences */}
        <div className="space-y-2">
          <label className="text-slate-400 font-semibold flex items-center gap-1.5 text-[11px]">
            <Bot size={13} className="text-cyan-400" />
            <span>AI Copilot Engine</span>
          </label>
          <select
            value={profile.aiModel}
            onChange={(e) => onUpdateProfile({ aiModel: e.target.value })}
            className="w-full bg-[#101626] border border-white/10 rounded-lg p-2 text-xs text-slate-200 outline-none focus:border-cyan-500/50"
          >
            <option value="Gemini 2.0 Flash">Google Gemini 2.0 Flash (Fastest)</option>
            <option value="Gemini 2.0 Pro">Google Gemini 2.0 Pro (High Reasoning)</option>
            <option value="Claude 3.5 Sonnet">Anthropic Claude 3.5 Sonnet</option>
            <option value="GPT-4o">OpenAI GPT-4o</option>
            <option value="Local 2-TEK Engine">Local 2-TEK Vector Engine (Offline)</option>
          </select>
        </div>

        {/* Sync Controls */}
        <div className="space-y-2 pt-2 border-t border-white/5">
          <button
            id="sync-to-localsqlserver-btn"
            onClick={() => handleSync("localsqlserver")}
            disabled={isSyncing}
            className="w-full flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg text-xs font-semibold bg-cyan-600 hover:bg-cyan-500 text-white transition shadow-lg shadow-cyan-950/40"
          >
            <Database size={14} />
            <span>{isSyncing ? "Syncing..." : "Sync to LocalSQLServer"}</span>
          </button>

          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={handleExportJson}
              className="flex items-center justify-center gap-1 py-1.5 px-2 rounded-lg bg-[#141c30] hover:bg-[#1a2542] text-slate-300 border border-white/5 transition"
            >
              <Download size={12} />
              <span>Export JSON</span>
            </button>

            <label className="flex items-center justify-center gap-1 py-1.5 px-2 rounded-lg bg-[#141c30] hover:bg-[#1a2542] text-slate-300 border border-white/5 transition cursor-pointer">
              <Upload size={12} />
              <span>Import JSON</span>
              <input type="file" accept=".json" onChange={handleImportJson} className="hidden" />
            </label>
          </div>
        </div>
      </div>
    </div>
  );
}
