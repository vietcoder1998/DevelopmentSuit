"use client";

import React, { useState, useRef, useEffect } from "react";
import { AiChatMessage, ProblemItem } from "./types";
import {
  Sparkles,
  Send,
  Bot,
  User,
  Copy,
  Check,
  Code2,
  FileCode,
  Wand2,
  Bug,
  TestTube2,
  FileText,
  X,
  CornerDownLeft,
} from "lucide-react";

interface Props {
  messages: AiChatMessage[];
  onSendMessage: (text: string, action?: string) => Promise<void>;
  activeFileName?: string;
  selectedCode?: string;
  diagnostics?: ProblemItem[];
  currentModel: string;
  onSelectModel: (model: string) => void;
  onApplyCodeToEditor: (code: string) => void;
  onClose?: () => void;
}

export function AiChatPanel({
  messages,
  onSendMessage,
  activeFileName,
  selectedCode,
  diagnostics = [],
  currentModel,
  onSelectModel,
  onApplyCodeToEditor,
  onClose,
}: Props) {
  const [inputText, setInputText] = useState("");
  const [isSending, setIsSending] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = async (action?: string) => {
    const textToSend = action ? "" : inputText.trim();
    if (!textToSend && !action) return;
    if (isSending) return;

    setIsSending(true);
    setInputText("");
    try {
      await onSendMessage(textToSend, action);
    } finally {
      setIsSending(false);
    }
  };

  const handleCopy = (code: string, id: string) => {
    navigator.clipboard.writeText(code);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div id="ai-chat-panel" className="h-full flex flex-col bg-[#0b0f1d] border-l border-white/5 select-none font-sans">
      {/* Header */}
      <div className="flex items-center justify-between px-3 py-2.5 border-b border-white/10 bg-[#080c16]">
        <div className="flex items-center gap-2">
          <div className="w-5 h-5 rounded-md bg-gradient-to-tr from-cyan-500 to-purple-500 flex items-center justify-center shadow-md shadow-cyan-500/20">
            <Sparkles size={12} className="text-white" />
          </div>
          <span className="font-semibold text-xs text-slate-100">2-TEK AI Copilot</span>
        </div>

        <div className="flex items-center gap-1.5">
          <select
            id="ai-model-selector"
            value={currentModel}
            onChange={(e) => onSelectModel(e.target.value)}
            className="bg-[#12192c] border border-white/10 rounded px-2 py-0.5 text-[11px] text-cyan-300 font-mono outline-none"
          >
            <option value="Gemini 2.0 Flash">Gemini 2.0 Flash</option>
            <option value="Gemini 2.0 Pro">Gemini 2.0 Pro</option>
            <option value="Claude 3.5 Sonnet">Claude 3.5 Sonnet</option>
            <option value="GPT-4o">GPT-4o</option>
            <option value="Local 2-TEK Engine">Local Engine</option>
          </select>

          {onClose && (
            <button
              onClick={onClose}
              className="p-1 text-slate-400 hover:text-white rounded hover:bg-white/5"
            >
              <X size={14} />
            </button>
          )}
        </div>
      </div>

      {/* Context Badge */}
      <div className="px-3 py-1.5 bg-[#090d18] border-b border-white/5 flex items-center justify-between text-[11px] text-slate-400 font-mono">
        <div className="flex items-center gap-1.5 truncate">
          <FileCode size={12} className="text-cyan-400 shrink-0" />
          <span className="truncate">{activeFileName || "No active file"}</span>
        </div>
        {selectedCode && (
          <span className="text-[10px] px-1.5 py-0.2 rounded bg-purple-950 text-purple-300 border border-purple-800">
            Snippet Selected
          </span>
        )}
      </div>

      {/* Quick Action Pills */}
      <div className="p-2 border-b border-white/5 flex flex-wrap gap-1 bg-[#0a0e1c]">
        <button
          onClick={() => handleSend("explain")}
          disabled={isSending}
          className="flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] bg-[#141b2e] hover:bg-cyan-950 hover:text-cyan-300 text-slate-300 border border-white/5 transition"
        >
          <Code2 size={10} className="text-cyan-400" />
          <span>Explain</span>
        </button>

        <button
          onClick={() => handleSend("refactor")}
          disabled={isSending}
          className="flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] bg-[#141b2e] hover:bg-purple-950 hover:text-purple-300 text-slate-300 border border-white/5 transition"
        >
          <Wand2 size={10} className="text-purple-400" />
          <span>Refactor</span>
        </button>

        <button
          onClick={() => handleSend("fix-warnings")}
          disabled={isSending}
          className="flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] bg-[#141b2e] hover:bg-amber-950 hover:text-amber-300 text-slate-300 border border-white/5 transition"
        >
          <Bug size={10} className="text-amber-400" />
          <span>Fix Warnings ({diagnostics.length})</span>
        </button>

        <button
          onClick={() => handleSend("test")}
          disabled={isSending}
          className="flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] bg-[#141b2e] hover:bg-emerald-950 hover:text-emerald-300 text-slate-300 border border-white/5 transition"
        >
          <TestTube2 size={10} className="text-emerald-400" />
          <span>Unit Tests</span>
        </button>
      </div>

      {/* Message Stream */}
      <div className="flex-1 overflow-y-auto p-3 space-y-3">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex flex-col space-y-1.5 ${
              msg.role === "user" ? "items-end" : "items-start"
            }`}
          >
            <div className="flex items-center gap-1.5 text-[10px] text-slate-500 font-mono">
              {msg.role === "user" ? (
                <>
                  <span>You</span>
                  <User size={11} />
                </>
              ) : (
                <>
                  <Bot size={11} className="text-cyan-400" />
                  <span>2-TEK AI</span>
                </>
              )}
              <span>•</span>
              <span>{msg.timestamp}</span>
            </div>

            <div
              className={`p-3 rounded-xl text-xs leading-relaxed max-w-[95%] ${
                msg.role === "user"
                  ? "bg-cyan-600 text-white shadow-md shadow-cyan-900/30 font-medium"
                  : "bg-[#11172a] text-slate-200 border border-white/10"
              }`}
            >
              <div className="whitespace-pre-wrap">{msg.content}</div>

              {/* Code Snippets */}
              {msg.codeSnippets && msg.codeSnippets.length > 0 && (
                <div className="mt-2 space-y-2">
                  {msg.codeSnippets.map((snippet, sIdx) => {
                    const snippetId = `${msg.id}-${sIdx}`;
                    const isCopied = copiedId === snippetId;

                    return (
                      <div
                        key={sIdx}
                        className="rounded-lg overflow-hidden border border-white/10 bg-[#080c14] font-mono text-[11px]"
                      >
                        <div className="flex items-center justify-between px-2.5 py-1 bg-[#05070c] border-b border-white/5 text-[10px] text-slate-400">
                          <span>{snippet.fileName || snippet.language}</span>
                          <div className="flex items-center gap-1">
                            <button
                              onClick={() => handleCopy(snippet.code, snippetId)}
                              className="p-1 hover:text-white rounded flex items-center gap-1 text-[10px]"
                            >
                              {isCopied ? (
                                <Check size={11} className="text-emerald-400" />
                              ) : (
                                <Copy size={11} />
                              )}
                              <span>{isCopied ? "Copied" : "Copy"}</span>
                            </button>
                            <button
                              onClick={() => onApplyCodeToEditor(snippet.code)}
                              className="p-1 text-cyan-400 hover:text-cyan-300 rounded flex items-center gap-1 text-[10px] font-semibold"
                            >
                              <CornerDownLeft size={11} />
                              <span>Insert</span>
                            </button>
                          </div>
                        </div>
                        <pre className="p-2.5 overflow-x-auto text-slate-300">
                          <code>{snippet.code}</code>
                        </pre>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        ))}
        {isSending && (
          <div className="flex items-center gap-2 text-xs text-cyan-400 font-mono p-2 animate-pulse">
            <Sparkles size={14} className="animate-spin" />
            <span>2-TEK AI is thinking and generating code...</span>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Box */}
      <div className="p-3 border-t border-white/10 bg-[#080c16]">
        <div className="relative flex items-center">
          <textarea
            id="ai-chat-input"
            rows={2}
            placeholder="Ask AI anything about the code, refactorings, or Checker..."
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            className="w-full bg-[#12192c] border border-white/10 rounded-xl p-2.5 pr-10 text-xs text-slate-100 placeholder-slate-500 outline-none focus:border-cyan-500/50 resize-none font-sans"
          />
          <button
            id="ai-chat-send-btn"
            onClick={() => handleSend()}
            disabled={!inputText.trim() || isSending}
            className="absolute right-2.5 p-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 disabled:opacity-40 text-white transition"
          >
            <Send size={14} />
          </button>
        </div>
      </div>
    </div>
  );
}
