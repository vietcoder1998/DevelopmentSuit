"use client";

import React, { useState, useEffect, useRef } from "react";
import { FileTreeNode } from "./types";
import { Search, FileCode, Folder, X } from "lucide-react";

interface Props {
  isOpen: boolean;
  onClose: () => void;
  files: string[];
  onSelectFile: (path: string) => void;
}

export function QuickOpenModal({ isOpen, onClose, files, onSelectFile }: Props) {
  const [query, setQuery] = useState("");
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setQuery("");
      setSelectedIndex(0);
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const filtered = files
    .filter((f) => f.toLowerCase().includes(query.toLowerCase()))
    .slice(0, 15);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Escape") {
      onClose();
    } else if (e.key === "ArrowDown") {
      e.preventDefault();
      setSelectedIndex((prev) => (prev + 1 < filtered.length ? prev + 1 : prev));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setSelectedIndex((prev) => (prev > 0 ? prev - 1 : 0));
    } else if (e.key === "Enter" && filtered[selectedIndex]) {
      e.preventDefault();
      onSelectFile(filtered[selectedIndex]);
      onClose();
    }
  };

  return (
    <div
      id="quick-open-backdrop"
      className="fixed inset-0 z-50 flex items-start justify-center pt-24 bg-black/60 backdrop-blur-sm animate-fade-in"
      onClick={onClose}
    >
      <div
        id="quick-open-modal"
        className="w-full max-w-xl bg-[#0e1424] border border-cyan-500/30 rounded-xl shadow-2xl overflow-hidden animate-slide-down"
        onClick={(e) => e.stopPropagation()}
        onKeyDown={handleKeyDown}
      >
        {/* Search Input */}
        <div className="flex items-center gap-3 px-4 py-3 bg-[#0a0f1d] border-b border-white/10">
          <Search size={18} className="text-cyan-400 shrink-0" />
          <input
            ref={inputRef}
            id="quick-open-input"
            type="text"
            placeholder="Search files by name (e.g. repo.ts, page.tsx, package.json)..."
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setSelectedIndex(0);
            }}
            className="w-full bg-transparent text-sm text-slate-100 placeholder-slate-500 outline-none font-mono"
          />
          <button
            onClick={onClose}
            className="text-slate-500 hover:text-slate-300 p-1 rounded"
          >
            <X size={16} />
          </button>
        </div>

        {/* Results */}
        <div className="max-h-80 overflow-y-auto p-2 space-y-1">
          {filtered.length === 0 ? (
            <div className="py-8 text-center text-xs text-slate-500">
              No matching files found for &quot;{query}&quot;
            </div>
          ) : (
            filtered.map((filePath, index) => {
              const isSelected = index === selectedIndex;
              const fileName = filePath.split("/").pop() || filePath;
              const dirName = filePath.includes("/")
                ? filePath.slice(0, filePath.lastIndexOf("/"))
                : "";

              return (
                <div
                  key={filePath}
                  onClick={() => {
                    onSelectFile(filePath);
                    onClose();
                  }}
                  onMouseEnter={() => setSelectedIndex(index)}
                  className={`flex items-center justify-between px-3 py-2 rounded-lg cursor-pointer text-xs font-mono transition ${
                    isSelected
                      ? "bg-cyan-500/15 text-cyan-200 border border-cyan-500/30"
                      : "text-slate-300 hover:bg-white/5 border border-transparent"
                  }`}
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <FileCode
                      size={14}
                      className={isSelected ? "text-cyan-400" : "text-slate-400"}
                    />
                    <span className="font-semibold text-slate-100 truncate">{fileName}</span>
                  </div>
                  {dirName && (
                    <span className="text-[11px] text-slate-500 truncate ml-4 max-w-xs">
                      {dirName}
                    </span>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* Footer shortcuts hint */}
        <div className="flex items-center justify-between px-4 py-2 bg-[#080c16] border-t border-white/5 text-[11px] text-slate-500">
          <span>Navigate with &uarr; &darr;</span>
          <span>Select with ↵ Enter</span>
          <span>Close with Esc</span>
        </div>
      </div>
    </div>
  );
}
