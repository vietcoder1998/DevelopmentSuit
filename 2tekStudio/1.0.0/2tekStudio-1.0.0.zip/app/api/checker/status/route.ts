import { NextRequest, NextResponse } from "next/server";
import { resolveRepoDir, Repository } from "@/app/lib/get-repo";

export { resolveRepoDir };

export async function GET() {
  try {
    const repoDir = resolveRepoDir();
    const isRepo = Repository.isRepository(repoDir);

    if (!isRepo) {
      return NextResponse.json({
        success: true,
        isRepository: false,
        repoPath: repoDir,
        branch: "none",
        stagedFiles: [],
        unstagedFiles: [],
        untrackedFiles: [],
        modifiedFiles: [],
      });
    }

    const repo = new Repository(repoDir);
    const status = repo.getStatus();

    let lastCommit: any = null;
    try {
      const logs = repo.getLog(1);
      if (logs.length > 0) {
        lastCommit = logs[0];
      }
    } catch {}

    const modifiedFiles = Array.from(
      new Set([
        ...status.staged,
        ...status.modified,
        ...status.untracked,
      ])
    );

    return NextResponse.json({
      success: true,
      isRepository: true,
      repoPath: repoDir,
      branch: status.branch || "main",
      stagedFiles: status.staged || [],
      unstagedFiles: status.modified || [],
      untrackedFiles: status.untracked || [],
      deletedFiles: status.deleted || [],
      modifiedFiles,
      isClean: status.isClean,
      ahead: 0,
      behind: 0,
      lastCommitHash: lastCommit?.hash || "",
      lastCommitMessage: lastCommit?.message || "",
    });
  } catch (err: any) {
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}
