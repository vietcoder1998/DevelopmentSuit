import { NextRequest, NextResponse } from "next/server";
import { resolveRepoDir, Repository } from "@/app/lib/get-repo";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const filePath = searchParams.get("file") || undefined;

    const repoDir = resolveRepoDir();
    if (!Repository.isRepository(repoDir)) {
      return NextResponse.json({ success: false, error: "Not a Checker repository" }, { status: 400 });
    }

    const repo = new Repository(repoDir);
    const diffs = repo.getDiff(filePath);

    return NextResponse.json({
      success: true,
      diffs,
      filePath,
      totalFiles: diffs.length,
    });
  } catch (err: any) {
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}
