import { NextRequest, NextResponse } from "next/server";
import { resolveRepoDir, Repository } from "@/app/lib/get-repo";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));
    const { branch, patchContent, chrRecordId } = body;

    const repoDir = resolveRepoDir();
    if (!Repository.isRepository(repoDir)) {
      return NextResponse.json({ success: false, error: "Not a Checker repository" }, { status: 400 });
    }

    const repo = new Repository(repoDir);
    const results: {
      action: string;
      pulledCommits?: number;
      appliedFiles?: string[];
      branch?: string;
      message: string;
    } = {
      action: "pull",
      message: "Checker pull completed",
    };

    if (patchContent) {
      const patchResult = repo.applyChrPatch(patchContent);
      results.appliedFiles = patchResult.appliedFiles;
      results.message = `Applied .chr patch with ${patchResult.appliedFiles.length} file(s) updated.`;
      return NextResponse.json({ success: true, ...results });
    }

    if (chrRecordId) {
      repo.applyChrRecord(chrRecordId);
      results.message = `Pulled and applied CHR record ${chrRecordId}`;
      return NextResponse.json({ success: true, ...results });
    }

    try {
      const syncResult = await repo.syncAllToDb();
      results.pulledCommits = syncResult.commitsSynced;
    } catch {
      // Local sync fallback
    }

    if (branch && branch !== repo.refManager.getCurrentBranch()) {
      repo.switchBranch(branch);
      results.branch = branch;
    }

    const currentStatus = repo.getStatus();
    results.message = `Successfully pulled code via Checker. Active branch: ${currentStatus.branch || "main"}.`;

    return NextResponse.json({
      success: true,
      ...results,
      status: currentStatus,
    });
  } catch (err: any) {
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}
