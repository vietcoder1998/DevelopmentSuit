import { NextRequest, NextResponse } from "next/server";
import { resolveRepoDir, Repository } from "@/app/lib/get-repo";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));
    const {
      message = "Commit from 2-TEK Studio",
      author = { name: "Developer", email: "dev@2tek.local" },
      paths,
      stageAll = true,
    } = body;

    const repoDir = resolveRepoDir();
    if (!Repository.isRepository(repoDir)) {
      return NextResponse.json({ success: false, error: "Not a Checker repository" }, { status: 400 });
    }

    const repo = new Repository(repoDir);

    if (stageAll) {
      repo.stage();
    } else if (Array.isArray(paths) && paths.length > 0) {
      repo.stage(paths);
    }

    const commitObj = repo.commit({
      message: message.trim(),
      author,
    });

    try {
      await repo.syncCommitToDb(commitObj);
    } catch {
      // Local commit fallback
    }

    return NextResponse.json({
      success: true,
      commit: commitObj,
      message: `Committed ${commitObj.hash.slice(0, 7)}: ${commitObj.message}`,
    });
  } catch (err: any) {
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}
