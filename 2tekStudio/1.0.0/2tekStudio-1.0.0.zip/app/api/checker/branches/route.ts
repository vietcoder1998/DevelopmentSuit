import { NextRequest, NextResponse } from "next/server";
import { resolveRepoDir, Repository } from "@/app/lib/get-repo";

export async function GET() {
  try {
    const repoDir = resolveRepoDir();
    if (!Repository.isRepository(repoDir)) {
      return NextResponse.json({ success: true, branches: [], currentBranch: "main" });
    }

    const repo = new Repository(repoDir);
    const branchNames = repo.refManager.listBranches();
    const currentBranch = repo.refManager.getCurrentBranch();

    const branches = branchNames.map((name) => ({
      name,
      commitHash: repo.refManager.getBranchCommit(name) || "",
      isCurrent: name === currentBranch,
    }));

    return NextResponse.json({
      success: true,
      branches,
      currentBranch,
    });
  } catch (err: any) {
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));
    const { action = "switch", branchName } = body;

    if (!branchName) {
      return NextResponse.json({ success: false, error: "Missing branchName" }, { status: 400 });
    }

    const repoDir = resolveRepoDir();
    if (!Repository.isRepository(repoDir)) {
      return NextResponse.json({ success: false, error: "Not a Checker repository" }, { status: 400 });
    }

    const repo = new Repository(repoDir);

    if (action === "create") {
      const created = repo.createBranch(branchName);
      if (!created) {
        return NextResponse.json({ success: false, error: "Branch already exists" }, { status: 400 });
      }
      repo.switchBranch(branchName);
      return NextResponse.json({
        success: true,
        message: `Created and switched to branch "${branchName}"`,
        branch: branchName,
      });
    }

    if (action === "switch") {
      repo.switchBranch(branchName);
      return NextResponse.json({
        success: true,
        message: `Switched to branch "${branchName}"`,
        branch: branchName,
      });
    }

    return NextResponse.json({ success: false, error: "Invalid action" }, { status: 400 });
  } catch (err: any) {
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}
