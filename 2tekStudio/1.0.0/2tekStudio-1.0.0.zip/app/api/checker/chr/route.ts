import { NextRequest, NextResponse } from "next/server";
import fs from "node:fs";
import path from "node:path";
import { resolveRepoDir, Repository } from "@/app/lib/get-repo";

export async function GET() {
  try {
    const repoDir = resolveRepoDir();
    if (!Repository.isRepository(repoDir)) {
      return NextResponse.json({ success: true, records: [] });
    }

    const repo = new Repository(repoDir);
    const records = repo.listChrRecords();

    return NextResponse.json({
      success: true,
      records,
    });
  } catch (err: any) {
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));
    const {
      action = "export",
      filePath,
      filePaths,
      message = "Export changes to .chr patch",
      author = { name: "Developer", email: "dev@2tek.local" },
      saveToFile = true,
      patchContent,
      outputFileName = "changes.chr",
    } = body;

    const repoDir = resolveRepoDir();
    if (!Repository.isRepository(repoDir)) {
      return NextResponse.json({ success: false, error: "Not a Checker repository" }, { status: 400 });
    }

    const repo = new Repository(repoDir);

    if (action === "export") {
      const { patch, chrText } = repo.exportChrPatch({
        filePath,
        filePaths,
        message,
        author,
      });

      let savedPath: string | null = null;
      if (saveToFile) {
        const fullPath = path.isAbsolute(outputFileName)
          ? outputFileName
          : path.join(repo.workingDir, outputFileName);
        fs.writeFileSync(fullPath, chrText, "utf-8");
        savedPath = path.relative(repo.workingDir, fullPath) || outputFileName;
      }

      return NextResponse.json({
        success: true,
        patch,
        chrText,
        savedPath,
        stats: patch.stats,
      });
    }

    if (action === "apply") {
      if (!patchContent) {
        return NextResponse.json({ success: false, error: "Missing patchContent" }, { status: 400 });
      }

      const applyRes = repo.applyChrPatch(patchContent);
      return NextResponse.json({
        success: true,
        appliedFiles: applyRes.appliedFiles,
        errors: applyRes.errors,
      });
    }

    return NextResponse.json({ success: false, error: "Invalid action" }, { status: 400 });
  } catch (err: any) {
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}
