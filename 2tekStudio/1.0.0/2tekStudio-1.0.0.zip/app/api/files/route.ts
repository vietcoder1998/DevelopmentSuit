import { NextRequest, NextResponse } from "next/server";
import fs from "node:fs";
import path from "node:path";

const workspaceRoot = path.resolve(process.cwd(), "..");

const IGNORED_DIRS = new Set([
  "node_modules",
  ".next",
  ".git",
  ".turbo",
  "dist",
  ".cache",
  "downloads",
]);

function buildFileTree(dir: string, depth = 0, maxDepth = 4): any[] {
  if (depth > maxDepth) return [];
  try {
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    const result: any[] = [];

    // Sort: directories first, then alphabetical
    const sorted = entries.sort((a, b) => {
      if (a.isDirectory() && !b.isDirectory()) return -1;
      if (!a.isDirectory() && b.isDirectory()) return 1;
      return a.name.localeCompare(b.name);
    });

    for (const entry of sorted) {
      if (IGNORED_DIRS.has(entry.name)) continue;
      if (entry.name.startsWith(".DS_Store")) continue;

      const fullPath = path.join(dir, entry.name);
      const relPath = path.relative(workspaceRoot, fullPath);

      if (entry.isDirectory()) {
        result.push({
          name: entry.name,
          path: relPath,
          isDirectory: true,
          children: buildFileTree(fullPath, depth + 1, maxDepth),
        });
      } else {
        let size = 0;
        try {
          size = fs.statSync(fullPath).size;
        } catch {}
        result.push({
          name: entry.name,
          path: relPath,
          isDirectory: false,
          sizeBytes: size,
        });
      }
    }
    return result;
  } catch {
    return [];
  }
}

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const action = searchParams.get("action") || "tree";
    const targetPath = searchParams.get("path");

    if (action === "tree") {
      const tree = buildFileTree(workspaceRoot);
      return NextResponse.json({
        success: true,
        root: workspaceRoot,
        tree,
      });
    }

    if (action === "read" && targetPath) {
      const resolved = path.isAbsolute(targetPath)
        ? targetPath
        : path.join(workspaceRoot, targetPath);

      if (!fs.existsSync(resolved)) {
        return NextResponse.json(
          { success: false, error: `File not found: ${targetPath}` },
          { status: 404 }
        );
      }

      const stat = fs.statSync(resolved);
      if (stat.isDirectory()) {
        return NextResponse.json(
          { success: false, error: `Path is a directory, not a file` },
          { status: 400 }
        );
      }

      if (stat.size > 2 * 1024 * 1024) {
        return NextResponse.json(
          { success: false, error: "File exceeds 2MB limit for editor preview" },
          { status: 413 }
        );
      }

      const content = fs.readFileSync(resolved, "utf-8");
      return NextResponse.json({
        success: true,
        path: targetPath,
        content,
        size: stat.size,
      });
    }

    return NextResponse.json({ success: false, error: "Invalid action" }, { status: 400 });
  } catch (err: any) {
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));
    const { action = "write", filePath, content, isDirectory, newPath } = body;

    if (!filePath) {
      return NextResponse.json({ success: false, error: "Missing filePath" }, { status: 400 });
    }

    const resolved = path.isAbsolute(filePath)
      ? filePath
      : path.join(workspaceRoot, filePath);

    if (action === "write") {
      const dir = path.dirname(resolved);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      fs.writeFileSync(resolved, content ?? "", "utf-8");
      return NextResponse.json({
        success: true,
        message: `Saved ${filePath}`,
        path: filePath,
      });
    }

    if (action === "create") {
      if (isDirectory) {
        fs.mkdirSync(resolved, { recursive: true });
        return NextResponse.json({ success: true, message: `Created directory ${filePath}` });
      } else {
        const dir = path.dirname(resolved);
        if (!fs.existsSync(dir)) {
          fs.mkdirSync(dir, { recursive: true });
        }
        if (!fs.existsSync(resolved)) {
          fs.writeFileSync(resolved, content ?? "", "utf-8");
        }
        return NextResponse.json({ success: true, message: `Created file ${filePath}` });
      }
    }

    if (action === "rename" && newPath) {
      const resolvedNew = path.isAbsolute(newPath)
        ? newPath
        : path.join(workspaceRoot, newPath);

      if (fs.existsSync(resolved)) {
        fs.renameSync(resolved, resolvedNew);
        return NextResponse.json({ success: true, message: `Renamed to ${newPath}` });
      }
      return NextResponse.json({ success: false, error: "Original file not found" }, { status: 404 });
    }

    if (action === "delete") {
      if (fs.existsSync(resolved)) {
        const stat = fs.statSync(resolved);
        if (stat.isDirectory()) {
          fs.rmSync(resolved, { recursive: true, force: true });
        } else {
          fs.unlinkSync(resolved);
        }
        return NextResponse.json({ success: true, message: `Deleted ${filePath}` });
      }
      return NextResponse.json({ success: false, error: "File not found" }, { status: 404 });
    }

    return NextResponse.json({ success: false, error: "Invalid action" }, { status: 400 });
  } catch (err: any) {
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}
