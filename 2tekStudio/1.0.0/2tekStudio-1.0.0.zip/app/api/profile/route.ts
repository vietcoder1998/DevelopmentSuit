import { NextRequest, NextResponse } from "next/server";
import fs from "node:fs";
import path from "node:path";

const workspaceRoot = path.resolve(process.cwd(), "..");
const PROFILE_FILE = path.join(workspaceRoot, ".2tek-studio-profile.json");

const DEFAULT_PROFILE = {
  id: "profile_default",
  name: "2-TEK Fullstack Developer",
  theme: "dark-modern",
  fontSize: 14,
  tabSize: 2,
  formatOnSave: true,
  minimap: true,
  wordWrap: true,
  aiModel: "Gemini 2.0 Flash",
  lastSynced: new Date().toISOString(),
  syncSource: "localsqlserver",
};

export async function GET() {
  try {
    if (fs.existsSync(PROFILE_FILE)) {
      const content = fs.readFileSync(PROFILE_FILE, "utf-8");
      const parsed = JSON.parse(content);
      return NextResponse.json({ success: true, profile: parsed });
    }
    return NextResponse.json({ success: true, profile: DEFAULT_PROFILE });
  } catch (err: any) {
    return NextResponse.json({ success: false, error: err.message, profile: DEFAULT_PROFILE });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));
    const { profile, syncTarget = "local" } = body;

    const merged = {
      ...DEFAULT_PROFILE,
      ...profile,
      lastSynced: new Date().toISOString(),
      syncSource: syncTarget,
    };

    fs.writeFileSync(PROFILE_FILE, JSON.stringify(merged, null, 2), "utf-8");

    return NextResponse.json({
      success: true,
      profile: merged,
      message: `Profile synchronized successfully (${syncTarget})`,
    });
  } catch (err: any) {
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}
