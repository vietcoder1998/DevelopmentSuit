import { NextRequest, NextResponse } from "next/server";
import vm from "node:vm";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));
    const { expression } = body;

    if (!expression || typeof expression !== "string") {
      return NextResponse.json({ success: false, error: "Missing expression" }, { status: 400 });
    }

    const logs: string[] = [];
    const sandbox = {
      console: {
        log: (...args: any[]) => logs.push(args.map((a) => (typeof a === "object" ? JSON.stringify(a) : String(a))).join(" ")),
        warn: (...args: any[]) => logs.push("[WARN] " + args.map(String).join(" ")),
        error: (...args: any[]) => logs.push("[ERROR] " + args.map(String).join(" ")),
      },
      process: {
        platform: process.platform,
        version: process.version,
        env: { NODE_ENV: process.env.NODE_ENV || "development" },
      },
      Math,
      Date,
      JSON,
      Array,
      Object,
      String,
      Number,
      Boolean,
    };

    const context = vm.createContext(sandbox);
    const script = new vm.Script(expression);
    const result = script.runInContext(context, { timeout: 3000 });

    let stringifiedResult = "";
    try {
      stringifiedResult = typeof result === "object" ? JSON.stringify(result, null, 2) : String(result);
    } catch {
      stringifiedResult = String(result);
    }

    return NextResponse.json({
      success: true,
      result: stringifiedResult,
      type: typeof result,
      logs,
    });
  } catch (err: any) {
    return NextResponse.json({
      success: false,
      error: err.message,
      type: "error",
    });
  }
}
