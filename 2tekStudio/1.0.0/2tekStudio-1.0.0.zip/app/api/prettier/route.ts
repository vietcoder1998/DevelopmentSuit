import { NextRequest, NextResponse } from "next/server";
import prettier from "prettier";
import path from "node:path";

function resolveParser(filepath?: string): string {
  if (!filepath) return "typescript";
  const ext = path.extname(filepath).toLowerCase();
  switch (ext) {
    case ".ts":
    case ".tsx":
      return "typescript";
    case ".js":
    case ".jsx":
    case ".mjs":
    case ".cjs":
      return "babel";
    case ".json":
      return "json";
    case ".css":
    case ".scss":
      return "css";
    case ".html":
      return "html";
    case ".md":
    case ".markdown":
      return "markdown";
    case ".yaml":
    case ".yml":
      return "yaml";
    default:
      return "typescript";
  }
}

export async function POST(req: NextRequest) {
  const startTime = Date.now();
  try {
    const body = await req.json().catch(() => ({}));
    const { code, filepath, options = {} } = body;

    if (typeof code !== "string") {
      return NextResponse.json({ success: false, error: "Missing or invalid code string" }, { status: 400 });
    }

    const parser = options.parser || resolveParser(filepath);

    const prettierConfig = {
      parser,
      semi: options.semi !== false,
      singleQuote: options.singleQuote !== false,
      tabWidth: options.tabWidth || 2,
      useTabs: Boolean(options.useTabs),
      trailingComma: options.trailingComma || "es5",
      printWidth: options.printWidth || 100,
      bracketSpacing: true,
      arrowParens: "always",
    };

    const formatted = await prettier.format(code, prettierConfig);
    const durationMs = Date.now() - startTime;

    return NextResponse.json({
      success: true,
      formatted,
      parser,
      durationMs,
      changed: formatted !== code,
    });
  } catch (err: any) {
    const durationMs = Date.now() - startTime;
    return NextResponse.json({
      success: false,
      error: err.message,
      line: err.loc?.start?.line,
      column: err.loc?.start?.column,
      durationMs,
    }, { status: 422 });
  }
}
