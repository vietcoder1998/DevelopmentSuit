import { NextRequest, NextResponse } from "next/server";
import { exec } from "node:child_process";
import path from "node:path";

const workspaceRoot = path.resolve(process.cwd(), "..");

export async function POST(req: NextRequest) {
  const startTime = Date.now();
  try {
    const body = await req.json().catch(() => ({}));
    const { command, cwd: requestedCwd } = body;

    if (!command || typeof command !== "string") {
      return NextResponse.json({ success: false, error: "Missing command" }, { status: 400 });
    }

    const trimmed = command.trim();
    if (!trimmed) {
      return NextResponse.json({ success: true, output: "", exitCode: 0, durationMs: 0 });
    }

    // Resolve working directory safely within workspace
    let cwd = workspaceRoot;
    if (requestedCwd) {
      const resolved = path.isAbsolute(requestedCwd)
        ? requestedCwd
        : path.resolve(workspaceRoot, requestedCwd);
      if (resolved.startsWith(workspaceRoot)) {
        cwd = resolved;
      }
    }

    return new Promise((resolve) => {
      exec(
        trimmed,
        {
          cwd,
          timeout: 30000,
          maxBuffer: 1024 * 1024 * 5,
          env: {
            ...process.env,
            FORCE_COLOR: "1",
            CI: "1",
          },
        },
        (error, stdout, stderr) => {
          const durationMs = Date.now() - startTime;
          const output = (stdout || "") + (stderr ? (stdout ? "\n" : "") + stderr : "");
          const exitCode = error ? (error.code ?? 1) : 0;

          resolve(
            NextResponse.json({
              success: exitCode === 0,
              output: output || (exitCode === 0 ? "Done." : error?.message || "Command failed"),
              stdout,
              stderr,
              exitCode,
              durationMs,
              cwd,
            })
          );
        }
      );
    });
  } catch (err: any) {
    const durationMs = Date.now() - startTime;
    return NextResponse.json({
      success: false,
      error: err.message,
      output: err.message,
      exitCode: 1,
      durationMs,
    }, { status: 500 });
  }
}
