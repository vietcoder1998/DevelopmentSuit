"use client";

import { StudioLayout } from "../components/StudioLayout";

export default function StudioPage() {
  return <StudioLayout />;
}
