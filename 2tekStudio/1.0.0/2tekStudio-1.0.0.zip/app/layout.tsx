import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "2-TEK Studio — Fullstack Code Editor & VCS IDE",
  description:
    "VS Code-grade Fullstack IDE integrated with Checker VCS, Monaco Editor, in-code diagnostics, Prettier formatter, Terminal, and AI Copilot.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <head>
        <link rel="icon" href="/favicon.ico" sizes="any" />
      </head>
      <body>{children}</body>
    </html>
  );
}
