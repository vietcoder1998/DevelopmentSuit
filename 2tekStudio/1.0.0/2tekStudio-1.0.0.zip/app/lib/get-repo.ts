import path from "node:path";
import process from "node:process";
import { Repository } from "../../../checker/sources/core/repo";

export function resolveRepoDir(): string {
  let dir = process.env.CHECKER_REPO_PATH || path.resolve(process.cwd(), "..");
  while (dir !== "/" && !Repository.isRepository(dir)) {
    const parent = path.dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }
  return dir;
}

export function getRepoInstance(): Repository {
  const dir = resolveRepoDir();
  return new Repository(dir);
}

export { Repository };
