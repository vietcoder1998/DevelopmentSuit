export type ConnectionProtocol = "http" | "grpc" | "websocket" | "ipc";
export type McpTransportType = "sse" | "stdio" | "http";

export interface EndpointConfig {
  readonly protocol: ConnectionProtocol;
  readonly host: string;
  readonly port: number;
  readonly path?: string;
  readonly secure?: boolean;
}

export interface ServiceConnectionState {
  readonly serviceName: "SQL" | "Vector" | "MCP";
  readonly protocol: ConnectionProtocol;
  readonly endpoint: string;
  readonly isConnected: boolean;
  readonly isTesting: boolean;
  readonly latencyMs: number | null;
  readonly lastTestedAt: number | null;
  readonly errorMessage: string | null;
}

export interface MultiConnectionConfig {
  readonly sql: ServiceConnectionState;
  readonly vector: ServiceConnectionState;
}

export interface SavedConnectionProfile {
  readonly id: string;
  readonly name: string;
  readonly serviceName: "SQL" | "Vector" | "MCP";
  readonly protocol: ConnectionProtocol;
  readonly endpoint: string;
  readonly isDefault?: boolean;
  readonly createdAt: number;
  /** MCP-specific transport type (only when serviceName === "MCP") */
  readonly mcpTransport?: McpTransportType;
}

export const DEFAULT_SQL_CONNECTION: ServiceConnectionState = {
  serviceName: "SQL",
  protocol: "http",
  endpoint: "http://127.0.0.1:3110",
  isConnected: false,
  isTesting: false,
  latencyMs: null,
  lastTestedAt: null,
  errorMessage: null,
};

export const DEFAULT_VECTOR_CONNECTION: ServiceConnectionState = {
  serviceName: "Vector",
  protocol: "http",
  endpoint: "http://127.0.0.1:3120",
  isConnected: false,
  isTesting: false,
  latencyMs: null,
  lastTestedAt: null,
  errorMessage: null,
};

export const DEFAULT_MCP_CONNECTION: ServiceConnectionState = {
  serviceName: "MCP",
  protocol: "http",
  endpoint: "http://127.0.0.1:3130",
  isConnected: false,
  isTesting: false,
  latencyMs: null,
  lastTestedAt: null,
  errorMessage: null,
};

export const INITIAL_SAVED_CONNECTIONS: SavedConnectionProfile[] = [
  {
    id: "conn-sql-local",
    name: "SQL Local (LocalSQLServer)",
    serviceName: "SQL",
    protocol: "http",
    endpoint: "http://127.0.0.1:3110",
    isDefault: true,
    createdAt: 1727600000000,
  },
  {
    id: "conn-vector-default",
    name: "Vector DB (LocalVectorServer)",
    serviceName: "Vector",
    protocol: "http",
    endpoint: "http://127.0.0.1:3120",
    isDefault: true,
    createdAt: 1727600000000,
  },
  {
    id: "conn-mcp-default",
    name: "MCP Client (LocalMCPServer)",
    serviceName: "MCP",
    protocol: "http",
    endpoint: "http://127.0.0.1:3130",
    isDefault: true,
    mcpTransport: "sse",
    createdAt: 1727600000000,
  },
];
