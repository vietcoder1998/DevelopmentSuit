import React, { useState } from "react";
import { IdeIcon, Button, Input, Badge } from "../bases";
import {
  ConnectionProtocol,
  ServiceConnectionState,
  SavedConnectionProfile,
  INITIAL_SAVED_CONNECTIONS,
} from "./connection-types";

export interface ConnectionManagerProps {
  readonly sqlConnection: ServiceConnectionState;
  readonly vectorConnection: ServiceConnectionState;
  readonly savedProfiles?: SavedConnectionProfile[];
  readonly onUpdateSqlConnection: (updated: Partial<ServiceConnectionState>) => void;
  readonly onUpdateVectorConnection: (updated: Partial<ServiceConnectionState>) => void;
  readonly onTestConnection: (serviceName: "SQL" | "Vector") => Promise<void>;
  readonly onSaveAndConnect?: (profile: {
    name: string;
    serviceName: "SQL" | "Vector";
    protocol: ConnectionProtocol;
    endpoint: string;
  }) => Promise<void>;
  readonly onSelectSavedProfile?: (profile: SavedConnectionProfile) => Promise<void>;
  readonly onDeleteProfile?: (id: string) => Promise<void>;
}

export const ConnectionManager: React.FC<ConnectionManagerProps> = ({
  sqlConnection,
  vectorConnection,
  savedProfiles = INITIAL_SAVED_CONNECTIONS,
  onUpdateSqlConnection,
  onUpdateVectorConnection,
  onTestConnection,
  onSaveAndConnect,
  onSelectSavedProfile,
  onDeleteProfile,
}) => {
  const [customSqlEndpoint, setCustomSqlEndpoint]: [
    string,
    React.Dispatch<React.SetStateAction<string>>
  ] = useState<string>(sqlConnection.endpoint);
  const [customVectorEndpoint, setCustomVectorEndpoint]: [
    string,
    React.Dispatch<React.SetStateAction<string>>
  ] = useState<string>(vectorConnection.endpoint);

  // Create Connection Form State
  const [createName, setCreateName]: [
    string,
    React.Dispatch<React.SetStateAction<string>>
  ] = useState<string>("");
  const [createService, setCreateService]: [
    "SQL" | "Vector",
    React.Dispatch<React.SetStateAction<"SQL" | "Vector">>
  ] = useState<"SQL" | "Vector">("SQL");
  const [createProtocol, setCreateProtocol]: [
    ConnectionProtocol,
    React.Dispatch<React.SetStateAction<ConnectionProtocol>>
  ] = useState<ConnectionProtocol>("http");
  const [createEndpoint, setCreateEndpoint]: [
    string,
    React.Dispatch<React.SetStateAction<string>>
  ] = useState<string>("http://127.0.0.1:3110");
  const [isSaving, setIsSaving]: [
    boolean,
    React.Dispatch<React.SetStateAction<boolean>>
  ] = useState<boolean>(false);
  const [statusMessage, setStatusMessage]: [
    string | null,
    React.Dispatch<React.SetStateAction<string | null>>
  ] = useState<string | null>(null);

  const availableProtocols: Array<{
    protocol: ConnectionProtocol;
    label: string;
    description: string;
    defaultPort: number;
  }> = [
    {
      protocol: "http",
      label: "HTTP REST",
      description: "Standard JSON API with health, query, and metrics endpoints",
      defaultPort: 3110,
    },
    {
      protocol: "grpc",
      label: "gRPC Binary",
      description: "High-throughput binary RPC protocol using Protocol Buffers",
      defaultPort: 50051,
    },
    {
      protocol: "websocket",
      label: "WebSocket",
      description: "Full-duplex real-time streaming for telemetry and subscription feeds",
      defaultPort: 3121,
    },
    {
      protocol: "ipc",
      label: "Local IPC",
      description: "Direct Unix socket / in-memory local process bus for zero latency",
      defaultPort: 0,
    },
  ];

  const handleProtocolChange: (
    service: "SQL" | "Vector",
    proto: ConnectionProtocol
  ) => void = (service: "SQL" | "Vector", proto: ConnectionProtocol): void => {
    let newEndpoint: string = "";
    if (service === "SQL") {
      if (proto === "http") newEndpoint = "http://127.0.0.1:3110";
      else if (proto === "grpc") newEndpoint = "127.0.0.1:50051";
      else if (proto === "websocket") newEndpoint = "ws://127.0.0.1:3110";
      else newEndpoint = "ipc:///tmp/2tek-localsql.sock";

      setCustomSqlEndpoint(newEndpoint);
      onUpdateSqlConnection({ protocol: proto, endpoint: newEndpoint });
    } else {
      if (proto === "http") newEndpoint = "http://127.0.0.1:3120";
      else if (proto === "grpc") newEndpoint = "127.0.0.1:50052";
      else if (proto === "websocket") newEndpoint = "ws://127.0.0.1:3121";
      else newEndpoint = "ipc:///tmp/2tek-localvector.sock";

      setCustomVectorEndpoint(newEndpoint);
      onUpdateVectorConnection({ protocol: proto, endpoint: newEndpoint });
    }
  };

  const handleSelectServiceForCreate: (service: "SQL" | "Vector") => void = (
    service: "SQL" | "Vector"
  ): void => {
    setCreateService(service);
    if (service === "SQL" && (createEndpoint === "http://127.0.0.1:3120" || createEndpoint === "")) {
      setCreateEndpoint("http://127.0.0.1:3110");
    } else if (service === "Vector" && (createEndpoint === "http://127.0.0.1:3110" || createEndpoint === "")) {
      setCreateEndpoint("http://127.0.0.1:3120");
    }
  };

  const handleSelectProtocolForCreate: (proto: ConnectionProtocol) => void = (
    proto: ConnectionProtocol
  ): void => {
    setCreateProtocol(proto);
    if (createService === "SQL") {
      if (proto === "http") setCreateEndpoint("http://127.0.0.1:3110");
      else if (proto === "grpc") setCreateEndpoint("127.0.0.1:50051");
      else if (proto === "websocket") setCreateEndpoint("ws://127.0.0.1:3110");
      else setCreateEndpoint("ipc:///tmp/2tek-localsql.sock");
    } else {
      if (proto === "http") setCreateEndpoint("http://127.0.0.1:3120");
      else if (proto === "grpc") setCreateEndpoint("127.0.0.1:50052");
      else if (proto === "websocket") setCreateEndpoint("ws://127.0.0.1:3121");
      else setCreateEndpoint("ipc:///tmp/2tek-localvector.sock");
    }
  };

  const handleSaveAndConnectSubmit: () => Promise<void> = async (): Promise<void> => {
    const finalName: string =
      createName.trim() || `${createService} (${createProtocol.toUpperCase()}) - ${createEndpoint}`;
    const finalEndpoint: string = createEndpoint.trim();

    if (!finalEndpoint) {
      setStatusMessage("Endpoint URI is required");
      return;
    }

    setIsSaving(true);
    setStatusMessage(null);

    try {
      if (onSaveAndConnect) {
        await onSaveAndConnect({
          name: finalName,
          serviceName: createService,
          protocol: createProtocol,
          endpoint: finalEndpoint,
        });
      } else {
        if (createService === "SQL") {
          onUpdateSqlConnection({ protocol: createProtocol, endpoint: finalEndpoint });
          await onTestConnection("SQL");
        } else {
          onUpdateVectorConnection({ protocol: createProtocol, endpoint: finalEndpoint });
          await onTestConnection("Vector");
        }
      }
      setStatusMessage(`Saved & connected to ${finalName}!`);
      setCreateName("");
    } catch (err: unknown) {
      const errText: string = err instanceof Error ? err.message : "Failed to save connection";
      setStatusMessage(`Error: ${errText}`);
    } finally {
      setIsSaving(false);
    }
  };

  const handleConnectProfile: (profile: SavedConnectionProfile) => Promise<void> = async (
    profile: SavedConnectionProfile
  ): Promise<void> => {
    if (onSelectSavedProfile) {
      await onSelectSavedProfile(profile);
    } else {
      if (profile.serviceName === "SQL") {
        setCustomSqlEndpoint(profile.endpoint);
        onUpdateSqlConnection({ protocol: profile.protocol, endpoint: profile.endpoint });
        await onTestConnection("SQL");
      } else {
        setCustomVectorEndpoint(profile.endpoint);
        onUpdateVectorConnection({ protocol: profile.protocol, endpoint: profile.endpoint });
        await onTestConnection("Vector");
      }
    }
  };

  return (
    <div id="localdb-connection-manager-container" className="div-col gap-4">
      {/* Overview Banner */}
      <div id="connection-overview-card" className="localdb-connection-card">
        <div id="connection-overview-header" className="div-row gap-2 align-center">
          <IdeIcon name="Network" size="md" color="var(--primary, #2563eb)" />
          <h2 id="connection-overview-title" className="text-base font-bold">
            Multi-Connection Protocol Manager
          </h2>
        </div>
        <p id="connection-overview-desc" className="theme-text-muted text-xs">
          LocalDBClient unifies database exploration across SQL (LocalSQLServer) and Vector (LocalVectorServer).
          Create new connection endpoints, persist them via Next.js, and switch seamlessly between HTTP, gRPC, WebSocket, and Local IPC.
        </p>
      </div>

      {/* CREATE NEW CONNECTION CARD */}
      <div id="create-connection-form-card" className="localdb-create-conn-card">
        <div id="create-connection-header" className="div-row gap-2 align-center justify-between">
          <div id="create-connection-title-box" className="div-row gap-2 align-center">
            <IdeIcon name="PlusCircle" size="sm" color="var(--primary, #2563eb)" />
            <h3 id="create-connection-heading" className="font-semibold text-sm">
              Create New Connection
            </h3>
          </div>
          <span id="create-connection-hint" className="theme-text-muted text-xs">
            Persisted via Next.js API & auto-connect
          </span>
        </div>

        <div id="create-connection-form-grid" className="div-col gap-3">
          {/* Row 1: Connection Name & Target Service */}
          <div id="create-conn-row-name-service" className="div-row gap-4 align-end flex-wrap">
            <div id="create-conn-name-group" className="flex-1 min-w-200 div-col gap-1">
              <label htmlFor="input-create-conn-name" className="text-xs font-semibold theme-text-muted">
                Connection Name:
              </label>
              <Input
                id="input-create-conn-name"
                size="sm"
                placeholder="e.g. Local SQL Primary or Vector DB"
                value={createName}
                onChange={(e: React.ChangeEvent<HTMLInputElement>): void => setCreateName(e.target.value)}
              />
            </div>

            <div id="create-conn-service-group" className="div-col gap-1">
              <span id="label-create-conn-service" className="text-xs font-semibold theme-text-muted">
                Database Engine:
              </span>
              <div id="create-conn-service-selector" className="localdb-connection-type-selector">
                <button
                  id="btn-select-service-sql"
                  type="button"
                  className={`localdb-connection-type-pill ${createService === "SQL" ? "active" : ""}`}
                  onClick={(): void => handleSelectServiceForCreate("SQL")}
                >
                  <IdeIcon name="Database" size="xs" />
                  <span>SQL</span>
                </button>
                <button
                  id="btn-select-service-vector"
                  type="button"
                  className={`localdb-connection-type-pill ${createService === "Vector" ? "active" : ""}`}
                  onClick={(): void => handleSelectServiceForCreate("Vector")}
                >
                  <IdeIcon name="Cpu" size="xs" />
                  <span>Vector</span>
                </button>
              </div>
            </div>
          </div>

          {/* Row 2: Protocol Selection */}
          <div id="create-conn-protocol-group" className="div-col gap-1">
            <span id="label-create-conn-protocol" className="text-xs font-semibold theme-text-muted">
              Connection Protocol:
            </span>
            <div id="create-conn-protocol-selector" className="localdb-connection-type-selector">
              {availableProtocols.map((p) => {
                const isSelected: boolean = createProtocol === p.protocol;
                return (
                  <button
                    key={`create-proto-${p.protocol}`}
                    id={`btn-create-proto-${p.protocol}`}
                    type="button"
                    className={`localdb-connection-type-pill ${isSelected ? "active" : ""}`}
                    onClick={(): void => handleSelectProtocolForCreate(p.protocol)}
                  >
                    {p.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Row 3: Endpoint Input & Save & Connect Button */}
          <div id="create-conn-endpoint-row" className="div-row gap-2 align-end">
            <div id="create-conn-endpoint-wrap" className="flex-1 div-col gap-1">
              <label htmlFor="input-create-conn-endpoint" className="text-xs font-semibold theme-text-muted">
                Endpoint URI:
              </label>
              <Input
                id="input-create-conn-endpoint"
                size="sm"
                placeholder={createService === "SQL" ? "http://127.0.0.1:3110" : "http://127.0.0.1:3120"}
                value={createEndpoint}
                onChange={(e: React.ChangeEvent<HTMLInputElement>): void => setCreateEndpoint(e.target.value)}
              />
            </div>

            <Button
              id="btn-save-and-connect"
              data-testid="btn-save-and-connect"
              variant="primary"
              size="sm"
              disabled={isSaving}
              onClick={handleSaveAndConnectSubmit}
            >
              <IdeIcon
                name={isSaving ? "RotateCw" : "Link2"}
                size="xs"
                className={isSaving ? "spin" : ""}
              />
              <span>{isSaving ? "Connecting..." : "Save & Connect"}</span>
            </Button>
          </div>

          {statusMessage && (
            <div id="create-conn-status-message" className="text-xs font-medium theme-text-muted">
              {statusMessage}
            </div>
          )}
        </div>
      </div>

      {/* SAVED CONNECTIONS PROFILES SECTION */}
      <div id="saved-connections-section" className="localdb-connection-card">
        <div id="saved-connections-header" className="div-row gap-2 align-center justify-between">
          <div id="saved-connections-title-box" className="div-row gap-2 align-center">
            <IdeIcon name="Bookmark" size="sm" color="var(--primary, #2563eb)" />
            <h3 id="saved-connections-heading" className="font-semibold text-sm">
              Saved Connections
            </h3>
          </div>
          <span id="saved-connections-count" className="theme-text-muted text-xs">
            {savedProfiles.length} configured profiles
          </span>
        </div>

        <div id="saved-connections-list" className="localdb-saved-profiles-list">
          {savedProfiles.map((p: SavedConnectionProfile) => {
            const isActiveSql: boolean =
              p.serviceName === "SQL" &&
              sqlConnection.endpoint === p.endpoint &&
              sqlConnection.protocol === p.protocol;
            const isActiveVector: boolean =
              p.serviceName === "Vector" &&
              vectorConnection.endpoint === p.endpoint &&
              vectorConnection.protocol === p.protocol;
            const isActive: boolean = isActiveSql || isActiveVector;

            return (
              <div
                key={p.id}
                id={`saved-profile-card-${p.id}`}
                className={`localdb-saved-profile-item ${isActive ? "active" : ""}`}
              >
                <div id={`profile-info-group-${p.id}`} className="div-col gap-1 min-w-0 flex-1">
                  <div id={`profile-header-row-${p.id}`} className="div-row gap-2 align-center flex-wrap">
                    <span id={`profile-name-${p.id}`} className="font-semibold text-sm truncate">
                      {p.name}
                    </span>
                    <Badge variant={p.serviceName === "SQL" ? "primary" : "success"} size="xs">
                      {p.serviceName}
                    </Badge>
                    <Badge variant="secondary" size="xs">
                      {p.protocol.toUpperCase()}
                    </Badge>
                    {p.isDefault && (
                      <span id={`profile-default-tag-${p.id}`} className="theme-text-muted text-xs">
                        (Default)
                      </span>
                    )}
                  </div>
                  <span id={`profile-endpoint-${p.id}`} className="theme-text-muted text-xs font-mono truncate">
                    {p.endpoint}
                  </span>
                </div>

                <div id={`profile-actions-group-${p.id}`} className="div-row gap-2 align-center ml-2">
                  <Button
                    id={`btn-connect-profile-${p.id}`}
                    variant={isActive ? "outline" : "primary"}
                    size="sm"
                    onClick={(): Promise<void> => handleConnectProfile(p)}
                  >
                    <IdeIcon name={isActive ? "Check" : "Zap"} size="xs" />
                    <span>{isActive ? "Active" : "Connect"}</span>
                  </Button>

                  {!p.isDefault && onDeleteProfile && (
                    <Button
                      id={`btn-delete-profile-${p.id}`}
                      variant="ghost"
                      size="sm"
                      onClick={(): Promise<void> => onDeleteProfile(p.id)}
                      title="Delete saved connection"
                    >
                      <IdeIcon name="Trash2" size="xs" color="var(--danger, #ef4444)" />
                    </Button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* ACTIVE SERVICE STATUS & CONFIGURATION CARDS */}
      <div id="connection-services-grid" className="localdb-connection-grid">
        {/* Service 1: LocalSQLServer Connection Card */}
        <div id="connection-card-sql" className="localdb-connection-card">
          <div id="connection-header-sql" className="localdb-connection-card-header">
            <div id="connection-title-group-sql" className="div-row gap-2 align-center">
              <IdeIcon name="Database" size="sm" color="var(--primary, #2563eb)" />
              <h3 id="connection-service-title-sql" className="font-semibold text-sm">
                SQL Database Connection (LocalSQLServer)
              </h3>
            </div>
            <div id="connection-status-sql-wrap" className="div-row gap-2 align-center">
              <span
                id="connection-dot-sql"
                className={`localdb-status-dot ${sqlConnection.isConnected ? "status-online" : "status-offline"}`}
              />
              <span id="connection-status-text-sql" className="text-xs font-medium">
                {sqlConnection.isConnected ? "Connected" : "Disconnected"}
              </span>
            </div>
          </div>

          {/* Protocol Type Selector */}
          <div id="connection-protocols-sql" className="div-col gap-2">
            <span id="label-protocols-sql" className="text-xs font-semibold theme-text-muted">
              Select Connection Protocol:
            </span>
            <div id="protocols-pill-group-sql" className="localdb-connection-type-selector">
              {availableProtocols.map((p) => {
                const isActive: boolean = sqlConnection.protocol === p.protocol;
                return (
                  <button
                    key={p.protocol}
                    id={`btn-proto-sql-${p.protocol}`}
                    type="button"
                    className={`localdb-connection-type-pill ${isActive ? "active" : ""}`}
                    onClick={(): void => handleProtocolChange("SQL", p.protocol)}
                  >
                    {p.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Endpoint Input */}
          <div id="connection-endpoint-sql-group" className="div-col gap-1">
            <label htmlFor="input-endpoint-sql" className="text-xs font-semibold theme-text-muted">
              Endpoint URI ({sqlConnection.protocol.toUpperCase()}):
            </label>
            <div id="connection-endpoint-input-row-sql" className="div-row gap-2 align-center">
              <div id="input-wrap-sql" className="flex-1">
                <Input
                  id="input-endpoint-sql"
                  size="sm"
                  value={customSqlEndpoint}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>): void => {
                    setCustomSqlEndpoint(e.target.value);
                    onUpdateSqlConnection({ endpoint: e.target.value });
                  }}
                  placeholder="e.g. http://127.0.0.1:3110"
                />
              </div>
              <Button
                id="btn-test-connection-sql"
                variant="primary"
                size="sm"
                disabled={sqlConnection.isTesting}
                onClick={(): Promise<void> => onTestConnection("SQL")}
              >
                <IdeIcon
                  name={sqlConnection.isTesting ? "RotateCw" : "Zap"}
                  size="xs"
                  className={sqlConnection.isTesting ? "spin" : ""}
                />
                <span>{sqlConnection.isTesting ? "Testing..." : "Test Ping"}</span>
              </Button>
            </div>
          </div>

          {/* Diagnostics Info */}
          <div id="connection-diagnostics-sql" className="theme-surface-muted p-3 rounded div-col gap-1 text-xs">
            <div id="diag-row-sql-latency" className="div-row justify-between">
              <span className="theme-text-muted">Latency:</span>
              <span id="val-sql-latency" className="font-mono font-semibold">
                {sqlConnection.latencyMs !== null ? `${sqlConnection.latencyMs} ms` : "—"}
              </span>
            </div>
            <div id="diag-row-sql-proto" className="div-row justify-between">
              <span className="theme-text-muted">Active Protocol:</span>
              <Badge variant="primary" size="xs">
                {sqlConnection.protocol.toUpperCase()}
              </Badge>
            </div>
            {sqlConnection.errorMessage && (
              <div id="diag-row-sql-error" className="text-danger text-xs mt-1">
                Error: {sqlConnection.errorMessage}
              </div>
            )}
          </div>
        </div>

        {/* Service 2: LocalVectorServer Connection Card */}
        <div id="connection-card-vector" className="localdb-connection-card">
          <div id="connection-header-vector" className="localdb-connection-card-header">
            <div id="connection-title-group-vector" className="div-row gap-2 align-center">
              <IdeIcon name="Cpu" size="sm" color="var(--primary, #6938ef)" />
              <h3 id="connection-service-title-vector" className="font-semibold text-sm">
                Vector Database Connection (LocalVectorServer)
              </h3>
            </div>
            <div id="connection-status-vector-wrap" className="div-row gap-2 align-center">
              <span
                id="connection-dot-vector"
                className={`localdb-status-dot ${vectorConnection.isConnected ? "status-online" : "status-offline"}`}
              />
              <span id="connection-status-text-vector" className="text-xs font-medium">
                {vectorConnection.isConnected ? "Connected" : "Disconnected"}
              </span>
            </div>
          </div>

          {/* Protocol Type Selector */}
          <div id="connection-protocols-vector" className="div-col gap-2">
            <span id="label-protocols-vector" className="text-xs font-semibold theme-text-muted">
              Select Connection Protocol:
            </span>
            <div id="protocols-pill-group-vector" className="localdb-connection-type-selector">
              {availableProtocols.map((p) => {
                const isActive: boolean = vectorConnection.protocol === p.protocol;
                return (
                  <button
                    key={p.protocol}
                    id={`btn-proto-vector-${p.protocol}`}
                    type="button"
                    className={`localdb-connection-type-pill ${isActive ? "active" : ""}`}
                    onClick={(): void => handleProtocolChange("Vector", p.protocol)}
                  >
                    {p.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Endpoint Input */}
          <div id="connection-endpoint-vector-group" className="div-col gap-1">
            <label htmlFor="input-endpoint-vector" className="text-xs font-semibold theme-text-muted">
              Endpoint URI ({vectorConnection.protocol.toUpperCase()}):
            </label>
            <div id="connection-endpoint-input-row-vector" className="div-row gap-2 align-center">
              <div id="input-wrap-vector" className="flex-1">
                <Input
                  id="input-endpoint-vector"
                  size="sm"
                  value={customVectorEndpoint}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>): void => {
                    setCustomVectorEndpoint(e.target.value);
                    onUpdateVectorConnection({ endpoint: e.target.value });
                  }}
                  placeholder="e.g. http://127.0.0.1:3120"
                />
              </div>
              <Button
                id="btn-test-connection-vector"
                variant="primary"
                size="sm"
                disabled={vectorConnection.isTesting}
                onClick={(): Promise<void> => onTestConnection("Vector")}
              >
                <IdeIcon
                  name={vectorConnection.isTesting ? "RotateCw" : "Zap"}
                  size="xs"
                  className={vectorConnection.isTesting ? "spin" : ""}
                />
                <span>{vectorConnection.isTesting ? "Testing..." : "Test Ping"}</span>
              </Button>
            </div>
          </div>

          {/* Diagnostics Info */}
          <div id="connection-diagnostics-vector" className="theme-surface-muted p-3 rounded div-col gap-1 text-xs">
            <div id="diag-row-vector-latency" className="div-row justify-between">
              <span className="theme-text-muted">Latency:</span>
              <span id="val-vector-latency" className="font-mono font-semibold">
                {vectorConnection.latencyMs !== null ? `${vectorConnection.latencyMs} ms` : "—"}
              </span>
            </div>
            <div id="diag-row-vector-proto" className="div-row justify-between">
              <span className="theme-text-muted">Active Protocol:</span>
              <Badge variant="primary" size="xs">
                {vectorConnection.protocol.toUpperCase()}
              </Badge>
            </div>
            {vectorConnection.errorMessage && (
              <div id="diag-row-vector-error" className="text-danger text-xs mt-1">
                Error: {vectorConnection.errorMessage}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
