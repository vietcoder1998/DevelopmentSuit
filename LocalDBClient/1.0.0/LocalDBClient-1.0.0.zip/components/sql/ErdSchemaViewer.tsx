"use client";

import React, { useState, useMemo, useRef, useEffect, useCallback } from "react";
import { IdeIcon, Badge, Input, Button } from "../bases";
import {
  ErdColumnMeta,
  ErdDiagramData,
  ErdLayoutMode,
  ErdSchemaViewerProps,
  ErdTableNode,
  ErdTablePosition,
  TableRelationship,
  XmlErpRelationship,
  XmlErpSchemaDefinition,
} from "./erd-types";
import { inferTableRelationships } from "./erd-relationship-engine";
import { parseXmlErpSchema, serializeErpSchemaToXml } from "./erd-xml-parser";

const SAMPLE_ENTERPRISE_ERP_XML: string = `<?xml version="1.0" encoding="UTF-8"?>
<erp-schema name="enterprise_erp_model" version="1.0">
  <tables>
    <table name="users" rowCount="142" description="ERP system user accounts and credentials">
      <column name="id" type="INTEGER" primaryKey="true" />
      <column name="username" type="VARCHAR(100)" />
      <column name="email" type="VARCHAR(255)" />
      <column name="role_id" type="INTEGER" />
      <column name="department_id" type="INTEGER" />
      <column name="created_at" type="TIMESTAMP" />
    </table>

    <table name="roles" rowCount="8" description="System security permissions">
      <column name="id" type="INTEGER" primaryKey="true" />
      <column name="role_name" type="VARCHAR(50)" />
      <column name="description" type="TEXT" />
    </table>

    <table name="departments" rowCount="12" description="Business departments">
      <column name="id" type="INTEGER" primaryKey="true" />
      <column name="name" type="VARCHAR(120)" />
      <column name="manager_id" type="INTEGER" />
    </table>

    <table name="customers" rowCount="560" description="Customer CRM records">
      <column name="id" type="INTEGER" primaryKey="true" />
      <column name="name" type="VARCHAR(200)" />
      <column name="email" type="VARCHAR(255)" />
      <column name="assigned_sales_rep_id" type="INTEGER" />
    </table>

    <table name="orders" rowCount="1280" description="Customer purchase orders">
      <column name="id" type="INTEGER" primaryKey="true" />
      <column name="order_number" type="VARCHAR(64)" />
      <column name="customer_id" type="INTEGER" />
      <column name="total_amount" type="DECIMAL(12,2)" />
      <column name="status" type="VARCHAR(32)" />
      <column name="created_at" type="TIMESTAMP" />
    </table>

    <table name="order_items" rowCount="4320" description="Invoice line items">
      <column name="id" type="INTEGER" primaryKey="true" />
      <column name="order_id" type="INTEGER" />
      <column name="product_id" type="INTEGER" />
      <column name="quantity" type="INTEGER" />
      <column name="unit_price" type="DECIMAL(12,2)" />
    </table>

    <table name="products" rowCount="340" description="Inventory products catalog">
      <column name="id" type="INTEGER" primaryKey="true" />
      <column name="sku" type="VARCHAR(64)" />
      <column name="name" type="VARCHAR(255)" />
      <column name="category_id" type="INTEGER" />
      <column name="price" type="DECIMAL(12,2)" />
      <column name="stock_qty" type="INTEGER" />
    </table>

    <table name="categories" rowCount="24" description="Hierarchical product categorization">
      <column name="id" type="INTEGER" primaryKey="true" />
      <column name="category_name" type="VARCHAR(100)" />
      <column name="parent_id" type="INTEGER" />
    </table>
  </tables>

  <relationships>
    <relationship id="rel-users-roles" sourceTable="users" sourceColumn="role_id" targetTable="roles" targetColumn="id" cardinality="many-to-one" label="users.role_id ➔ roles.id" />
    <relationship id="rel-users-departments" sourceTable="users" sourceColumn="department_id" targetTable="departments" targetColumn="id" cardinality="many-to-one" label="users.department_id ➔ departments.id" />
    <relationship id="rel-departments-manager" sourceTable="departments" sourceColumn="manager_id" targetTable="users" targetColumn="id" cardinality="many-to-one" label="departments.manager_id ➔ users.id" />
    <relationship id="rel-customers-salesrep" sourceTable="customers" sourceColumn="assigned_sales_rep_id" targetTable="users" targetColumn="id" cardinality="many-to-one" label="customers.assigned_sales_rep_id ➔ users.id" />
    <relationship id="rel-orders-customers" sourceTable="orders" sourceColumn="customer_id" targetTable="customers" targetColumn="id" cardinality="many-to-one" label="orders.customer_id ➔ customers.id" />
    <relationship id="rel-order_items-orders" sourceTable="order_items" sourceColumn="order_id" targetTable="orders" targetColumn="id" cardinality="many-to-one" label="order_items.order_id ➔ orders.id" />
    <relationship id="rel-order_items-products" sourceTable="order_items" sourceColumn="product_id" targetTable="products" targetColumn="id" cardinality="many-to-one" label="order_items.product_id ➔ products.id" />
    <relationship id="rel-products-categories" sourceTable="products" sourceColumn="category_id" targetTable="categories" targetColumn="id" cardinality="many-to-one" label="products.category_id ➔ categories.id" />
    <relationship id="rel-categories-parent" sourceTable="categories" sourceColumn="parent_id" targetTable="categories" targetColumn="id" cardinality="many-to-one" label="categories.parent_id ➔ categories.id" />
  </relationships>
</erp-schema>`;

export const ErdSchemaViewer: React.FC<ErdSchemaViewerProps> = ({
  tables,
  activeTable,
  initialXmlSchema,
  onSelectTable,
  onOpenInConsole,
  onSwitchToExplorer,
  onXmlSchemaLoaded,
}) => {
  const [zoom, setZoom]: [number, React.Dispatch<React.SetStateAction<number>>] = useState<number>(1.0);
  const [pan, setPan]: [ErdTablePosition, React.Dispatch<React.SetStateAction<ErdTablePosition>>] =
    useState<ErdTablePosition>({ x: 0, y: 0 });
  const [isPanning, setIsPanning]: [boolean, React.Dispatch<React.SetStateAction<boolean>>] =
    useState<boolean>(false);

  const [layoutMode, setLayoutMode]: [ErdLayoutMode, React.Dispatch<React.SetStateAction<ErdLayoutMode>>] =
    useState<ErdLayoutMode>("grid");
  const [searchFilter, setSearchFilter]: [string, React.Dispatch<React.SetStateAction<string>>] = useState<string>("");
  const [selectedTable, setSelectedTable]: [string | null, React.Dispatch<React.SetStateAction<string | null>>] =
    useState<string | null>(activeTable);
  const [hoveredRelId, setHoveredRelId]: [string | null, React.Dispatch<React.SetStateAction<string | null>>] =
    useState<string | null>(null);

  // Custom table card positions from drag-and-drop
  const [customPositions, setCustomPositions]: [
    Record<string, ErdTablePosition>,
    React.Dispatch<React.SetStateAction<Record<string, ErdTablePosition>>>
  ] = useState<Record<string, ErdTablePosition>>({});

  // Active dragging card state
  const [draggingCard, setDraggingCard]: [
    {
      tableName: string;
      startMouseX: number;
      startMouseY: number;
      initialCardX: number;
      initialCardY: number;
    } | null,
    React.Dispatch<
      React.SetStateAction<{
        tableName: string;
        startMouseX: number;
        startMouseY: number;
        initialCardX: number;
        initialCardY: number;
      } | null>
    >
  ] = useState<{
    tableName: string;
    startMouseX: number;
    startMouseY: number;
    initialCardX: number;
    initialCardY: number;
  } | null>(null);

  // ERP XML Schema state
  const [xmlSchema, setXmlSchema]: [
    XmlErpSchemaDefinition | null,
    React.Dispatch<React.SetStateAction<XmlErpSchemaDefinition | null>>
  ] = useState<XmlErpSchemaDefinition | null>((): XmlErpSchemaDefinition | null => {
    if (initialXmlSchema) {
      try {
        return parseXmlErpSchema(initialXmlSchema);
      } catch {
        return null;
      }
    }
    return null;
  });

  const [isXmlModalOpen, setIsXmlModalOpen]: [boolean, React.Dispatch<React.SetStateAction<boolean>>] =
    useState<boolean>(false);
  const [xmlInputText, setXmlInputText]: [string, React.Dispatch<React.SetStateAction<string>>] =
    useState<string>("");
  const [xmlError, setXmlError]: [string | null, React.Dispatch<React.SetStateAction<string | null>>] =
    useState<string | null>(null);

  const canvasRef: React.RefObject<HTMLDivElement | null> = useRef<HTMLDivElement | null>(null);
  const panStartRef: React.MutableRefObject<{
    startX: number;
    startY: number;
    initialPanX: number;
    initialPanY: number;
  }> = useRef<{
    startX: number;
    startY: number;
    initialPanX: number;
    initialPanY: number;
  }>({
    startX: 0,
    startY: 0,
    initialPanX: 0,
    initialPanY: 0,
  });

  // Derive diagram layout data with XML schema support
  const diagramData: ErdDiagramData = useMemo((): ErdDiagramData => {
    try {
      return inferTableRelationships(tables, layoutMode, xmlSchema);
    } catch (err: unknown) {
      console.error("Failed to compute ERD diagram data:", err);
      return { tables: [], relationships: [] };
    }
  }, [tables, layoutMode, xmlSchema]);

  // Compute canvas bounding box to size SVG container, considering dragged custom positions
  const canvasBounds: { width: number; height: number } = useMemo((): { width: number; height: number } => {
    if (!Array.isArray(diagramData.tables) || diagramData.tables.length === 0) {
      return { width: 900, height: 650 };
    }
    let maxX: number = 900;
    let maxY: number = 650;
    diagramData.tables.forEach((node: ErdTableNode): void => {
      const pos: ErdTablePosition = customPositions[node.name] || { x: node.x, y: node.y };
      const right: number = (pos.x ?? 0) + (node.width ?? 240) + 150;
      const bottom: number = (pos.y ?? 0) + (node.height ?? 200) + 150;
      if (right > maxX) maxX = right;
      if (bottom > maxY) maxY = bottom;
    });
    return { width: Math.max(maxX, 900), height: Math.max(maxY, 650) };
  }, [diagramData, customPositions]);

  // Handle zoom actions
  const handleZoomIn: () => void = (): void => {
    setZoom((prev: number): number => Math.min(prev + 0.15, 2.0));
  };

  const handleZoomOut: () => void = (): void => {
    setZoom((prev: number): number => Math.max(prev - 0.15, 0.4));
  };

  const handleResetZoom: () => void = (): void => {
    setZoom(1.0);
  };

  const handleResetPan: () => void = (): void => {
    setPan({ x: 0, y: 0 });
  };

  const handleResetPositions: () => void = (): void => {
    setCustomPositions({});
  };

  const handleFitView: () => void = (): void => {
    setPan({ x: 0, y: 0 });
    if (!canvasRef.current || !Array.isArray(diagramData.tables) || diagramData.tables.length === 0) {
      setZoom(1.0);
      return;
    }
    const containerWidth: number = canvasRef.current.clientWidth || 900;
    const containerHeight: number = canvasRef.current.clientHeight || 650;
    const scaleX: number = (containerWidth - 60) / canvasBounds.width;
    const scaleY: number = (containerHeight - 60) / canvasBounds.height;
    const calculatedScale: number = Math.min(scaleX, scaleY, 1.0);
    setZoom(Math.max(calculatedScale, 0.4));
  };

  // Node lookup map
  const tableNodeMap: Map<string, ErdTableNode> = useMemo((): Map<string, ErdTableNode> => {
    const map: Map<string, ErdTableNode> = new Map<string, ErdTableNode>();
    if (Array.isArray(diagramData.tables)) {
      diagramData.tables.forEach((node: ErdTableNode): void => {
        if (node && node.name) {
          map.set(node.name.toLowerCase(), node);
        }
      });
    }
    return map;
  }, [diagramData]);

  // Compute curved SVG connector paths for relationships, taking custom card positions into account
  const HEADER_HEIGHT: number = 42;
  const ROW_HEIGHT: number = 28;

  const relationshipPaths: Array<{
    rel: TableRelationship;
    d: string;
    startX: number;
    startY: number;
    endX: number;
    endY: number;
    isHighlighted: boolean;
  }> = useMemo(() => {
    if (!Array.isArray(diagramData.relationships)) return [];
    return diagramData.relationships.map((rel: TableRelationship) => {
      const sourceNode: ErdTableNode | undefined = tableNodeMap.get(rel.sourceTable.toLowerCase());
      const targetNode: ErdTableNode | undefined = tableNodeMap.get(rel.targetTable.toLowerCase());

      if (!sourceNode || !targetNode) {
        return {
          rel,
          d: "",
          startX: 0,
          startY: 0,
          endX: 0,
          endY: 0,
          isHighlighted: false,
        };
      }

      const sourcePos: ErdTablePosition = customPositions[sourceNode.name] || {
        x: sourceNode.x,
        y: sourceNode.y,
      };
      const targetPos: ErdTablePosition = customPositions[targetNode.name] || {
        x: targetNode.x,
        y: targetNode.y,
      };

      const sourceCols: ErdColumnMeta[] = Array.isArray(sourceNode.columns) ? sourceNode.columns : [];
      const targetCols: ErdColumnMeta[] = Array.isArray(targetNode.columns) ? targetNode.columns : [];

      const sourceColIdx: number = Math.max(
        0,
        sourceCols.findIndex((c: ErdColumnMeta): boolean => c.name === rel.sourceColumn)
      );
      const targetColIdx: number = Math.max(
        0,
        targetCols.findIndex((c: ErdColumnMeta): boolean => c.name === rel.targetColumn)
      );

      const startY: number = sourcePos.y + HEADER_HEIGHT + (sourceColIdx + 0.5) * ROW_HEIGHT;
      const endY: number = targetPos.y + HEADER_HEIGHT + (targetColIdx + 0.5) * ROW_HEIGHT;

      let startX: number = 0;
      let endX: number = 0;

      if (sourceNode.name.toLowerCase() === targetNode.name.toLowerCase()) {
        // Self-referencing table loop
        startX = sourcePos.x + sourceNode.width;
        endX = sourcePos.x + sourceNode.width;
        const loopRadius: number = 30;
        const d: string = `M ${startX} ${startY} C ${startX + loopRadius * 2} ${startY}, ${
          endX + loopRadius * 2
        } ${endY}, ${endX} ${endY}`;
        const isHighlighted: boolean =
          hoveredRelId === rel.id ||
          selectedTable === rel.sourceTable ||
          selectedTable === rel.targetTable;

        return { rel, d, startX, startY, endX, endY, isHighlighted };
      }

      if (sourcePos.x < targetPos.x) {
        startX = sourcePos.x + sourceNode.width;
        endX = targetPos.x;
      } else {
        startX = sourcePos.x;
        endX = targetPos.x + targetNode.width;
      }

      const deltaX: number = Math.abs(endX - startX);
      const curveOffset: number = Math.max(deltaX * 0.45, 40);

      const ctrl1X: number = startX < endX ? startX + curveOffset : startX - curveOffset;
      const ctrl2X: number = startX < endX ? endX - curveOffset : endX + curveOffset;

      const d: string = `M ${startX} ${startY} C ${ctrl1X} ${startY}, ${ctrl2X} ${endY}, ${endX} ${endY}`;
      const isHighlighted: boolean =
        hoveredRelId === rel.id ||
        selectedTable === rel.sourceTable ||
        selectedTable === rel.targetTable;

      return {
        rel,
        d,
        startX,
        startY,
        endX,
        endY,
        isHighlighted,
      };
    });
  }, [diagramData, tableNodeMap, hoveredRelId, selectedTable, customPositions]);

  // Check if table matches search query
  const isTableMatchingSearch: (tblName: string) => boolean = (tblName: string): boolean => {
    if (!searchFilter.trim()) return true;
    return tblName.toLowerCase().includes(searchFilter.trim().toLowerCase());
  };

  // ── Drag & Drop Canvas View Panning ──
  const handleCanvasMouseDown: (e: React.MouseEvent<HTMLDivElement>) => void = (
    e: React.MouseEvent<HTMLDivElement>
  ): void => {
    // Only pan if clicking on viewport background or SVG canvas, not on cards or buttons
    const target: HTMLElement = e.target as HTMLElement;
    if (
      target.closest(".erd-table-card") ||
      target.closest("button") ||
      target.closest("input") ||
      target.closest(".erd-toolbar")
    ) {
      return;
    }

    panStartRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      initialPanX: pan.x,
      initialPanY: pan.y,
    };
    setIsPanning(true);
  };

  const handleGlobalMouseMove: (e: React.MouseEvent<HTMLDivElement>) => void = (
    e: React.MouseEvent<HTMLDivElement>
  ): void => {
    if (draggingCard) {
      const dx: number = (e.clientX - draggingCard.startMouseX) / zoom;
      const dy: number = (e.clientY - draggingCard.startMouseY) / zoom;
      const newX: number = Math.max(10, Math.round(draggingCard.initialCardX + dx));
      const newY: number = Math.max(10, Math.round(draggingCard.initialCardY + dy));

      setCustomPositions(
        (prev: Record<string, ErdTablePosition>): Record<string, ErdTablePosition> => ({
          ...prev,
          [draggingCard.tableName]: { x: newX, y: newY },
        })
      );
    } else if (isPanning) {
      const dx: number = e.clientX - panStartRef.current.startX;
      const dy: number = e.clientY - panStartRef.current.startY;
      setPan({
        x: Math.round(panStartRef.current.initialPanX + dx),
        y: Math.round(panStartRef.current.initialPanY + dy),
      });
    }
  };

  const handleGlobalMouseUp: () => void = (): void => {
    if (draggingCard) {
      setDraggingCard(null);
    }
    if (isPanning) {
      setIsPanning(false);
    }
  };

  // ── Drag & Drop Table Card Repositioning ──
  const handleCardHeaderMouseDown: (tableName: string, node: ErdTableNode, e: React.MouseEvent) => void = (
    tableName: string,
    node: ErdTableNode,
    e: React.MouseEvent
  ): void => {
    e.stopPropagation();
    setSelectedTable(tableName);
    if (onSelectTable) onSelectTable(tableName);

    const currentPos: ErdTablePosition = customPositions[tableName] || { x: node.x, y: node.y };

    setDraggingCard({
      tableName,
      startMouseX: e.clientX,
      startMouseY: e.clientY,
      initialCardX: currentPos.x,
      initialCardY: currentPos.y,
    });
  };

  // ── XML Modal Handlers ──
  const handleOpenXmlModal: () => void = (): void => {
    if (xmlSchema) {
      setXmlInputText(serializeErpSchemaToXml(xmlSchema));
    } else if (diagramData.tables.length > 0) {
      // Serialize current diagram data as starting template
      const currentSchema: XmlErpSchemaDefinition = {
        name: "current_database_schema",
        version: "1.0",
        tables: diagramData.tables.map((t: ErdTableNode) => ({
          name: t.name,
          rowCount: t.rowCount,
          columns: t.columns.map((c: ErdColumnMeta) => ({
            name: c.name,
            type: c.inferredType,
            primaryKey: c.isPrimaryKey,
            targetTable: c.targetTable,
            targetColumn: c.targetColumn,
          })),
        })),
        relationships: diagramData.relationships.map((r: TableRelationship) => ({
          id: r.id,
          sourceTable: r.sourceTable,
          sourceColumn: r.sourceColumn,
          targetTable: r.targetTable,
          targetColumn: r.targetColumn,
          cardinality: r.cardinality,
          label: r.label,
        })),
      };
      setXmlInputText(serializeErpSchemaToXml(currentSchema));
    } else {
      setXmlInputText(SAMPLE_ENTERPRISE_ERP_XML);
    }
    setXmlError(null);
    setIsXmlModalOpen(true);
  };

  const handleApplyXmlText: () => void = (): void => {
    try {
      const parsed: XmlErpSchemaDefinition = parseXmlErpSchema(xmlInputText);
      if (!parsed.tables.length && !parsed.relationships.length) {
        setXmlError("XML did not contain any valid <table ...> or <relationship ...> elements.");
        return;
      }
      setXmlSchema(parsed);
      setXmlError(null);
      setIsXmlModalOpen(false);
      if (onXmlSchemaLoaded) {
        onXmlSchemaLoaded(parsed);
      }
    } catch (err: unknown) {
      setXmlError(`Failed to parse XML: ${err instanceof Error ? err.message : String(err)}`);
    }
  };

  const handleLoadSampleXml: () => void = (): void => {
    setXmlInputText(SAMPLE_ENTERPRISE_ERP_XML);
    setXmlError(null);
  };

  const handleFileUpload: (e: React.ChangeEvent<HTMLInputElement>) => void = (
    e: React.ChangeEvent<HTMLInputElement>
  ): void => {
    const file: File | undefined = e.target.files?.[0];
    if (!file) return;

    const reader: FileReader = new FileReader();
    reader.onload = (event: ProgressEvent<FileReader>): void => {
      const content: string = (event.target?.result as string) || "";
      setXmlInputText(content);
      setXmlError(null);
    };
    reader.readAsText(file);
  };

  const handleClearXmlSchema: () => void = (): void => {
    setXmlSchema(null);
    setCustomPositions({});
  };

  return (
    <div
      id="erd-schema-viewer-container"
      className="erd-viewer-container"
      onMouseMove={handleGlobalMouseMove}
      onMouseUp={handleGlobalMouseUp}
    >
      {/* ── 1. ERD Controls & Filtering Toolbar ── */}
      <div id="erd-toolbar" className="erd-toolbar" role="toolbar" aria-label="ERD Controls">
        <div id="erd-toolbar-left-group" className="flex items-center gap-2">
          <div id="erd-search-input-box" className="w-56">
            <Input
              id="input-erd-search-table"
              size="sm"
              placeholder="Search table in ERD..."
              value={searchFilter}
              onChange={(e: React.ChangeEvent<HTMLInputElement>): void => setSearchFilter(e.target.value)}
            />
          </div>

          <div id="erd-stats-badges" className="flex items-center gap-1.5 ml-1">
            <Badge id="badge-erd-tables-count" variant="primary" size="sm">
              <IdeIcon name="Table" size="xs" className="mr-1" />
              {diagramData.tables.length} Tables
            </Badge>
            <Badge id="badge-erd-relations-count" variant="secondary" size="sm">
              <IdeIcon name="Network" size="xs" className="mr-1" />
              {diagramData.relationships.length} Relationships
            </Badge>

            {xmlSchema && (
              <div id="erd-xml-active-badge-group" className="flex items-center gap-1 ml-1">
                <Badge
                  id="badge-erd-xml-active"
                  variant="primary"
                  size="sm"
                  title={`ERP XML active: ${xmlSchema.name} (${xmlSchema.relationships.length} relationships)`}
                >
                  <IdeIcon name="FileCode" size="xs" className="mr-1" />
                  ERP XML: {xmlSchema.name}
                </Badge>
                <Button
                  id="btn-erd-clear-xml"
                  variant="ghost"
                  size="xs"
                  onClick={handleClearXmlSchema}
                  title="Remove XML schema and revert to database schema"
                  aria-label="Clear XML Schema"
                >
                  <IdeIcon name="X" size="xs" />
                </Button>
              </div>
            )}
          </div>
        </div>

        {/* Center / Right Layout, XML, Pan & Zoom Controls */}
        <div id="erd-toolbar-right-group" className="flex items-center gap-1.5">
          {/* ERP XML Action Button */}
          <Button
            id="btn-erd-xml-modal"
            variant={xmlSchema ? "primary" : "secondary"}
            size="xs"
            onClick={handleOpenXmlModal}
            title="Import, Edit or Load ERP XML Schema Mapping"
            aria-label="ERP XML Mapping"
          >
            <IdeIcon name="FileCode" size="xs" />
            <span>ERP XML</span>
          </Button>

          {/* Reset positions if any custom drag coordinates are set */}
          {Object.keys(customPositions).length > 0 && (
            <Button
              id="btn-erd-reset-positions"
              variant="ghost"
              size="xs"
              onClick={handleResetPositions}
              title="Reset dragged table positions to default layout"
              aria-label="Reset Table Positions"
            >
              <IdeIcon name="RotateCcw" size="xs" />
              <span>Reset Layout</span>
            </Button>
          )}

          {/* Reset Pan if panned */}
          {(pan.x !== 0 || pan.y !== 0) && (
            <Button
              id="btn-erd-reset-pan"
              variant="ghost"
              size="xs"
              onClick={handleResetPan}
              title={`Reset Pan (X: ${pan.x}, Y: ${pan.y})`}
              aria-label="Reset Pan View"
            >
              <IdeIcon name="Move" size="xs" />
              <span>Center</span>
            </Button>
          )}

          {/* Layout Mode Toggles */}
          <div id="erd-layout-toggle-group" className="flex items-center gap-1 bg-surface-muted rounded p-0.5 border border-border">
            <Button
              id="btn-erd-layout-grid"
              variant={layoutMode === "grid" ? "primary" : "ghost"}
              size="xs"
              onClick={(): void => {
                setLayoutMode("grid");
                setCustomPositions({});
              }}
              title="Arrange tables in compact Grid layout"
              aria-label="Grid Layout"
            >
              <IdeIcon name="Grid" size="xs" />
              <span>Grid</span>
            </Button>
            <Button
              id="btn-erd-layout-hierarchical"
              variant={layoutMode === "hierarchical" ? "primary" : "ghost"}
              size="xs"
              onClick={(): void => {
                setLayoutMode("hierarchical");
                setCustomPositions({});
              }}
              title="Arrange tables in Topological / Hierarchical dependency order"
              aria-label="Hierarchical Layout"
            >
              <IdeIcon name="GitFork" size="xs" />
              <span>Hierarchy</span>
            </Button>
          </div>

          {/* Zoom Controls */}
          <div id="erd-zoom-controls-group" className="flex items-center gap-1 border-l border-border pl-2 ml-1">
            <Button
              id="btn-erd-zoom-out"
              variant="ghost"
              size="xs"
              onClick={handleZoomOut}
              title="Zoom Out (-)"
              aria-label="Zoom Out"
            >
              <IdeIcon name="Minus" size="xs" />
            </Button>

            <span id="text-erd-zoom-level" className="text-xs font-mono font-medium theme-text px-1 min-w-[42px] text-center">
              {Math.round(zoom * 100)}%
            </span>

            <Button
              id="btn-erd-zoom-in"
              variant="ghost"
              size="xs"
              onClick={handleZoomIn}
              title="Zoom In (+)"
              aria-label="Zoom In"
            >
              <IdeIcon name="Plus" size="xs" />
            </Button>

            <Button
              id="btn-erd-zoom-reset"
              variant="ghost"
              size="xs"
              onClick={handleResetZoom}
              title="Reset Zoom to 100%"
              aria-label="Reset Zoom"
            >
              <IdeIcon name="Maximize2" size="xs" />
            </Button>

            <Button
              id="btn-erd-fit-view"
              variant="ghost"
              size="xs"
              onClick={handleFitView}
              title="Fit diagram to viewport"
              aria-label="Fit View"
            >
              <IdeIcon name="Shrink" size="xs" />
              <span>Fit</span>
            </Button>
          </div>

          {onSwitchToExplorer && (
            <Button
              id="btn-erd-open-explorer"
              variant="secondary"
              size="xs"
              onClick={onSwitchToExplorer}
              title="Switch to Tables Explorer data grid"
              aria-label="Tables Explorer"
              className="ml-2"
            >
              <IdeIcon name="Table" size="xs" />
              <span>Data Grid</span>
            </Button>
          )}
        </div>
      </div>

      {/* ── 2. ERD Interactive Canvas Area with Drag-to-Pan ── */}
      <div
        id="erd-canvas-viewport"
        ref={canvasRef}
        className={`erd-canvas-wrapper ${isPanning ? "is-panning" : ""}`}
        onMouseDown={handleCanvasMouseDown}
      >
        {diagramData.tables.length === 0 ? (
          <div id="erd-empty-state-card" className="erd-empty-state">
            <IdeIcon name="Network" size="xl" color="var(--primary, #2563eb)" />
            <h3 id="erd-empty-title" className="text-sm font-semibold theme-text mt-2">
              No Tables in Active Database
            </h3>
            <p id="erd-empty-desc" className="text-xs theme-text-muted mt-1 max-w-sm text-center">
              Create tables in SQL Query Console or click ERP XML above to load an enterprise schema mapping file.
            </p>
            <Button
              id="btn-erd-empty-load-sample"
              variant="primary"
              size="sm"
              className="mt-3"
              onClick={handleOpenXmlModal}
            >
              <IdeIcon name="FileCode" size="xs" />
              <span>Load ERP XML Schema</span>
            </Button>
          </div>
        ) : (
          <div
            id="erd-zoom-spacer"
            className="erd-zoom-spacer"
            style={{
              width: Math.ceil((canvasBounds.width + Math.abs(pan.x)) * zoom),
              height: Math.ceil((canvasBounds.height + Math.abs(pan.y)) * zoom),
            }}
          >
            <div
              id="erd-scalable-canvas"
              className="erd-canvas"
              style={{
                width: canvasBounds.width,
                height: canvasBounds.height,
                transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
                transformOrigin: "0 0",
              }}
            >
              {/* SVG Connector Layer */}
              <svg
                id="erd-svg-connectors"
                className="erd-svg-layer"
                width={canvasBounds.width}
                height={canvasBounds.height}
              >
                <defs>
                  <marker
                    id="erd-arrow-end"
                    markerWidth="8"
                    markerHeight="8"
                    refX="6"
                    refY="4"
                    orient="auto"
                  >
                    <polygon points="0 1, 7 4, 0 7" fill="var(--primary, #2563eb)" />
                  </marker>
                  <marker
                    id="erd-arrow-dimmed"
                    markerWidth="8"
                    markerHeight="8"
                    refX="6"
                    refY="4"
                    orient="auto"
                  >
                    <polygon points="0 1, 7 4, 0 7" fill="var(--border, #94a3b8)" />
                  </marker>
                </defs>

                {relationshipPaths.map((item) => {
                  if (!item.d) return null;
                  const pathClass: string = `erd-connector-path ${item.isHighlighted ? "highlighted" : ""}`;
                  return (
                    <g
                      key={item.rel.id}
                      id={`erd-rel-group-${item.rel.id.replace(/[^a-zA-Z0-9_-]/g, "-")}`}
                      className="erd-connector-group"
                      onMouseEnter={(): void => setHoveredRelId(item.rel.id)}
                      onMouseLeave={(): void => setHoveredRelId(null)}
                    >
                      {/* Wider transparent hit-area for easier hovering */}
                      <path
                        d={item.d}
                        fill="none"
                        stroke="transparent"
                        strokeWidth={14}
                        className="cursor-pointer"
                      >
                        <title>{item.rel.label} ({item.rel.cardinality})</title>
                      </path>

                      {/* Visible relationship connector line */}
                      <path
                        id={`path-${item.rel.id.replace(/[^a-zA-Z0-9_-]/g, "-")}`}
                        d={item.d}
                        fill="none"
                        stroke={item.isHighlighted ? "var(--primary, #2563eb)" : "var(--border, #94a3b8)"}
                        strokeWidth={item.isHighlighted ? 2.5 : 1.5}
                        strokeDasharray={item.isHighlighted ? "none" : "4 2"}
                        markerEnd={item.isHighlighted ? "url(#erd-arrow-end)" : "url(#erd-arrow-dimmed)"}
                        className={pathClass}
                      />

                      {/* Source Anchor Circle */}
                      <circle
                        cx={item.startX}
                        cy={item.startY}
                        r={item.isHighlighted ? 4 : 3}
                        fill={item.isHighlighted ? "var(--primary, #2563eb)" : "var(--text-muted, #64748b)"}
                      />
                    </g>
                  );
                })}
              </svg>

              {/* DOM Table Node Cards with Drag-and-Drop */}
              {diagramData.tables.map((node: ErdTableNode) => {
                const isSelected: boolean = selectedTable === node.name;
                const matchesSearch: boolean = isTableMatchingSearch(node.name);
                const pos: ErdTablePosition = customPositions[node.name] || { x: node.x, y: node.y };
                const isDraggingThisCard: boolean = draggingCard?.tableName === node.name;

                return (
                  <div
                    key={node.name}
                    id={`erd-table-card-${node.name}`}
                    className={`erd-table-card ${isSelected ? "selected" : ""} ${
                      matchesSearch ? "" : "dimmed"
                    } ${isDraggingThisCard ? "is-dragging" : ""}`}
                    style={{
                      left: pos.x,
                      top: pos.y,
                      width: node.width,
                    }}
                    onClick={(): void => {
                      setSelectedTable(node.name);
                      if (onSelectTable) onSelectTable(node.name);
                    }}
                  >
                    {/* Table Card Header (Draggable handle) */}
                    <div
                      id={`erd-header-${node.name}`}
                      className="erd-table-header draggable"
                      onMouseDown={(e: React.MouseEvent): void => handleCardHeaderMouseDown(node.name, node, e)}
                      title="Click and drag header to move table card"
                    >
                      <div className="flex items-center gap-1.5 truncate">
                        <IdeIcon name="Move" size="xs" className="text-muted opacity-60 mr-0.5" />
                        <IdeIcon name="Table" size="xs" color="var(--primary, #2563eb)" />
                        <span className="font-semibold text-xs theme-text truncate" title={node.name}>
                          {node.name}
                        </span>
                      </div>

                      <Badge variant="secondary" size="xs">
                        {node.rowCount}
                      </Badge>
                    </div>

                    {/* Columns List */}
                    <div id={`erd-columns-${node.name}`} className="erd-table-columns">
                      {(Array.isArray(node.columns) ? node.columns : []).map((col: ErdColumnMeta) => {
                        const isPk: boolean = col.isPrimaryKey;
                        const isFk: boolean = col.isForeignKey;

                        return (
                          <div
                            key={col.name}
                            id={`erd-col-${node.name}-${col.name}`}
                            className={`erd-column-row ${isPk ? "is-pk" : ""} ${isFk ? "is-fk" : ""}`}
                            title={
                              isFk
                                ? `Foreign Key ➔ ${col.targetTable}.${col.targetColumn}`
                                : isPk
                                ? "Primary Key"
                                : col.name
                            }
                          >
                            <div className="flex items-center gap-1.5 truncate min-w-0">
                              {isPk && (
                                <span className="erd-badge-pk" title="Primary Key">
                                  <IdeIcon name="Key" size="xs" color="#f59e0b" />
                                </span>
                              )}
                              {isFk && !isPk && (
                                <span className="erd-badge-fk" title={`References ${col.targetTable}.${col.targetColumn}`}>
                                  <IdeIcon name="Link2" size="xs" color="#3b82f6" />
                                </span>
                              )}
                              {!isPk && !isFk && (
                                <span className="w-3 inline-block" />
                              )}
                              <span className="erd-column-name truncate">
                                {col.name}
                              </span>
                            </div>

                            <span className="erd-column-type" title={col.inferredType}>
                              {col.inferredType.split(" ")[0]}
                            </span>
                          </div>
                        );
                      })}
                    </div>

                    {/* Table Card Actions Footer */}
                    <div id={`erd-footer-${node.name}`} className="erd-table-footer">
                      <Button
                        id={`btn-erd-query-${node.name}`}
                        variant="ghost"
                        size="xs"
                        className="erd-card-action-btn"
                        onClick={(e: React.MouseEvent): void => {
                          e.stopPropagation();
                          if (onOpenInConsole) onOpenInConsole(node.name);
                        }}
                        title={`Open SQL Query Console for table ${node.name}`}
                        aria-label={`Query ${node.name}`}
                      >
                        <IdeIcon name="Terminal" size="xs" color="var(--primary, #2563eb)" />
                        <span>Query</span>
                      </Button>

                      <Button
                        id={`btn-erd-inspect-${node.name}`}
                        variant="ghost"
                        size="xs"
                        className="erd-card-action-btn"
                        onClick={(e: React.MouseEvent): void => {
                          e.stopPropagation();
                          if (onSelectTable) onSelectTable(node.name);
                          if (onSwitchToExplorer) onSwitchToExplorer();
                        }}
                        title={`View table ${node.name} rows in Tables Explorer`}
                        aria-label={`View data for ${node.name}`}
                      >
                        <IdeIcon name="Table" size="xs" />
                        <span>Data</span>
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* ── 3. ERP XML Schema Mapping Modal ── */}
      {isXmlModalOpen && (
        <div id="erd-xml-modal-overlay" className="erd-xml-modal-overlay" onClick={(): void => setIsXmlModalOpen(false)}>
          <div
            id="erd-xml-modal-container"
            className="erd-xml-modal-container"
            onClick={(e: React.MouseEvent): void => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div id="erd-xml-modal-header" className="erd-xml-modal-header">
              <div className="flex items-center gap-2">
                <IdeIcon name="FileCode" size="sm" color="var(--primary, #2563eb)" />
                <h3 className="font-semibold text-sm theme-text">
                  ERP Schema &amp; Relationship Mapping (XML)
                </h3>
              </div>
              <Button
                id="btn-erd-xml-close"
                variant="ghost"
                size="xs"
                onClick={(): void => setIsXmlModalOpen(false)}
                aria-label="Close Modal"
              >
                <IdeIcon name="X" size="xs" />
              </Button>
            </div>

            {/* Modal Body */}
            <div id="erd-xml-modal-body" className="erd-xml-modal-body">
              <div id="erd-xml-modal-actions-bar" className="flex items-center justify-between gap-2 flex-wrap">
                <div className="flex items-center gap-1.5">
                  <Button
                    id="btn-erd-xml-sample"
                    variant="secondary"
                    size="xs"
                    onClick={handleLoadSampleXml}
                    title="Load complete Enterprise ERP sample schema with 8 tables and relationships"
                  >
                    <IdeIcon name="FileText" size="xs" />
                    <span>Load ERP Sample</span>
                  </Button>

                  <label
                    id="label-erd-xml-upload"
                    className="inline-flex items-center gap-1 text-xs px-2.5 py-1 rounded border border-border bg-surface-muted hover:bg-surface cursor-pointer theme-text font-medium"
                  >
                    <IdeIcon name="Upload" size="xs" />
                    <span>Upload .xml</span>
                    <input
                      id="input-erd-xml-file"
                      type="file"
                      accept=".xml,text/xml"
                      className="hidden"
                      onChange={handleFileUpload}
                    />
                  </label>
                </div>

                <span className="text-xs theme-text-muted">
                  Paste or edit XML schema definitions containing &lt;table&gt; and &lt;relationship&gt;
                </span>
              </div>

              {xmlError && (
                <div id="erd-xml-error-alert" className="p-2.5 rounded bg-red-50 text-red-700 text-xs border border-red-200">
                  <strong>XML Parsing Error:</strong> {xmlError}
                </div>
              )}

              <textarea
                id="erd-xml-textarea"
                className="erd-xml-textarea"
                value={xmlInputText}
                onChange={(e: React.ChangeEvent<HTMLTextAreaElement>): void => setXmlInputText(e.target.value)}
                placeholder="Paste XML ERP schema definition here..."
                spellCheck={false}
              />
            </div>

            {/* Modal Footer */}
            <div id="erd-xml-modal-footer" className="erd-xml-modal-footer">
              <div className="flex items-center gap-2">
                {xmlSchema && (
                  <Button
                    id="btn-erd-xml-clear"
                    variant="ghost"
                    size="xs"
                    onClick={(): void => {
                      handleClearXmlSchema();
                      setIsXmlModalOpen(false);
                    }}
                  >
                    <IdeIcon name="Trash2" size="xs" />
                    <span>Clear Schema</span>
                  </Button>
                )}
              </div>

              <div className="flex items-center gap-2">
                <Button
                  id="btn-erd-xml-cancel"
                  variant="ghost"
                  size="sm"
                  onClick={(): void => setIsXmlModalOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  id="btn-erd-xml-apply"
                  variant="primary"
                  size="sm"
                  onClick={handleApplyXmlText}
                >
                  <IdeIcon name="Check" size="xs" />
                  <span>Apply ERP Mapping</span>
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ErdSchemaViewer;
