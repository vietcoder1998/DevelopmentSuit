import React, { useState } from "react";
import { Button, Input, IdeIcon, Modal } from "../bases";

export interface DatabaseSelectorProps {
  readonly databases: string[];
  readonly activeDatabase: string;
  readonly onSelectDatabase: (name: string) => void;
  readonly onCreateDatabase: (name: string) => Promise<void>;
  readonly onRequestCreateModal?: () => void;
}

export const DatabaseSelector: React.FC<DatabaseSelectorProps> = ({
  databases,
  activeDatabase,
  onSelectDatabase,
  onCreateDatabase,
  onRequestCreateModal,
}) => {
  const [showInternalModal, setShowInternalModal]: [
    boolean,
    React.Dispatch<React.SetStateAction<boolean>>
  ] = useState<boolean>(false);
  const [newDbName, setNewDbName]: [
    string,
    React.Dispatch<React.SetStateAction<string>>
  ] = useState<string>("");
  const [isSubmitting, setIsSubmitting]: [
    boolean,
    React.Dispatch<React.SetStateAction<boolean>>
  ] = useState<boolean>(false);
  const [errorMsg, setErrorMsg]: [
    string | null,
    React.Dispatch<React.SetStateAction<string | null>>
  ] = useState<string | null>(null);

  const handleOpenCreate: () => void = (): void => {
    if (onRequestCreateModal) {
      onRequestCreateModal();
    } else {
      setShowInternalModal(true);
      setErrorMsg(null);
    }
  };

  const handleCloseInternalModal: () => void = (): void => {
    setShowInternalModal(false);
    setNewDbName("");
    setErrorMsg(null);
  };

  const handleCreate: () => Promise<void> = async (): Promise<void> => {
    const trimmed: string = newDbName.trim();
    if (!trimmed || isSubmitting) return;

    if (databases.includes(trimmed)) {
      setErrorMsg(`Database "${trimmed}" already exists.`);
      return;
    }

    setIsSubmitting(true);
    try {
      await onCreateDatabase(trimmed);
      setNewDbName("");
      setErrorMsg(null);
      setShowInternalModal(false);
    } catch (err: unknown) {
      setErrorMsg(err instanceof Error ? err.message : "Failed to create database");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div id="sqlclient-database-selector-bar" className="flex items-center gap-2 w-full">
      <div id="sqlclient-database-dropdown-container" className="flex items-center gap-2 flex-1 min-w-0">
        <label
          id="sqlclient-db-select-label"
          htmlFor="sqlclient-db-select"
          className="text-xs font-semibold theme-text-muted flex items-center gap-1 shrink-0"
        >
          <IdeIcon name="Database" size="xs" color="var(--primary, #2563eb)" />
          Database:
        </label>
        <select
          id="sqlclient-db-select"
          value={activeDatabase}
          onChange={(e: React.ChangeEvent<HTMLSelectElement>): void =>
            onSelectDatabase(e.target.value)
          }
          className="px-2.5 py-1 text-xs rounded border theme-border theme-surface theme-text w-full truncate"
        >
          {databases.map((db: string) => (
            <option key={db} value={db}>
              {db}
            </option>
          ))}
        </select>
      </div>

      <Button
        id="sqlclient-new-db-btn"
        variant="secondary"
        size="xs"
        onClick={handleOpenCreate}
        title="Create New Database (Electron Modal)"
        aria-label="Create New Database"
        className="shrink-0"
      >
        <IdeIcon name="Plus" size="xs" className="mr-1" />
        New DB
      </Button>

      {/* Internal Electron Modal (when onRequestCreateModal is not supplied) */}
      {!onRequestCreateModal && showInternalModal && (
        <Modal
          id="sqlclient-create-db-modal"
          isOpen={showInternalModal}
          onClose={handleCloseInternalModal}
          title="Create New Database"
          footer={
            <div id="sqlclient-create-db-modal-footer" className="flex items-center justify-end gap-2 w-full">
              <Button
                id="sqlclient-cancel-create-db-btn"
                variant="secondary"
                size="sm"
                onClick={handleCloseInternalModal}
                disabled={isSubmitting}
              >
                Cancel
              </Button>
              <Button
                id="sqlclient-confirm-create-db-btn"
                variant="primary"
                size="sm"
                onClick={handleCreate}
                disabled={!newDbName.trim() || isSubmitting}
              >
                {isSubmitting ? "Creating..." : "Create"}
              </Button>
            </div>
          }
        >
          <div id="sqlclient-create-db-modal-body" className="div-col gap-3 py-2">
            <div id="sqlclient-modal-desc-box" className="flex items-center gap-2">
              <IdeIcon name="Database" size="sm" color="var(--primary, #2563eb)" />
              <p id="sqlclient-modal-desc-text" className="text-xs theme-text-muted">
                Enter a name for the new SQLite / LocalDB database. It will be initialized and activated immediately.
              </p>
            </div>

            <div id="sqlclient-modal-input-group" className="div-col gap-1.5">
              <label htmlFor="sqlclient-new-db-input" className="text-xs font-semibold theme-text">
                Database Name
              </label>
              <Input
                id="sqlclient-new-db-input"
                size="sm"
                placeholder="e.g. metrics_db..."
                value={newDbName}
                onChange={(e: React.ChangeEvent<HTMLInputElement>): void => {
                  setNewDbName(e.target.value);
                  if (errorMsg) setErrorMsg(null);
                }}
                onKeyDown={(e: React.KeyboardEvent<HTMLInputElement>): void => {
                  if (e.key === "Enter" && newDbName.trim() && !isSubmitting) {
                    e.preventDefault();
                    void handleCreate();
                  }
                }}
                autoFocus
              />
              {errorMsg && (
                <span id="sqlclient-new-db-error" className="text-xs text-red-500 font-medium">
                  {errorMsg}
                </span>
              )}
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};

export default DatabaseSelector;
