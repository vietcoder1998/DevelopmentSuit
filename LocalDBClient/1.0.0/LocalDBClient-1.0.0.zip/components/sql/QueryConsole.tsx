import React, { useState } from "react";
import { IdeIcon, Button, Badge } from "../bases";

export interface QueryResultData {
  readonly data: unknown;
  readonly executionTimeMs: number;
  readonly rowsAffected: number;
}

export interface QueryConsoleProps {
  readonly onRunQuery: (sql: string) => Promise<QueryResultData>;
  readonly defaultQuery?: string;
  readonly activeDatabase?: string;
}

export const QueryConsole: React.FC<QueryConsoleProps> = ({
  onRunQuery,
  defaultQuery = "SELECT * FROM users;",
}) => {
  const [sqlQuery, setSqlQuery]: [
    string,
    React.Dispatch<React.SetStateAction<string>>
  ] = useState<string>(defaultQuery);
  const [isExecuting, setIsExecuting]: [
    boolean,
    React.Dispatch<React.SetStateAction<boolean>>
  ] = useState<boolean>(false);
  const [executionResult, setExecutionResult]: [
    unknown | null,
    React.Dispatch<React.SetStateAction<unknown | null>>
  ] = useState<unknown | null>(null);
  const [lastExecutionTimeMs, setLastExecutionTimeMs]: [
    number | null,
    React.Dispatch<React.SetStateAction<number | null>>
  ] = useState<number | null>(null);
  const [errorMessage, setErrorMessage]: [
    string | null,
    React.Dispatch<React.SetStateAction<string | null>>
  ] = useState<string | null>(null);

  const presets: Array<{ label: string; sql: string }> = [
    { label: "Show Tables", sql: "SHOW TABLES;" },
    { label: "Show Databases", sql: "SHOW DATABASES;" },
    { label: "Select Users", sql: "SELECT * FROM users;" },
    { label: "Select Settings", sql: "SELECT * FROM lc_settings;" },
  ];

  const handleExecute = async (): Promise<void> => {
    if (!sqlQuery.trim()) return;
    setIsExecuting(true);
    setErrorMessage(null);
    try {
      const res = await onRunQuery(sqlQuery);
      setExecutionResult(res.data);
      setLastExecutionTimeMs(res.executionTimeMs);
    } catch (err: unknown) {
      setErrorMessage(err instanceof Error ? err.message : String(err));
      setExecutionResult(null);
    } finally {
      setIsExecuting(false);
    }
  };

  const columnsList: string[] =
    Array.isArray(executionResult) &&
    executionResult.length > 0 &&
    typeof executionResult[0] === "object" &&
    executionResult[0] !== null
      ? Object.keys(executionResult[0] as Record<string, unknown>)
      : [];

  return (
    <div id="sqlclient-query-console-container" className="sqlclient-card flex flex-col gap-4">
      <div id="sqlclient-query-console-header" className="sqlclient-card-header">
        <h3 id="sqlclient-query-console-title" className="sqlclient-card-title">
          <IdeIcon name="Terminal" size="md" color="var(--primary, #2563eb)" />
          Interactive SQL Console
        </h3>

        <div id="sqlclient-preset-queries-bar" className="sqlclient-preset-queries">
          {presets.map((preset) => (
            <button
              key={preset.label}
              id={`sqlclient-preset-btn-${preset.label.toLowerCase().replace(/\s+/g, "-")}`}
              className="sqlclient-preset-btn"
              onClick={(): void => setSqlQuery(preset.sql)}
            >
              {preset.label}
            </button>
          ))}
        </div>
      </div>

      <textarea
        id="sqlclient-sql-query-textarea"
        value={sqlQuery}
        onChange={(e: React.ChangeEvent<HTMLTextAreaElement>): void =>
          setSqlQuery(e.target.value)
        }
        placeholder="Enter SQL statement (e.g. SELECT * FROM users;)"
        className="sqlclient-query-editor"
      />

      <div id="sqlclient-query-actions-bar" className="sqlclient-query-actions">
        <div className="flex items-center gap-3">
          <Button
            id="sqlclient-run-query-btn"
            variant="primary"
            size="md"
            onClick={handleExecute}
            disabled={isExecuting}
          >
            <IdeIcon
              name="Play"
              size="xs"
              className={isExecuting ? "animate-spin mr-1" : "mr-1"}
            />
            {isExecuting ? "Executing..." : "Run Query"}
          </Button>

          {lastExecutionTimeMs !== null && (
            <Badge variant="success" size="sm">
              Execution Time: {lastExecutionTimeMs} ms
            </Badge>
          )}
        </div>
      </div>

      {errorMessage && (
        <div
          id="sqlclient-query-error-banner"
          className="p-3 text-xs bg-red-50 text-red-600 dark:bg-red-950 dark:text-red-300 rounded border border-red-200 dark:border-red-800"
        >
          {errorMessage}
        </div>
      )}

      {executionResult !== null && (
        <div id="sqlclient-query-results-wrapper" className="mt-2 flex flex-col gap-2">
          <h4 className="text-xs font-semibold uppercase theme-text-muted">
            Query Results (
            {Array.isArray(executionResult) ? executionResult.length : 1} rows)
          </h4>

          {Array.isArray(executionResult) && executionResult.length > 0 ? (
            <div
              id="sqlclient-query-result-table-wrapper"
              className="sqlclient-data-table-wrapper"
            >
              <table id="sqlclient-query-result-table" className="sqlclient-data-table">
                <thead>
                  <tr>
                    {columnsList.map((col: string) => (
                      <th key={col}>{col}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {executionResult.map((row: unknown, rIdx: number) => {
                    const rowObj: Record<string, unknown> =
                      typeof row === "object" && row !== null
                        ? (row as Record<string, unknown>)
                        : { value: row };
                    return (
                      <tr key={rIdx}>
                        {columnsList.map((col: string) => (
                          <td key={col} className="truncate max-w-[200px]">
                            {String(rowObj[col] ?? "NULL")}
                          </td>
                        ))}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          ) : (
            <div
              id="sqlclient-query-result-empty"
              className="p-4 rounded border theme-border theme-surface text-xs font-mono"
            >
              {JSON.stringify(executionResult, null, 2)}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default QueryConsole;
