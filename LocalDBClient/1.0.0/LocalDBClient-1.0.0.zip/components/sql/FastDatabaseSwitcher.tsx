"use client";

import React, { useState, useRef, useEffect } from "react";
import { IdeIcon, Button, Input, Badge } from "../bases";

export interface FastDatabaseSwitcherProps {
  readonly id?: string;
  readonly databases: string[];
  readonly activeDatabase: string;
  readonly onSelectDatabase: (name: string) => void;
  readonly onCreateDatabase?: (name: string) => Promise<void> | void;
  readonly variant?: "header" | "ribbon" | "sidebar";
  readonly className?: string;
}

export const FastDatabaseSwitcher: React.FC<FastDatabaseSwitcherProps> = ({
  id = "fast-db-switcher",
  databases,
  activeDatabase,
  onSelectDatabase,
  onCreateDatabase,
  variant = "header",
  className = "",
}) => {
  const [isOpen, setIsOpen]: [
    boolean,
    React.Dispatch<React.SetStateAction<boolean>>
  ] = useState<boolean>(false);
  const [filterText, setFilterText]: [
    string,
    React.Dispatch<React.SetStateAction<string>>
  ] = useState<string>("");
  const [isCreating, setIsCreating]: [
    boolean,
    React.Dispatch<React.SetStateAction<boolean>>
  ] = useState<boolean>(false);
  const [newDbInput, setNewDbInput]: [
    string,
    React.Dispatch<React.SetStateAction<string>>
  ] = useState<string>("");
  const [isSubmitting, setIsSubmitting]: [
    boolean,
    React.Dispatch<React.SetStateAction<boolean>>
  ] = useState<boolean>(false);

  const containerRef: React.MutableRefObject<HTMLDivElement | null> = useRef<HTMLDivElement | null>(null);

  // Click outside to close
  useEffect((): (() => void) => {
    const handleClickOutside: (e: MouseEvent) => void = (e: MouseEvent): void => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
        setIsCreating(false);
      }
    };
    if (isOpen) {
      document.addEventListener("mousedown", handleClickOutside);
    }
    return (): void => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [isOpen]);

  // Keyboard navigation: Escape closes popover
  useEffect((): (() => void) => {
    const handleKeyDown: (e: KeyboardEvent) => void = (e: KeyboardEvent): void => {
      if (e.key === "Escape" && isOpen) {
        setIsOpen(false);
        setIsCreating(false);
      }
    };
    if (isOpen) {
      window.addEventListener("keydown", handleKeyDown);
    }
    return (): void => {
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [isOpen]);

  const handleSelect: (dbName: string) => void = (dbName: string): void => {
    onSelectDatabase(dbName);
    setIsOpen(false);
    setIsCreating(false);
    setFilterText("");
  };

  const handleCreateSubmit: () => Promise<void> = async (): Promise<void> => {
    const trimmed: string = newDbInput.trim();
    if (!trimmed || isSubmitting) return;
    setIsSubmitting(true);
    try {
      if (onCreateDatabase) {
        await onCreateDatabase(trimmed);
      }
      onSelectDatabase(trimmed);
      setNewDbInput("");
      setIsCreating(false);
      setIsOpen(false);
    } finally {
      setIsSubmitting(false);
    }
  };

  const filteredDatabases: string[] = databases.filter((db: string): boolean =>
    db.toLowerCase().includes(filterText.toLowerCase())
  );

  const containerId: string = id;
  const triggerBtnId: string = `${id}-trigger-btn`;
  const dropdownId: string = `${id}-dropdown-menu`;

  return (
    <div
      ref={containerRef}
      id={containerId}
      className={`fast-db-switcher-container ${className}`}
    >
      {/* Fast Database Switcher Trigger Button */}
      <button
        id={triggerBtnId}
        type="button"
        aria-label={`Fast switch database (current: ${activeDatabase || "default"})`}
        className={`fast-db-switcher-btn variant-${variant} ${isOpen ? "open" : ""}`}
        onClick={(): void => setIsOpen((prev: boolean): boolean => !prev)}
        title={`Fast switch database (current: ${activeDatabase || "default"})`}
        aria-expanded={isOpen}
        aria-haspopup="listbox"
      >
        <IdeIcon name="Database" size="xs" color="var(--primary, #2563eb)" />
        <span id={`${id}-label-prefix`} className="theme-text-muted font-normal text-xs">
          DB:
        </span>
        <span id={`${id}-active-db-text`} className="font-semibold text-xs theme-text truncate max-w-[130px]">
          {activeDatabase || "default"}
        </span>
        <IdeIcon
          name={isOpen ? "ChevronUp" : "ChevronDown"}
          size="xs"
          className="theme-text-muted ml-0.5"
        />
      </button>

      {/* Floating Dropdown / Popover for Fast Switching */}
      {isOpen && (
        <div id={dropdownId} className="fast-db-switcher-dropdown" role="listbox">
          <div id={`${id}-dropdown-header`} className="fast-db-dropdown-header">
            <div className="flex items-center gap-1.5">
              <IdeIcon name="Database" size="xs" color="var(--primary, #2563eb)" />
              <span>Switch Database</span>
            </div>
            <Badge variant="secondary" size="xs">
              {databases.length}
            </Badge>
          </div>

          {/* Search filter if there are more than 3 databases */}
          {databases.length > 3 && (
            <div id={`${id}-search-box`} className="fast-db-search-box">
              <Input
                id={`${id}-filter-input`}
                size="sm"
                placeholder="Search databases..."
                value={filterText}
                onChange={(e: React.ChangeEvent<HTMLInputElement>): void =>
                  setFilterText(e.target.value)
                }
                autoFocus
              />
            </div>
          )}

          {/* List of available databases */}
          <div id={`${id}-databases-list`} className="fast-db-list">
            {filteredDatabases.map((db: string) => {
              const isActive: boolean = db === activeDatabase;
              return (
                <button
                  key={db}
                  id={`${id}-item-${db}`}
                  role="option"
                  aria-selected={isActive}
                  type="button"
                  className={`fast-db-item ${isActive ? "active" : ""}`}
                  onClick={(): void => handleSelect(db)}
                >
                  <div className="flex items-center gap-2 truncate">
                    <IdeIcon
                      name="Database"
                      size="xs"
                      color={isActive ? "var(--primary, #2563eb)" : "var(--text-muted, #64748b)"}
                    />
                    <span className="truncate">{db}</span>
                  </div>
                  {isActive && (
                    <IdeIcon name="Check" size="xs" color="var(--primary, #2563eb)" />
                  )}
                </button>
              );
            })}

            {filteredDatabases.length === 0 && (
              <div id={`${id}-no-databases`} className="p-3 text-center text-xs theme-text-muted">
                No database found
              </div>
            )}
          </div>

          {/* Quick Create Database Box */}
          {onCreateDatabase && (
            <div id={`${id}-create-box`} className="fast-db-create-box">
              {!isCreating ? (
                <Button
                  id={`${id}-new-db-btn`}
                  variant="ghost"
                  size="xs"
                  className="w-full justify-start text-xs font-medium"
                  onClick={(): void => setIsCreating(true)}
                >
                  <IdeIcon name="Plus" size="xs" className="mr-1" />
                  New Database
                </Button>
              ) : (
                <div id={`${id}-create-form`} className="flex items-center gap-1.5">
                  <Input
                    id={`${id}-new-db-input`}
                    size="sm"
                    placeholder="New DB name..."
                    value={newDbInput}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>): void =>
                      setNewDbInput(e.target.value)
                    }
                    onKeyDown={(e: React.KeyboardEvent<HTMLInputElement>): void => {
                      if (e.key === "Enter") handleCreateSubmit();
                    }}
                    autoFocus
                  />
                  <Button
                    id={`${id}-confirm-create-btn`}
                    variant="primary"
                    size="xs"
                    disabled={!newDbInput.trim() || isSubmitting}
                    onClick={handleCreateSubmit}
                  >
                    {isSubmitting ? "..." : "Add"}
                  </Button>
                  <Button
                    id={`${id}-cancel-create-btn`}
                    variant="ghost"
                    size="xs"
                    onClick={(): void => {
                      setIsCreating(false);
                      setNewDbInput("");
                    }}
                  >
                    <IdeIcon name="X" size="xs" />
                  </Button>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default FastDatabaseSwitcher;
