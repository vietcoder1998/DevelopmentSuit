import { TableItemMetadata } from "./TablesExplorer";

export type ErdCardinality = "one-to-many" | "many-to-one" | "one-to-one";

export interface TableRelationship {
  readonly id: string;
  readonly sourceTable: string;
  readonly sourceColumn: string;
  readonly targetTable: string;
  readonly targetColumn: string;
  readonly cardinality: ErdCardinality;
  readonly label: string;
}

export interface ErdColumnMeta {
  readonly name: string;
  readonly inferredType: string;
  readonly isPrimaryKey: boolean;
  readonly isForeignKey: boolean;
  readonly targetTable?: string;
  readonly targetColumn?: string;
}

export interface ErdTableNode {
  readonly name: string;
  readonly rowCount: number;
  readonly columnCount: number;
  readonly columns: ErdColumnMeta[];
  readonly x: number;
  readonly y: number;
  readonly width: number;
  readonly height: number;
}

export type ErdLayoutMode = "grid" | "hierarchical";

export interface ErdTablePosition {
  readonly x: number;
  readonly y: number;
}

export interface XmlErpTableColumn {
  readonly name: string;
  readonly type?: string;
  readonly primaryKey?: boolean;
  readonly foreignKey?: string;
  readonly references?: string;
  readonly targetTable?: string;
  readonly targetColumn?: string;
}

export interface XmlErpTable {
  readonly name: string;
  readonly rowCount?: number;
  readonly columnCount?: number;
  readonly description?: string;
  readonly columns: XmlErpTableColumn[];
}

export interface XmlErpRelationship {
  readonly id: string;
  readonly sourceTable: string;
  readonly sourceColumn: string;
  readonly targetTable: string;
  readonly targetColumn: string;
  readonly cardinality: ErdCardinality;
  readonly label: string;
}

export interface XmlErpSchemaDefinition {
  readonly name: string;
  readonly version?: string;
  readonly description?: string;
  readonly tables: XmlErpTable[];
  readonly relationships: XmlErpRelationship[];
  readonly rawXml?: string;
}

export interface ErdDiagramData {
  readonly tables: ErdTableNode[];
  readonly relationships: TableRelationship[];
  readonly xmlSchema?: XmlErpSchemaDefinition;
}

export interface ErdSchemaViewerProps {
  readonly tables: TableItemMetadata[];
  readonly activeTable: string | null;
  readonly initialXmlSchema?: string;
  readonly onSelectTable?: (tableName: string) => void;
  readonly onOpenInConsole?: (tableName: string) => void;
  readonly onSwitchToExplorer?: () => void;
  readonly onXmlSchemaLoaded?: (schema: XmlErpSchemaDefinition) => void;
}
