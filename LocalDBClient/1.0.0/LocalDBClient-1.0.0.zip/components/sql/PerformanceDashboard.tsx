import React, { useState, useEffect } from "react";
import { IdeIcon, Badge, Button } from "../bases";

export interface LatencyStatsPayload {
  readonly minMs: number;
  readonly maxMs: number;
  readonly avgMs: number;
  readonly p50Ms: number;
  readonly p95Ms: number;
  readonly p99Ms: number;
}

export interface MemoryStatsPayload {
  readonly heapUsedMb: number;
  readonly heapTotalMb: number;
  readonly rssMb: number;
  readonly externalMb: number;
  readonly systemTotalMb: number;
  readonly systemFreeMb: number;
}

export interface ServerPerformanceMetricsPayload {
  readonly uptimeSeconds: number;
  readonly totalQueries: number;
  readonly readsCount: number;
  readonly writesCount: number;
  readonly queriesPerSecond: number;
  readonly latency: LatencyStatsPayload;
  readonly memory: MemoryStatsPayload;
  readonly activeConnections: {
    readonly http: number;
    readonly grpc: number;
    readonly local: number;
    readonly total: number;
  };
  readonly timestamp: string;
}

export type PerformanceMetrics = ServerPerformanceMetricsPayload;

export interface PerformanceDashboardProps {
  readonly metrics: ServerPerformanceMetricsPayload | null;
  readonly onRefresh: () => void;
  readonly isRefreshing: boolean;
}

export const PerformanceDashboard: React.FC<PerformanceDashboardProps> = ({
  metrics,
  onRefresh,
  isRefreshing,
}) => {
  const [autoRefreshInterval, setAutoRefreshInterval]: [
    number,
    React.Dispatch<React.SetStateAction<number>>
  ] = useState<number>(3); // 3 seconds default

  useEffect((): (() => void) => {
    if (autoRefreshInterval <= 0) return (): void => {};
    const timer: NodeJS.Timeout = setInterval((): void => {
      onRefresh();
    }, autoRefreshInterval * 1000);
    return (): void => clearInterval(timer);
  }, [autoRefreshInterval, onRefresh]);

  const formatUptime = (seconds: number): string => {
    const hrs: number = Math.floor(seconds / 3600);
    const mins: number = Math.floor((seconds % 3600) / 60);
    const secs: number = Math.floor(seconds % 60);
    return `${hrs}h ${mins}m ${secs}s`;
  };

  const readWriteRatio: number =
    metrics && metrics.totalQueries > 0
      ? Number(((metrics.readsCount / metrics.totalQueries) * 100).toFixed(1))
      : 50;

  return (
    <div id="sqlclient-performance-dashboard-container" className="flex flex-col gap-5">
      {/* Top Bar Controls */}
      <div
        id="sqlclient-perf-header-bar"
        className="sqlclient-card flex items-center justify-between"
      >
        <div className="flex items-center gap-3">
          <IdeIcon name="Activity" size="lg" color="var(--primary, #2563eb)" />
          <div>
            <h3 id="sqlclient-perf-title" className="text-base font-bold theme-text">
              LocalSQLServer Performance Monitor
            </h3>
            <p className="text-xs theme-text-muted">
              Live telemetry: Local in-memory speed, LAN HTTP REST throughput, and gRPC execution.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 text-xs theme-text-muted">
            <span>Auto Refresh:</span>
            <select
              id="sqlclient-auto-refresh-select"
              value={autoRefreshInterval}
              onChange={(e: React.ChangeEvent<HTMLSelectElement>): void =>
                setAutoRefreshInterval(Number(e.target.value))
              }
              className="px-2 py-1 text-xs rounded border theme-border theme-surface theme-text"
            >
              <option value={0}>Off</option>
              <option value={1}>1 second</option>
              <option value={3}>3 seconds</option>
              <option value={5}>5 seconds</option>
            </select>
          </div>

          <Button
            id="sqlclient-perf-refresh-btn"
            variant="secondary"
            size="sm"
            onClick={onRefresh}
            disabled={isRefreshing}
          >
            <IdeIcon
              name="RotateCw"
              size="xs"
              className={isRefreshing ? "animate-spin mr-1" : "mr-1"}
            />
            Poll
          </Button>
        </div>
      </div>

      {metrics ? (
        <>
          {/* Key Metrics Grid */}
          <div id="sqlclient-perf-metrics-grid" className="sqlclient-metrics-grid">
            {/* 1. QPS */}
            <div id="sqlclient-metric-qps-card" className="sqlclient-metric-card">
              <div className="sqlclient-metric-header">
                <span>Queries / Sec</span>
                <IdeIcon name="Zap" size="sm" color="var(--warning, #f59e0b)" />
              </div>
              <div className="sqlclient-metric-value">{metrics.queriesPerSecond ?? 0}</div>
              <div className="sqlclient-metric-subtext">Current throughput</div>
            </div>

            {/* 2. Avg Latency */}
            <div id="sqlclient-metric-latency-card" className="sqlclient-metric-card">
              <div className="sqlclient-metric-header">
                <span>Avg Latency</span>
                <IdeIcon name="Clock" size="sm" color="var(--primary, #2563eb)" />
              </div>
              <div className="sqlclient-metric-value">
                {metrics.latency?.avgMs ?? 0} <span className="text-xs font-normal">ms</span>
              </div>
              <div className="sqlclient-metric-subtext">
                P50: {metrics.latency?.p50Ms ?? 0}ms | P95: {metrics.latency?.p95Ms ?? 0}ms
              </div>
            </div>

            {/* 3. Total Queries */}
            <div id="sqlclient-metric-queries-card" className="sqlclient-metric-card">
              <div className="sqlclient-metric-header">
                <span>Total Queries</span>
                <IdeIcon name="Database" size="sm" color="var(--success, #10b981)" />
              </div>
              <div className="sqlclient-metric-value">{metrics.totalQueries ?? 0}</div>
              <div className="sqlclient-metric-subtext">
                Reads: {metrics.readsCount ?? 0} | Writes: {metrics.writesCount ?? 0}
              </div>
            </div>

            {/* 4. Memory Heap */}
            <div id="sqlclient-metric-memory-card" className="sqlclient-metric-card">
              <div className="sqlclient-metric-header">
                <span>Heap Memory</span>
                <IdeIcon name="Cpu" size="sm" color="var(--info, #3b82f6)" />
              </div>
              <div className="sqlclient-metric-value">
                {metrics.memory?.heapUsedMb ?? 0} <span className="text-xs font-normal">MB</span>
              </div>
              <div className="sqlclient-metric-subtext">
                RSS: {metrics.memory?.rssMb ?? 0} MB / Total: {metrics.memory?.heapTotalMb ?? 0} MB
              </div>
            </div>

            {/* 5. Connections */}
            <div id="sqlclient-metric-connections-card" className="sqlclient-metric-card">
              <div className="sqlclient-metric-header">
                <span>Active Clients</span>
                <IdeIcon name="Radio" size="sm" color="var(--primary, #2563eb)" />
              </div>
              <div className="sqlclient-metric-value">
                {metrics.activeConnections?.total ?? 0}
              </div>
              <div className="sqlclient-metric-subtext">
                HTTP: {metrics.activeConnections?.http ?? 0} | gRPC: {metrics.activeConnections?.grpc ?? 0}
              </div>
            </div>

            {/* 6. Uptime */}
            <div id="sqlclient-metric-uptime-card" className="sqlclient-metric-card">
              <div className="sqlclient-metric-header">
                <span>Server Uptime</span>
                <IdeIcon name="CheckCircle" size="sm" color="var(--success, #10b981)" />
              </div>
              <div className="sqlclient-metric-value">
                {formatUptime(metrics.uptimeSeconds ?? 0)}
              </div>
              <div className="sqlclient-metric-subtext">Running in background</div>
            </div>
          </div>

          {/* Detailed Telemetry Panels */}
          <div id="sqlclient-telemetry-panels-row" className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* Latency Percentiles Card */}
            <div id="sqlclient-latency-percentiles-card" className="sqlclient-card">
              <h4 className="font-semibold text-sm mb-4 flex items-center gap-2">
                <IdeIcon name="BarChart3" size="sm" />
                Latency Percentiles (Microsecond Accuracy)
              </h4>
              <div className="space-y-3">
                <div className="flex justify-between items-center text-xs">
                  <span className="theme-text-muted">Minimum Latency:</span>
                  <span className="font-mono font-semibold">{metrics.latency?.minMs ?? 0} ms</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="theme-text-muted">P50 (Median):</span>
                  <span className="font-mono font-semibold">{metrics.latency?.p50Ms ?? 0} ms</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="theme-text-muted">P95 Latency:</span>
                  <span className="font-mono font-semibold">{metrics.latency?.p95Ms ?? 0} ms</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="theme-text-muted">P99 Latency:</span>
                  <span className="font-mono font-semibold">{metrics.latency?.p99Ms ?? 0} ms</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="theme-text-muted">Maximum Peak:</span>
                  <span className="font-mono font-semibold">{metrics.latency?.maxMs ?? 0} ms</span>
                </div>
              </div>
            </div>

            {/* Reads vs Writes Breakdown */}
            <div id="sqlclient-read-write-card" className="sqlclient-card">
              <h4 className="font-semibold text-sm mb-4 flex items-center gap-2">
                <IdeIcon name="PieChart" size="sm" />
                Query Workload Distribution
              </h4>
              <div className="space-y-4">
                <div className="flex justify-between text-xs">
                  <span>Reads (SELECT): {metrics.readsCount} ({readWriteRatio}%)</span>
                  <span>Writes (INSERT/UPDATE/DDL): {metrics.writesCount} ({(100 - readWriteRatio).toFixed(1)}%)</span>
                </div>
                <div className="w-full bg-slate-200 dark:bg-slate-700 h-3 rounded-full overflow-hidden flex">
                  <div className="bg-blue-600 h-full flex-1" />
                  <div className="bg-amber-500 h-full flex-1" />
                </div>
                <div className="flex items-center gap-4 text-xs theme-text-muted">
                  <div className="flex items-center gap-1">
                    <span className="w-2.5 h-2.5 rounded-full bg-blue-600" />
                    <span>Reads: {readWriteRatio}%</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                    <span>Writes: {(100 - readWriteRatio).toFixed(1)}%</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </>
      ) : (
        <div
          id="sqlclient-perf-loading-placeholder"
          className="p-12 text-center theme-text-muted text-sm sqlclient-card"
        >
          Connecting to LocalSQLServer metrics stream on port 3110...
        </div>
      )}
    </div>
  );
};

export default PerformanceDashboard;
