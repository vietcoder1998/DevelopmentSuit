import { TableItemMetadata } from "./TablesExplorer";
import {
  ErdCardinality,
  TableRelationship,
  XmlErpRelationship,
  XmlErpSchemaDefinition,
  XmlErpTable,
  XmlErpTableColumn,
} from "./erd-types";

/**
 * Normalizes a cardinality string to ErdCardinality type.
 */
export function normalizeCardinality(val?: string | null): ErdCardinality {
  if (!val) return "many-to-one";
  const lower: string = val.toLowerCase().trim();
  if (lower === "one-to-one" || lower === "1:1" || lower === "onetoone") {
    return "one-to-one";
  }
  if (lower === "one-to-many" || lower === "1:n" || lower === "1:m" || lower === "onetomany") {
    return "one-to-many";
  }
  return "many-to-one";
}

/**
 * Robust XML ERP Schema Parser that supports both Browser DOMParser and Regex fallback for Node/headless environments.
 */
export function parseXmlErpSchema(xmlContent: string): XmlErpSchemaDefinition {
  const trimmed: string = (xmlContent || "").trim();
  if (!trimmed) {
    return {
      name: "empty_schema",
      tables: [],
      relationships: [],
      rawXml: xmlContent,
    };
  }

  // Attempt standard DOMParser if present
  if (typeof DOMParser !== "undefined") {
    try {
      const parser: DOMParser = new DOMParser();
      const doc: Document = parser.parseFromString(trimmed, "application/xml");
      const parseError: Element | null = doc.querySelector("parsererror");
      if (!parseError) {
        return parseXmlFromDom(doc, trimmed);
      }
    } catch {
      // Fallback to regex parser
    }
  }

  return parseXmlViaRegex(trimmed);
}

/**
 * Extracts schema information from a parsed XML Document.
 */
function parseXmlFromDom(doc: Document, rawXml: string): XmlErpSchemaDefinition {
  const root: Element | null = doc.documentElement;
  const schemaName: string =
    root?.getAttribute("name") ||
    root?.getAttribute("id") ||
    root?.getAttribute("title") ||
    "erp_schema";
  const version: string = root?.getAttribute("version") || "1.0";
  const description: string | undefined = root?.getAttribute("description") || undefined;

  const parsedTables: XmlErpTable[] = [];
  const parsedRelationships: XmlErpRelationship[] = [];
  const processedRelIds: Set<string> = new Set<string>();

  // Find all table elements
  const tableElements: NodeListOf<Element> = doc.querySelectorAll("table, entity, Table, Entity");
  tableElements.forEach((tableEl: Element): void => {
    const tableName: string =
      tableEl.getAttribute("name") ||
      tableEl.getAttribute("id") ||
      tableEl.getAttribute("tableName") ||
      "";
    if (!tableName) return;

    const rowCountAttr: string | null = tableEl.getAttribute("rowCount") || tableEl.getAttribute("rows");
    const rowCount: number = rowCountAttr ? parseInt(rowCountAttr, 10) || 0 : 0;
    const tableDesc: string | undefined = tableEl.getAttribute("description") || undefined;

    const columns: XmlErpTableColumn[] = [];
    const colElements: NodeListOf<Element> = tableEl.querySelectorAll("column, field, Column, Field");
    colElements.forEach((colEl: Element): void => {
      const colName: string = colEl.getAttribute("name") || colEl.getAttribute("id") || "";
      if (!colName) return;

      const colType: string =
        colEl.getAttribute("type") ||
        colEl.getAttribute("sqlType") ||
        colEl.getAttribute("dataType") ||
        "VARCHAR(255)";
      const isPkAttr: string | null =
        colEl.getAttribute("primaryKey") ||
        colEl.getAttribute("isPrimaryKey") ||
        colEl.getAttribute("pk");
      const isPk: boolean = isPkAttr === "true" || isPkAttr === "1";

      const fkAttr: string | null = colEl.getAttribute("foreignKey") || colEl.getAttribute("fk");
      const refAttr: string | null = colEl.getAttribute("references") || colEl.getAttribute("ref");
      let targetTable: string | undefined = colEl.getAttribute("targetTable") || undefined;
      let targetColumn: string | undefined = colEl.getAttribute("targetColumn") || undefined;

      if (refAttr && !targetTable) {
        // e.g. references="orders(id)" or references="orders.id"
        const dotMatch: RegExpMatchArray | null = refAttr.match(/([a-zA-Z0-9_]+)[.(]([a-zA-Z0-9_]+)\)?/);
        if (dotMatch) {
          targetTable = dotMatch[1];
          targetColumn = dotMatch[2];
        } else {
          targetTable = refAttr;
          targetColumn = "id";
        }
      } else if (fkAttr && !targetTable) {
        const dotMatch: RegExpMatchArray | null = fkAttr.match(/([a-zA-Z0-9_]+)[.(]([a-zA-Z0-9_]+)\)?/);
        if (dotMatch) {
          targetTable = dotMatch[1];
          targetColumn = dotMatch[2];
        }
      }

      columns.push({
        name: colName,
        type: colType,
        primaryKey: isPk,
        foreignKey: fkAttr || undefined,
        references: refAttr || undefined,
        targetTable,
        targetColumn,
      });

      // If column defines a foreign key directly
      if (targetTable && targetColumn) {
        const relId: string = `xml-rel-${tableName}-${colName}->${targetTable}-${targetColumn}`;
        if (!processedRelIds.has(relId)) {
          processedRelIds.add(relId);
          parsedRelationships.push({
            id: relId,
            sourceTable: tableName,
            sourceColumn: colName,
            targetTable,
            targetColumn,
            cardinality: "many-to-one",
            label: `${tableName}.${colName} ➔ ${targetTable}.${targetColumn}`,
          });
        }
      }
    });

    // Check for nested <foreign-key> or <foreignKey> tags within table
    const fkElements: NodeListOf<Element> = tableEl.querySelectorAll("foreign-key, foreignKey, fk");
    fkElements.forEach((fkEl: Element): void => {
      const foreignTable: string =
        fkEl.getAttribute("foreignTable") ||
        fkEl.getAttribute("targetTable") ||
        fkEl.getAttribute("table") ||
        "";
      if (!foreignTable) return;

      const refNodes: NodeListOf<Element> = fkEl.querySelectorAll("reference");
      if (refNodes.length > 0) {
        refNodes.forEach((refNode: Element): void => {
          const localCol: string = refNode.getAttribute("local") || refNode.getAttribute("localColumn") || "";
          const foreignCol: string =
            refNode.getAttribute("foreign") || refNode.getAttribute("foreignColumn") || "id";
          if (localCol) {
            const relId: string = `xml-rel-${tableName}-${localCol}->${foreignTable}-${foreignCol}`;
            if (!processedRelIds.has(relId)) {
              processedRelIds.add(relId);
              parsedRelationships.push({
                id: relId,
                sourceTable: tableName,
                sourceColumn: localCol,
                targetTable: foreignTable,
                targetColumn: foreignCol,
                cardinality: "many-to-one",
                label: `${tableName}.${localCol} ➔ ${foreignTable}.${foreignCol}`,
              });
            }
          }
        });
      } else {
        const localCol: string =
          fkEl.getAttribute("sourceColumn") || fkEl.getAttribute("column") || "";
        const foreignCol: string =
          fkEl.getAttribute("targetColumn") || fkEl.getAttribute("foreignColumn") || "id";
        if (localCol) {
          const relId: string = `xml-rel-${tableName}-${localCol}->${foreignTable}-${foreignCol}`;
          if (!processedRelIds.has(relId)) {
            processedRelIds.add(relId);
            parsedRelationships.push({
              id: relId,
              sourceTable: tableName,
              sourceColumn: localCol,
              targetTable: foreignTable,
              targetColumn: foreignCol,
              cardinality: "many-to-one",
              label: `${tableName}.${localCol} ➔ ${foreignTable}.${foreignCol}`,
            });
          }
        }
      }
    });

    parsedTables.push({
      name: tableName,
      rowCount,
      columnCount: columns.length,
      description: tableDesc,
      columns,
    });
  });

  // Find explicit top-level relationship elements (<relationship>, <relation>, <association>)
  const relElements: NodeListOf<Element> = doc.querySelectorAll(
    "relationship, relation, association, Relationship, Relation"
  );
  relElements.forEach((relEl: Element, idx: number): void => {
    const sourceTable: string =
      relEl.getAttribute("sourceTable") ||
      relEl.getAttribute("fromTable") ||
      relEl.getAttribute("table") ||
      "";
    const sourceColumn: string =
      relEl.getAttribute("sourceColumn") ||
      relEl.getAttribute("fromColumn") ||
      relEl.getAttribute("column") ||
      "";
    const targetTable: string =
      relEl.getAttribute("targetTable") ||
      relEl.getAttribute("toTable") ||
      relEl.getAttribute("refTable") ||
      "";
    const targetColumn: string =
      relEl.getAttribute("targetColumn") ||
      relEl.getAttribute("toColumn") ||
      relEl.getAttribute("refColumn") ||
      "id";

    if (!sourceTable || !targetTable) return;

    const relId: string =
      relEl.getAttribute("id") ||
      `xml-rel-${sourceTable}-${sourceColumn || "fk"}->${targetTable}-${targetColumn || "pk"}-${idx}`;

    if (!processedRelIds.has(relId)) {
      processedRelIds.add(relId);
      parsedRelationships.push({
        id: relId,
        sourceTable,
        sourceColumn: sourceColumn || "id",
        targetTable,
        targetColumn: targetColumn || "id",
        cardinality: normalizeCardinality(relEl.getAttribute("cardinality")),
        label:
          relEl.getAttribute("label") ||
          `${sourceTable}.${sourceColumn || "id"} ➔ ${targetTable}.${targetColumn || "id"}`,
      });
    }
  });

  return {
    name: schemaName,
    version,
    description,
    tables: parsedTables,
    relationships: parsedRelationships,
    rawXml,
  };
}

/**
 * Regex-based XML parser for resilient fallback in headless test and server-side environments.
 */
function parseXmlViaRegex(xmlContent: string): XmlErpSchemaDefinition {
  const schemaMatch: RegExpMatchArray | null = xmlContent.match(
    /<(?:erp-schema|schema|database|model)\s+([^>]*?)>/i
  );
  let schemaName: string = "erp_schema";
  let version: string = "1.0";

  if (schemaMatch && schemaMatch[1]) {
    const nameMatch: RegExpMatchArray | null = schemaMatch[1].match(/name=["']([^"']+)["']/i);
    if (nameMatch) schemaName = nameMatch[1];
    const verMatch: RegExpMatchArray | null = schemaMatch[1].match(/version=["']([^"']+)["']/i);
    if (verMatch) version = verMatch[1];
  }

  const tables: XmlErpTable[] = [];
  const relationships: XmlErpRelationship[] = [];
  const processedRelIds: Set<string> = new Set<string>();

  // Extract all <table>...</table> or <table ... />
  const tableRegex: RegExp = /<table\s+([^>]*?)>([\s\S]*?)<\/table>/gi;
  let tableMatch: RegExpExecArray | null = tableRegex.exec(xmlContent);

  while (tableMatch !== null) {
    const tableAttrs: string = tableMatch[1];
    const tableBody: string = tableMatch[2];

    const nameMatch: RegExpMatchArray | null = tableAttrs.match(/name=["']([^"']+)["']/i);
    if (nameMatch) {
      const tableName: string = nameMatch[1];
      const rowsMatch: RegExpMatchArray | null = tableAttrs.match(/(?:rowCount|rows)=["'](\d+)["']/i);
      const rowCount: number = rowsMatch ? parseInt(rowsMatch[1], 10) : 0;

      const columns: XmlErpTableColumn[] = [];
      const colRegex: RegExp = /<column\s+([^>]*?)(?:\/>|>([\s\S]*?)<\/column>)/gi;
      let colMatch: RegExpExecArray | null = colRegex.exec(tableBody);

      while (colMatch !== null) {
        const colAttrs: string = colMatch[1];
        const colNameMatch: RegExpMatchArray | null = colAttrs.match(/name=["']([^"']+)["']/i);
        if (colNameMatch) {
          const colName: string = colNameMatch[1];
          const typeMatch: RegExpMatchArray | null = colAttrs.match(/type=["']([^"']+)["']/i);
          const pkMatch: RegExpMatchArray | null = colAttrs.match(/(?:primaryKey|isPrimaryKey|pk)=["']true["']/i);
          const targetTableMatch: RegExpMatchArray | null = colAttrs.match(/targetTable=["']([^"']+)["']/i);
          const targetColMatch: RegExpMatchArray | null = colAttrs.match(/targetColumn=["']([^"']+)["']/i);
          const refMatch: RegExpMatchArray | null = colAttrs.match(/(?:references|foreignKey)=["']([^"']+)["']/i);

          let targetTable: string | undefined = targetTableMatch ? targetTableMatch[1] : undefined;
          let targetColumn: string | undefined = targetColMatch ? targetColMatch[1] : undefined;

          if (refMatch && !targetTable) {
            const splitMatch: RegExpMatchArray | null = refMatch[1].match(/([a-zA-Z0-9_]+)[.(]([a-zA-Z0-9_]+)\)?/);
            if (splitMatch) {
              targetTable = splitMatch[1];
              targetColumn = splitMatch[2];
            }
          }

          columns.push({
            name: colName,
            type: typeMatch ? typeMatch[1] : "VARCHAR(255)",
            primaryKey: Boolean(pkMatch),
            targetTable,
            targetColumn,
          });

          if (targetTable && targetColumn) {
            const relId: string = `xml-rel-${tableName}-${colName}->${targetTable}-${targetColumn}`;
            if (!processedRelIds.has(relId)) {
              processedRelIds.add(relId);
              relationships.push({
                id: relId,
                sourceTable: tableName,
                sourceColumn: colName,
                targetTable,
                targetColumn,
                cardinality: "many-to-one",
                label: `${tableName}.${colName} ➔ ${targetTable}.${targetColumn}`,
              });
            }
          }
        }
        colMatch = colRegex.exec(tableBody);
      }

      tables.push({
        name: tableName,
        rowCount,
        columnCount: columns.length,
        columns,
      });
    }

    tableMatch = tableRegex.exec(xmlContent);
  }

  // Extract explicit <relationship ... /> elements
  const relRegex: RegExp = /<(?:relationship|relation)\s+([^>]*?)(?:\/>|>[\s\S]*?<\/(?:relationship|relation)>)/gi;
  let relMatch: RegExpExecArray | null = relRegex.exec(xmlContent);
  let relIdx: number = 0;

  while (relMatch !== null) {
    const relAttrs: string = relMatch[1];
    const srcTableMatch: RegExpMatchArray | null = relAttrs.match(/(?:sourceTable|fromTable|table)=["']([^"']+)["']/i);
    const srcColMatch: RegExpMatchArray | null = relAttrs.match(/(?:sourceColumn|fromColumn|column)=["']([^"']+)["']/i);
    const tgtTableMatch: RegExpMatchArray | null = relAttrs.match(/(?:targetTable|toTable|refTable)=["']([^"']+)["']/i);
    const tgtColMatch: RegExpMatchArray | null = relAttrs.match(/(?:targetColumn|toColumn|refColumn)=["']([^"']+)["']/i);
    const cardMatch: RegExpMatchArray | null = relAttrs.match(/cardinality=["']([^"']+)["']/i);
    const labelMatch: RegExpMatchArray | null = relAttrs.match(/label=["']([^"']+)["']/i);
    const idMatch: RegExpMatchArray | null = relAttrs.match(/id=["']([^"']+)["']/i);

    if (srcTableMatch && tgtTableMatch) {
      const sourceTable: string = srcTableMatch[1];
      const targetTable: string = tgtTableMatch[1];
      const sourceColumn: string = srcColMatch ? srcColMatch[1] : "id";
      const targetColumn: string = tgtColMatch ? tgtColMatch[1] : "id";
      const relId: string =
        idMatch && idMatch[1]
          ? idMatch[1]
          : `xml-rel-${sourceTable}-${sourceColumn}->${targetTable}-${targetColumn}-${relIdx}`;

      if (!processedRelIds.has(relId)) {
        processedRelIds.add(relId);
        relationships.push({
          id: relId,
          sourceTable,
          sourceColumn,
          targetTable,
          targetColumn,
          cardinality: normalizeCardinality(cardMatch ? cardMatch[1] : undefined),
          label: labelMatch ? labelMatch[1] : `${sourceTable}.${sourceColumn} ➔ ${targetTable}.${targetColumn}`,
        });
      }
    }

    relIdx++;
    relMatch = relRegex.exec(xmlContent);
  }

  return {
    name: schemaName,
    version,
    tables,
    relationships,
    rawXml: xmlContent,
  };
}

/**
 * Serializes an ERP schema definition to well-formed XML.
 */
export function serializeErpSchemaToXml(schema: XmlErpSchemaDefinition): string {
  const lines: string[] = [
    '<?xml version="1.0" encoding="UTF-8"?>',
    `<erp-schema name="${escapeXml(schema.name || "erp_schema")}" version="${escapeXml(schema.version || "1.0")}">`,
    "  <tables>",
  ];

  schema.tables.forEach((table: XmlErpTable): void => {
    lines.push(
      `    <table name="${escapeXml(table.name)}" rowCount="${table.rowCount ?? 0}"${
        table.description ? ` description="${escapeXml(table.description)}"` : ""
      }>`
    );
    table.columns.forEach((col: XmlErpTableColumn): void => {
      let colXml: string = `      <column name="${escapeXml(col.name)}" type="${escapeXml(col.type || "VARCHAR(255)")}"`;
      if (col.primaryKey) {
        colXml += ' primaryKey="true"';
      }
      if (col.targetTable && col.targetColumn) {
        colXml += ` targetTable="${escapeXml(col.targetTable)}" targetColumn="${escapeXml(col.targetColumn)}"`;
      }
      colXml += " />";
      lines.push(colXml);
    });
    lines.push("    </table>");
  });

  lines.push("  </tables>");
  lines.push("  <relationships>");

  schema.relationships.forEach((rel: XmlErpRelationship): void => {
    lines.push(
      `    <relationship id="${escapeXml(rel.id)}" sourceTable="${escapeXml(
        rel.sourceTable
      )}" sourceColumn="${escapeXml(rel.sourceColumn)}" targetTable="${escapeXml(
        rel.targetTable
      )}" targetColumn="${escapeXml(rel.targetColumn)}" cardinality="${escapeXml(
        rel.cardinality
      )}" label="${escapeXml(rel.label)}" />`
    );
  });

  lines.push("  </relationships>");
  lines.push("</erp-schema>");

  return lines.join("\n");
}

function escapeXml(unsafe: string): string {
  return (unsafe || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

/**
 * Merges loaded XML ERP schema with database tables.
 */
export function mergeXmlWithDatabaseTables(
  dbTables: TableItemMetadata[],
  xmlSchema: XmlErpSchemaDefinition
): {
  tables: TableItemMetadata[];
  relationships: TableRelationship[];
} {
  const mergedTablesMap: Map<string, TableItemMetadata> = new Map<string, TableItemMetadata>();

  // 1. Add all DB tables
  (dbTables || []).forEach((t: TableItemMetadata): void => {
    if (t && t.name) {
      mergedTablesMap.set(t.name.toLowerCase(), { ...t });
    }
  });

  // 2. Augment with XML tables
  (xmlSchema.tables || []).forEach((xt: XmlErpTable): void => {
    const lowerName: string = xt.name.toLowerCase();
    const existing: TableItemMetadata | undefined = mergedTablesMap.get(lowerName);

    if (existing) {
      // Merge column lists if XML has extra columns
      const existingCols: string[] = Array.isArray(existing.columns) ? existing.columns : [];
      const xmlCols: string[] = xt.columns.map((c: XmlErpTableColumn): string => c.name);
      const combinedCols: string[] = Array.from(new Set([...existingCols, ...xmlCols]));

      mergedTablesMap.set(lowerName, {
        ...existing,
        columns: combinedCols,
        columnCount: combinedCols.length,
        rowCount: existing.rowCount || xt.rowCount || 0,
      });
    } else {
      // Add table defined in XML if not present in DB
      const xmlCols: string[] = xt.columns.map((c: XmlErpTableColumn): string => c.name);
      mergedTablesMap.set(lowerName, {
        name: xt.name,
        rowCount: xt.rowCount || 0,
        columnCount: xmlCols.length,
        columns: xmlCols,
      });
    }
  });

  // 3. Format relationships
  const relationships: TableRelationship[] = (xmlSchema.relationships || []).map(
    (rel: XmlErpRelationship): TableRelationship => ({
      id: rel.id,
      sourceTable: rel.sourceTable,
      sourceColumn: rel.sourceColumn,
      targetTable: rel.targetTable,
      targetColumn: rel.targetColumn,
      cardinality: rel.cardinality,
      label: rel.label || `${rel.sourceTable}.${rel.sourceColumn} ➔ ${rel.targetTable}.${rel.targetColumn}`,
    })
  );

  return {
    tables: Array.from(mergedTablesMap.values()),
    relationships,
  };
}
