import React, { useState, useEffect } from "react";
import { IdeIcon, Badge, Input, Button, Modal } from "../bases";

export interface TableItemMetadata {
  readonly name: string;
  readonly rowCount: number;
  readonly columnCount: number;
  readonly columns: string[];
}

export type CellDataType = "string" | "number" | "boolean" | "null" | "json";

export interface EditingCellState {
  readonly rowIndex: number;
  readonly col: string;
  readonly value: string;
  readonly type: CellDataType;
}

export interface TablesExplorerProps {
  readonly tables: TableItemMetadata[];
  readonly activeTable: string | null;
  readonly onSelectTable: (name: string) => void;
  readonly tableData: unknown[];
  readonly tableSchema: unknown;
  readonly isLoading: boolean;
  readonly hideInternalSidebar?: boolean;
  readonly isLocked?: boolean;
  readonly onLockTable?: (tableName: string, locked: boolean) => void;
  readonly onEditTable?: (oldName: string, newName: string) => Promise<void> | void;
  readonly onDeleteTable?: (tableName: string) => Promise<void> | void;
  readonly onDeleteRows?: (tableName: string, rowKeys: string[]) => Promise<void> | void;
  readonly onUpdateCellValue?: (
    tableName: string,
    rowIndex: number,
    column: string,
    newValue: unknown,
    dataType: CellDataType
  ) => Promise<void> | void;
  readonly onDuplicateRow?: (
    tableName: string,
    rowIndex: number,
    duplicatedRow: Record<string, unknown>
  ) => Promise<void> | void;
  readonly onInsertRow?: (
    tableName: string,
    newRow: Record<string, unknown>
  ) => Promise<void> | void;
}

const normalizeRow: (row: unknown) => Record<string, unknown> = (
  row: unknown
): Record<string, unknown> => {
  if (!row || typeof row !== "object") {
    return { value: row };
  }
  const rawObj: Record<string, unknown> = row as Record<string, unknown>;

  // Check if rawObj has a `value` field that is a JSON string or object (LocalDB storage standard)
  if ("value" in rawObj && rawObj.value !== undefined) {
    let unpacked: unknown = rawObj.value;
    if (
      typeof unpacked === "string" &&
      (unpacked.trim().startsWith("{") || unpacked.trim().startsWith("["))
    ) {
      try {
        unpacked = JSON.parse(unpacked);
      } catch {
        // Keep original string if parsing fails
      }
    }

    if (unpacked && typeof unpacked === "object" && !Array.isArray(unpacked)) {
      const flattened: Record<string, unknown> = { ...(unpacked as Record<string, unknown>) };
      if (flattened.id === undefined) {
        if (rawObj.id !== undefined) {
          flattened.id = rawObj.id;
        } else if (rawObj.key !== undefined) {
          flattened.id = rawObj.key;
        }
      }
      return flattened;
    }
  }

  // If rawObj has key but no id, map key to id
  if (rawObj.id === undefined && rawObj.key !== undefined) {
    return { id: rawObj.key, ...rawObj };
  }

  return rawObj;
};

export const TablesExplorer: React.FC<TablesExplorerProps> = ({
  tables,
  activeTable,
  onSelectTable,
  tableData,
  tableSchema,
  isLoading,
  hideInternalSidebar = false,
  isLocked: isLockedProp,
  onLockTable,
  onEditTable,
  onDeleteTable,
  onDeleteRows,
  onUpdateCellValue,
  onDuplicateRow,
  onInsertRow,
}) => {
  const [showInsertRowPanel, setShowInsertRowPanel]: [
    boolean,
    React.Dispatch<React.SetStateAction<boolean>>
  ] = useState<boolean>(false);

  const [insertRowFields, setInsertRowFields]: [
    Record<string, string>,
    React.Dispatch<React.SetStateAction<Record<string, string>>>
  ] = useState<Record<string, string>>({});

  const [searchFilter, setSearchFilter]: [
    string,
    React.Dispatch<React.SetStateAction<string>>
  ] = useState<string>("");
  const [activeTab, setActiveTab]: [
    "data" | "schema",
    React.Dispatch<React.SetStateAction<"data" | "schema">>
  ] = useState<"data" | "schema">("data");

  const [localLockedMap, setLocalLockedMap]: [
    Record<string, boolean>,
    React.Dispatch<React.SetStateAction<Record<string, boolean>>>
  ] = useState<Record<string, boolean>>({});

  const isCurrentTableLocked: boolean = Boolean(
    activeTable && (isLockedProp !== undefined ? isLockedProp : localLockedMap[activeTable])
  );

  const [selectedRowKeys, setSelectedRowKeys]: [
    Set<string>,
    React.Dispatch<React.SetStateAction<Set<string>>>
  ] = useState<Set<string>>(new Set<string>());

  const [localEditedRows, setLocalEditedRows]: [
    Record<string, unknown>[] | null,
    React.Dispatch<React.SetStateAction<Record<string, unknown>[] | null>>
  ] = useState<Record<string, unknown>[] | null>(null);

  const [editingCell, setEditingCell]: [
    EditingCellState | null,
    React.Dispatch<React.SetStateAction<EditingCellState | null>>
  ] = useState<EditingCellState | null>(null);

  const [showEditModal, setShowEditModal]: [
    boolean,
    React.Dispatch<React.SetStateAction<boolean>>
  ] = useState<boolean>(false);

  const [editTableNameInput, setEditTableNameInput]: [
    string,
    React.Dispatch<React.SetStateAction<string>>
  ] = useState<string>("");

  const [showDeleteTableModal, setShowDeleteTableModal]: [
    boolean,
    React.Dispatch<React.SetStateAction<boolean>>
  ] = useState<boolean>(false);

  const [showDeleteRowsModal, setShowDeleteRowsModal]: [
    boolean,
    React.Dispatch<React.SetStateAction<boolean>>
  ] = useState<boolean>(false);

  const [isOperating, setIsOperating]: [
    boolean,
    React.Dispatch<React.SetStateAction<boolean>>
  ] = useState<boolean>(false);

  useEffect((): void => {
    setSelectedRowKeys(new Set<string>());
    setEditTableNameInput(activeTable || "");
    setLocalEditedRows(null);
    setEditingCell(null);
  }, [activeTable, tableData]);

  const handleToggleLock: () => void = (): void => {
    if (!activeTable) return;
    const nextLocked: boolean = !isCurrentTableLocked;
    if (onLockTable) {
      onLockTable(activeTable, nextLocked);
    }
    setLocalLockedMap((prev: Record<string, boolean>): Record<string, boolean> => ({
      ...prev,
      [activeTable]: nextLocked,
    }));
  };

  const handleToggleRow: (rowKey: string) => void = (rowKey: string): void => {
    setSelectedRowKeys((prev: Set<string>): Set<string> => {
      const next: Set<string> = new Set<string>(prev);
      if (next.has(rowKey)) {
        next.delete(rowKey);
      } else {
        next.add(rowKey);
      }
      return next;
    });
  };

  const handleToggleSelectAll: () => void = (): void => {
    if (selectedRowKeys.size === normalizedRows.length) {
      setSelectedRowKeys(new Set<string>());
    } else {
      const allKeys: Set<string> = new Set<string>();
      normalizedRows.forEach((r: Record<string, unknown>, idx: number): void => {
        const key: string = String(r.id ?? r.key ?? idx);
        allKeys.add(key);
      });
      setSelectedRowKeys(allKeys);
    }
  };

  const handleClearSelection: () => void = (): void => {
    setSelectedRowKeys(new Set<string>());
  };

  const handleConfirmEditTable: () => Promise<void> = async (): Promise<void> => {
    if (!activeTable || !editTableNameInput.trim() || isCurrentTableLocked) return;
    setIsOperating(true);
    try {
      if (onEditTable) {
        await onEditTable(activeTable, editTableNameInput.trim());
      }
      setShowEditModal(false);
    } finally {
      setIsOperating(false);
    }
  };

  const handleConfirmDeleteTable: () => Promise<void> = async (): Promise<void> => {
    if (!activeTable || isCurrentTableLocked) return;
    setIsOperating(true);
    try {
      if (onDeleteTable) {
        await onDeleteTable(activeTable);
      }
      setShowDeleteTableModal(false);
      setSelectedRowKeys(new Set<string>());
    } finally {
      setIsOperating(false);
    }
  };

  const handleConfirmDeleteRows: () => Promise<void> = async (): Promise<void> => {
    if (!activeTable || selectedRowKeys.size === 0 || isCurrentTableLocked) return;
    setIsOperating(true);
    try {
      if (onDeleteRows) {
        await onDeleteRows(activeTable, Array.from(selectedRowKeys));
      }
      setSelectedRowKeys(new Set<string>());
      setShowDeleteRowsModal(false);
    } finally {
      setIsOperating(false);
    }
  };

  const filteredTables: TableItemMetadata[] = tables.filter(
    (tbl: TableItemMetadata): boolean =>
      tbl.name.toLowerCase().includes(searchFilter.toLowerCase())
  );

  // Normalize table rows: unwrap inner value object / JSON strings into first-class columns
  const normalizedRows: Array<Record<string, unknown>> = React.useMemo((): Array<Record<string, unknown>> => {
    return tableData.map(normalizeRow);
  }, [tableData]);

  const activeRows: Array<Record<string, unknown>> = localEditedRows ?? normalizedRows;

  const detectCellType: (val: unknown) => CellDataType = (val: unknown): CellDataType => {
    if (val === null || val === undefined) return "null";
    if (typeof val === "boolean") return "boolean";
    if (typeof val === "number") return "number";
    if (typeof val === "object") return "json";
    return "string";
  };

  const formatValueForEdit: (val: unknown, type: CellDataType) => string = (
    val: unknown,
    type: CellDataType
  ): string => {
    if (val === null || val === undefined) return "";
    if (type === "json") {
      try {
        return typeof val === "string" ? val : JSON.stringify(val);
      } catch {
        return String(val);
      }
    }
    return String(val);
  };

  const startEditingCell: (rowIndex: number, col: string, val: unknown) => void = (
    rowIndex: number,
    col: string,
    val: unknown
  ): void => {
    if (isCurrentTableLocked) return;
    const detectedType: CellDataType = detectCellType(val);
    setEditingCell({
      rowIndex,
      col,
      value: formatValueForEdit(val, detectedType),
      type: detectedType,
    });
  };

  const handleTypeChange: (newType: CellDataType) => void = (newType: CellDataType): void => {
    setEditingCell((prev: EditingCellState | null): EditingCellState | null => {
      if (!prev) return null;
      let nextVal: string = prev.value;
      if (newType === "boolean") {
        nextVal = prev.value === "true" || prev.value === "1" ? "true" : "false";
      } else if (newType === "number") {
        const num: number = Number(prev.value);
        nextVal = isNaN(num) ? "0" : String(num);
      } else if (newType === "null") {
        nextVal = "";
      } else if (newType === "json") {
        if (!prev.value || prev.value === "0" || prev.value === "false") {
          nextVal = "{}";
        }
      }
      return {
        ...prev,
        type: newType,
        value: nextVal,
      };
    });
  };

  const handleSaveInlineEdit: () => Promise<void> = async (): Promise<void> => {
    if (!editingCell) return;
    const { rowIndex, col, value, type }: EditingCellState = editingCell;

    let parsedVal: unknown;
    if (type === "null") {
      parsedVal = null;
    } else if (type === "boolean") {
      parsedVal = value === "true" || value === "TRUE";
    } else if (type === "number") {
      const num: number = Number(value);
      parsedVal = isNaN(num) ? 0 : num;
    } else if (type === "json") {
      try {
        parsedVal = JSON.parse(value);
      } catch {
        parsedVal = value;
      }
    } else {
      parsedVal = value;
    }

    const currentRows: Record<string, unknown>[] = [...(localEditedRows ?? normalizedRows)];
    if (currentRows[rowIndex]) {
      currentRows[rowIndex] = {
        ...currentRows[rowIndex],
        [col]: parsedVal,
      };
      setLocalEditedRows(currentRows);
    }

    setEditingCell(null);

    if (onUpdateCellValue && activeTable) {
      await onUpdateCellValue(activeTable, rowIndex, col, parsedVal, type);
    }
  };

  const handleCancelInlineEdit: () => void = (): void => {
    setEditingCell(null);
  };

  const handleEditorKeyDown: (e: React.KeyboardEvent<HTMLElement>) => void = (
    e: React.KeyboardEvent<HTMLElement>
  ): void => {
    if (e.key === "Enter") {
      e.preventDefault();
      void handleSaveInlineEdit();
    } else if (e.key === "Escape") {
      e.preventDefault();
      handleCancelInlineEdit();
    }
  };

  // Extract columns for data table (derived from key names of normalized rows)
  const columnsList: string[] = React.useMemo((): string[] => {
    const genericStorageSet: Set<string> = new Set<string>([
      "key",
      "value",
      "namespace",
      "createdAt",
      "updatedAt",
      "ttlMs",
      "version",
      "tags",
    ]);

    let schemaCols: string[] = [];
    if (tableSchema && typeof tableSchema === "object" && "columns" in tableSchema) {
      const cols: Record<string, unknown> =
        (tableSchema as { columns: Record<string, unknown> }).columns || {};
      schemaCols = Object.keys(cols);
    }

    const isGenericSchema: boolean =
      schemaCols.length > 0 && schemaCols.every((c: string): boolean => genericStorageSet.has(c));

    if (activeRows.length > 0) {
      const keysSet: Set<string> = new Set<string>();

      // If schema has non-generic domain columns, prioritize them
      if (schemaCols.length > 0 && !isGenericSchema) {
        schemaCols.forEach((c: string): void => {
          keysSet.add(c);
        });
      }

      // Collect all key names from the rows
      for (const row of activeRows.slice(0, 100)) {
        Object.keys(row).forEach((k: string): void => {
          keysSet.add(k);
        });
      }

      const allKeys: string[] = Array.from(keysSet);
      const idKeys: string[] = allKeys.filter((k: string): boolean => k === "id" || k === "_id" || k === "key");
      const metaKeys: string[] = allKeys.filter((k: string): boolean => genericStorageSet.has(k));
      const domainKeys: string[] = allKeys.filter(
        (k: string): boolean => !idKeys.includes(k) && !metaKeys.includes(k)
      );

      return [...idKeys, ...domainKeys, ...metaKeys];
    }

    if (schemaCols.length > 0) {
      return schemaCols;
    }

    return [];
  }, [activeRows, tableSchema]);

  const handleFieldChange: (col: string, val: string) => void = (col: string, val: string): void => {
    setInsertRowFields((prev: Record<string, string>): Record<string, string> => ({
      ...prev,
      [col]: val,
    }));
  };

  const handleConfirmInsertRow: () => Promise<void> = async (): Promise<void> => {
    if (!activeTable || isCurrentTableLocked) return;
    const newRow: Record<string, unknown> = {};
    for (const col of columnsList) {
      const rawVal: string | undefined = insertRowFields[col];
      if (rawVal !== undefined && rawVal !== "") {
        if (rawVal.toLowerCase() === "true") newRow[col] = true;
        else if (rawVal.toLowerCase() === "false") newRow[col] = false;
        else if (rawVal.toLowerCase() === "null") newRow[col] = null;
        else if (!isNaN(Number(rawVal)) && rawVal.trim() !== "") newRow[col] = Number(rawVal);
        else newRow[col] = rawVal;
      } else {
        newRow[col] = col === "id" ? Date.now() : "";
      }
    }
    if (newRow.id === undefined) {
      newRow.id = Date.now();
    }

    setLocalEditedRows((prev: Record<string, unknown>[] | null): Record<string, unknown>[] => {
      const list: Record<string, unknown>[] = [...(prev ?? normalizedRows), newRow];
      return list;
    });

    if (onInsertRow) {
      await onInsertRow(activeTable, newRow);
    }

    setInsertRowFields({});
    setShowInsertRowPanel(false);
  };

  const handleDuplicateRow: (rowIndex: number, rowObj: Record<string, unknown>) => void = (
    rowIndex: number,
    rowObj: Record<string, unknown>
  ): void => {
    if (isCurrentTableLocked) return;
    const duplicatedRow: Record<string, unknown> = { ...rowObj };
    if ("id" in duplicatedRow) {
      if (typeof duplicatedRow.id === "number") {
        const existingIds: number[] = activeRows
          .map((r: Record<string, unknown>): number => Number(r.id))
          .filter((n: number): boolean => !isNaN(n));
        duplicatedRow.id = existingIds.length > 0 ? Math.max(...existingIds) + 1 : Date.now();
      } else if (typeof duplicatedRow.id === "string") {
        duplicatedRow.id = `${duplicatedRow.id}_copy`;
      }
    }
    const currentList: Record<string, unknown>[] = [...(localEditedRows ?? normalizedRows)];
    const targetIndex: number = rowIndex + 1;
    currentList.splice(targetIndex, 0, duplicatedRow);
    setLocalEditedRows(currentList);

    const firstCol: string = columnsList.find((c: string): boolean => c !== "id") ?? columnsList[0];
    if (firstCol) {
      startEditingCell(targetIndex, firstCol, duplicatedRow[firstCol]);
    }

    if (onDuplicateRow && activeTable) {
      void onDuplicateRow(activeTable, rowIndex, duplicatedRow);
    }
  };


  // Extract schema details
  const schemaColumns: Array<{
    name: string;
    type: string;
    primaryKey: boolean;
    nullable: boolean;
  }> = React.useMemo((): Array<{
    name: string;
    type: string;
    primaryKey: boolean;
    nullable: boolean;
  }> => {
    const genericStorageSet: Set<string> = new Set<string>([
      "key",
      "value",
      "namespace",
      "createdAt",
      "updatedAt",
      "ttlMs",
      "version",
      "tags",
    ]);

    let rawCols: Record<string, { type?: string; primaryKey?: boolean; nullable?: boolean }> = {};
    if (tableSchema && typeof tableSchema === "object" && "columns" in tableSchema) {
      rawCols =
        (
          tableSchema as {
            columns: Record<string, { type?: string; primaryKey?: boolean; nullable?: boolean }>;
          }
        ).columns || {};
    }

    const rawSchemaKeyList: string[] = Object.keys(rawCols);
    const isGenericSchema: boolean =
      rawSchemaKeyList.length > 0 &&
      rawSchemaKeyList.every((c: string): boolean => genericStorageSet.has(c));

    if (rawSchemaKeyList.length > 0 && !isGenericSchema) {
      return Object.entries(rawCols).map(([colName, def]): {
        name: string;
        type: string;
        primaryKey: boolean;
        nullable: boolean;
      } => ({
        name: colName,
        type: def.type || "VARCHAR",
        primaryKey: Boolean(def.primaryKey || colName === "id" || colName === "key"),
        nullable: Boolean(def.nullable ?? true),
      }));
    }

    if (columnsList.length > 0) {
      return columnsList.map((colName: string): {
        name: string;
        type: string;
        primaryKey: boolean;
        nullable: boolean;
      } => {
        let inferredType: string = "VARCHAR";
        let hasNull: boolean = false;

        for (const row of normalizedRows.slice(0, 50)) {
          const val: unknown = row[colName];
          if (val === null || val === undefined) {
            hasNull = true;
          } else if (typeof val === "number") {
            inferredType = Number.isInteger(val) ? "INTEGER" : "REAL";
          } else if (typeof val === "boolean") {
            inferredType = "BOOLEAN";
          } else if (typeof val === "object") {
            inferredType = "JSON";
          }
        }

        const isPk: boolean = colName === "id" || colName === "key" || colName === "_id";
        return {
          name: colName,
          type: inferredType,
          primaryKey: isPk,
          nullable: isPk ? false : hasNull,
        };
      });
    }

    return [];
  }, [tableSchema, columnsList, normalizedRows]);

  return (
    <div
      id="sqlclient-explorer-root-layout"
      className={`sqlclient-explorer-layout ${hideInternalSidebar ? "content-only" : ""}`}
    >
      {/* Sidebar: Tables List */}
      {!hideInternalSidebar && (
        <aside id="sqlclient-tables-sidebar" className="sqlclient-sidebar">
        <div id="sqlclient-tables-sidebar-header" className="flex items-center justify-between">
          <span className="text-xs font-bold uppercase tracking-wider theme-text-muted">
            Tables ({tables.length})
          </span>
        </div>

        <Input
          id="sqlclient-table-search-input"
          size="sm"
          placeholder="Filter tables..."
          value={searchFilter}
          onChange={(e: React.ChangeEvent<HTMLInputElement>): void =>
            setSearchFilter(e.target.value)
          }
        />

        <div id="sqlclient-tables-list-container" className="sqlclient-tables-list">
          {filteredTables.map((tbl: TableItemMetadata) => {
            const isSelected: boolean = activeTable === tbl.name;
            return (
              <button
                key={tbl.name}
                id={`sqlclient-table-item-${tbl.name}`}
                className={`sqlclient-table-item ${isSelected ? "active" : ""}`}
                onClick={(): void => onSelectTable(tbl.name)}
              >
                <div className="flex items-center gap-2">
                  <IdeIcon name="Table" size="xs" />
                  <span className="truncate max-w-[150px]">{tbl.name}</span>
                </div>
                <span className="sqlclient-table-count-badge">
                  {tbl.rowCount}
                </span>
              </button>
            );
          })}

          {filteredTables.length === 0 && (
            <div
              id="sqlclient-no-tables-placeholder"
              className="p-4 text-center text-xs theme-text-muted"
            >
              No tables found
            </div>
          )}
        </div>
      </aside>
      )}

      {/* Main Table Viewer */}
      <section id="sqlclient-table-viewer-panel" className="sqlclient-card flex-1 flex flex-col">
        {activeTable ? (
          <>
            <div id="sqlclient-table-viewer-header" className="sqlclient-card-header">
              <div id="sqlclient-table-header-left" className="flex items-center gap-2.5">
                <div id="sqlclient-table-icon-box" className="sqlclient-table-icon-box">
                  <IdeIcon name="Table2" size="sm" color="var(--primary, #2563eb)" />
                </div>
                <h3 id="sqlclient-active-table-name" className="sqlclient-card-title">
                  {activeTable}
                </h3>
                <span id="sqlclient-record-count-text" className="sqlclient-header-record-count">
                  {tableData.length} records
                </span>
                {isCurrentTableLocked && (
                  <Badge id="sqlclient-table-locked-badge" variant="warning" size="sm">
                    <IdeIcon name="Lock" size="xs" className="mr-1" />
                    Locked
                  </Badge>
                )}
              </div>

              {/* Actions and Sub-tabs */}
              <div id="sqlclient-table-viewer-actions" className="flex items-center gap-1.5">
                {/* Lock / Unlock Toggle Button */}
                <button
                  id="sqlclient-toggle-lock-btn"
                  type="button"
                  className="sqlclient-action-icon-btn"
                  onClick={handleToggleLock}
                  title={isCurrentTableLocked ? "Unlock Table" : "Lock Table"}
                  aria-label={isCurrentTableLocked ? "Unlock Table" : "Lock Table"}
                >
                  <IdeIcon name={isCurrentTableLocked ? "Unlock" : "Lock"} size="xs" />
                </button>

                {/* Edit Table Button (Rename) */}
                <button
                  id="sqlclient-edit-table-btn"
                  type="button"
                  className="sqlclient-action-icon-btn"
                  onClick={(): void => {
                    setEditTableNameInput(activeTable);
                    setShowEditModal(true);
                  }}
                  disabled={isCurrentTableLocked}
                  title={isCurrentTableLocked ? "Table is locked" : "Edit Table"}
                  aria-label="Edit"
                >
                  <IdeIcon name="Edit3" size="xs" />
                </button>

                {/* Delete Table Button */}
                <button
                  id="sqlclient-delete-table-btn"
                  type="button"
                  className="sqlclient-action-icon-btn danger"
                  onClick={(): void => setShowDeleteTableModal(true)}
                  disabled={isCurrentTableLocked}
                  title={isCurrentTableLocked ? "Table is locked" : "Delete Table"}
                  aria-label="Delete"
                >
                  <IdeIcon name="Trash2" size="xs" />
                </button>

                {/* Filter / Options Menu Button */}
                <button
                  id="sqlclient-filter-options-btn"
                  type="button"
                  className="sqlclient-action-icon-btn"
                  title="Table Filter Options"
                  aria-label="Table Filter Options"
                >
                  <IdeIcon name="SlidersHorizontal" size="xs" />
                </button>

                {/* Code / DDL Button */}
                <button
                  id="sqlclient-code-view-btn"
                  type="button"
                  className="sqlclient-action-icon-btn"
                  title="View DDL Code"
                  aria-label="View DDL Code"
                  onClick={(): void => setActiveTab(activeTab === "schema" ? "data" : "schema")}
                >
                  <IdeIcon name="Code" size="xs" />
                </button>

                {/* Sub tabs: Data vs Schema */}
                <div id="sqlclient-table-subtab-nav" className="flex gap-1 ml-1">
                  <Button
                    id="sqlclient-tab-data-btn"
                    size="xs"
                    variant={activeTab === "data" ? "primary" : "secondary"}
                    onClick={(): void => setActiveTab("data")}
                    className="sqlclient-subtab-btn"
                  >
                    <IdeIcon name="List" size="xs" className="mr-1" />
                    Data
                  </Button>
                  <Button
                    id="sqlclient-tab-schema-btn"
                    size="xs"
                    variant={activeTab === "schema" ? "primary" : "secondary"}
                    onClick={(): void => setActiveTab("schema")}
                    className="sqlclient-subtab-btn"
                  >
                    <IdeIcon name="Code" size="xs" className="mr-1" />
                    Schema
                  </Button>
                  <Button
                    id="sqlclient-insert-row-btn"
                    size="xs"
                    variant={showInsertRowPanel ? "secondary" : "primary"}
                    disabled={isCurrentTableLocked || activeTab !== "data"}
                    onClick={(): void => setShowInsertRowPanel((prev: boolean): boolean => !prev)}
                    className="sqlclient-subtab-btn ml-1"
                    title={isCurrentTableLocked ? "Table is locked" : "Insert new row upper the table"}
                  >
                    <IdeIcon name="Plus" size="xs" className="mr-1" />
                    Insert Row
                  </Button>
                </div>
              </div>
            </div>

            {/* Row Selection Action Bar */}
            {selectedRowKeys.size > 0 && activeTab === "data" && (
              <div id="sqlclient-selection-action-bar" className="sqlclient-selection-bar">
                <div className="flex items-center gap-2">
                  <IdeIcon name="CheckSquare" size="sm" color="var(--primary, #2563eb)" />
                  <span id="sqlclient-selection-count-text" className="font-semibold text-xs theme-text">
                    {selectedRowKeys.size} row{selectedRowKeys.size > 1 ? "s" : ""} selected
                  </span>
                  <button
                    id="sqlclient-clear-selection-btn"
                    className="sqlclient-link-btn text-xs ml-2"
                    onClick={handleClearSelection}
                  >
                    Clear selection
                  </button>
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    id="sqlclient-delete-selected-rows-btn"
                    size="sm"
                    variant="danger"
                    disabled={isCurrentTableLocked || isOperating}
                    onClick={(): void => setShowDeleteRowsModal(true)}
                  >
                    <IdeIcon name="Trash2" size="xs" className="mr-1" />
                    Delete Selected ({selectedRowKeys.size})
                  </Button>
                </div>
              </div>
            )}

            {/* Quick Insert Row Bar Upper the Table */}
            {showInsertRowPanel && activeTab === "data" && (
              <div id="sqlclient-insert-row-panel" className="sqlclient-insert-row-container">
                <div id="sqlclient-insert-row-header" className="flex items-center justify-between">
                  <div id="sqlclient-insert-row-title" className="flex items-center gap-1.5 text-xs font-semibold theme-text">
                    <IdeIcon name="PlusCircle" size="xs" color="var(--primary, #2563eb)" />
                    <span>Insert Row into {activeTable.toUpperCase()}</span>
                  </div>
                  <div id="sqlclient-insert-row-header-actions" className="flex items-center gap-1.5">
                    <Button
                      id="sqlclient-confirm-insert-row-btn"
                      size="xs"
                      variant="primary"
                      onClick={handleConfirmInsertRow}
                    >
                      <IdeIcon name="Check" size="xs" className="mr-1" />
                      Insert
                    </Button>
                    <Button
                      id="sqlclient-cancel-insert-row-btn"
                      size="xs"
                      variant="ghost"
                      onClick={(): void => {
                        setShowInsertRowPanel(false);
                        setInsertRowFields({});
                      }}
                    >
                      <IdeIcon name="X" size="xs" />
                    </Button>
                  </div>
                </div>
                <div id="sqlclient-insert-row-grid" className="sqlclient-insert-row-grid">
                  {columnsList.map((col: string) => {
                    const colMeta: { name: string; type: string } | undefined = schemaColumns.find(
                      (c: { name: string; type: string }) => c.name.toLowerCase() === col.toLowerCase()
                    );
                    const colType: string = colMeta?.type ?? "VARCHAR";
                    return (
                      <div key={col} id={`sqlclient-insert-field-group-${col}`} className="sqlclient-insert-field-group">
                        <label
                          id={`sqlclient-insert-label-${col}`}
                          htmlFor={`sqlclient-insert-input-${col}`}
                          className="sqlclient-insert-field-label"
                        >
                          <span>{col}</span>
                          <span className="theme-text-muted font-mono font-normal text-[10px]">
                            ({colType.split("(")[0]})
                          </span>
                        </label>
                        <Input
                          id={`sqlclient-insert-input-${col}`}
                          size="sm"
                          placeholder={`Enter ${col}...`}
                          value={insertRowFields[col] ?? ""}
                          onChange={(e: React.ChangeEvent<HTMLInputElement>): void =>
                            handleFieldChange(col, e.target.value)
                          }
                          onKeyDown={(e: React.KeyboardEvent<HTMLInputElement>): void => {
                            if (e.key === "Enter") {
                              e.preventDefault();
                              void handleConfirmInsertRow();
                            } else if (e.key === "Escape") {
                              e.preventDefault();
                              setShowInsertRowPanel(false);
                            }
                          }}
                        />
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {isLoading ? (
              <div
                id="sqlclient-table-loading-spinner"
                className="flex-1 flex items-center justify-center p-12 theme-text-muted text-sm"
              >
                <IdeIcon name="RotateCw" size="md" className="animate-spin mr-2" />
                Loading table data...
              </div>
            ) : activeTab === "data" ? (
              <div
                id="sqlclient-table-data-wrapper"
                className="sqlclient-data-table-wrapper flex-1"
              >
                {activeRows.length > 0 ? (
                  <table id="sqlclient-records-data-table" className="sqlclient-data-table">
                    <thead>
                      <tr>
                        <th id="th-row-select" className="row-select-header">
                          <input
                            type="checkbox"
                            id="checkbox-select-all-rows"
                            aria-label="Select all rows"
                            checked={
                              activeRows.length > 0 &&
                              selectedRowKeys.size === activeRows.length
                            }
                            onChange={handleToggleSelectAll}
                          />
                        </th>
                        <th id="th-row-number" className="row-index-header">
                          #
                        </th>
                        {columnsList.map((col: string) => {
                          const colMeta: { name: string; type: string } | undefined = schemaColumns.find(
                            (c: { name: string; type: string }) => c.name.toLowerCase() === col.toLowerCase()
                          );
                          const colType: string = colMeta?.type ?? "VARCHAR";
                          return (
                            <th key={col} id={`th-col-${col}`} className="sqlclient-column-header-th">
                              <div id={`th-col-inner-${col}`} className="sqlclient-column-header-inner">
                                <span className="sqlclient-col-name">{col}</span>
                                <span className="sqlclient-col-type-tag">{colType.split("(")[0]}</span>
                              </div>
                            </th>
                          );
                        })}
                        <th id="th-row-actions" className="row-actions-header text-right pr-4">
                          Actions
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {activeRows.map((rowObj: Record<string, unknown>, rowIndex: number) => {
                        const rowKey: string = String(rowObj.id ?? rowObj.key ?? rowIndex);
                        const isRowSelected: boolean = selectedRowKeys.has(rowKey);
                        const isRowEditing: boolean = editingCell?.rowIndex === rowIndex;
                        return (
                          <tr
                            key={rowIndex}
                            id={`table-row-${rowIndex}`}
                            className={isRowSelected ? "selected-row" : ""}
                          >
                            <td className="row-select-cell">
                              <input
                                type="checkbox"
                                id={`checkbox-row-${rowIndex}`}
                                aria-label={`Select row ${rowIndex + 1}`}
                                checked={isRowSelected}
                                onChange={(): void => handleToggleRow(rowKey)}
                              />
                            </td>
                            <td className="row-index-cell">{rowIndex + 1}</td>
                            {columnsList.map((col: string) => {
                              const cellValue: unknown = rowObj[col];
                              const isThisCellEditing: boolean =
                                isRowEditing && editingCell?.col === col;

                              return (
                                <td
                                  key={col}
                                  id={`table-cell-${rowIndex}-${col}`}
                                  className={
                                    isThisCellEditing
                                      ? "sqlclient-cell-editing p-1"
                                      : "truncate max-w-[240px] group/cell"
                                  }
                                  onDoubleClick={(): void => {
                                    if (!isThisCellEditing) {
                                      startEditingCell(rowIndex, col, cellValue);
                                    }
                                  }}
                                >
                                  {isThisCellEditing && editingCell ? (
                                    <div
                                      id={`inline-edit-box-${rowIndex}-${col}`}
                                      className="sqlclient-inline-editor-box flex items-center gap-1.5 w-full"
                                    >
                                      {/* Type Selector */}
                                      <select
                                        id="inline-edit-type-select"
                                        aria-label="Select data type"
                                        className="sqlclient-inline-type-select"
                                        value={editingCell.type}
                                        onChange={(e: React.ChangeEvent<HTMLSelectElement>): void => {
                                          handleTypeChange(e.target.value as CellDataType);
                                        }}
                                      >
                                        <option value="string">string</option>
                                        <option value="number">number</option>
                                        <option value="boolean">boolean</option>
                                        <option value="null">null</option>
                                        <option value="json">json</option>
                                      </select>

                                      {/* Value Input by Type */}
                                      {editingCell.type === "string" && (
                                        <input
                                          id="inline-edit-value-input"
                                          type="text"
                                          className="sqlclient-inline-input"
                                          value={editingCell.value}
                                          onChange={(e: React.ChangeEvent<HTMLInputElement>): void => {
                                            setEditingCell((prev: EditingCellState | null): EditingCellState | null =>
                                              prev ? { ...prev, value: e.target.value } : null
                                            );
                                          }}
                                          onKeyDown={handleEditorKeyDown}
                                          autoFocus
                                        />
                                      )}

                                      {editingCell.type === "number" && (
                                        <input
                                          id="inline-edit-value-input"
                                          type="number"
                                          className="sqlclient-inline-input"
                                          value={editingCell.value}
                                          onChange={(e: React.ChangeEvent<HTMLInputElement>): void => {
                                            setEditingCell((prev: EditingCellState | null): EditingCellState | null =>
                                              prev ? { ...prev, value: e.target.value } : null
                                            );
                                          }}
                                          onKeyDown={handleEditorKeyDown}
                                          autoFocus
                                        />
                                      )}

                                      {editingCell.type === "boolean" && (
                                        <select
                                          id="inline-edit-value-select"
                                          aria-label="Select boolean value"
                                          className="sqlclient-inline-select"
                                          value={editingCell.value === "true" || editingCell.value === "TRUE" ? "true" : "false"}
                                          onChange={(e: React.ChangeEvent<HTMLSelectElement>): void => {
                                            setEditingCell((prev: EditingCellState | null): EditingCellState | null =>
                                              prev ? { ...prev, value: e.target.value } : null
                                            );
                                          }}
                                          onKeyDown={handleEditorKeyDown}
                                          autoFocus
                                        >
                                          <option value="true">TRUE</option>
                                          <option value="false">FALSE</option>
                                        </select>
                                      )}

                                      {editingCell.type === "null" && (
                                        <span id="inline-edit-null-display" className="sqlclient-inline-null-badge">
                                          NULL
                                        </span>
                                      )}

                                      {editingCell.type === "json" && (
                                        <input
                                          id="inline-edit-value-input"
                                          type="text"
                                          placeholder="{...} or [...]"
                                          className="sqlclient-inline-input font-mono"
                                          value={editingCell.value}
                                          onChange={(e: React.ChangeEvent<HTMLInputElement>): void => {
                                            setEditingCell((prev: EditingCellState | null): EditingCellState | null =>
                                              prev ? { ...prev, value: e.target.value } : null
                                            );
                                          }}
                                          onKeyDown={handleEditorKeyDown}
                                          autoFocus
                                        />
                                      )}

                                      {/* Inline Save & Cancel Buttons */}
                                      <div id={`inline-edit-actions-${rowIndex}-${col}`} className="flex items-center gap-1 shrink-0">
                                        <button
                                          id="btn-save-inline-edit"
                                          type="button"
                                          className="sqlclient-inline-save-btn"
                                          title="Save changes"
                                          aria-label="Save value"
                                          onClick={handleSaveInlineEdit}
                                        >
                                          <IdeIcon name="Check" size="xs" />
                                          <span>Save</span>
                                        </button>
                                        <button
                                          id="btn-cancel-inline-edit"
                                          type="button"
                                          className="sqlclient-inline-cancel-btn"
                                          title="Cancel and discard"
                                          aria-label="Cancel editing"
                                          onClick={handleCancelInlineEdit}
                                        >
                                          <IdeIcon name="X" size="xs" />
                                          <span>Cancel</span>
                                        </button>
                                      </div>
                                    </div>
                                  ) : (
                                    <div
                                      id={`cell-content-${rowIndex}-${col}`}
                                      className="flex items-center justify-between gap-1 w-full"
                                    >
                                      <span className="truncate block">
                                        {cellValue === null || cellValue === undefined ? (
                                          <span className="theme-text-muted italic text-xs">NULL</span>
                                        ) : typeof cellValue === "boolean" ? (
                                          <Badge variant={cellValue ? "primary" : "secondary"} size="xs">
                                            {cellValue ? "TRUE" : "FALSE"}
                                          </Badge>
                                        ) : typeof cellValue === "object" ? (
                                          <code className="text-xs font-mono theme-text-muted truncate block max-w-[200px]">
                                            {JSON.stringify(cellValue)}
                                          </code>
                                        ) : (
                                          <span className="theme-text truncate block max-w-[200px]">
                                            {String(cellValue)}
                                          </span>
                                        )}
                                      </span>
                                      {!isCurrentTableLocked && (
                                        <button
                                          id={`btn-edit-cell-${rowIndex}-${col}`}
                                          type="button"
                                          className="sqlclient-cell-edit-btn opacity-0 group-hover/cell:opacity-100 shrink-0"
                                          title="Edit value inline"
                                          aria-label={`Modify ${col} value`}
                                          onClick={(e: React.MouseEvent): void => {
                                            e.stopPropagation();
                                            startEditingCell(rowIndex, col, cellValue);
                                          }}
                                        >
                                          <IdeIcon name="Edit2" size="xs" />
                                        </button>
                                      )}
                                    </div>
                                  )}
                                </td>
                              );
                            })}

                            {/* Row Action Column */}
                            <td id={`td-row-actions-${rowIndex}`} className="row-actions-cell text-right pr-4">
                              {isRowEditing ? (
                                <div id={`row-actions-editing-${rowIndex}`} className="flex items-center justify-end gap-1">
                                  <button
                                    id={`btn-save-row-${rowIndex}`}
                                    type="button"
                                    className="sqlclient-inline-save-btn"
                                    onClick={handleSaveInlineEdit}
                                    title="Save changes"
                                    aria-label="Save row"
                                  >
                                    <IdeIcon name="Check" size="xs" />
                                    <span>Save</span>
                                  </button>
                                  <button
                                    id={`btn-cancel-row-${rowIndex}`}
                                    type="button"
                                    className="sqlclient-inline-cancel-btn"
                                    onClick={handleCancelInlineEdit}
                                    title="Cancel and discard"
                                    aria-label="Cancel row"
                                  >
                                    <IdeIcon name="X" size="xs" />
                                    <span>Cancel</span>
                                  </button>
                                </div>
                               ) : (
                                <div id={`row-actions-default-${rowIndex}`} className="flex items-center justify-end gap-1.5">
                                  <button
                                    id={`btn-edit-row-${rowIndex}`}
                                    type="button"
                                    disabled={isCurrentTableLocked}
                                    className="sqlclient-row-edit-action-btn"
                                    onClick={(): void => {
                                      const firstCol: string = columnsList.find((c: string): boolean => c !== "id") ?? columnsList[0];
                                      if (firstCol) {
                                        startEditingCell(rowIndex, firstCol, rowObj[firstCol]);
                                      }
                                    }}
                                    title="Edit row value inline"
                                    aria-label={`Modify row ${rowIndex + 1}`}
                                  >
                                    <IdeIcon name="Edit" size="xs" className="mr-1" />
                                    <span>Edit</span>
                                  </button>
                                  <button
                                    id={`btn-duplicate-row-${rowIndex}`}
                                    type="button"
                                    disabled={isCurrentTableLocked}
                                    className="sqlclient-row-duplicate-action-btn"
                                    onClick={(): void => handleDuplicateRow(rowIndex, rowObj)}
                                    title="Duplicate row for edit"
                                    aria-label={`Duplicate row ${rowIndex + 1}`}
                                  >
                                    <IdeIcon name="Copy" size="xs" className="mr-1" />
                                    <span>Duplicate</span>
                                  </button>
                                </div>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                ) : (
                  <div
                    id="sqlclient-empty-records-message"
                    className="p-8 text-center theme-text-muted text-sm"
                  >
                    No records in table <strong>{activeTable}</strong>
                  </div>
                )}
              </div>
            ) : (
              <div
                id="sqlclient-table-schema-wrapper"
                className="sqlclient-data-table-wrapper flex-1"
              >
                <table id="sqlclient-schema-table" className="sqlclient-data-table">
                  <thead>
                    <tr>
                      <th>Column Name</th>
                      <th>Data Type</th>
                      <th>Primary Key</th>
                      <th>Nullable</th>
                    </tr>
                  </thead>
                  <tbody>
                    {schemaColumns.map((col) => (
                      <tr key={col.name}>
                        <td className="font-semibold">{col.name}</td>
                        <td>
                          <Badge variant="secondary" size="xs">
                            {col.type}
                          </Badge>
                        </td>
                        <td>
                          {col.primaryKey ? (
                            <Badge variant="primary" size="xs">
                              PK
                            </Badge>
                          ) : (
                            "-"
                          )}
                        </td>
                        <td>{col.nullable ? "YES" : "NO"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {/* Center Data Grid Status Bar (Stitch Design) */}
            <div id="sqlclient-grid-status-bar" className="sqlclient-grid-status-bar">
              <div id="sqlclient-grid-status-left" className="sqlclient-grid-status-left">
                <span id="sqlclient-grid-selected-status">
                  Row {selectedRowKeys.size > 0 ? selectedRowKeys.size : 1} of {activeRows.length || 1} selected
                </span>
                <span className="sqlclient-status-pipe">|</span>
                <span id="sqlclient-query-time-badge" className="sqlclient-query-time-badge">
                  Query executed in 0.04 ms
                </span>
              </div>
              <div id="sqlclient-grid-status-right" className="sqlclient-grid-status-right">
                <span id="sqlclient-encoding-text">UTF-8</span>
                <span className="sqlclient-status-dot-sep">·</span>
                <span id="sqlclient-autocommit-text">Auto-commit: ON</span>
              </div>
            </div>
          </>
        ) : (
          <div
            id="sqlclient-no-selection-placeholder"
            className="flex-1 flex flex-col items-center justify-center p-12 theme-text-muted gap-3"
          >
            <IdeIcon name="Database" size="xl" />
            <p className="text-sm">Select a table from the sidebar to inspect records and schema</p>
          </div>
        )}
      </section>

      {/* Edit Table Modal */}
      <Modal
        id="modal-edit-table"
        isOpen={showEditModal}
        onClose={(): void => setShowEditModal(false)}
        title={`Edit Table: ${activeTable ?? ""}`}
        footer={
          <div id="modal-edit-table-footer" className="flex items-center justify-end gap-2">
            <Button
              id="modal-edit-table-cancel-btn"
              size="sm"
              variant="secondary"
              onClick={(): void => setShowEditModal(false)}
            >
              Cancel
            </Button>
            <Button
              id="modal-edit-table-submit-btn"
              size="sm"
              variant="primary"
              disabled={
                !editTableNameInput.trim() ||
                editTableNameInput.trim() === activeTable ||
                isOperating
              }
              onClick={handleConfirmEditTable}
            >
              {isOperating ? "Renaming..." : "Save Changes"}
            </Button>
          </div>
        }
      >
        <div id="modal-edit-table-content" className="div-col gap-3 p-2">
          <label htmlFor="input-edit-table-name" className="text-xs font-semibold theme-text">
            Table Name
          </label>
          <Input
            id="input-edit-table-name"
            size="sm"
            value={editTableNameInput}
            onChange={(e: React.ChangeEvent<HTMLInputElement>): void =>
              setEditTableNameInput(e.target.value)
            }
            placeholder="Enter new table name"
          />
        </div>
      </Modal>

      {/* Delete Table Modal */}
      <Modal
        id="modal-delete-table"
        isOpen={showDeleteTableModal}
        onClose={(): void => setShowDeleteTableModal(false)}
        title={`Delete Table: ${activeTable ?? ""}`}
        footer={
          <div id="modal-delete-table-footer" className="flex items-center justify-end gap-2">
            <Button
              id="modal-delete-table-cancel-btn"
              size="sm"
              variant="secondary"
              onClick={(): void => setShowDeleteTableModal(false)}
            >
              Cancel
            </Button>
            <Button
              id="modal-delete-table-confirm-btn"
              size="sm"
              variant="danger"
              disabled={isOperating}
              onClick={handleConfirmDeleteTable}
            >
              {isOperating ? "Deleting..." : "Delete Table"}
            </Button>
          </div>
        }
      >
        <div id="modal-delete-table-content" className="div-col gap-2 p-2">
          <p className="text-sm theme-text">
            Are you sure you want to drop table <strong>{activeTable}</strong>?
          </p>
          <p className="text-xs text-danger">
            This action cannot be undone. All data and schemas will be permanently deleted.
          </p>
        </div>
      </Modal>

      {/* Delete Rows Modal */}
      <Modal
        id="modal-delete-rows"
        isOpen={showDeleteRowsModal}
        onClose={(): void => setShowDeleteRowsModal(false)}
        title="Delete Selected Rows"
        footer={
          <div id="modal-delete-rows-footer" className="flex items-center justify-end gap-2">
            <Button
              id="modal-delete-rows-cancel-btn"
              size="sm"
              variant="secondary"
              onClick={(): void => setShowDeleteRowsModal(false)}
            >
              Cancel
            </Button>
            <Button
              id="modal-delete-rows-confirm-btn"
              size="sm"
              variant="danger"
              disabled={isOperating}
              onClick={handleConfirmDeleteRows}
            >
              {isOperating ? "Deleting..." : `Delete ${selectedRowKeys.size} Row(s)`}
            </Button>
          </div>
        }
      >
        <div id="modal-delete-rows-content" className="div-col gap-2 p-2">
          <p className="text-sm theme-text">
            Are you sure you want to delete <strong>{selectedRowKeys.size}</strong> selected row(s) from table <strong>{activeTable}</strong>?
          </p>
          <p className="text-xs text-danger">
            This action will remove these records permanently from the database.
          </p>
        </div>
      </Modal>
    </div>
  );
};

export default TablesExplorer;
