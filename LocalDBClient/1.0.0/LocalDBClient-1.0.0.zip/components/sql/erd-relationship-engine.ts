import { TableItemMetadata } from "./TablesExplorer";
import {
  ErdColumnMeta,
  ErdDiagramData,
  ErdLayoutMode,
  ErdTableNode,
  TableRelationship,
  XmlErpRelationship,
  XmlErpSchemaDefinition,
  XmlErpTable,
  XmlErpTableColumn,
} from "./erd-types";
import { mergeXmlWithDatabaseTables } from "./erd-xml-parser";

/**
 * Normalizes an entity name to find candidate table names (singular & plural forms).
 */
export function getCandidateTableNames(columnPrefix: string): string[] {
  const lower: string = columnPrefix.toLowerCase().trim();
  const candidates: string[] = [lower];

  // Pluralization rules
  if (lower.endsWith("y") && !lower.endsWith("ay") && !lower.endsWith("ey") && !lower.endsWith("oy")) {
    candidates.push(`${lower.slice(0, -1)}ies`);
  } else if (
    lower.endsWith("s") ||
    lower.endsWith("x") ||
    lower.endsWith("z") ||
    lower.endsWith("ch") ||
    lower.endsWith("sh")
  ) {
    candidates.push(`${lower}es`);
  } else {
    candidates.push(`${lower}s`);
  }

  // Singularization rules if the prefix itself is already plural
  if (lower.endsWith("ies")) {
    candidates.push(`${lower.slice(0, -3)}y`);
  } else if (lower.endsWith("es")) {
    candidates.push(lower.slice(0, -2));
  } else if (lower.endsWith("s") && !lower.endsWith("ss")) {
    candidates.push(lower.slice(0, -1));
  }

  return Array.from(new Set(candidates));
}

/**
 * Determines whether a column is likely a Primary Key.
 */
export function isColumnPrimaryKey(columnName: string, tableName: string): boolean {
  const lowerCol: string = columnName.toLowerCase();
  const lowerTable: string = tableName.toLowerCase();
  if (lowerCol === "id" || lowerCol === "_id" || lowerCol === "pk") {
    return true;
  }
  if (lowerCol === `${lowerTable}_id` || lowerCol === `${lowerTable}id`) {
    return true;
  }
  const candidates: string[] = getCandidateTableNames(lowerTable);
  return candidates.some(
    (cand: string): boolean => lowerCol === `${cand}_id` || lowerCol === `${cand}id`
  );
}

/**
 * Infers SQL data type from column name heuristics.
 */
export function inferColumnType(columnName: string, isPk: boolean, isFk: boolean): string {
  const lower: string = columnName.toLowerCase();

  if (isPk) return "INTEGER (PK)";
  if (isFk) return "INTEGER (FK)";

  if (
    lower.endsWith("_date") ||
    lower.endsWith("_at") ||
    lower === "date" ||
    lower === "timestamp" ||
    lower === "created" ||
    lower === "updated"
  ) {
    return "TIMESTAMP";
  }

  if (
    lower.startsWith("is_") ||
    lower.startsWith("has_") ||
    lower === "active" ||
    lower === "enabled" ||
    lower === "locked" ||
    lower === "verified" ||
    lower === "archived"
  ) {
    return "BOOLEAN";
  }

  if (
    lower.includes("price") ||
    lower.includes("amount") ||
    lower.includes("total") ||
    lower.includes("cost") ||
    lower.includes("balance") ||
    lower.includes("salary") ||
    lower === "discount" ||
    lower === "rate"
  ) {
    return "DECIMAL(12,2)";
  }

  if (
    lower === "count" ||
    lower === "quantity" ||
    lower === "qty" ||
    lower === "age" ||
    lower === "views" ||
    lower === "sort_order" ||
    lower === "priority" ||
    lower === "level"
  ) {
    return "INTEGER";
  }

  if (
    lower === "description" ||
    lower === "content" ||
    lower === "body" ||
    lower === "notes" ||
    lower === "bio" ||
    lower === "summary" ||
    lower === "text"
  ) {
    return "TEXT";
  }

  if (
    lower === "metadata" ||
    lower === "settings" ||
    lower === "payload" ||
    lower === "extra" ||
    lower === "json" ||
    lower === "data" ||
    lower === "config"
  ) {
    return "JSON";
  }

  return "VARCHAR(255)";
}

/**
 * Parses all tables and infers entity relationships (Foreign Keys and Primary Keys).
 */
export function inferTableRelationships(
  tables: TableItemMetadata[],
  layoutMode: ErdLayoutMode = "grid",
  xmlSchema?: XmlErpSchemaDefinition | null
): ErdDiagramData {
  let workingTables: TableItemMetadata[] = Array.isArray(tables) ? tables : [];
  if (xmlSchema && Array.isArray(xmlSchema.tables) && xmlSchema.tables.length > 0) {
    const merged: { tables: TableItemMetadata[]; relationships: TableRelationship[] } =
      mergeXmlWithDatabaseTables(workingTables, xmlSchema);
    workingTables = merged.tables;
  }

  if (workingTables.length === 0) {
    return { tables: [], relationships: [], xmlSchema: xmlSchema || undefined };
  }

  const validTables: TableItemMetadata[] = workingTables.filter(
    (tbl: TableItemMetadata): boolean => Boolean(tbl && tbl.name)
  );

  const tableNameMap: Map<string, TableItemMetadata> = new Map<string, TableItemMetadata>();
  validTables.forEach((tbl: TableItemMetadata): void => {
    tableNameMap.set(tbl.name.toLowerCase(), tbl);
  });

  const relationships: TableRelationship[] = [];
  const processedRelIds: Set<string> = new Set<string>();

  // If XML schema has explicit relationships, prioritize them
  const xmlRelByColKey: Map<string, XmlErpRelationship> = new Map<string, XmlErpRelationship>();
  if (xmlSchema && Array.isArray(xmlSchema.relationships)) {
    xmlSchema.relationships.forEach((rel: XmlErpRelationship): void => {
      const relId: string =
        rel.id || `${rel.sourceTable}.${rel.sourceColumn}->${rel.targetTable}.${rel.targetColumn}`;
      if (!processedRelIds.has(relId)) {
        processedRelIds.add(relId);
        relationships.push({
          id: relId,
          sourceTable: rel.sourceTable,
          sourceColumn: rel.sourceColumn,
          targetTable: rel.targetTable,
          targetColumn: rel.targetColumn,
          cardinality: rel.cardinality,
          label: rel.label || `${rel.sourceTable}.${rel.sourceColumn} ➔ ${rel.targetTable}.${rel.targetColumn}`,
        });
      }
      xmlRelByColKey.set(`${rel.sourceTable.toLowerCase()}.${rel.sourceColumn.toLowerCase()}`, rel);
    });
  }

  // XML table columns metadata lookup
  const xmlColMap: Map<string, XmlErpTableColumn> = new Map<string, XmlErpTableColumn>();
  if (xmlSchema && Array.isArray(xmlSchema.tables)) {
    xmlSchema.tables.forEach((xt: XmlErpTable): void => {
      if (Array.isArray(xt.columns)) {
        xt.columns.forEach((xc: XmlErpTableColumn): void => {
          xmlColMap.set(`${xt.name.toLowerCase()}.${xc.name.toLowerCase()}`, xc);
        });
      }
    });
  }

  // Intermediate table column metadata map
  const tableColumnsMetaMap: Map<string, ErdColumnMeta[]> = new Map<string, ErdColumnMeta[]>();

  validTables.forEach((table: TableItemMetadata): void => {
    const colMetas: ErdColumnMeta[] = [];
    const safeColumns: string[] = Array.isArray(table.columns) ? table.columns : [];

    // Find table PK
    let pkColName: string = "id";
    const foundPk: string | undefined = safeColumns.find((col: string): boolean =>
      isColumnPrimaryKey(col, table.name)
    );
    if (foundPk) {
      pkColName = foundPk;
    }

    safeColumns.forEach((col: string): void => {
      const lowerCol: string = col.toLowerCase();
      const colKey: string = `${table.name.toLowerCase()}.${lowerCol}`;
      const xmlColDef: XmlErpTableColumn | undefined = xmlColMap.get(colKey);
      const xmlRelDef: XmlErpRelationship | undefined = xmlRelByColKey.get(colKey);

      let isPk: boolean = isColumnPrimaryKey(col, table.name);
      if (xmlColDef && typeof xmlColDef.primaryKey === "boolean") {
        isPk = xmlColDef.primaryKey;
      }

      let isFk: boolean = false;
      let targetTable: string | undefined = undefined;
      let targetColumn: string | undefined = undefined;

      if (xmlRelDef) {
        isFk = true;
        targetTable = xmlRelDef.targetTable;
        targetColumn = xmlRelDef.targetColumn;
      } else if (xmlColDef && (xmlColDef.targetTable || xmlColDef.foreignKey || xmlColDef.references)) {
        isFk = true;
        targetTable = xmlColDef.targetTable;
        targetColumn = xmlColDef.targetColumn || "id";
      } else if (!isPk && (lowerCol.endsWith("_id") || lowerCol.endsWith("id"))) {
        // Heuristic candidate
        const prefix: string = lowerCol.endsWith("_id")
          ? lowerCol.slice(0, -3)
          : lowerCol.slice(0, -2);

        // Check self-referencing (parent_id)
        if (prefix === "parent" || prefix === "manager") {
          isFk = true;
          targetTable = table.name;
          targetColumn = pkColName;
        } else {
          const candidates: string[] = getCandidateTableNames(prefix);
          const matchedTarget: TableItemMetadata | undefined = candidates
            .map((c: string): TableItemMetadata | undefined => tableNameMap.get(c))
            .find(Boolean);

          if (matchedTarget) {
            isFk = true;
            targetTable = matchedTarget.name;
            const targetCols: string[] = Array.isArray(matchedTarget.columns) ? matchedTarget.columns : [];
            const targetPk: string =
              targetCols.find((tc: string): boolean =>
                isColumnPrimaryKey(tc, matchedTarget.name)
              ) || "id";
            targetColumn = targetPk;
          }
        }
      }

      if (isFk && targetTable && targetColumn) {
        const relId: string = `${table.name}.${col}->${targetTable}.${targetColumn}`;
        if (!processedRelIds.has(relId)) {
          processedRelIds.add(relId);
          relationships.push({
            id: relId,
            sourceTable: table.name,
            sourceColumn: col,
            targetTable,
            targetColumn,
            cardinality: "many-to-one",
            label: `${table.name}.${col} ➔ ${targetTable}.${targetColumn}`,
          });
        }
      }

      const inferredType: string = xmlColDef?.type || inferColumnType(col, isPk, isFk);

      colMetas.push({
        name: col,
        inferredType,
        isPrimaryKey: isPk,
        isForeignKey: isFk,
        targetTable,
        targetColumn,
      });
    });

    tableColumnsMetaMap.set(table.name, colMetas);
  });

  // Calculate layout coordinates
  const CARD_WIDTH: number = 240;
  const HEADER_HEIGHT: number = 42;
  const ROW_HEIGHT: number = 28;
  const FOOTER_HEIGHT: number = 32;
  const PADDING: number = 30;

  const tableNodes: ErdTableNode[] = [];

  if (layoutMode === "hierarchical") {
    // Group into layers: root tables (referenced by others), middle, and leaves
    const incomingCount: Map<string, number> = new Map<string, number>();
    const outgoingCount: Map<string, number> = new Map<string, number>();

    validTables.forEach((t: TableItemMetadata): void => {
      incomingCount.set(t.name, 0);
      outgoingCount.set(t.name, 0);
    });

    relationships.forEach((rel: TableRelationship): void => {
      outgoingCount.set(rel.sourceTable, (outgoingCount.get(rel.sourceTable) || 0) + 1);
      incomingCount.set(rel.targetTable, (incomingCount.get(rel.targetTable) || 0) + 1);
    });

    // Layer 0: Most referenced tables / least outgoing FKs
    const layer0: TableItemMetadata[] = [];
    const layer1: TableItemMetadata[] = [];
    const layer2: TableItemMetadata[] = [];

    validTables.forEach((t: TableItemMetadata): void => {
      const out: number = outgoingCount.get(t.name) || 0;
      const inc: number = incomingCount.get(t.name) || 0;

      if (out === 0 && inc > 0) {
        layer0.push(t);
      } else if (out > 0 && inc > 0) {
        layer1.push(t);
      } else {
        layer2.push(t);
      }
    });

    const layers: TableItemMetadata[][] = [layer0, layer1, layer2].filter(
      (layer: TableItemMetadata[]): boolean => layer.length > 0
    );

    let currentX: number = PADDING;
    layers.forEach((layer: TableItemMetadata[]): void => {
      let currentY: number = PADDING;
      layer.forEach((tbl: TableItemMetadata): void => {
        const cols: ErdColumnMeta[] = tableColumnsMetaMap.get(tbl.name) || [];
        const cardHeight: number = HEADER_HEIGHT + cols.length * ROW_HEIGHT + FOOTER_HEIGHT;

        tableNodes.push({
          name: tbl.name,
          rowCount: tbl.rowCount ?? 0,
          columnCount: tbl.columnCount ?? cols.length,
          columns: cols,
          x: currentX,
          y: currentY,
          width: CARD_WIDTH,
          height: cardHeight,
        });

        currentY += cardHeight + 36;
      });
      currentX += CARD_WIDTH + 100;
    });
  } else {
    // Standard Grid layout
    const COLUMNS_PER_ROW: number = Math.max(1, Math.min(3, Math.ceil(Math.sqrt(validTables.length))));
    const GAP_X: number = 80;
    const GAP_Y: number = 40;

    let colIdx: number = 0;
    const columnMaxY: number[] = new Array(COLUMNS_PER_ROW).fill(PADDING);

    validTables.forEach((tbl: TableItemMetadata): void => {
      const cols: ErdColumnMeta[] = tableColumnsMetaMap.get(tbl.name) || [];
      const cardHeight: number = HEADER_HEIGHT + cols.length * ROW_HEIGHT + FOOTER_HEIGHT;

      const posX: number = PADDING + colIdx * (CARD_WIDTH + GAP_X);
      const posY: number = columnMaxY[colIdx];

      tableNodes.push({
        name: tbl.name,
        rowCount: tbl.rowCount ?? 0,
        columnCount: tbl.columnCount ?? cols.length,
        columns: cols,
        x: posX,
        y: posY,
        width: CARD_WIDTH,
        height: cardHeight,
      });

      columnMaxY[colIdx] = posY + cardHeight + GAP_Y;

      colIdx++;
      if (colIdx >= COLUMNS_PER_ROW) {
        colIdx = 0;
      }
    });
  }

  return {
    tables: tableNodes,
    relationships,
    xmlSchema: xmlSchema || undefined,
  };
}
