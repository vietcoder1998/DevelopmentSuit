import React from "react";
import { IdeIcon } from "./bases";
import { useSafeTranslations } from "./bases/use-safe-translations";
import { ServiceConnectionState } from "./connection/connection-types";
import { FastDatabaseSwitcher } from "./sql/FastDatabaseSwitcher";

export type ActiveStudioMode = "sql" | "vector" | "connections";

export interface AppHeaderProps {
  readonly activeMode: ActiveStudioMode;
  readonly onChangeMode: (mode: ActiveStudioMode) => void;
  readonly sqlConnection: ServiceConnectionState;
  readonly vectorConnection: ServiceConnectionState;
  readonly activeSqlDatabase: string;
  readonly activeVectorCollection: string;
  readonly onRefreshAll?: () => Promise<void>;
  readonly isRefreshing?: boolean;
  readonly sqlDatabases?: string[];
  readonly onSelectSqlDatabase?: (name: string) => void;
  readonly onCreateSqlDatabase?: (name: string) => Promise<void> | void;
}

export const AppHeader: React.FC<AppHeaderProps> = ({
  activeMode,
  onChangeMode,
  sqlConnection,
  vectorConnection,
  activeSqlDatabase,
  activeVectorCollection,
  sqlDatabases,
  onSelectSqlDatabase,
  onCreateSqlDatabase,
}) => {
  const t: (key: string, fallback: string) => string = useSafeTranslations("localdbclient.header");

  return (
    <header id="localdb-app-header" className="localdb-header sticky-header">
      {/* Brand & Connection Status Badges */}
      <div id="localdb-header-left-group" className="localdb-header-left">
        <div id="localdb-brand-box" className="div-row gap-2 align-center">
          <IdeIcon name="Database" size="md" color="var(--primary, #2563eb)" />
          <span id="localdb-brand-title" className="localdb-brand-title">
            {t("brandTitle", "2-TEK LocalDB Studio")}
          </span>
        </div>

        {/* Status Indicators */}
        <div id="localdb-status-indicators-group" className="div-row gap-2 align-center">
          <div
            id="status-badge-sql"
            className="localdb-status-badge cursor-pointer"
            onClick={(): void => onChangeMode("connections")}
            title={`SQL Server via ${sqlConnection.protocol.toUpperCase()} (${sqlConnection.endpoint})`}
          >
            <span
              id="dot-sql-header"
              className={`localdb-status-dot ${sqlConnection.isConnected ? "status-online" : "status-offline"}`}
            />
            <span id="text-sql-status" className="font-semibold text-xs">
              SQL: {sqlConnection.isConnected ? sqlConnection.protocol.toUpperCase() : "Offline"}
            </span>
          </div>

          <div
            id="status-badge-vector"
            className="localdb-status-badge cursor-pointer"
            onClick={(): void => onChangeMode("connections")}
            title={`Vector Server via ${vectorConnection.protocol.toUpperCase()} (${vectorConnection.endpoint})`}
          >
            <span
              id="dot-vector-header"
              className={`localdb-status-dot ${vectorConnection.isConnected ? "status-online" : "status-offline"}`}
            />
            <span id="text-vector-status" className="font-semibold text-xs">
              Vector: {vectorConnection.isConnected ? vectorConnection.protocol.toUpperCase() : "Offline"}
            </span>
          </div>
        </div>
      </div>

      {/* Center Engine Switcher */}
      <div id="localdb-engine-switcher-container" className="div-row gap-2 align-center">
        <button
          id="btn-switch-sql-studio"
          type="button"
          className={`localdb-engine-tab-btn ${activeMode === "sql" ? "active" : ""}`}
          onClick={(): void => onChangeMode("sql")}
        >
          <IdeIcon name="Table" size="sm" />
          <span>{t("tabSqlStudio", "SQL Database")}</span>
        </button>

        <button
          id="btn-switch-vector-studio"
          type="button"
          className={`localdb-engine-tab-btn ${activeMode === "vector" ? "active" : ""}`}
          onClick={(): void => onChangeMode("vector")}
        >
          <IdeIcon name="Cpu" size="sm" />
          <span>{t("tabVectorStudio", "Vector Database")}</span>
        </button>

        <button
          id="btn-switch-connections"
          data-testid="btn-create-connection"
          type="button"
          className={`localdb-engine-tab-btn ${activeMode === "connections" ? "active" : ""}`}
          onClick={(): void => onChangeMode("connections")}
        >
          <IdeIcon name="PlusCircle" size="sm" />
          <span>{t("tabCreateConnection", "Create Connection")}</span>
        </button>
      </div>

      {/* Right Actions & Context */}
      <div id="localdb-header-right-group" className="localdb-header-right">
        {activeMode === "sql" && (
          sqlDatabases && onSelectSqlDatabase ? (
            <FastDatabaseSwitcher
              databases={sqlDatabases}
              activeDatabase={activeSqlDatabase || "default"}
              onSelectDatabase={onSelectSqlDatabase}
              onCreateDatabase={onCreateSqlDatabase}
              variant="header"
            />
          ) : (
            <div id="context-badge-active-db" className="localdb-status-badge">
              <IdeIcon name="Database" size="xs" color="var(--primary, #2563eb)" />
              <span id="text-active-db" className="text-xs truncate max-w-150">
                DB: {activeSqlDatabase || "default"}
              </span>
            </div>
          )
        )}

        {activeMode === "vector" && (
          <div id="context-badge-active-col" className="localdb-status-badge">
            <IdeIcon name="Layers" size="xs" />
            <span id="text-active-col" className="text-xs truncate max-w-150">
              Col: {activeVectorCollection || "default"}
            </span>
          </div>
        )}
      </div>
    </header>
  );
};
