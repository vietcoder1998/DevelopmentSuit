"use client";

import React, { useState, useEffect, useCallback } from "react";
import { IdeIcon } from "../bases/ide-icon";
import { Button } from "../bases/button";
import { Input } from "../bases/input";

// ── Types ──────────────────────────────────────────────────────────────────

export interface McpTool {
  readonly name: string;
  readonly description: string;
  readonly inputSchema?: Record<string, unknown>;
}

export interface McpResource {
  readonly uri: string;
  readonly name: string;
  readonly description?: string;
  readonly mimeType?: string;
}

export interface McpPrompt {
  readonly name: string;
  readonly description?: string;
  readonly arguments?: Array<{ name: string; description?: string; required?: boolean }>;
}

export interface McpServerInfo {
  readonly name: string;
  readonly version: string;
  readonly protocolVersion: string;
}

export interface McpCallResult {
  readonly toolName: string;
  readonly input: string;
  readonly output: string;
  readonly isError: boolean;
  readonly durationMs: number;
}

export interface McpExplorerProps {
  readonly endpoint: string;
  readonly transport?: "sse" | "stdio" | "http";
}

export type McpSubTab = "tools" | "resources" | "prompts" | "console";

// ── Default seed data (when server is offline / not yet connected) ─────────

function getSeedTools(): McpTool[] {
  return [
    {
      name: "read_file",
      description: "Read the contents of a file at the given path.",
      inputSchema: { type: "object", properties: { path: { type: "string" } } },
    },
    {
      name: "list_directory",
      description: "List all files and directories inside a given path.",
      inputSchema: { type: "object", properties: { path: { type: "string" } } },
    },
    {
      name: "search_files",
      description: "Search for files matching a pattern inside a directory.",
      inputSchema: {
        type: "object",
        properties: {
          path: { type: "string" },
          pattern: { type: "string" },
        },
      },
    },
    {
      name: "execute_query",
      description: "Run a SQL query against the local database.",
      inputSchema: { type: "object", properties: { query: { type: "string" } } },
    },
  ];
}

function getSeedResources(): McpResource[] {
  return [
    { uri: "file:///data/database.sqlite", name: "Local SQLite Database", mimeType: "application/octet-stream" },
    { uri: "file:///logs/server.log", name: "Server Log", mimeType: "text/plain" },
    { uri: "config://settings.json", name: "Application Settings", mimeType: "application/json" },
  ];
}

function getSeedPrompts(): McpPrompt[] {
  return [
    {
      name: "summarize_table",
      description: "Generate a summary of a database table schema and its row count.",
      arguments: [
        { name: "table_name", description: "Name of the table", required: true },
      ],
    },
    {
      name: "explain_query",
      description: "Explain a SQL query in plain English.",
      arguments: [
        { name: "query", description: "SQL query to explain", required: true },
      ],
    },
  ];
}

// ── Component ─────────────────────────────────────────────────────────────

export const McpExplorer: React.FC<McpExplorerProps> = ({ endpoint, transport = "sse" }) => {
  const [activeTab, setActiveTab]: [McpSubTab, React.Dispatch<React.SetStateAction<McpSubTab>>] =
    useState<McpSubTab>("tools");

  const [tools, setTools]: [McpTool[], React.Dispatch<React.SetStateAction<McpTool[]>>] =
    useState<McpTool[]>([]);

  const [resources, setResources]: [McpResource[], React.Dispatch<React.SetStateAction<McpResource[]>>] =
    useState<McpResource[]>([]);

  const [prompts, setPrompts]: [McpPrompt[], React.Dispatch<React.SetStateAction<McpPrompt[]>>] =
    useState<McpPrompt[]>([]);

  const [serverInfo, setServerInfo]: [
    McpServerInfo | null,
    React.Dispatch<React.SetStateAction<McpServerInfo | null>>
  ] = useState<McpServerInfo | null>(null);

  const [isLoading, setIsLoading]: [boolean, React.Dispatch<React.SetStateAction<boolean>>] =
    useState<boolean>(false);

  const [searchQuery, setSearchQuery]: [string, React.Dispatch<React.SetStateAction<string>>] =
    useState<string>("");

  const [selectedTool, setSelectedTool]: [McpTool | null, React.Dispatch<React.SetStateAction<McpTool | null>>] =
    useState<McpTool | null>(null);

  const [toolInput, setToolInput]: [string, React.Dispatch<React.SetStateAction<string>>] =
    useState<string>("");

  const [isRunning, setIsRunning]: [boolean, React.Dispatch<React.SetStateAction<boolean>>] =
    useState<boolean>(false);

  const [callResults, setCallResults]: [McpCallResult[], React.Dispatch<React.SetStateAction<McpCallResult[]>>] =
    useState<McpCallResult[]>([]);

  const [expandedTools, setExpandedTools]: [Set<string>, React.Dispatch<React.SetStateAction<Set<string>>>] =
    useState<Set<string>>(new Set());

  // ── Fetch MCP data from server ─────────────────────────────────────────

  const fetchMcpData: () => Promise<void> = useCallback(async (): Promise<void> => {
    setIsLoading(true);
    try {
      // Attempt to fetch server info (MCP /info or compatible endpoint)
      const infoRes: Response = await fetch(`${endpoint}/info`, {
        signal: AbortSignal.timeout(2000),
      });
      if (infoRes.ok) {
        const info: McpServerInfo = await infoRes.json();
        setServerInfo(info);
      }

      // Attempt to fetch tools list
      const toolsRes: Response = await fetch(`${endpoint}/tools`, {
        signal: AbortSignal.timeout(2000),
      });
      if (toolsRes.ok) {
        const data: { tools?: McpTool[] } = await toolsRes.json();
        if (Array.isArray(data.tools) && data.tools.length > 0) {
          setTools(data.tools);
        } else {
          setTools(getSeedTools());
        }
      } else {
        setTools(getSeedTools());
      }

      // Attempt to fetch resources list
      const resRes: Response = await fetch(`${endpoint}/resources`, {
        signal: AbortSignal.timeout(2000),
      });
      if (resRes.ok) {
        const data: { resources?: McpResource[] } = await resRes.json();
        if (Array.isArray(data.resources) && data.resources.length > 0) {
          setResources(data.resources);
        } else {
          setResources(getSeedResources());
        }
      } else {
        setResources(getSeedResources());
      }

      // Attempt to fetch prompts list
      const promptsRes: Response = await fetch(`${endpoint}/prompts`, {
        signal: AbortSignal.timeout(2000),
      });
      if (promptsRes.ok) {
        const data: { prompts?: McpPrompt[] } = await promptsRes.json();
        if (Array.isArray(data.prompts) && data.prompts.length > 0) {
          setPrompts(data.prompts);
        } else {
          setPrompts(getSeedPrompts());
        }
      } else {
        setPrompts(getSeedPrompts());
      }
    } catch {
      // Offline — show seed data
      setTools(getSeedTools());
      setResources(getSeedResources());
      setPrompts(getSeedPrompts());
    } finally {
      setIsLoading(false);
    }
  }, [endpoint]);

  useEffect((): void => {
    void fetchMcpData();
  }, [fetchMcpData]);

  // ── Tool call execution ────────────────────────────────────────────────

  const handleRunTool: () => Promise<void> = async (): Promise<void> => {
    if (!selectedTool || isRunning) return;
    setIsRunning(true);
    const startMs: number = Date.now();
    try {
      let parsedInput: unknown = {};
      try {
        parsedInput = toolInput.trim() ? JSON.parse(toolInput) : {};
      } catch {
        parsedInput = { input: toolInput };
      }

      const res: Response = await fetch(`${endpoint}/tools/${encodeURIComponent(selectedTool.name)}/call`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ arguments: parsedInput }),
        signal: AbortSignal.timeout(10000),
      });
      const durationMs: number = Date.now() - startMs;
      if (res.ok) {
        const data: { content?: string; result?: string; output?: string } = await res.json();
        const output: string = data.content ?? data.result ?? data.output ?? JSON.stringify(data, null, 2);
        setCallResults((prev: McpCallResult[]): McpCallResult[] => [
          { toolName: selectedTool.name, input: toolInput, output, isError: false, durationMs },
          ...prev,
        ]);
      } else {
        const errorText: string = await res.text();
        setCallResults((prev: McpCallResult[]): McpCallResult[] => [
          {
            toolName: selectedTool.name,
            input: toolInput,
            output: `HTTP ${res.status}: ${errorText}`,
            isError: true,
            durationMs: Date.now() - startMs,
          },
          ...prev,
        ]);
      }
    } catch (err: unknown) {
      const msg: string = err instanceof Error ? err.message : "Tool call failed";
      setCallResults((prev: McpCallResult[]): McpCallResult[] => [
        {
          toolName: selectedTool.name,
          input: toolInput,
          output: msg,
          isError: true,
          durationMs: Date.now() - startMs,
        },
        ...prev,
      ]);
    } finally {
      setIsRunning(false);
    }
  };

  const handleToggleToolExpand: (toolName: string) => void = (toolName: string): void => {
    setExpandedTools((prev: Set<string>): Set<string> => {
      const next: Set<string> = new Set(prev);
      if (next.has(toolName)) {
        next.delete(toolName);
      } else {
        next.add(toolName);
      }
      return next;
    });
  };

  // ── Filtered data ──────────────────────────────────────────────────────

  const q: string = searchQuery.toLowerCase();

  const filteredTools: McpTool[] = tools.filter(
    (t: McpTool): boolean =>
      !q || t.name.toLowerCase().includes(q) || t.description.toLowerCase().includes(q)
  );

  const filteredResources: McpResource[] = resources.filter(
    (r: McpResource): boolean =>
      !q || r.name.toLowerCase().includes(q) || r.uri.toLowerCase().includes(q)
  );

  const filteredPrompts: McpPrompt[] = prompts.filter(
    (p: McpPrompt): boolean =>
      !q || p.name.toLowerCase().includes(q) || (p.description ?? "").toLowerCase().includes(q)
  );

  const MCP_TABS: Array<{ id: McpSubTab; icon: string; label: string }> = [
    { id: "tools", icon: "Wrench", label: "Tools" },
    { id: "resources", icon: "FileCode2", label: "Resources" },
    { id: "prompts", icon: "MessageSquare", label: "Prompts" },
    { id: "console", icon: "Terminal", label: "Console" },
  ];

  // ── Render ─────────────────────────────────────────────────────────────

  return (
    <div id="mcp-explorer-container" className="mcp-explorer-container">
      {/* ── Header: Server Info ── */}
      <div id="mcp-explorer-header" className="mcp-explorer-header">
        <div id="mcp-header-info" className="div-row gap-3 align-center">
          <div id="mcp-server-icon-box" className="mcp-server-icon-box">
            <IdeIcon name="Plug" size="md" color="var(--mcp-accent, #16a34a)" />
          </div>
          <div id="mcp-server-details" className="div-col">
            <span id="mcp-server-name" className="mcp-server-name">
              {serverInfo?.name ?? "MCP Server"}
            </span>
            <span id="mcp-server-meta" className="mcp-server-meta">
              {serverInfo ? `v${serverInfo.version} · Protocol ${serverInfo.protocolVersion}` : endpoint}
            </span>
          </div>

          <div id="mcp-transport-badge-wrap" className="div-row gap-2 align-center">
            <span id="mcp-transport-badge" className={`mcp-transport-badge mcp-transport-${transport}`}>
              {transport.toUpperCase()}
            </span>
            {isLoading && (
              <span id="mcp-loading-indicator" className="div-row gap-1 align-center text-xs theme-text-muted">
                <IdeIcon name="Loader" size="xs" />
                <span>Connecting…</span>
              </span>
            )}
          </div>
        </div>

        <div id="mcp-header-stats" className="div-row gap-3 align-center">
          <span id="mcp-stat-tools" className="mcp-stat-chip">
            <IdeIcon name="Wrench" size="xs" />
            <span>{tools.length} Tools</span>
          </span>
          <span id="mcp-stat-resources" className="mcp-stat-chip">
            <IdeIcon name="FileCode2" size="xs" />
            <span>{resources.length} Resources</span>
          </span>
          <span id="mcp-stat-prompts" className="mcp-stat-chip">
            <IdeIcon name="MessageSquare" size="xs" />
            <span>{prompts.length} Prompts</span>
          </span>
          <Button
            id="btn-mcp-refresh"
            variant="ghost"
            size="sm"
            onClick={(): void => void fetchMcpData()}
            title="Reload MCP server data"
            aria-label="Refresh MCP data"
          >
            <IdeIcon name="RefreshCw" size="xs" />
          </Button>
        </div>
      </div>

      {/* ── Tab Navigation ── */}
      <div id="mcp-tab-nav" className="mcp-tab-nav">
        {MCP_TABS.map((tab: { id: McpSubTab; icon: string; label: string }): React.ReactElement => (
          <button
            key={tab.id}
            id={`mcp-tab-${tab.id}`}
            type="button"
            role="tab"
            aria-selected={activeTab === tab.id}
            className={`mcp-tab-btn ${activeTab === tab.id ? "active" : ""}`}
            onClick={(): void => setActiveTab(tab.id)}
          >
            <IdeIcon
              name={tab.icon}
              size="xs"
              color={activeTab === tab.id ? "var(--mcp-accent, #16a34a)" : "currentColor"}
            />
            <span>{tab.label}</span>
          </button>
        ))}

        {/* Search */}
        <div id="mcp-tab-search-wrap" className="mcp-tab-search-wrap">
          <Input
            id="mcp-search-input"
            placeholder={`Search ${activeTab}…`}
            value={searchQuery}
            onChange={(e: React.ChangeEvent<HTMLInputElement>): void => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      {/* ── Tab Content ── */}
      <div id="mcp-tab-content" className="mcp-tab-content">

        {/* Tools Tab */}
        {activeTab === "tools" && (
          <div id="mcp-tools-panel" className="mcp-list-panel">
            {filteredTools.length === 0 ? (
              <div id="mcp-tools-empty" className="mcp-empty-state">
                <IdeIcon name="Wrench" size="xl" color="var(--text-muted)" />
                <span className="mcp-empty-label">No tools found</span>
              </div>
            ) : (
              filteredTools.map((tool: McpTool): React.ReactElement => {
                const isExpanded: boolean = expandedTools.has(tool.name);
                const isSelected: boolean = selectedTool?.name === tool.name;
                return (
                  <div
                    key={tool.name}
                    id={`mcp-tool-card-${tool.name}`}
                    className={`mcp-item-card ${isSelected ? "mcp-item-selected" : ""}`}
                  >
                    <div
                      id={`mcp-tool-header-${tool.name}`}
                      className="mcp-item-header"
                      onClick={(): void => handleToggleToolExpand(tool.name)}
                    >
                      <div id={`mcp-tool-title-group-${tool.name}`} className="div-row gap-2 align-center">
                        <IdeIcon name="Wrench" size="sm" color="var(--mcp-accent, #16a34a)" />
                        <span id={`mcp-tool-name-${tool.name}`} className="mcp-item-name">
                          {tool.name}
                        </span>
                      </div>
                      <div id={`mcp-tool-actions-${tool.name}`} className="div-row gap-2 align-center">
                        <Button
                          id={`btn-select-tool-${tool.name}`}
                          variant="primary"
                          size="sm"
                          onClick={(e: React.MouseEvent): void => {
                            e.stopPropagation();
                            setSelectedTool(tool);
                            setActiveTab("console");
                            setToolInput(
                              tool.inputSchema
                                ? JSON.stringify(
                                    Object.fromEntries(
                                      Object.keys(
                                        (tool.inputSchema as { properties?: Record<string, unknown> }).properties ?? {}
                                      ).map((k: string): [string, string] => [k, ""])
                                    ),
                                    null,
                                    2
                                  )
                                : ""
                            );
                          }}
                          aria-label={`Run ${tool.name}`}
                        >
                          <IdeIcon name="Play" size="xs" />
                          <span>Run</span>
                        </Button>
                        <IdeIcon
                          name={isExpanded ? "ChevronUp" : "ChevronDown"}
                          size="sm"
                          color="var(--text-muted)"
                        />
                      </div>
                    </div>

                    <p id={`mcp-tool-desc-${tool.name}`} className="mcp-item-desc">
                      {tool.description}
                    </p>

                    {isExpanded && tool.inputSchema && (
                      <div id={`mcp-tool-schema-${tool.name}`} className="mcp-schema-block">
                        <span className="mcp-schema-label">Input Schema</span>
                        <pre id={`mcp-tool-schema-pre-${tool.name}`} className="mcp-schema-pre">
                          {JSON.stringify(tool.inputSchema, null, 2)}
                        </pre>
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>
        )}

        {/* Resources Tab */}
        {activeTab === "resources" && (
          <div id="mcp-resources-panel" className="mcp-list-panel">
            {filteredResources.length === 0 ? (
              <div id="mcp-resources-empty" className="mcp-empty-state">
                <IdeIcon name="FileCode2" size="xl" color="var(--text-muted)" />
                <span className="mcp-empty-label">No resources found</span>
              </div>
            ) : (
              filteredResources.map((res: McpResource): React.ReactElement => (
                <div
                  key={res.uri}
                  id={`mcp-resource-card-${encodeURIComponent(res.uri)}`}
                  className="mcp-item-card"
                >
                  <div id={`mcp-resource-header-${res.name}`} className="mcp-item-header">
                    <div id={`mcp-resource-title-group-${res.name}`} className="div-row gap-2 align-center">
                      <IdeIcon
                        name={res.mimeType?.includes("json") ? "Braces" : "FileCode2"}
                        size="sm"
                        color="var(--primary, #2563eb)"
                      />
                      <div id={`mcp-resource-info-${res.name}`} className="div-col">
                        <span id={`mcp-resource-name-${res.name}`} className="mcp-item-name">
                          {res.name}
                        </span>
                        <span id={`mcp-resource-uri-${res.name}`} className="mcp-item-meta">
                          {res.uri}
                        </span>
                      </div>
                    </div>
                    {res.mimeType && (
                      <span id={`mcp-resource-mime-${res.name}`} className="mcp-mime-badge">
                        {res.mimeType}
                      </span>
                    )}
                  </div>
                  {res.description && (
                    <p id={`mcp-resource-desc-${res.name}`} className="mcp-item-desc">
                      {res.description}
                    </p>
                  )}
                </div>
              ))
            )}
          </div>
        )}

        {/* Prompts Tab */}
        {activeTab === "prompts" && (
          <div id="mcp-prompts-panel" className="mcp-list-panel">
            {filteredPrompts.length === 0 ? (
              <div id="mcp-prompts-empty" className="mcp-empty-state">
                <IdeIcon name="MessageSquare" size="xl" color="var(--text-muted)" />
                <span className="mcp-empty-label">No prompts found</span>
              </div>
            ) : (
              filteredPrompts.map((prompt: McpPrompt): React.ReactElement => (
                <div
                  key={prompt.name}
                  id={`mcp-prompt-card-${prompt.name}`}
                  className="mcp-item-card"
                >
                  <div id={`mcp-prompt-header-${prompt.name}`} className="mcp-item-header">
                    <div id={`mcp-prompt-title-group-${prompt.name}`} className="div-row gap-2 align-center">
                      <IdeIcon name="MessageSquare" size="sm" color="var(--purple-600, #9333ea)" />
                      <span id={`mcp-prompt-name-${prompt.name}`} className="mcp-item-name">
                        {prompt.name}
                      </span>
                    </div>
                    {prompt.arguments && prompt.arguments.length > 0 && (
                      <span id={`mcp-prompt-args-badge-${prompt.name}`} className="mcp-args-badge">
                        {prompt.arguments.length} arg{prompt.arguments.length !== 1 ? "s" : ""}
                      </span>
                    )}
                  </div>
                  {prompt.description && (
                    <p id={`mcp-prompt-desc-${prompt.name}`} className="mcp-item-desc">
                      {prompt.description}
                    </p>
                  )}
                  {prompt.arguments && prompt.arguments.length > 0 && (
                    <div id={`mcp-prompt-args-${prompt.name}`} className="mcp-args-list">
                      {prompt.arguments.map(
                        (arg: { name: string; description?: string; required?: boolean }): React.ReactElement => (
                          <div key={arg.name} id={`mcp-arg-${prompt.name}-${arg.name}`} className="mcp-arg-row">
                            <code id={`mcp-arg-code-${prompt.name}-${arg.name}`} className="mcp-arg-name">
                              {arg.name}
                            </code>
                            {arg.required && (
                              <span id={`mcp-arg-required-${prompt.name}-${arg.name}`} className="mcp-required-badge">
                                required
                              </span>
                            )}
                            {arg.description && (
                              <span id={`mcp-arg-desc-${prompt.name}-${arg.name}`} className="mcp-arg-desc">
                                {arg.description}
                              </span>
                            )}
                          </div>
                        )
                      )}
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        )}

        {/* Console Tab */}
        {activeTab === "console" && (
          <div id="mcp-console-panel" className="mcp-console-panel">
            {/* Tool selector + input */}
            <div id="mcp-console-input-section" className="mcp-console-input-section">
              <div id="mcp-console-tool-row" className="div-row gap-3 align-center">
                <div id="mcp-console-tool-select-wrap" className="div-col gap-1 flex-1">
                  <label id="lbl-mcp-tool-select" className="mcp-console-label" htmlFor="mcp-console-tool-select">
                    Tool
                  </label>
                  <select
                    id="mcp-console-tool-select"
                    className="mcp-console-select"
                    value={selectedTool?.name ?? ""}
                    onChange={(e: React.ChangeEvent<HTMLSelectElement>): void => {
                      const found: McpTool | undefined = tools.find(
                        (t: McpTool): boolean => t.name === e.target.value
                      );
                      setSelectedTool(found ?? null);
                      if (found?.inputSchema) {
                        setToolInput(
                          JSON.stringify(
                            Object.fromEntries(
                              Object.keys(
                                (found.inputSchema as { properties?: Record<string, unknown> }).properties ?? {}
                              ).map((k: string): [string, string] => [k, ""])
                            ),
                            null,
                            2
                          )
                        );
                      } else {
                        setToolInput("");
                      }
                    }}
                  >
                    <option value="">— Select a tool —</option>
                    {tools.map((t: McpTool): React.ReactElement => (
                      <option key={t.name} value={t.name}>
                        {t.name}
                      </option>
                    ))}
                  </select>
                </div>

                <Button
                  id="btn-mcp-run-tool"
                  variant="primary"
                  size="sm"
                  disabled={!selectedTool || isRunning}
                  onClick={(): void => void handleRunTool()}
                  aria-label="Run selected MCP tool"
                >
                  {isRunning ? (
                    <IdeIcon name="Loader" size="xs" />
                  ) : (
                    <IdeIcon name="Play" size="xs" />
                  )}
                  <span>{isRunning ? "Running…" : "Run Tool"}</span>
                </Button>

                <Button
                  id="btn-mcp-clear-results"
                  variant="ghost"
                  size="sm"
                  onClick={(): void => setCallResults([])}
                  aria-label="Clear tool call results"
                >
                  <IdeIcon name="Eraser" size="xs" />
                </Button>
              </div>

              {selectedTool && (
                <div id="mcp-console-tool-desc" className="mcp-console-tool-desc">
                  <IdeIcon name="Info" size="xs" color="var(--primary, #2563eb)" />
                  <span>{selectedTool.description}</span>
                </div>
              )}

              <div id="mcp-console-input-wrap" className="div-col gap-1">
                <label id="lbl-mcp-tool-input" className="mcp-console-label" htmlFor="mcp-tool-input-area">
                  Input (JSON)
                </label>
                <textarea
                  id="mcp-tool-input-area"
                  className="mcp-console-textarea"
                  placeholder='{ "path": "/data/file.txt" }'
                  value={toolInput}
                  rows={4}
                  onChange={(e: React.ChangeEvent<HTMLTextAreaElement>): void => setToolInput(e.target.value)}
                />
              </div>
            </div>

            {/* Results */}
            <div id="mcp-console-results" className="mcp-console-results">
              {callResults.length === 0 ? (
                <div id="mcp-console-empty" className="mcp-empty-state">
                  <IdeIcon name="Terminal" size="xl" color="var(--text-muted)" />
                  <span className="mcp-empty-label">Select a tool and run it — results appear here</span>
                </div>
              ) : (
                callResults.map((result: McpCallResult, idx: number): React.ReactElement => (
                  <div
                    key={`result-${idx}`}
                    id={`mcp-result-${idx}`}
                    className={`mcp-result-card ${result.isError ? "mcp-result-error" : "mcp-result-success"}`}
                  >
                    <div id={`mcp-result-header-${idx}`} className="mcp-result-header">
                      <div id={`mcp-result-title-${idx}`} className="div-row gap-2 align-center">
                        <IdeIcon
                          name={result.isError ? "AlertTriangle" : "CheckCircle"}
                          size="sm"
                          color={result.isError ? "var(--error, #dc2626)" : "var(--mcp-accent, #16a34a)"}
                        />
                        <code id={`mcp-result-tool-name-${idx}`} className="mcp-result-tool-name">
                          {result.toolName}
                        </code>
                      </div>
                      <span id={`mcp-result-duration-${idx}`} className="mcp-result-duration">
                        {result.durationMs}ms
                      </span>
                    </div>
                    <pre id={`mcp-result-output-${idx}`} className="mcp-result-output">
                      {result.output}
                    </pre>
                  </div>
                ))
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
