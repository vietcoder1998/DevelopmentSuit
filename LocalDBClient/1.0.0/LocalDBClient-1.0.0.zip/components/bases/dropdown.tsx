/**
 * Packages/Shared/components/Hub/bases/dropdown.tsx
 * ─────────────────────────────────────────────────────────────────────────────
 * 2-TEK Hub Kernel UI — Dropdown Menu Base Component
 *
 * Positioned dropdown menu with keyboard dismiss (Escape) and outside-click
 * close. Zero inline styles — fully CSS-class-based with theme token support.
 * ─────────────────────────────────────────────────────────────────────────────
 */
"use client";

import React, { useEffect, useId, useRef } from "react";
import { IdeIcon } from "./ide-icon";

export interface DropdownItemProps {
  id?: string;
  label: string;
  icon?: string;
  onClick?: () => void;
  disabled?: boolean;
  danger?: boolean;
  className?: string;
  testId?: string;
}

export const DropdownItem: React.FC<DropdownItemProps> = ({
  id,
  label,
  icon,
  onClick,
  disabled = false,
  danger = false,
  className = "",
  testId,
}) => {
  const generatedIdentifier: string = useId().replace(/:/g, "");
  const effectiveIdentifier: string = id || `hub-dropdown-item-${generatedIdentifier}`;

  const itemClasses: string = [
    "hub-dropdown-item",
    danger ? "hub-dropdown-item-danger" : "",
    disabled ? "hub-dropdown-item-disabled" : "",
    className,
  ]
    .filter(Boolean)
    .join(" ");

  return (
    <button
      id={effectiveIdentifier}
      type="button"
      className={itemClasses}
      onClick={disabled ? undefined : onClick}
      disabled={disabled}
      data-testid={testId || effectiveIdentifier}
    >
      {icon ? (
        <span id={`${effectiveIdentifier}-icon`} className="hub-dropdown-item-icon">
          <IdeIcon name={icon} size={13} />
        </span>
      ) : null}
      <span id={`${effectiveIdentifier}-label`} className="hub-dropdown-item-label">
        {label}
      </span>
    </button>
  );
};

export interface DropdownDividerProps {
  id?: string;
}

export const DropdownDivider: React.FC<DropdownDividerProps> = ({ id }) => {
  const generatedIdentifier: string = useId().replace(/:/g, "");
  return (
    <div
      id={id || `hub-dropdown-divider-${generatedIdentifier}`}
      className="hub-dropdown-divider"
    />
  );
};

export interface DropdownProps {
  id?: string;
  isOpen: boolean;
  onClose: () => void;
  trigger: React.ReactNode;
  children: React.ReactNode;
  align?: "left" | "right";
  className?: string;
  menuClassName?: string;
  testId?: string;
}

export const Dropdown: React.FC<DropdownProps> = ({
  id,
  isOpen,
  onClose,
  trigger,
  children,
  align = "left",
  className = "",
  menuClassName = "",
  testId,
}) => {
  const generatedIdentifier: string = useId().replace(/:/g, "");
  const effectiveIdentifier: string = id || `hub-dropdown-${generatedIdentifier}`;
  const wrapperRef: React.RefObject<HTMLDivElement | null> = useRef<HTMLDivElement | null>(null);

  useEffect((): (() => void) => {
    if (!isOpen) {
      return (): void => undefined;
    }

    const handleOutsideClick = (clickEvent: MouseEvent): void => {
      const targetNode: Node = clickEvent.target as Node;
      if (wrapperRef.current && !wrapperRef.current.contains(targetNode)) {
        onClose();
      }
    };

    const handleKeyDown = (keyboardEvent: KeyboardEvent): void => {
      if (keyboardEvent.key === "Escape") {
        onClose();
      }
    };

    document.addEventListener("mousedown", handleOutsideClick);
    document.addEventListener("keydown", handleKeyDown);

    return (): void => {
      document.removeEventListener("mousedown", handleOutsideClick);
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [isOpen, onClose]);

  const wrapperClasses: string = ["hub-dropdown-wrapper", className]
    .filter(Boolean)
    .join(" ");

  const menuClasses: string = [
    "hub-dropdown-menu",
    `hub-dropdown-align-${align}`,
    isOpen ? "hub-dropdown-menu-open" : "",
    menuClassName,
  ]
    .filter(Boolean)
    .join(" ");

  return (
    <div
      id={effectiveIdentifier}
      className={wrapperClasses}
      ref={wrapperRef}
      data-testid={testId || effectiveIdentifier}
    >
      <div id={`${effectiveIdentifier}-trigger`} className="hub-dropdown-trigger">
        {trigger}
      </div>
      {isOpen ? (
        <div
          id={`${effectiveIdentifier}-menu`}
          className={menuClasses}
          role="menu"
          aria-orientation="vertical"
        >
          {children}
        </div>
      ) : null}
    </div>
  );
};
