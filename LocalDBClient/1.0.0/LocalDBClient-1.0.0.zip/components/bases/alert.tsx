/**
 * Packages/Shared/components/Hub/bases/alert.tsx
 * ─────────────────────────────────────────────────────────────────────────────
 * 2-TEK Hub Kernel UI — Alert Banner Base Component
 *
 * Inline contextual feedback panel for errors, warnings, success, and info.
 * Distinct from Toast (which is floating + auto-dismiss). Alert is embedded
 * inside forms, modals, and content areas.
 * ─────────────────────────────────────────────────────────────────────────────
 */
"use client";

import React, { useId } from "react";
import { IdeIcon } from "./ide-icon";

export type AlertType = "error" | "warning" | "success" | "info";

export interface AlertProps {
  id?: string;
  type?: AlertType;
  title?: string;
  message: string;
  detail?: string;
  onClose?: () => void;
  className?: string;
  testId?: string;
}

const resolveAlertIconName = (alertType: AlertType): string => {
  switch (alertType) {
    case "error":
      return "AlertCircle";
    case "warning":
      return "AlertTriangle";
    case "success":
      return "CheckCircle2";
    case "info":
    default:
      return "Info";
  }
};

export const Alert: React.FC<AlertProps> = ({
  id,
  type = "info",
  title,
  message,
  detail,
  onClose,
  className = "",
  testId,
}) => {
  const generatedIdentifier: string = useId().replace(/:/g, "");
  const effectiveIdentifier: string = id || `hub-alert-${generatedIdentifier}`;
  const iconName: string = resolveAlertIconName(type);

  const containerClasses: string = [
    "hub-alert",
    `hub-alert-${type}`,
    className,
  ]
    .filter(Boolean)
    .join(" ");

  return (
    <div
      id={effectiveIdentifier}
      className={containerClasses}
      role="alert"
      data-testid={testId || effectiveIdentifier}
    >
      <div id={`${effectiveIdentifier}-icon`} className="hub-alert-icon">
        <IdeIcon name={iconName} size={14} />
      </div>
      <div id={`${effectiveIdentifier}-body`} className="hub-alert-body">
        {title ? (
          <div id={`${effectiveIdentifier}-title`} className="hub-alert-title">
            {title}
          </div>
        ) : null}
        <div id={`${effectiveIdentifier}-message`} className="hub-alert-message">
          {message}
        </div>
        {detail ? (
          <div id={`${effectiveIdentifier}-detail`} className="hub-alert-detail">
            {detail}
          </div>
        ) : null}
      </div>
      {onClose ? (
        <button
          id={`${effectiveIdentifier}-close-btn`}
          type="button"
          className="hub-alert-close"
          onClick={onClose}
          aria-label="Dismiss alert"
        >
          <IdeIcon name="X" size={12} />
        </button>
      ) : null}
    </div>
  );
};
