"use client";

import React, { useEffect, useId } from "react";
import { IdeIcon } from "./ide-icon";

export interface ModalProps {
  id?: string;
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  children: React.ReactNode;
  footer?: React.ReactNode;
  className?: string;
  testId?: string;
}

export const Modal: React.FC<ModalProps> = ({
  id,
  isOpen,
  onClose,
  title,
  children,
  footer,
  className = "",
  testId,
}) => {
  const generatedIdentifier: string = useId().replace(/:/g, "");
  const effectiveIdentifier: string = id || `hub-modal-${generatedIdentifier}`;

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape" && isOpen) {
        onClose();
      }
    };

    if (isOpen) {
      window.addEventListener("keydown", handleKeyDown);
      document.body.style.overflow = "hidden";
    }

    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      document.body.style.overflow = "";
    };
  }, [isOpen, onClose]);

  if (!isOpen) {
    return null;
  }

  const containerClasses: string = [
    "hub-modal-container",
    className,
  ].filter(Boolean).join(" ");

  return (
    <div
      id={`${effectiveIdentifier}-overlay`}
      className="hub-modal-overlay"
      onClick={onClose}
      data-testid={testId || effectiveIdentifier}
    >
      <div
        id={effectiveIdentifier}
        className={containerClasses}
        onClick={(clickEvent: React.MouseEvent<HTMLDivElement>) => clickEvent.stopPropagation()}
      >
        {title ? (
          <div id={`${effectiveIdentifier}-header`} className="hub-modal-header">
            <h3 id={`${effectiveIdentifier}-title`} className="hub-modal-title">
              {title}
            </h3>
            <button
              id={`${effectiveIdentifier}-close-button`}
              className="hub-modal-close-btn"
              onClick={onClose}
              aria-label="Close modal"
            >
              <IdeIcon name="X" size={16} />
            </button>
          </div>
        ) : null}
        <div id={`${effectiveIdentifier}-body`} className="hub-modal-body">
          {children}
        </div>
        {footer ? (
          <div id={`${effectiveIdentifier}-footer`} className="hub-modal-footer">
            {footer}
          </div>
        ) : null}
      </div>
    </div>
  );
};
