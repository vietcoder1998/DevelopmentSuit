"use client";

import React, { ElementType, forwardRef, useId } from "react";
import { Item, type ItemProps } from "./item";

export type ListVariant =
  | "default"
  | "grid"
  | "vertical"
  | "horizontal"
  | "row"
  | "col"
  | "cards";

export interface ListProps extends React.HTMLAttributes<HTMLDivElement> {
  readonly id?: string;
  readonly as?: ElementType;
  readonly variant?: ListVariant;
  readonly gap?: "none" | "xs" | "sm" | "md" | "lg" | number | string;
  readonly bordered?: boolean;
  readonly empty?: boolean;
  readonly emptyText?: string;
  readonly testId?: string;
}

interface ListComponent
  extends React.ForwardRefExoticComponent<
    ListProps & React.RefAttributes<HTMLDivElement>
  > {
  Item: typeof Item;
}

export const List = forwardRef<HTMLDivElement, ListProps>(
  (
    {
      as: Component = "div",
      variant = "default",
      gap,
      bordered = false,
      empty = false,
      emptyText,
      className = "",
      id,
      testId,
      children,
      ...restProps
    }: ListProps,
    forwardedReference: React.ForwardedRef<HTMLDivElement>
  ): React.ReactElement => {
    const generatedIdentifier: string = useId().replace(/:/g, "");
    const effectiveIdentifier: string =
      id || `hub-list-${variant}-${generatedIdentifier}`;

    const resolvedClasses: string[] = ["hub-base-list"];

    switch (variant) {
      case "grid":
      case "cards":
        resolvedClasses.push("hub-list-grid hub-apps-grid");
        break;
      case "horizontal":
      case "row":
        resolvedClasses.push("hub-list-horizontal div-row");
        break;
      case "vertical":
      case "col":
      case "default":
      default:
        resolvedClasses.push("hub-list-vertical div-col");
        break;
    }

    if (bordered) {
      resolvedClasses.push("theme-border");
    }
    if (className) {
      resolvedClasses.push(className);
    }

    const combinedClassName: string = resolvedClasses.join(" ");

    if (empty) {
      return (
        <Component
          ref={forwardedReference}
          id={effectiveIdentifier}
          className={`${combinedClassName} hub-list-empty`.trim()}
          data-testid={testId || effectiveIdentifier}
          role={Component === "ul" || Component === "ol" ? "list" : (restProps.role || "list")}
          {...restProps}
        >
          {emptyText ? (
            <div
              id={`${effectiveIdentifier}-empty-state`}
              className="hub-list-empty-state theme-text-muted"
            >
              {emptyText}
            </div>
          ) : (
            children
          )}
        </Component>
      );
    }

    return (
      <Component
        ref={forwardedReference}
        id={effectiveIdentifier}
        className={combinedClassName}
        data-testid={testId || effectiveIdentifier}
        role={Component === "ul" || Component === "ol" ? "list" : (restProps.role || "list")}
        {...restProps}
      >
        {children}
      </Component>
    );
  }
) as ListComponent;

List.displayName = "BaseList";
List.Item = Item;

export const HubList = List;
export { List as BaseList };
