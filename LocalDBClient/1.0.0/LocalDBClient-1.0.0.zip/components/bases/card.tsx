"use client";

import React, { useId } from "react";

export interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  id?: string;
  hoverable?: boolean;
  testId?: string;
}

export const Card: React.FC<CardProps> = ({
  id,
  hoverable = false,
  children,
  className = "",
  testId,
  ...restProps
}) => {
  const generatedIdentifier: string = useId().replace(/:/g, "");
  const effectiveIdentifier: string = id || `hub-card-${generatedIdentifier}`;

  const cardClasses: string = [
    "hub-card",
    hoverable ? "hub-card-hover" : "",
    className,
  ].filter(Boolean).join(" ");

  return (
    <div
      id={effectiveIdentifier}
      className={cardClasses}
      data-testid={testId || effectiveIdentifier}
      {...restProps}
    >
      {children}
    </div>
  );
};
