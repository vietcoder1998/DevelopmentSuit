"use client";

import React, { useId } from "react";

export type BadgeVariant =
  | "running"
  | "stopped"
  | "starting"
  | "building"
  | "error"
  | "success"
  | "danger"
  | "primary"
  | "secondary"
  | "warning";

export type BadgeSize = "xs" | "sm" | "md" | "lg";

export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  id?: string;
  variant?: BadgeVariant;
  size?: BadgeSize;
  showDot?: boolean;
  testId?: string;
}

export const Badge: React.FC<BadgeProps> = ({
  id,
  variant = "stopped",
  size = "md",
  showDot = true,
  children,
  className = "",
  testId,
  ...restProps
}) => {
  const generatedIdentifier: string = useId().replace(/:/g, "");
  const effectiveIdentifier: string = id || `hub-badge-${generatedIdentifier}`;

  const badgeClasses: string = [
    "hub-badge",
    `hub-badge-${variant}`,
    `hub-badge-${size}`,
    className,
  ].filter(Boolean).join(" ");

  return (
    <span
      id={effectiveIdentifier}
      className={badgeClasses}
      data-testid={testId || effectiveIdentifier}
      {...restProps}
    >
      {showDot ? <span className="hub-badge-dot" /> : null}
      {children}
    </span>
  );
};
