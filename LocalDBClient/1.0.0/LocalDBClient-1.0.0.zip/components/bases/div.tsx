"use client";

import React, { ElementType, forwardRef, useId } from "react";

export type DivVariant =
  | "default"
  | "row"
  | "col"
  | "center"
  | "between"
  | "grid"
  | "card"
  | "panel"
  | "divider"
  | "spacer"
  | "surface"
  | "muted";

export interface DivProps extends React.HTMLAttributes<HTMLDivElement> {
  as?: ElementType;
  variant?: DivVariant;
  align?: "start" | "center" | "end" | "stretch";
  justify?: "start" | "center" | "end" | "between" | "around";
  gap?: "none" | "xs" | "sm" | "md" | "lg" | number | string;
  padding?: "none" | "xs" | "sm" | "md" | "lg" | number | string;
  bordered?: boolean;
  centered?: boolean;
  fillHeight?: boolean;
}

export const Div = forwardRef<HTMLDivElement, DivProps>(
  (
    {
      as: Component = "div",
      variant = "default",
      align,
      justify,
      gap,
      padding,
      bordered = false,
      centered = false,
      fillHeight = false,
      className = "",
      id,
      children,
      ...restProps
    },
    forwardedReference
  ) => {
    const generatedIdentifier: string = useId().replace(/:/g, "");
    const effectiveIdentifier: string = id || `hub-div-${variant}-${generatedIdentifier}`;

    const resolvedClasses: string[] = [];

    switch (variant) {
      case "row":
        resolvedClasses.push("div-row");
        break;
      case "col":
        resolvedClasses.push("div-col");
        break;
      case "center":
        resolvedClasses.push("div-center");
        break;
      case "between":
        resolvedClasses.push("div-between");
        break;
      case "grid":
        resolvedClasses.push("div-grid");
        break;
      case "card":
        resolvedClasses.push("div-card theme-surface-card theme-border");
        break;
      case "panel":
        resolvedClasses.push("div-panel theme-surface theme-border");
        break;
      case "surface":
        resolvedClasses.push("theme-surface");
        break;
      case "muted":
        resolvedClasses.push("theme-surface-muted");
        break;
      default:
        break;
    }

    if (bordered && variant !== "card" && variant !== "panel") {
      resolvedClasses.push("theme-border");
    }
    if (centered && variant !== "center") {
      resolvedClasses.push("div-center");
    }
    if (fillHeight) {
      resolvedClasses.push("h-full");
    }

    if (className) {
      resolvedClasses.push(className);
    }

    const combinedClassName: string = resolvedClasses.join(" ");

    return (
      <Component
        ref={forwardedReference}
        id={effectiveIdentifier}
        className={combinedClassName || undefined}
        {...restProps}
      >
        {children}
      </Component>
    );
  }
);

Div.displayName = "BaseDiv";

export const DivRow = forwardRef<HTMLDivElement, Omit<DivProps, "variant">>(
  (props, ref) => <Div ref={ref} variant="row" {...props} />
);
DivRow.displayName = "BaseDivRow";

export const DivCol = forwardRef<HTMLDivElement, Omit<DivProps, "variant">>(
  (props, ref) => <Div ref={ref} variant="col" {...props} />
);
DivCol.displayName = "BaseDivCol";

export const DivCenter = forwardRef<HTMLDivElement, Omit<DivProps, "variant">>(
  (props, ref) => <Div ref={ref} variant="center" {...props} />
);
DivCenter.displayName = "BaseDivCenter";

export const DivBetween = forwardRef<HTMLDivElement, Omit<DivProps, "variant">>(
  (props, ref) => <Div ref={ref} variant="between" {...props} />
);
DivBetween.displayName = "BaseDivBetween";

export const DivGrid = forwardRef<HTMLDivElement, Omit<DivProps, "variant">>(
  (props, ref) => <Div ref={ref} variant="grid" {...props} />
);
DivGrid.displayName = "BaseDivGrid";

export const DivCard = forwardRef<HTMLDivElement, Omit<DivProps, "variant">>(
  (props, ref) => <Div ref={ref} variant="card" {...props} />
);
DivCard.displayName = "BaseDivCard";

export const DivPanel = forwardRef<HTMLDivElement, Omit<DivProps, "variant">>(
  (props, ref) => <Div ref={ref} variant="panel" {...props} />
);
DivPanel.displayName = "BaseDivPanel";

export { Div as BaseDiv };
