"use client";

import React, { useId } from "react";
import { IdeIcon } from "./ide-icon";

export type ToastType = "error" | "warning" | "success" | "info";

export interface ToastProps {
  id?: string;
  type?: ToastType;
  title?: string;
  message: string;
  detail?: string;
  onClose?: () => void;
  className?: string;
  testId?: string;
}

const resolveIconName: (toastType: ToastType) => string = (toastType: ToastType): string => {
  switch (toastType) {
    case "error":
      return "AlertCircle";
    case "warning":
      return "AlertTriangle";
    case "success":
      return "CheckCircle2";
    case "info":
    default:
      return "Info";
  }
};

export const Toast: React.FC<ToastProps> = ({
  id,
  type = "info",
  title,
  message,
  detail,
  onClose,
  className = "",
  testId,
}) => {
  const generatedIdentifier: string = useId().replace(/:/g, "");
  const effectiveIdentifier: string = id || `hub-toast-${generatedIdentifier}`;

  const iconName: string = resolveIconName(type);

  return (
    <div
      id={effectiveIdentifier}
      className={`hub-toast hub-toast-${type} ${className}`}
      data-testid={testId || effectiveIdentifier}
      role="alert"
    >
      <div id={`${effectiveIdentifier}-icon-container`} className="hub-toast-icon">
        <IdeIcon name={iconName} size={16} />
      </div>
      <div id={`${effectiveIdentifier}-body`} className="hub-toast-body">
        {title ? (
          <div id={`${effectiveIdentifier}-title`} className="hub-toast-title">
            {title}
          </div>
        ) : null}
        <div id={`${effectiveIdentifier}-message`} className="hub-toast-message">
          {message}
        </div>
        {detail ? (
          <div id={`${effectiveIdentifier}-detail`} className="hub-toast-detail">
            {detail}
          </div>
        ) : null}
      </div>
      {onClose ? (
        <button
          id={`${effectiveIdentifier}-close-btn`}
          type="button"
          className="hub-toast-close"
          onClick={onClose}
          aria-label="Close notification"
          data-testid={`${effectiveIdentifier}-close-btn`}
        >
          <IdeIcon name="X" size={14} />
        </button>
      ) : null}
    </div>
  );
};
