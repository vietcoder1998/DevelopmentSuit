"use client";

import React, { useId } from "react";
import { IdeIcon } from "./ide-icon";

export type InputSize = "xs" | "sm" | "md" | "lg" | number;

export interface InputProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, "size"> {
  id?: string;
  label?: string;
  icon?: string;
  error?: string;
  size?: InputSize;
  testId?: string;
}

export const Input: React.FC<InputProps> = ({
  id,
  label,
  icon,
  error,
  size,
  className = "",
  testId,
  ...restProps
}) => {
  const generatedIdentifier: string = useId().replace(/:/g, "");
  const effectiveIdentifier: string = id || `hub-input-${generatedIdentifier}`;

  const sizeClass: string = typeof size === "string" ? `hub-input-${size}` : "";

  const inputClasses: string = [
    "hub-input",
    sizeClass,
    icon ? "hub-input-has-icon" : "",
    error ? "hub-input-error" : "",
    className,
  ].filter(Boolean).join(" ");

  return (
    <div id={`${effectiveIdentifier}-wrapper`} className="hub-input-wrapper">
      {label ? (
        <label htmlFor={effectiveIdentifier} className="hub-input-label">
          {label}
        </label>
      ) : null}
      <div id={`${effectiveIdentifier}-container`} className="hub-input-container">
        {icon ? (
          <span className="hub-input-icon-left">
            <IdeIcon name={icon} size={16} />
          </span>
        ) : null}
        <input
          id={effectiveIdentifier}
          className={inputClasses}
          data-testid={testId || effectiveIdentifier}
          {...restProps}
        />
      </div>
      {error ? (
        <span id={`${effectiveIdentifier}-error`} className="hub-input-error-text">
          {error}
        </span>
      ) : null}
    </div>
  );
};
