"use client";

import React, { useId } from "react";
import { IdeIcon } from "./ide-icon";

export type ButtonVariant = "primary" | "secondary" | "outline" | "ghost" | "danger" | "success";
export type ButtonSize = "xs" | "sm" | "md" | "lg";

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  id?: string;
  variant?: ButtonVariant;
  size?: ButtonSize;
  icon?: string;
  iconPosition?: "left" | "right";
  isLoading?: boolean;
  testId?: string;
}

export const Button: React.FC<ButtonProps> = ({
  id,
  variant = "primary",
  size = "md",
  icon,
  iconPosition = "left",
  isLoading = false,
  children,
  className = "",
  disabled,
  testId,
  ...restProps
}) => {
  const generatedIdentifier: string = useId().replace(/:/g, "");
  const effectiveIdentifier: string = id || `hub-btn-${generatedIdentifier}`;

  const buttonClasses: string = [
    "hub-button",
    `hub-btn-${variant}`,
    `hub-btn-${size}`,
    className,
  ].filter(Boolean).join(" ");

  const iconPixelSize: number = size === "xs" ? 11 : size === "sm" ? 12 : size === "lg" ? 16 : 14;

  return (
    <button
      id={effectiveIdentifier}
      className={buttonClasses}
      disabled={disabled || isLoading}
      data-testid={testId || effectiveIdentifier}
      {...restProps}
    >
      {isLoading ? (
        <IdeIcon name="Loader2" size={iconPixelSize} className="hub-spin" />
      ) : icon && iconPosition === "left" ? (
        <IdeIcon name={icon} size={iconPixelSize} />
      ) : null}
      {children}
      {!isLoading && icon && iconPosition === "right" ? (
        <IdeIcon name={icon} size={iconPixelSize} />
      ) : null}
    </button>
  );
};
