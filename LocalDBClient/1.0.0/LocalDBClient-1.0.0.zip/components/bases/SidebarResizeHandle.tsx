"use client";

import React from "react";

export interface SidebarResizeHandleProps {
  readonly id: string;
  readonly isResizing: boolean;
  readonly sidebarWidth: number;
  readonly minWidth?: number;
  readonly maxWidth?: number;
  readonly onMouseDown: (e: React.MouseEvent) => void;
  readonly onTouchStart?: (e: React.TouchEvent) => void;
  readonly onDoubleClick: () => void;
  readonly onKeyDown: (e: React.KeyboardEvent) => void;
  readonly className?: string;
}

export const SidebarResizeHandle: React.FC<SidebarResizeHandleProps> = ({
  id,
  isResizing,
  sidebarWidth,
  minWidth = 180,
  maxWidth = 520,
  onMouseDown,
  onTouchStart,
  onDoubleClick,
  onKeyDown,
  className = "",
}) => {
  const activeClass: string = isResizing ? "is-resizing" : "";
  const combinedClass: string = `sidebar-resize-handle ${activeClass} ${className}`.trim();

  return (
    <div
      id={id}
      role="separator"
      aria-orientation="vertical"
      aria-label="Resize sidebar"
      aria-valuenow={sidebarWidth}
      aria-valuemin={minWidth}
      aria-valuemax={maxWidth}
      tabIndex={0}
      title="Drag to resize sidebar, double-click to reset"
      className={combinedClass}
      onMouseDown={onMouseDown}
      onTouchStart={onTouchStart}
      onDoubleClick={onDoubleClick}
      onKeyDown={onKeyDown}
    >
      <div id={`${id}-indicator`} className="sidebar-resize-handle-indicator" />
    </div>
  );
};
