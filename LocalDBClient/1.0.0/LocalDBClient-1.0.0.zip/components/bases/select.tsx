"use client";

import React, { forwardRef } from "react";

export type SelectSize = "xs" | "sm" | "md";
export type SelectVariant = "default" | "unstyled" | "outline" | "none";

export interface SelectOption {
  value: string;
  label: string;
  disabled?: boolean;
}

export interface SelectProps
  extends Omit<React.SelectHTMLAttributes<HTMLSelectElement>, "size"> {
  selectSize?: SelectSize;
  variant?: SelectVariant;
  options?: SelectOption[];
}

export const Select: React.ForwardRefExoticComponent<
  SelectProps & React.RefAttributes<HTMLSelectElement>
> = forwardRef<HTMLSelectElement, SelectProps>(
  (
    {
      selectSize = "md",
      variant = "default",
      options,
      className = "",
      children,
      ...rest
    }: SelectProps,
    forwardedReference: React.ForwardedRef<HTMLSelectElement>
  ): React.JSX.Element => {
    const isUnstyled: boolean = variant === "unstyled" || variant === "none";
    const variantClass: string =
      !isUnstyled && variant !== "default" ? `variant-${variant}` : "";
    const sizeClass: string =
      isUnstyled || selectSize === "md" ? "" : `size-${selectSize}`;
    const baseClass: string = isUnstyled ? "" : "base-select hub-form-select";
    const combinedClasses: string = [
      baseClass,
      variantClass,
      sizeClass,
      className,
    ]
      .filter(Boolean)
      .join(" ");

    return (
      <select ref={forwardedReference} className={combinedClasses} {...rest}>
        {options
          ? options.map((optionItem: SelectOption): React.JSX.Element => (
              <option
                key={optionItem.value}
                value={optionItem.value}
                disabled={optionItem.disabled}
                className="hub-select-option"
              >
                {optionItem.label}
              </option>
            ))
          : children}
      </select>
    );
  }
);

Select.displayName = "Select";
export { Select as BaseSelect };
