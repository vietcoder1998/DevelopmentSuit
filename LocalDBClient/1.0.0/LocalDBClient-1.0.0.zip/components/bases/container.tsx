"use client";

import React, { ElementType, forwardRef, useId } from "react";

export type ContainerVariant =
  | "default"
  | "surface"
  | "panel"
  | "card"
  | "muted"
  | "bordered"
  | "fluid";

export interface ContainerProps extends React.HTMLAttributes<HTMLElement> {
  as?: ElementType;
  variant?: ContainerVariant;
  bordered?: boolean;
  centered?: boolean;
  fillHeight?: boolean;
}

export const Container = forwardRef<HTMLElement, ContainerProps>(
  (
    {
      as: Component = "div",
      variant = "default",
      bordered = false,
      centered = false,
      fillHeight = false,
      className = "",
      id,
      children,
      ...restProps
    },
    forwardedReference
  ) => {
    const generatedIdentifier: string = useId().replace(/:/g, "");
    const effectiveIdentifier: string = id || `hub-container-${variant}-${generatedIdentifier}`;

    const resolvedClasses: string[] = ["hub-container"];

    switch (variant) {
      case "surface":
        resolvedClasses.push("theme-surface");
        break;
      case "muted":
        resolvedClasses.push("theme-surface-muted");
        break;
      case "card":
        resolvedClasses.push("theme-surface-card theme-border");
        break;
      case "panel":
        resolvedClasses.push("theme-surface theme-border");
        break;
      case "bordered":
        resolvedClasses.push("theme-border");
        break;
      case "fluid":
        resolvedClasses.push("w-full");
        break;
      default:
        break;
    }

    if (bordered && variant !== "card" && variant !== "panel" && variant !== "bordered") {
      resolvedClasses.push("theme-border");
    }
    if (centered) {
      resolvedClasses.push("div-center");
    }
    if (fillHeight) {
      resolvedClasses.push("h-full");
    }

    if (className) {
      resolvedClasses.push(className);
    }

    const combinedClassName: string = resolvedClasses.join(" ");

    return (
      <Component
        ref={forwardedReference}
        id={effectiveIdentifier}
        className={combinedClassName}
        {...restProps}
      >
        {children}
      </Component>
    );
  }
);

Container.displayName = "BaseContainer";

export { Container as BaseContainer };
