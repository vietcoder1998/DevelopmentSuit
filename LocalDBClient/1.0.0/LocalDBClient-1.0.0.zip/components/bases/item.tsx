"use client";

import React, { ElementType, forwardRef, useId } from "react";

export type ItemVariant =
  | "default"
  | "row"
  | "card"
  | "interactive"
  | "grid"
  | "list-item";

export interface ItemProps extends React.HTMLAttributes<HTMLDivElement> {
  readonly id?: string;
  readonly as?: ElementType;
  readonly variant?: ItemVariant;
  readonly selected?: boolean;
  readonly active?: boolean;
  readonly disabled?: boolean;
  readonly hoverable?: boolean;
  readonly bordered?: boolean;
  readonly testId?: string;
}

export const Item = forwardRef<HTMLDivElement, ItemProps>(
  (
    {
      as: Component = "div",
      variant = "default",
      selected = false,
      active = false,
      disabled = false,
      hoverable = true,
      bordered = false,
      className = "",
      id,
      testId,
      children,
      ...restProps
    }: ItemProps,
    forwardedReference: React.ForwardedRef<HTMLDivElement>
  ): React.ReactElement => {
    const generatedIdentifier: string = useId().replace(/:/g, "");
    const effectiveIdentifier: string =
      id || `hub-item-${variant}-${generatedIdentifier}`;

    const resolvedClasses: string[] = ["hub-base-item"];

    switch (variant) {
      case "row":
        resolvedClasses.push("hub-item-row");
        break;
      case "card":
        resolvedClasses.push("hub-item-card theme-surface-card theme-border");
        break;
      case "interactive":
        resolvedClasses.push("hub-item-interactive cursor-pointer");
        break;
      case "grid":
        resolvedClasses.push("hub-item-grid");
        break;
      case "list-item":
        resolvedClasses.push("hub-app-list-item");
        break;
      case "default":
      default:
        break;
    }

    if (hoverable) {
      resolvedClasses.push("hub-item-hover");
    }
    if (bordered && variant !== "card") {
      resolvedClasses.push("theme-border");
    }
    if (selected) {
      resolvedClasses.push("hub-item-selected selected card-selected");
    }
    if (active) {
      resolvedClasses.push("hub-item-active active card-active");
    }
    if (disabled) {
      resolvedClasses.push("hub-item-disabled opacity-50 pointer-events-none");
    }
    if (className) {
      resolvedClasses.push(className);
    }

    const combinedClassName: string = resolvedClasses.join(" ");

    return (
      <Component
        ref={forwardedReference}
        id={effectiveIdentifier}
        className={combinedClassName}
        data-testid={testId || effectiveIdentifier}
        data-selected={selected ? "true" : undefined}
        data-active={active ? "true" : undefined}
        data-disabled={disabled ? "true" : undefined}
        aria-selected={selected ? "true" : undefined}
        aria-disabled={disabled ? "true" : undefined}
        role={Component === "li" ? "listitem" : (restProps.role || "listitem")}
        {...restProps}
      >
        {children}
      </Component>
    );
  }
);

Item.displayName = "BaseItem";

export const ListItem = Item;
export const HubItem = Item;
export { Item as BaseItem };
