"use client";

import React, { useState, useEffect, useCallback, useRef } from "react";

export interface UseResizableSidebarOptions {
  readonly storageKey?: string;
  readonly defaultWidth?: number;
  readonly minWidth?: number;
  readonly maxWidth?: number;
}

export interface UseResizableSidebarResult {
  readonly sidebarWidth: number;
  readonly isResizing: boolean;
  readonly setSidebarWidth: React.Dispatch<React.SetStateAction<number>>;
  readonly startResizing: (e: React.MouseEvent | React.TouchEvent) => void;
  readonly handleKeyDown: (e: React.KeyboardEvent) => void;
  readonly resetWidth: () => void;
}

export const useResizableSidebar: (options?: UseResizableSidebarOptions) => UseResizableSidebarResult = (
  options: UseResizableSidebarOptions = {}
): UseResizableSidebarResult => {
  const storageKey: string = options.storageKey ?? "localdbclient_sidebar_width";
  const defaultWidth: number = options.defaultWidth ?? 240;
  const minWidth: number = options.minWidth ?? 180;
  const maxWidth: number = options.maxWidth ?? 520;

  const [sidebarWidth, setSidebarWidth]: [
    number,
    React.Dispatch<React.SetStateAction<number>>
  ] = useState<number>(defaultWidth);

  const [isResizing, setIsResizing]: [
    boolean,
    React.Dispatch<React.SetStateAction<boolean>>
  ] = useState<boolean>(false);

  const sidebarWidthRef: React.MutableRefObject<number> = useRef<number>(defaultWidth);

  // Synchronize ref with state
  useEffect((): void => {
    sidebarWidthRef.current = sidebarWidth;
  }, [sidebarWidth]);

  // Load persisted width on mount
  useEffect((): void => {
    try {
      if (typeof window !== "undefined" && window.localStorage && storageKey) {
        const saved: string | null = window.localStorage.getItem(storageKey);
        if (saved) {
          const parsed: number = parseInt(saved, 10);
          if (!isNaN(parsed) && parsed >= minWidth && parsed <= maxWidth) {
            setSidebarWidth(parsed);
            sidebarWidthRef.current = parsed;
          }
        }
      }
    } catch {
      // Ignore localStorage access restrictions in restricted runtimes
    }
  }, [storageKey, minWidth, maxWidth]);

  const persistWidth: (width: number) => void = useCallback(
    (width: number): void => {
      try {
        if (typeof window !== "undefined" && window.localStorage && storageKey) {
          window.localStorage.setItem(storageKey, String(width));
        }
      } catch {
        // Ignore localStorage errors
      }
    },
    [storageKey]
  );

  const resetWidth: () => void = useCallback((): void => {
    setSidebarWidth(defaultWidth);
    persistWidth(defaultWidth);
  }, [defaultWidth, persistWidth]);

  const startResizing: (e: React.MouseEvent | React.TouchEvent) => void = useCallback(
    (e: React.MouseEvent | React.TouchEvent): void => {
      e.preventDefault();
      setIsResizing(true);
    },
    []
  );

  const handleKeyDown: (e: React.KeyboardEvent) => void = useCallback(
    (e: React.KeyboardEvent): void => {
      const step: number = e.shiftKey ? 30 : 10;
      if (e.key === "ArrowLeft") {
        e.preventDefault();
        setSidebarWidth((prev: number): number => {
          const next: number = Math.max(prev - step, minWidth);
          persistWidth(next);
          return next;
        });
      } else if (e.key === "ArrowRight") {
        e.preventDefault();
        setSidebarWidth((prev: number): number => {
          const next: number = Math.min(prev + step, maxWidth);
          persistWidth(next);
          return next;
        });
      } else if (e.key === "Home") {
        e.preventDefault();
        setSidebarWidth(minWidth);
        persistWidth(minWidth);
      } else if (e.key === "End") {
        e.preventDefault();
        setSidebarWidth(maxWidth);
        persistWidth(maxWidth);
      } else if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        resetWidth();
      }
    },
    [minWidth, maxWidth, persistWidth, resetWidth]
  );

  useEffect((): (() => void) => {
    if (!isResizing) return (): void => {};

    const handleMouseMove: (e: MouseEvent) => void = (e: MouseEvent): void => {
      const clientX: number = e.clientX;
      const clamped: number = Math.min(Math.max(clientX, minWidth), maxWidth);
      setSidebarWidth(clamped);
      sidebarWidthRef.current = clamped;
    };

    const handleTouchMove: (e: TouchEvent) => void = (e: TouchEvent): void => {
      if (e.touches.length > 0) {
        const clientX: number = e.touches[0].clientX;
        const clamped: number = Math.min(Math.max(clientX, minWidth), maxWidth);
        setSidebarWidth(clamped);
        sidebarWidthRef.current = clamped;
      }
    };

    const handleEnd: () => void = (): void => {
      setIsResizing(false);
      persistWidth(sidebarWidthRef.current);
    };

    window.addEventListener("mousemove", handleMouseMove);
    window.addEventListener("mouseup", handleEnd);
    window.addEventListener("touchmove", handleTouchMove, { passive: true });
    window.addEventListener("touchend", handleEnd);

    if (typeof document !== "undefined" && document.body) {
      document.body.classList.add("sidebar-resizing-active");
    }

    return (): void => {
      window.removeEventListener("mousemove", handleMouseMove);
      window.removeEventListener("mouseup", handleEnd);
      window.removeEventListener("touchmove", handleTouchMove);
      window.removeEventListener("touchend", handleEnd);

      if (typeof document !== "undefined" && document.body) {
        document.body.classList.remove("sidebar-resizing-active");
      }
    };
  }, [isResizing, minWidth, maxWidth, persistWidth]);

  return {
    sidebarWidth,
    isResizing,
    setSidebarWidth,
    startResizing,
    handleKeyDown,
    resetWidth,
  };
};
