"use client";

import React, { ElementType, forwardRef, useId } from "react";

export interface TabProps extends React.HTMLAttributes<HTMLDivElement> {
  readonly id?: string;
  readonly as?: ElementType;
  readonly activeTab?: string;
  readonly onTabChange?: (tabKey: string) => void;
  readonly testId?: string;
  readonly className?: string;
  readonly children?: React.ReactNode;
}

export interface TabContentProps extends React.HTMLAttributes<HTMLDivElement> {
  readonly id?: string;
  readonly as?: ElementType;
  readonly activeTab?: string;
  readonly tabKey?: string;
  readonly testId?: string;
  readonly className?: string;
  readonly children?: React.ReactNode;
}

export interface TabTriggerProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  readonly id?: string;
  readonly tabKey: string;
  readonly active?: boolean;
  readonly icon?: string;
  readonly badge?: number | string;
  readonly testId?: string;
}

interface TabComponent
  extends React.ForwardRefExoticComponent<
    TabProps & React.RefAttributes<HTMLDivElement>
  > {
  Content: typeof TabContent;
}

export const TabContent = forwardRef<HTMLDivElement, TabContentProps>(
  (
    {
      as: Component = "div",
      activeTab,
      tabKey,
      className = "",
      id,
      testId,
      children,
      ...restProps
    }: TabContentProps,
    forwardedReference: React.ForwardedRef<HTMLDivElement>
  ): React.ReactElement | null => {
    const generatedIdentifier: string = useId().replace(/:/g, "");
    const effectiveIdentifier: string = id || `hub-tab-content-${generatedIdentifier}`;

    const resolvedClasses: string[] = ["hub-tab-content-base"];
    if (className) {
      resolvedClasses.push(className);
    }

    if (tabKey && activeTab && tabKey !== activeTab) {
      return null;
    }

    return (
      <Component
        ref={forwardedReference}
        id={effectiveIdentifier}
        className={resolvedClasses.join(" ")}
        data-testid={testId || effectiveIdentifier}
        role="tabpanel"
        {...restProps}
      >
        {children}
      </Component>
    );
  }
);

TabContent.displayName = "BaseTabContent";

export const Tab = forwardRef<HTMLDivElement, TabProps>(
  (
    {
      as: Component = "div",
      activeTab: _activeTab,
      onTabChange: _onTabChange,
      className = "",
      id,
      testId,
      children,
      ...restProps
    }: TabProps,
    forwardedReference: React.ForwardedRef<HTMLDivElement>
  ): React.ReactElement => {
    const generatedIdentifier: string = useId().replace(/:/g, "");
    const effectiveIdentifier: string = id || `hub-tabs-base-${generatedIdentifier}`;

    const resolvedClasses: string[] = ["hub-tab-base-container"];
    if (className) {
      resolvedClasses.push(className);
    }

    return (
      <Component
        ref={forwardedReference}
        id={effectiveIdentifier}
        className={resolvedClasses.join(" ")}
        data-testid={testId || effectiveIdentifier}
        {...restProps}
      >
        {children}
      </Component>
    );
  }
) as TabComponent;

Tab.displayName = "BaseTab";
Tab.Content = TabContent;

export const Tabs = Tab;
export { Tab as BaseTab, TabContent as BaseTabContent };
