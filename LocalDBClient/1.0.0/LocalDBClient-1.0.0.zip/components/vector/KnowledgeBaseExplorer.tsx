import React, { useState, useRef } from "react";
import { IdeIcon, Button, Input, Modal, Badge } from "../bases";
import { useSafeTranslations } from "../bases/use-safe-translations";

export interface KnowledgeDocItem {
  documentId: string;
  title: string;
  category: string;
  tags: string[];
  chunks: Array<{ chunkIndex: number; text: string; vectorId: string }>;
}

export interface KnowledgeBaseExplorerProps {
  readonly documents: KnowledgeDocItem[];
  readonly onUploadDoc: (data: {
    title: string;
    category: string;
    tags: string[];
    content: string;
  }) => Promise<void>;
}

export interface ParsedKnowledgeChunk {
  id: string;
  answer: string;
  question: string;
}

export function parseIdAnswerQuestionFormat(content: string): ParsedKnowledgeChunk[] {
  const trimmed: string = content.trim();
  if (!trimmed) return [];

  // 1. Try parsing JSON array: [{"id": "...", "answer": "...", "question": "..."}]
  if (trimmed.startsWith("[") && trimmed.endsWith("]")) {
    try {
      const parsed: unknown = JSON.parse(trimmed);
      if (Array.isArray(parsed)) {
        return parsed.map((item: Record<string, unknown>, idx: number): ParsedKnowledgeChunk => ({
          id: String(item.id ?? idx + 1),
          answer: String(item.answer ?? item.ans ?? item.content ?? ""),
          question: String(item.question ?? item.q ?? item.title ?? ""),
        }));
      }
    } catch {
      // Fall through to text-based parsing
    }
  }

  // 2. Line-by-line parsing
  const lines: string[] = trimmed
    .split(/\r?\n/)
    .map((l: string): string => l.trim())
    .filter((l: string): boolean => l.length > 0 && !l.startsWith("#"));

  const results: ParsedKnowledgeChunk[] = [];

  lines.forEach((line: string, idx: number): void => {
    // Format A: id - answer - question
    if (line.includes(" - ")) {
      const parts: string[] = line.split(" - ").map((p: string): string => p.trim());
      if (parts.length >= 3) {
        results.push({
          id: parts[0] || String(idx + 1),
          answer: parts[1] || "",
          question: parts.slice(2).join(" - ") || "",
        });
        return;
      } else if (parts.length === 2) {
        results.push({
          id: String(idx + 1),
          answer: parts[0],
          question: parts[1],
        });
        return;
      }
    }

    // Format B: Tab-separated (id \t answer \t question)
    if (line.includes("\t")) {
      const parts: string[] = line.split("\t").map((p: string): string => p.trim());
      if (parts.length >= 3) {
        results.push({
          id: parts[0] || String(idx + 1),
          answer: parts[1] || "",
          question: parts.slice(2).join("\t") || "",
        });
        return;
      } else if (parts.length === 2) {
        results.push({
          id: String(idx + 1),
          answer: parts[0],
          question: parts[1],
        });
        return;
      }
    }

    // Format C: Comma-separated (id, answer, question)
    if (line.includes(",")) {
      const parts: string[] = line
        .split(",")
        .map((p: string): string => p.trim().replace(/^["']|["']$/g, ""));
      if (parts.length >= 3) {
        results.push({
          id: parts[0] || String(idx + 1),
          answer: parts[1] || "",
          question: parts.slice(2).join(", ") || "",
        });
        return;
      }
    }

    // Format D: Hyphen without spaces (id-answer-question)
    const hyphenParts: string[] = line.split("-").map((p: string): string => p.trim());
    if (hyphenParts.length >= 3) {
      results.push({
        id: hyphenParts[0] || String(idx + 1),
        answer: hyphenParts[1] || "",
        question: hyphenParts.slice(2).join("-") || "",
      });
      return;
    }

    // Fallback: single chunk line
    results.push({
      id: String(idx + 1),
      answer: line,
      question: `Chunk #${idx + 1}`,
    });
  });

  return results;
}

export const KnowledgeBaseExplorer: React.FC<KnowledgeBaseExplorerProps> = ({
  documents = [],
  onUploadDoc,
}) => {
  const t: (key: string, fallback: string) => string = useSafeTranslations("vectorclient.kb");
  const fileInputRef: React.RefObject<HTMLInputElement | null> = useRef<HTMLInputElement>(null);

  const [isModalOpen, setIsModalOpen]: [
    boolean,
    React.Dispatch<React.SetStateAction<boolean>>
  ] = useState<boolean>(false);

  const [title, setTitle]: [
    string,
    React.Dispatch<React.SetStateAction<string>>
  ] = useState<string>("");

  const [category, setCategory]: [
    string,
    React.Dispatch<React.SetStateAction<string>>
  ] = useState<string>("general");

  const [rawContent, setRawContent]: [
    string,
    React.Dispatch<React.SetStateAction<string>>
  ] = useState<string>("");

  const [isDragging, setIsDragging]: [
    boolean,
    React.Dispatch<React.SetStateAction<boolean>>
  ] = useState<boolean>(false);

  const [isSubmitting, setIsSubmitting]: [
    boolean,
    React.Dispatch<React.SetStateAction<boolean>>
  ] = useState<boolean>(false);

  const [errorMessage, setErrorMessage]: [
    string | null,
    React.Dispatch<React.SetStateAction<string | null>>
  ] = useState<string | null>(null);

  const [searchFilter, setSearchFilter]: [
    string,
    React.Dispatch<React.SetStateAction<string>>
  ] = useState<string>("");

  const parsedChunks: ParsedKnowledgeChunk[] = React.useMemo((): ParsedKnowledgeChunk[] => {
    return parseIdAnswerQuestionFormat(rawContent);
  }, [rawContent]);

  const handleOpenFilePicker: () => void = (): void => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const handleProcessFile: (file: File) => Promise<void> = async (file: File): Promise<void> => {
    try {
      const text: string = await file.text();
      setRawContent(text);
      if (!title) {
        const cleanName: string = file.name.replace(/\.[^/.]+$/, "");
        setTitle(cleanName);
      }
      setErrorMessage(null);
    } catch {
      setErrorMessage("Failed to read the uploaded file.");
    }
  };

  const handleFileInputChange: (e: React.ChangeEvent<HTMLInputElement>) => void = (
    e: React.ChangeEvent<HTMLInputElement>
  ): void => {
    const file: File | undefined = e.target.files?.[0];
    if (file) {
      void handleProcessFile(file);
    }
  };

  const handleDragOver: (e: React.DragEvent<HTMLDivElement>) => void = (
    e: React.DragEvent<HTMLDivElement>
  ): void => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave: (e: React.DragEvent<HTMLDivElement>) => void = (
    e: React.DragEvent<HTMLDivElement>
  ): void => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDrop: (e: React.DragEvent<HTMLDivElement>) => void = (
    e: React.DragEvent<HTMLDivElement>
  ): void => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    const file: File | undefined = e.dataTransfer.files?.[0];
    if (file) {
      void handleProcessFile(file);
    }
  };

  const handleUploadSubmit: () => Promise<void> = async (): Promise<void> => {
    if (!title.trim()) {
      setErrorMessage("Please enter a document title.");
      return;
    }
    if (!rawContent.trim()) {
      setErrorMessage("Please provide document content or drop a file.");
      return;
    }

    setIsSubmitting(true);
    setErrorMessage(null);
    try {
      // Format content so each parsed chunk is cleanly delineated for vector embedding
      let contentToSend: string = rawContent.trim();
      if (parsedChunks.length > 0) {
        contentToSend = parsedChunks
          .map((c: ParsedKnowledgeChunk): string => `[${c.id}] Q: ${c.question}\nA: ${c.answer}`)
          .join("\n\n");
      }

      if (onUploadDoc) {
        await onUploadDoc({
          title: title.trim(),
          category: category.trim() || "general",
          tags: [category.trim() || "general"],
          content: contentToSend,
        });
      }

      setTitle("");
      setRawContent("");
      setIsModalOpen(false);
    } catch (err: unknown) {
      setErrorMessage(err instanceof Error ? err.message : "Failed to vectorize document");
    } finally {
      setIsSubmitting(false);
    }
  };

  const filteredDocuments: KnowledgeDocItem[] = documents.filter(
    (doc: KnowledgeDocItem): boolean =>
      doc.title.toLowerCase().includes(searchFilter.toLowerCase()) ||
      doc.category.toLowerCase().includes(searchFilter.toLowerCase()) ||
      doc.documentId.toLowerCase().includes(searchFilter.toLowerCase())
  );

  return (
    <div id="vector-kb-explorer-container" className="vector-panel-container">
      {/* ── Main Knowledge Base List Card ── */}
      <div id="vector-kb-list-card" className="vector-card-section">
        <div id="vector-kb-list-header" className="div-row gap-2 items-center justify-between">
          <div id="vector-kb-list-title-group" className="div-row gap-2 items-center">
            <IdeIcon name="BookOpen" size="sm" color="var(--primary, #2563eb)" />
            <span id="vector-kb-list-title" className="font-semibold text-sm theme-text">
              {t("listTitle", "Knowledge Base Documents")}
            </span>
            <span id="badge-kb-docs-count" className="system-nav-badge">
              {documents.length} docs
            </span>
          </div>

          <div id="vector-kb-list-actions" className="div-row gap-2 items-center">
            <div id="vector-kb-search-wrap" className="w-200">
              <Input
                id="input-kb-search-docs"
                size="sm"
                placeholder={t("searchPlaceholder", "Search documents...")}
                value={searchFilter}
                onChange={(e: React.ChangeEvent<HTMLInputElement>): void => setSearchFilter(e.target.value)}
              />
            </div>

            <Button
              id="btn-open-kb-upload-modal"
              variant="primary"
              size="sm"
              onClick={(): void => {
                setIsModalOpen(true);
                setErrorMessage(null);
              }}
              title="Add document to knowledge base via modal upload or drag-and-drop"
              aria-label="Upload Document"
            >
              <IdeIcon name="UploadCloud" size="xs" className="mr-1" />
              <span>Add Document / Drop File</span>
            </Button>
          </div>
        </div>

        <table id="vector-kb-table" className="vector-table">
          <thead>
            <tr id="vector-kb-th-row">
              <th id="th-kb-title">{t("thTitle", "Title")}</th>
              <th id="th-kb-cat">{t("thCategory", "Category")}</th>
              <th id="th-kb-chunks">{t("thChunks", "Chunks Vectorized")}</th>
              <th id="th-kb-id">{t("thDocId", "Document ID")}</th>
            </tr>
          </thead>
          <tbody id="vector-kb-body">
            {filteredDocuments.length === 0 ? (
              <tr id="tr-kb-empty">
                <td colSpan={4} id="td-kb-empty" className="text-center text-muted py-6">
                  <div id="div-kb-empty-inner" className="div-col gap-2 items-center">
                    <IdeIcon name="FileQuestion" size="lg" color="var(--text-muted, #94a3b8)" />
                    <span className="text-xs theme-text-muted">
                      {documents.length === 0
                        ? t("noDocs", "No documents in knowledge base yet. Click 'Add Document / Drop File' to upload.")
                        : "No matching documents found."}
                    </span>
                  </div>
                </td>
              </tr>
            ) : (
              filteredDocuments.map((doc: KnowledgeDocItem): React.ReactElement => (
                <tr id={`tr-kb-doc-${doc.documentId}`} key={doc.documentId}>
                  <td id={`td-kb-title-${doc.documentId}`} className="font-medium">
                    <div id={`div-kb-title-row-${doc.documentId}`} className="div-row gap-2 items-center">
                      <IdeIcon name="FileText" size="xs" color="var(--primary, #2563eb)" />
                      <span>{doc.title}</span>
                    </div>
                  </td>
                  <td id={`td-kb-cat-${doc.documentId}`}>
                    <Badge variant="secondary" size="xs">
                      {doc.category}
                    </Badge>
                  </td>
                  <td id={`td-kb-chunks-${doc.documentId}`}>
                    <span className="font-semibold text-xs">{doc.chunks.length} chunks</span>
                  </td>
                  <td id={`td-kb-id-${doc.documentId}`} className="text-muted text-xs font-mono">
                    {doc.documentId}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* ── Modal: Add Knowledge Base Document for Vector Chunking ── */}
      {isModalOpen && (
        <Modal
          id="modal-upload-knowledge-base"
          isOpen={isModalOpen}
          onClose={(): void => {
            if (!isSubmitting) {
              setIsModalOpen(false);
            }
          }}
          title={t("modalTitle", "Add Knowledge Base Document for Vector Chunking")}
          footer={
            <div id="kb-modal-footer-actions" className="div-row gap-2 justify-end w-full">
              <Button
                id="btn-cancel-kb-modal"
                variant="secondary"
                size="sm"
                onClick={(): void => setIsModalOpen(false)}
                disabled={isSubmitting}
              >
                <span>Cancel</span>
              </Button>
              <Button
                id="btn-submit-kb-modal"
                variant="primary"
                size="sm"
                onClick={handleUploadSubmit}
                disabled={isSubmitting || !title.trim() || !rawContent.trim()}
              >
                <IdeIcon name="Check" size="xs" className="mr-1" />
                <span>{isSubmitting ? "Vectorizing…" : "Chunk & Vectorize Document"}</span>
              </Button>
            </div>
          }
        >
          <div id="kb-modal-body-container" className="div-col gap-3 p-1">
            {errorMessage && (
              <div id="kb-modal-error-alert" className="p-2 text-xs rounded bg-red-50 text-red-600 border border-red-200">
                {errorMessage}
              </div>
            )}

            {/* Drag and Drop Zone */}
            <div
              id="kb-drag-drop-zone"
              className={`stitch-kb-dropzone ${isDragging ? "dragging" : ""}`}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              onClick={handleOpenFilePicker}
              role="button"
              tabIndex={0}
              onKeyDown={(e: React.KeyboardEvent): void => {
                if (e.key === "Enter" || e.key === " ") {
                  handleOpenFilePicker();
                }
              }}
              title="Click or drag files here"
              aria-label="Drag and drop file upload zone"
            >
              <input
                ref={fileInputRef}
                id="kb-dropzone-file-input"
                type="file"
                accept=".txt,.csv,.tsv,.json,.md"
                className="stitch-file-input-hidden"
                onChange={handleFileInputChange}
              />
              <IdeIcon name="UploadCloud" size="lg" className="stitch-kb-dropzone-icon" />
              <div id="kb-dropzone-texts" className="div-col items-center">
                <span id="kb-dropzone-title" className="text-xs font-semibold theme-text">
                  Drag & drop your file here, or click to browse
                </span>
                <span id="kb-dropzone-format-hint" className="text-2xs theme-text-muted mt-1">
                  Format: <code className="font-mono">id - answer - question</code> (.txt, .csv, .tsv, .json)
                </span>
              </div>
            </div>

            {/* Document Title & Category */}
            <div id="kb-modal-meta-row" className="div-row gap-3">
              <div id="kb-modal-title-col" className="flex-1 div-col gap-1">
                <label id="lbl-kb-modal-title" className="text-xs font-medium theme-text">
                  Document Title
                </label>
                <Input
                  id="kb-modal-title-input"
                  size="sm"
                  placeholder="e.g. Customer Support FAQ"
                  value={title}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>): void => setTitle(e.target.value)}
                />
              </div>

              <div id="kb-modal-cat-col" className="w-160 div-col gap-1">
                <label id="lbl-kb-modal-cat" className="text-xs font-medium theme-text">
                  Category
                </label>
                <Input
                  id="kb-modal-category-input"
                  size="sm"
                  placeholder="e.g. faq, guides"
                  value={category}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>): void => setCategory(e.target.value)}
                />
              </div>
            </div>

            {/* Direct Content Editor */}
            <div id="kb-modal-content-col" className="div-col gap-1">
              <div id="kb-modal-content-label-row" className="div-row justify-between items-center">
                <label id="lbl-kb-modal-content" className="text-xs font-medium theme-text">
                  Content (Format: <code className="font-mono">id - answer - question</code>)
                </label>
                {parsedChunks.length > 0 && (
                  <span id="badge-kb-chunks-parsed" className="text-2xs font-semibold theme-text-muted">
                    {parsedChunks.length} chunks detected
                  </span>
                )}
              </div>
              <textarea
                id="kb-modal-content-textarea"
                rows={5}
                className="w-full text-xs font-mono p-2 rounded border border-border bg-surface theme-text"
                placeholder="1 - 2-TEK LocalDB is an offline-first SQL database. - What is 2-TEK LocalDB?&#10;2 - Run npm run dev:localsqlserver to start the server. - How to start LocalSQLServer?"
                value={rawContent}
                onChange={(e: React.ChangeEvent<HTMLTextAreaElement>): void => setRawContent(e.target.value)}
              />
            </div>

            {/* Live Parsed Chunks Preview */}
            {parsedChunks.length > 0 && (
              <div id="kb-parsed-chunks-preview-col" className="div-col gap-1">
                <span id="lbl-kb-preview" className="text-xs font-semibold theme-text-muted">
                  Vector Chunks Preview ({parsedChunks.length})
                </span>
                <div id="kb-parsed-chunks-preview" className="stitch-kb-preview-card">
                  {parsedChunks.slice(0, 5).map((chunk: ParsedKnowledgeChunk, idx: number): React.ReactElement => (
                    <div key={idx} id={`kb-chunk-preview-row-${idx}`} className="stitch-kb-chunk-row">
                      <span className="stitch-kb-chunk-id">{chunk.id}</span>
                      <div id={`kb-chunk-preview-text-${idx}`} className="div-col gap-0.5 flex-1 overflow-hidden">
                        <span className="text-xs font-medium theme-text truncate">
                          Q: {chunk.question}
                        </span>
                        <span className="text-2xs theme-text-muted truncate">
                          A: {chunk.answer}
                        </span>
                      </div>
                    </div>
                  ))}
                  {parsedChunks.length > 5 && (
                    <div id="kb-preview-more-hint" className="text-center text-2xs theme-text-muted py-1">
                      + {parsedChunks.length - 5} more chunks
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </Modal>
      )}
    </div>
  );
};
