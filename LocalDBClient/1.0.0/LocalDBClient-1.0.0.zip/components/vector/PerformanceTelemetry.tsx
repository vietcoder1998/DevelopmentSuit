import React from "react";
import { IdeIcon } from "../bases/ide-icon";
import { Button } from "../bases/button";
import { useSafeTranslations } from "../bases/use-safe-translations";

export interface TelemetryData {
  uptimeSeconds: number;
  totalQueries: number;
  totalInserts: number;
  collectionsCount: number;
  totalVectorsCount: number;
  totalConversations: number;
  totalKnowledgeDocs: number;
  averageSearchLatencyMs: number;
  memoryHeapUsedBytes: number;
}

export interface PerformanceTelemetryProps {
  readonly telemetry: TelemetryData | null;
  readonly onRefresh: () => void;
}

export const PerformanceTelemetry: React.FC<PerformanceTelemetryProps> = ({
  telemetry,
  onRefresh,
}) => {
  const t = useSafeTranslations("vectorclient.telemetry");

  const formatBytes = (bytes: number): string => {
    if (!bytes) return "0 MB";
    const mb: number = Number((bytes / (1024 * 1024)).toFixed(1));
    return `${mb} MB`;
  };

  const formatUptime = (sec: number): string => {
    if (!sec) return "0s";
    const m: number = Math.floor(sec / 60);
    const s: number = sec % 60;
    return `${m}m ${s}s`;
  };

  return (
    <div id="vector-telemetry-container" className="vector-panel-container">
      <div id="vector-telemetry-card-section" className="vector-card-section">
        <div id="vector-telemetry-header" className="div-row justify-between align-center">
          <div id="vector-telemetry-title-group" className="div-row gap-2 align-center">
            <IdeIcon name="Activity" size="sm" color="var(--primary, #6938ef)" />
            <span id="vector-telemetry-title" className="font-semibold text-sm">
              {t("title", "LocalVectorServer Real-Time Telemetry & Performance")}
            </span>
          </div>
          <Button
            id="vector-telemetry-refresh-btn"
            variant="secondary"
            size="sm"
            onClick={onRefresh}
          >
            <IdeIcon name="RefreshCw" size="sm" />
            <span id="vector-telemetry-refresh-label">{t("refreshBtn", "Refresh Metrics")}</span>
          </Button>
        </div>

        <div id="vector-telemetry-grid" className="telemetry-grid">
          <div id="card-metric-queries" className="telemetry-card">
            <span id="lbl-total-queries" className="telemetry-label">{t("totalQueries", "Total Vector Queries")}</span>
            <span id="val-total-queries" className="telemetry-value">{telemetry?.totalQueries ?? 0}</span>
          </div>

          <div id="card-metric-inserts" className="telemetry-card">
            <span id="lbl-total-inserts" className="telemetry-label">{t("totalInserts", "Vectors Inserted")}</span>
            <span id="val-total-inserts" className="telemetry-value">{telemetry?.totalInserts ?? 0}</span>
          </div>

          <div id="card-metric-total-vectors" className="telemetry-card">
            <span id="lbl-total-vectors" className="telemetry-label">{t("totalVectors", "Total Vectors Indexed")}</span>
            <span id="val-total-vectors" className="telemetry-value">{telemetry?.totalVectorsCount ?? 0}</span>
          </div>

          <div id="card-metric-latency" className="telemetry-card">
            <span id="lbl-avg-latency" className="telemetry-label">{t("avgLatency", "Avg Search Latency")}</span>
            <span id="val-avg-latency" className="telemetry-value">{telemetry?.averageSearchLatencyMs ?? 0} ms</span>
          </div>

          <div id="card-metric-collections" className="telemetry-card">
            <span id="lbl-collections" className="telemetry-label">{t("collections", "Active Collections")}</span>
            <span id="val-collections" className="telemetry-value">{telemetry?.collectionsCount ?? 0}</span>
          </div>

          <div id="card-metric-conversations" className="telemetry-card">
            <span id="lbl-conversations" className="telemetry-label">{t("conversations", "Conversations Stored")}</span>
            <span id="val-conversations" className="telemetry-value">{telemetry?.totalConversations ?? 0}</span>
          </div>

          <div id="card-metric-knowledge" className="telemetry-card">
            <span id="lbl-knowledge" className="telemetry-label">{t("knowledge", "Knowledge Documents")}</span>
            <span id="val-knowledge" className="telemetry-value">{telemetry?.totalKnowledgeDocs ?? 0}</span>
          </div>

          <div id="card-metric-memory" className="telemetry-card">
            <span id="lbl-memory" className="telemetry-label">{t("heapMemory", "Node.js Heap Memory")}</span>
            <span id="val-memory" className="telemetry-value">{formatBytes(telemetry?.memoryHeapUsedBytes ?? 0)}</span>
          </div>

          <div id="card-metric-uptime" className="telemetry-card">
            <span id="lbl-uptime" className="telemetry-label">{t("uptime", "Server Uptime")}</span>
            <span id="val-uptime" className="telemetry-value">{formatUptime(telemetry?.uptimeSeconds ?? 0)}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
