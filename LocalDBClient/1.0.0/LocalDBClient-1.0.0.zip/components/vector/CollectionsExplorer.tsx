import React, { useState, useEffect, useCallback } from "react";
import { IdeIcon } from "../bases/ide-icon";
import { Button } from "../bases/button";
import { Input } from "../bases/input";
import { Modal } from "../bases/modal";
import { useSafeTranslations } from "../bases/use-safe-translations";
import { TableDetailModal } from "./TableDetailModal";

export interface CollectionItem {
  name: string;
  dimension: number;
  metric: string;
  vectorCount: number;
  createdAt: number;
}

export interface VectorTextRow {
  id: string;
  text: string;
  metadata?: Record<string, string | number | boolean | null>;
  values?: number[];
  createdAt?: number;
}

export interface CollectionsExplorerProps {
  readonly collections: CollectionItem[];
  readonly activeCollection: string;
  readonly endpoint?: string;
  readonly onSelectCollection: (name: string) => void;
  readonly onCreateCollection: (name: string, dimension: number, metric: string) => Promise<void>;
  readonly onSelectTableDetail?: (collection: CollectionItem) => void;
  readonly isCreateModalOpen?: boolean;
  readonly onOpenCreateModal?: () => void;
  readonly onCloseCreateModal?: () => void;
}

export function getDefaultTextRowsForCollection(collectionName: string): VectorTextRow[] {
  if (collectionName === "conversations_vectors") {
    return [
      {
        id: "vec-conv-001-turn-0",
        text: "Can you explain how HNSW vector indexing works in local databases?",
        metadata: {
          conversationId: "conv-seed-01",
          title: "HNSW Vector Indexing",
          role: "user",
          turnIndex: 0,
        },
        values: [0.082, -0.145, 0.432, 0.019],
        createdAt: 1774920000000,
      },
      {
        id: "vec-conv-001-turn-1",
        text: "HNSW builds hierarchical graphs with logarithmic search complexity for nearest neighbor queries.",
        metadata: {
          conversationId: "conv-seed-01",
          title: "HNSW Vector Indexing",
          role: "assistant",
          turnIndex: 1,
        },
        values: [0.114, -0.098, 0.387, 0.055],
        createdAt: 1774920002000,
      },
      {
        id: "vec-conv-002-turn-0",
        text: "How does flat indexing compare to IVF and graph-based vector search?",
        metadata: {
          conversationId: "conv-seed-02",
          title: "Vector Search Algorithms",
          role: "user",
          turnIndex: 0,
        },
        values: [0.045, -0.211, 0.512, -0.034],
        createdAt: 1774920010000,
      },
      {
        id: "vec-conv-002-turn-1",
        text: "Flat indexing performs exhaustive search across all vectors for 100% recall, while IVF partitions vector space for faster queries.",
        metadata: {
          conversationId: "conv-seed-02",
          title: "Vector Search Algorithms",
          role: "assistant",
          turnIndex: 1,
        },
        values: [0.071, -0.183, 0.49, -0.012],
        createdAt: 1774920015000,
      },
    ];
  }

  if (collectionName === "knowledge_vectors") {
    return [
      {
        id: "vec-kb-001-chunk-0",
        text: "Vector databases index high-dimensional embeddings for approximate nearest neighbor search.",
        metadata: {
          documentId: "kb-seed-01",
          title: "Vector Architecture",
          category: "architecture",
          chunkIndex: 0,
        },
        values: [0.124, 0.056, -0.291, 0.334],
        createdAt: 1774920000000,
      },
      {
        id: "vec-kb-001-chunk-1",
        text: "Cosine similarity measures the orientation between vectors to evaluate semantic similarity.",
        metadata: {
          documentId: "kb-seed-01",
          title: "Vector Architecture",
          category: "metrics",
          chunkIndex: 1,
        },
        values: [0.095, 0.041, -0.264, 0.312],
        createdAt: 1774920002000,
      },
      {
        id: "vec-kb-002-chunk-0",
        text: "Scalar quantization (SQ8) and Product Quantization (PQ) reduce memory footprint while preserving retrieval precision.",
        metadata: {
          documentId: "kb-seed-02",
          title: "Embedding Compression",
          category: "quantization",
          chunkIndex: 0,
        },
        values: [0.21, -0.012, 0.178, -0.412],
        createdAt: 1774920020000,
      },
    ];
  }

  return [
    {
      id: `vec-${collectionName}-001`,
      text: `Initial seed embedding for general semantic similarity search in ${collectionName}.`,
      metadata: {
        category: "general",
        title: `${collectionName} Seed`,
      },
      values: [0.012, 0.345, -0.122, 0.098],
      createdAt: 1774920000000,
    },
    {
      id: `vec-${collectionName}-002`,
      text: `System telemetry and high-dimensional clustering sample across node endpoints for ${collectionName}.`,
      metadata: {
        category: "benchmark",
        title: `${collectionName} Benchmark`,
      },
      values: [0.034, 0.312, -0.105, 0.115],
      createdAt: 1774920005000,
    },
  ];
}

export const CollectionsExplorer: React.FC<CollectionsExplorerProps> = ({
  collections,
  activeCollection,
  endpoint,
  onSelectCollection,
  onCreateCollection,
  onSelectTableDetail,
  isCreateModalOpen: isCreateModalOpenProp,
  onOpenCreateModal,
  onCloseCreateModal,
}) => {
  const t: (key: string, fallback: string) => string = useSafeTranslations("vectorclient.collections");
  const [internalCreateModalOpen, setInternalCreateModalOpen]: [
    boolean,
    React.Dispatch<React.SetStateAction<boolean>>
  ] = useState<boolean>(false);
  const [newColName, setNewColName]: [string, React.Dispatch<React.SetStateAction<string>>] = useState<string>("");
  const [dimension, setDimension]: [number, React.Dispatch<React.SetStateAction<number>>] = useState<number>(128);
  const [metric, setMetric]: [string, React.Dispatch<React.SetStateAction<string>>] = useState<string>("cosine");
  const [isSubmitting, setIsSubmitting]: [boolean, React.Dispatch<React.SetStateAction<boolean>>] = useState<boolean>(false);
  const [errorMessage, setErrorMessage]: [
    string | null,
    React.Dispatch<React.SetStateAction<string | null>>
  ] = useState<string | null>(null);
  const [detailCollection, setDetailCollection]: [
    CollectionItem | null,
    React.Dispatch<React.SetStateAction<CollectionItem | null>>
  ] = useState<CollectionItem | null>(null);
  const [isDetailModalOpen, setIsDetailModalOpen]: [
    boolean,
    React.Dispatch<React.SetStateAction<boolean>>
  ] = useState<boolean>(false);

  // ── Vector Text Rows State (Task 7130) ──
  const [textRows, setTextRows]: [
    VectorTextRow[],
    React.Dispatch<React.SetStateAction<VectorTextRow[]>>
  ] = useState<VectorTextRow[]>([]);
  const [isLoadingRows, setIsLoadingRows]: [
    boolean,
    React.Dispatch<React.SetStateAction<boolean>>
  ] = useState<boolean>(false);
  const [rowSearchQuery, setRowSearchQuery]: [
    string,
    React.Dispatch<React.SetStateAction<string>>
  ] = useState<string>("");

  const selectedColName: string =
    activeCollection || (collections.length > 0 ? collections[0].name : "");

  const loadTextRows: (colName: string) => Promise<void> = useCallback(
    async (colName: string): Promise<void> => {
      if (!colName) {
        setTextRows([]);
        return;
      }
      setIsLoadingRows(true);
      try {
        if (endpoint) {
          const res: Response = await fetch(
            `${endpoint}/api/collections/${encodeURIComponent(colName)}/records`,
            { signal: AbortSignal.timeout(2000) }
          );
          if (res.ok) {
            const data: { records?: VectorTextRow[] } = await res.json();
            if (data.records && Array.isArray(data.records) && data.records.length > 0) {
              setTextRows(data.records);
              setIsLoadingRows(false);
              return;
            }
          }
        }
        setTextRows(getDefaultTextRowsForCollection(colName));
      } catch {
        setTextRows(getDefaultTextRowsForCollection(colName));
      } finally {
        setIsLoadingRows(false);
      }
    },
    [endpoint]
  );

  useEffect((): void => {
    if (selectedColName) {
      void loadTextRows(selectedColName);
    }
  }, [selectedColName, loadTextRows]);

  const handleSelectCollection: (name: string) => void = (name: string): void => {
    onSelectCollection(name);
    void loadTextRows(name);
  };

  const isModalOpen: boolean =
    isCreateModalOpenProp !== undefined ? isCreateModalOpenProp : internalCreateModalOpen;

  const handleOpenModal: () => void = (): void => {
    if (onOpenCreateModal) {
      onOpenCreateModal();
    } else {
      setInternalCreateModalOpen(true);
    }
    setErrorMessage(null);
  };

  const handleCloseModal: () => void = (): void => {
    if (!isSubmitting) {
      if (onCloseCreateModal) {
        onCloseCreateModal();
      } else {
        setInternalCreateModalOpen(false);
      }
      setErrorMessage(null);
    }
  };

  const handleCreate: () => Promise<void> = async (): Promise<void> => {
    if (!newColName.trim()) {
      setErrorMessage("Please enter a collection name.");
      return;
    }
    setIsSubmitting(true);
    setErrorMessage(null);
    try {
      await onCreateCollection(newColName.trim(), dimension, metric);
      setNewColName("");
      handleCloseModal();
    } catch (err: unknown) {
      setErrorMessage(err instanceof Error ? err.message : "Failed to create collection");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleOpenTableDetail: (col: CollectionItem) => void = (col: CollectionItem): void => {
    setDetailCollection(col);
    setIsDetailModalOpen(true);
    if (onSelectTableDetail) {
      onSelectTableDetail(col);
    }
  };

  const filteredTextRows: VectorTextRow[] = textRows.filter((row: VectorTextRow): boolean => {
    if (!rowSearchQuery.trim()) return true;
    const query: string = rowSearchQuery.toLowerCase();
    const textMatch: boolean = row.text.toLowerCase().includes(query);
    const idMatch: boolean = row.id.toLowerCase().includes(query);
    const metaMatch: boolean = row.metadata
      ? Object.values(row.metadata).some(
          (val: string | number | boolean | null): boolean =>
            val !== null && String(val).toLowerCase().includes(query)
        )
      : false;
    return textMatch || idMatch || metaMatch;
  });

  const currentCollection: CollectionItem | undefined = collections.find(
    (c: CollectionItem): boolean => c.name === selectedColName
  );

  return (
    <div id="vector-collections-explorer-container" className="vector-panel-container">
      {/* ── Vector Text Rows Content Section ── */}
      {selectedColName ? (
        <div id="vector-collection-content-section" className="vector-card-section">
          <div id="vector-content-section-header" className="div-row gap-2 align-center justify-between">
            <div id="vector-content-title-group" className="div-row gap-2 align-center">
              <IdeIcon name="FileText" size="sm" color="var(--primary, #2563eb)" />
              <span id="vector-content-title" className="font-semibold text-sm theme-text">
                Vector Content Text Rows: <strong id="strong-active-col-name">[{selectedColName}]</strong>
              </span>
              {currentCollection && (
                <a
                  id={`link-table-detail-${selectedColName}`}
                  href={`#collection-${selectedColName}`}
                  role="button"
                  className="vector-table-link cursor-pointer text-xs"
                  onClick={(e: React.MouseEvent<HTMLAnchorElement>): void => {
                    e.preventDefault();
                    e.stopPropagation();
                    handleOpenTableDetail(currentCollection);
                  }}
                  title={`Select and view detail for ${selectedColName}`}
                >
                  <span id={`span-name-${selectedColName}`}>{selectedColName}</span>
                  <IdeIcon name="ExternalLink" size="xs" />
                </a>
              )}
              <span id="badge-total-text-rows-count" className="system-nav-badge">
                {filteredTextRows.length} {filteredTextRows.length === 1 ? "row" : "rows"}
              </span>
              {isLoadingRows && (
                <span id="spinner-loading-text-rows" className="div-row gap-1 align-center text-xs theme-text-muted">
                  <IdeIcon name="Loader" size="xs" />
                  <span>Loading…</span>
                </span>
              )}
            </div>

            <div id="vector-content-header-actions" className="div-row gap-2 align-center">
              <div id="wrapper-filter-text-rows" className="w-64">
                <Input
                  id="input-filter-text-rows"
                  placeholder="Filter text content..."
                  value={rowSearchQuery}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>): void => setRowSearchQuery(e.target.value)}
                />
              </div>
              <Button
                id="btn-refresh-text-rows"
                variant="secondary"
                size="sm"
                onClick={(): void => {
                  void loadTextRows(selectedColName);
                }}
                title="Reload text rows for active collection"
                aria-label="Reload text rows"
              >
                <IdeIcon name="RefreshCw" size="xs" />
                <span>Refresh</span>
              </Button>
              <Button
                id="btn-open-create-collection-modal"
                variant="primary"
                size="sm"
                onClick={handleOpenModal}
                title="Create new vector collection via modal dialog"
                aria-label="Create Vector Collection"
              >
                <IdeIcon name="PlusCircle" size="xs" className="mr-1" />
                <span>{t("createNew", "New Collection")}</span>
              </Button>
            </div>
          </div>

          {filteredTextRows.length === 0 ? (
            <div id="vector-text-rows-empty" className="p-4 text-center text-xs theme-text-muted">
              {rowSearchQuery.trim()
                ? `No text rows match "${rowSearchQuery}" in collection ${selectedColName}.`
                : `No text records found in collection ${selectedColName}.`}
            </div>
          ) : (
            <div id="vector-text-rows-container" className="vector-text-rows-wrapper">
              <table id="vector-text-rows-table" className="vector-table">
                <thead>
                  <tr id="vector-text-rows-head">
                    <th id="th-row-num" className="w-12">#</th>
                    <th id="th-row-id" className="w-48">RECORD ID</th>
                    <th id="th-row-text">TEXT CONTENT / SNIPPET</th>
                    <th id="th-row-meta" className="w-48">METADATA</th>
                    <th id="th-row-vector" className="w-56">VECTOR PREVIEW</th>
                    <th id="th-row-created" className="w-36">TIMESTAMP</th>
                  </tr>
                </thead>
                <tbody id="vector-text-rows-body">
                  {filteredTextRows.map((rec: VectorTextRow, index: number): React.ReactElement => {
                    const valuesPreview: string =
                      rec.values && rec.values.length > 0
                        ? `[${rec.values.slice(0, 4).map((v: number): string => v.toFixed(3)).join(", ")}${rec.values.length > 4 ? ", …" : ""}]`
                        : "[...]";

                    return (
                      <tr
                        key={rec.id}
                        id={`vector-text-row-${rec.id}`}
                        className="vector-text-row-item hover-row"
                      >
                        <td id={`td-row-idx-${rec.id}`} className="font-mono text-2xs theme-text-muted">
                          {index + 1}
                        </td>
                        <td id={`td-row-id-${rec.id}`} className="font-mono text-xs font-semibold theme-text">
                          <div id={`div-row-id-cell-${rec.id}`} className="div-row gap-1 align-center">
                            <IdeIcon name="Hash" size="xs" color="var(--primary, #2563eb)" />
                            <span id={`span-record-id-${rec.id}`}>{rec.id}</span>
                          </div>
                        </td>
                        <td id={`td-row-text-${rec.id}`} className="vector-text-content-cell">
                          <div id={`text-row-content-${rec.id}`} className="vector-text-content-text">
                            {rec.text}
                          </div>
                        </td>
                        <td id={`td-row-meta-${rec.id}`}>
                          <div id={`div-meta-badges-${rec.id}`} className="div-row gap-1 flex-wrap">
                            {rec.metadata?.role && (
                              <span
                                id={`badge-role-${rec.id}`}
                                className={`turn-role-badge role-${String(rec.metadata.role)}`}
                              >
                                {String(rec.metadata.role)}
                              </span>
                            )}
                            {rec.metadata?.category && (
                              <span id={`badge-cat-${rec.id}`} className="system-nav-badge">
                                {String(rec.metadata.category)}
                              </span>
                            )}
                            {rec.metadata?.title && (
                              <span id={`badge-title-${rec.id}`} className="system-nav-badge">
                                {String(rec.metadata.title)}
                              </span>
                            )}
                            {rec.metadata?.chunkIndex !== undefined && (
                              <span id={`badge-chunk-${rec.id}`} className="text-2xs theme-text-muted">
                                chunk #{String(rec.metadata.chunkIndex)}
                              </span>
                            )}
                            {rec.metadata?.turnIndex !== undefined && (
                              <span id={`badge-turn-${rec.id}`} className="text-2xs theme-text-muted">
                                turn #{String(rec.metadata.turnIndex)}
                              </span>
                            )}
                          </div>
                        </td>
                        <td id={`td-row-values-${rec.id}`} className="font-mono text-2xs theme-text-muted">
                          <span id={`span-val-preview-${rec.id}`} title={valuesPreview}>
                            {valuesPreview}
                          </span>
                        </td>
                        <td id={`td-row-created-${rec.id}`} className="text-2xs theme-text-muted whitespace-nowrap">
                          {rec.createdAt ? new Date(rec.createdAt).toLocaleTimeString() : "Seed"}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      ) : (
        <div id="vector-no-collection-selected" className="vector-card-section p-8 text-center div-col align-center justify-center gap-3">
          <IdeIcon name="Boxes" size="xl" color="var(--primary, #2563eb)" />
          <h3 id="vector-no-collection-title" className="text-sm font-semibold theme-text">
            {collections.length === 0 ? "No Vector Collections Available" : "No Collection Selected"}
          </h3>
          <p id="vector-no-collection-desc" className="text-xs theme-text-muted max-w-sm">
            {collections.length === 0
              ? "Create your first vector collection to store embeddings, documents, and text vectors."
              : "Select a collection from the sidebar to inspect its vector records and text rows."}
          </p>
          <Button
            id="btn-open-create-collection-modal"
            variant="primary"
            size="sm"
            onClick={handleOpenModal}
            title="Create new vector collection via modal dialog"
            aria-label="Create Vector Collection"
          >
            <IdeIcon name="PlusCircle" size="xs" className="mr-1" />
            <span>{t("createNew", "New Collection")}</span>
          </Button>
        </div>
      )}

      {/* Selected Table Detail Card */}
      {detailCollection && (
        <div id="vector-selected-table-detail-card" className="vector-card-section">
          <div id="vector-inline-detail-header" className="div-row gap-2 align-center justify-between">
            <div id="vector-inline-detail-title-group" className="div-row gap-2 align-center">
              <IdeIcon name="Database" size="sm" color="var(--primary, #6938ef)" />
              <span id="vector-inline-detail-title" className="font-semibold text-sm">
                Table Detail: {detailCollection.name}
              </span>
              <span id="vector-inline-detail-badge" className="turn-role-badge role-user">
                {detailCollection.metric}
              </span>
              {detailCollection.name === activeCollection && (
                <span id="vector-inline-active-pill" className="turn-role-badge role-assistant">
                  Active
                </span>
              )}
            </div>
            <div id="vector-inline-detail-actions" className="div-row gap-2 align-center">
              <Button
                id="btn-open-detail-modal"
                variant="secondary"
                size="sm"
                onClick={(): void => setIsDetailModalOpen(true)}
              >
                <IdeIcon name="Maximize2" size="xs" />
                <span>Expand Detail</span>
              </Button>
              <Button
                id="btn-close-inline-detail"
                variant="secondary"
                size="sm"
                onClick={(): void => setDetailCollection(null)}
              >
                <IdeIcon name="X" size="xs" />
                <span>Close</span>
              </Button>
            </div>
          </div>
          <div id="vector-inline-stats-grid" className="vector-detail-grid">
            <div id="inline-stat-dim" className="vector-detail-stat-card">
              <span id="inline-label-dim" className="vector-detail-stat-label">Dimensions</span>
              <span id="inline-val-dim" className="vector-detail-stat-value">{detailCollection.dimension} Float32</span>
            </div>
            <div id="inline-stat-metric" className="vector-detail-stat-card">
              <span id="inline-label-metric" className="vector-detail-stat-label">Metric</span>
              <span id="inline-val-metric" className="vector-detail-stat-value">{detailCollection.metric}</span>
            </div>
            <div id="inline-stat-vectors" className="vector-detail-stat-card">
              <span id="inline-label-vectors" className="vector-detail-stat-label">Vectors Indexed</span>
              <span id="inline-val-vectors" className="vector-detail-stat-value">{detailCollection.vectorCount}</span>
            </div>
            <div id="inline-stat-created" className="vector-detail-stat-card">
              <span id="inline-label-created" className="vector-detail-stat-label">Created At</span>
              <span id="inline-val-created" className="vector-detail-stat-value text-xs truncate">
                {detailCollection.createdAt ? new Date(detailCollection.createdAt).toLocaleString() : "Initial"}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Full Table Detail Modal */}
      <TableDetailModal
        collection={detailCollection}
        isOpen={isDetailModalOpen}
        onClose={(): void => setIsDetailModalOpen(false)}
        isActive={detailCollection ? detailCollection.name === activeCollection : false}
        onSelectActive={(name: string): void => handleSelectCollection(name)}
      />

      {/* ── Modal: Create New Vector Collection ── */}
      {isModalOpen && (
        <Modal
          id="modal-create-vector-collection"
          isOpen={isModalOpen}
          onClose={handleCloseModal}
          title={t("createNew", "Create New Vector Collection")}
          footer={
            <div id="vector-create-modal-footer-actions" className="div-row gap-2 justify-end w-full">
              <Button
                id="btn-cancel-create-collection-modal"
                variant="secondary"
                size="sm"
                onClick={handleCloseModal}
                disabled={isSubmitting}
              >
                <span>Cancel</span>
              </Button>
              <Button
                id="vector-submit-create-btn"
                variant="primary"
                size="sm"
                onClick={handleCreate}
                disabled={isSubmitting || !newColName.trim()}
              >
                <IdeIcon name="Check" size="xs" className="mr-1" />
                <span id="vector-create-btn-label">
                  {isSubmitting ? "Creating…" : t("createBtn", "Create Collection")}
                </span>
              </Button>
            </div>
          }
        >
          <div id="vector-create-modal-body" className="div-col gap-3 p-1">
            {errorMessage && (
              <div id="vector-create-modal-error" className="p-2 text-xs rounded bg-red-50 text-red-600 border border-red-200">
                {errorMessage}
              </div>
            )}

            {/* Collection Name */}
            <div id="vector-modal-field-name" className="div-col gap-1">
              <label id="lbl-vector-modal-name" className="text-xs font-medium theme-text">
                Collection Name <span className="text-red-500">*</span>
              </label>
              <Input
                id="vector-new-collection-name-input"
                placeholder={t("namePlaceholder", "e.g. conversations_vectors, product_embeddings")}
                value={newColName}
                onChange={(e: React.ChangeEvent<HTMLInputElement>): void => {
                  setNewColName(e.target.value);
                  if (errorMessage) setErrorMessage(null);
                }}
              />
            </div>

            {/* Dimension & Presets */}
            <div id="vector-modal-field-dim" className="div-col gap-1">
              <div id="vector-dim-label-row" className="div-row justify-between items-center">
                <label id="lbl-vector-modal-dim" className="text-xs font-medium theme-text">
                  Vector Dimension
                </label>
                <span id="text-dim-hint" className="text-2xs theme-text-muted">
                  Vector embedding width
                </span>
              </div>
              <Input
                id="vector-new-collection-dim-input"
                type="number"
                placeholder="128"
                value={String(dimension)}
                onChange={(e: React.ChangeEvent<HTMLInputElement>): void =>
                  setDimension(Number(e.target.value) || 128)
                }
              />
              <div id="vector-dim-presets-row" className="div-row gap-1.5 mt-1 flex-wrap">
                {[128, 384, 512, 768, 1536].map((preset: number): React.ReactElement => (
                  <button
                    key={preset}
                    id={`btn-dim-preset-${preset}`}
                    type="button"
                    className={`vector-dim-preset-btn ${dimension === preset ? "active" : ""}`}
                    onClick={(): void => setDimension(preset)}
                  >
                    {preset}D
                  </button>
                ))}
              </div>
            </div>

            {/* Distance Metric */}
            <div id="vector-modal-field-metric" className="div-col gap-1">
              <label id="lbl-vector-modal-metric" className="text-xs font-medium theme-text">
                Distance Metric
              </label>
              <div id="vector-metric-select-wrap" className="div-row gap-2">
                <button
                  id="vector-metric-cosine-btn"
                  type="button"
                  className={`vector-metric-card-btn ${metric === "cosine" ? "active" : ""}`}
                  onClick={(): void => setMetric("cosine")}
                >
                  <span className="font-semibold text-xs theme-text">Cosine</span>
                  <span className="text-2xs theme-text-muted">Angular similarity (Recommended)</span>
                </button>
                <button
                  id="vector-metric-euclidean-btn"
                  type="button"
                  className={`vector-metric-card-btn ${metric === "euclidean" ? "active" : ""}`}
                  onClick={(): void => setMetric("euclidean")}
                >
                  <span className="font-semibold text-xs theme-text">Euclidean</span>
                  <span className="text-2xs theme-text-muted">L2 distance</span>
                </button>
                <button
                  id="vector-metric-dot-btn"
                  type="button"
                  className={`vector-metric-card-btn ${metric === "dot" ? "active" : ""}`}
                  onClick={(): void => setMetric("dot")}
                >
                  <span className="font-semibold text-xs theme-text">Dot Product</span>
                  <span className="text-2xs theme-text-muted">Inner product similarity</span>
                </button>
              </div>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
