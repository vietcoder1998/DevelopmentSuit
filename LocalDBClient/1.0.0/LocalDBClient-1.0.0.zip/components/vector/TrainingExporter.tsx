import React, { useState } from "react";
import { IdeIcon } from "../bases/ide-icon";
import { Button } from "../bases/button";
import { Input } from "../bases/input";
import { useSafeTranslations } from "../bases/use-safe-translations";

export interface TrainingExporterProps {
  readonly onGenerateExport: (params: {
    format: "sharegpt" | "openai";
    limit: number;
    domain?: string;
  }) => Promise<{ format: string; recordCount: number; jsonlContent: string }>;
}

export const TrainingExporter: React.FC<TrainingExporterProps> = ({
  onGenerateExport,
}) => {
  const t = useSafeTranslations("vectorclient.training");
  const [format, setFormat] = useState<"sharegpt" | "openai">("sharegpt");
  const [limit, setLimit] = useState<number>(500);
  const [domain, setDomain] = useState<string>("");
  const [isExporting, setIsExporting] = useState<boolean>(false);
  const [previewContent, setPreviewContent] = useState<string>("");
  const [recordCount, setRecordCount] = useState<number>(0);

  const handleGenerate = async (): Promise<void> => {
    setIsExporting(true);
    try {
      const res = await onGenerateExport({
        format,
        limit,
        domain: domain.trim() || undefined,
      });
      setPreviewContent(res.jsonlContent || "// No records found");
      setRecordCount(res.recordCount);
    } finally {
      setIsExporting(false);
    }
  };

  const handleDownload = (): void => {
    if (!previewContent) return;
    const blob: Blob = new Blob([previewContent], { type: "application/x-jsonlines" });
    const url: string = URL.createObjectURL(blob);
    const a: HTMLAnchorElement = document.createElement("a");
    a.href = url;
    a.download = `dataset_${format}_${Date.now()}.jsonl`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div id="vector-training-exporter-container" className="vector-panel-container">
      <div id="vector-training-config-card" className="vector-card-section">
        <div id="vector-training-header" className="div-row gap-2 align-center justify-between">
          <div id="vector-training-title-group" className="div-row gap-2 align-center">
            <IdeIcon name="Cpu" size="sm" color="var(--primary, #6938ef)" />
            <span id="vector-training-title" className="font-semibold text-sm">
              {t("title", "Export Correlated Conversations for Model Fine-Tuning & Training")}
            </span>
          </div>
          <span id="vector-training-badge" className="turn-role-badge role-user">
            {format.toUpperCase()} JSONL
          </span>
        </div>

        <div id="vector-training-controls" className="div-row gap-3 align-center flex-wrap">
          <div id="vector-format-buttons" className="div-row gap-2 align-center">
            <Button
              id="vector-fmt-sharegpt-btn"
              variant={format === "sharegpt" ? "primary" : "secondary"}
              size="sm"
              onClick={(): void => setFormat("sharegpt")}
            >
              ShareGPT Format
            </Button>
            <Button
              id="vector-fmt-openai-btn"
              variant={format === "openai" ? "primary" : "secondary"}
              size="sm"
              onClick={(): void => setFormat("openai")}
            >
              OpenAI Messages Format
            </Button>
          </div>

          <div id="vector-limit-wrap" className="w-120">
            <Input
              id="vector-training-limit-input"
              type="number"
              placeholder="Limit"
              value={String(limit)}
              onChange={(e: React.ChangeEvent<HTMLInputElement>): void => setLimit(Number(e.target.value) || 100)}
            />
          </div>

          <div id="vector-domain-filter-wrap" className="w-180">
            <Input
              id="vector-training-domain-input"
              placeholder={t("domainFilterPlaceholder", "Domain filter (optional)")}
              value={domain}
              onChange={(e: React.ChangeEvent<HTMLInputElement>): void => setDomain(e.target.value)}
            />
          </div>

          <Button
            id="vector-generate-dataset-btn"
            variant="primary"
            size="sm"
            onClick={handleGenerate}
            disabled={isExporting}
          >
            <IdeIcon name="RefreshCw" size="sm" className={isExporting ? "spin" : ""} />
            <span id="vector-generate-label">
              {isExporting ? t("generating", "Generating...") : t("generateBtn", "Generate Preview")}
            </span>
          </Button>

          <Button
            id="vector-download-dataset-btn"
            variant="secondary"
            size="sm"
            onClick={handleDownload}
            disabled={!previewContent || recordCount === 0}
          >
            <IdeIcon name="Download" size="sm" />
            <span id="vector-download-label">{t("downloadBtn", "Download JSONL")}</span>
          </Button>
        </div>
      </div>

      <div id="vector-training-preview-card" className="vector-card-section">
        <div id="vector-preview-header" className="div-row gap-2 align-center justify-between">
          <div id="vector-preview-title-group" className="div-row gap-2 align-center">
            <IdeIcon name="Code" size="sm" color="var(--primary, #6938ef)" />
            <span id="vector-preview-title" className="font-semibold text-sm">
              {t("previewTitle", "Dataset JSONL Output Preview")}
            </span>
          </div>
          <span id="vector-record-count-badge" className="text-xs text-muted font-medium">
            {recordCount} {t("recordsExported", "records formatted")}
          </span>
        </div>

        <div id="vector-jsonl-preview-box" className="json-preview-box">
          {previewContent || t("placeholder", "// Click 'Generate Preview' to compile conversations into JSONL training data")}
        </div>
      </div>
    </div>
  );
};
