import React, { useState } from "react";
import { IdeIcon } from "../bases/ide-icon";
import { Button } from "../bases/button";
import { Input } from "../bases/input";
import { useSafeTranslations } from "../bases/use-safe-translations";

export interface RelatedItem {
  conversationId: string;
  title: string;
  messageId: string;
  role: string;
  snippet: string;
  score: number;
}

export interface RelatedConversationsViewProps {
  readonly onSearchRelated: (query: string, topK: number) => Promise<RelatedItem[]>;
}

export const RelatedConversationsView: React.FC<RelatedConversationsViewProps> = ({
  onSearchRelated,
}) => {
  const t = useSafeTranslations("vectorclient.related");
  const [query, setQuery] = useState<string>("");
  const [topK, setTopK] = useState<number>(5);
  const [isSearching, setIsSearching] = useState<boolean>(false);
  const [results, setResults] = useState<RelatedItem[]>([]);

  const handleSearch = async (): Promise<void> => {
    if (!query.trim()) return;
    setIsSearching(true);
    try {
      const items = await onSearchRelated(query.trim(), topK);
      setResults(items);
    } finally {
      setIsSearching(false);
    }
  };

  return (
    <div id="vector-related-conversations-container" className="vector-panel-container">
      <div id="vector-search-bar-card" className="vector-card-section">
        <div id="vector-search-header" className="div-row gap-2 align-center">
          <IdeIcon name="Search" size="sm" color="var(--primary, #6938ef)" />
          <span id="vector-search-title" className="font-semibold text-sm">
            {t("searchTitle", "Semantic Search & Related Dialog Correlation")}
          </span>
        </div>
        <div id="vector-search-controls" className="div-row gap-3 align-center">
          <div id="vector-query-input-wrap" className="flex-1">
            <Input
              id="vector-semantic-query-input"
              placeholder={t("queryPlaceholder", "Enter prompt, topic or query to correlate related conversations...")}
              value={query}
              onChange={(e: React.ChangeEvent<HTMLInputElement>): void => setQuery(e.target.value)}
              onKeyDown={(e: React.KeyboardEvent<HTMLInputElement>): void => {
                if (e.key === "Enter") {
                  handleSearch();
                }
              }}
            />
          </div>
          <div id="vector-topk-input-wrap" className="w-90">
            <Input
              id="vector-topk-input"
              type="number"
              placeholder="Top K"
              value={String(topK)}
              onChange={(e: React.ChangeEvent<HTMLInputElement>): void => setTopK(Number(e.target.value) || 5)}
            />
          </div>
          <Button
            id="vector-execute-search-btn"
            variant="primary"
            size="md"
            onClick={handleSearch}
            disabled={isSearching || !query.trim()}
          >
            <IdeIcon name="Search" size="sm" />
            <span id="vector-search-btn-label">
              {isSearching ? t("searching", "Searching...") : t("searchBtn", "Correlate")}
            </span>
          </Button>
        </div>
      </div>

      <div id="vector-search-results-card" className="vector-card-section">
        <div id="vector-results-header" className="div-row gap-2 align-center justify-between">
          <div id="vector-results-title-group" className="div-row gap-2 align-center">
            <IdeIcon name="GitMerge" size="sm" color="var(--primary, #6938ef)" />
            <span id="vector-results-title" className="font-semibold text-sm">
              {t("resultsTitle", "Correlated Conversation Turns & Threads")}
            </span>
          </div>
          <span id="vector-results-count-badge" className="text-xs text-muted font-medium">
            {results.length} {t("matches", "matches found")}
          </span>
        </div>

        {results.length === 0 ? (
          <div id="vector-no-results-view" className="div-center py-6 text-muted text-sm">
            <span id="span-no-results">{t("noMatches", "No correlated conversations found. Try another query or upload new dialogues.")}</span>
          </div>
        ) : (
          <div id="vector-results-list" className="div-col gap-3">
            {results.map((item: RelatedItem) => {
              const scorePercent: number = Math.max(0, Math.min(100, Math.round(item.score * 100)));
              return (
                <div
                  id={`vector-related-item-${item.conversationId}`}
                  key={`${item.conversationId}-${item.messageId}`}
                  className="conversation-turn-item"
                >
                  <div id={`vector-turn-header-${item.conversationId}`} className="div-row justify-between align-center">
                    <div id={`vector-turn-meta-${item.conversationId}`} className="div-row gap-2 align-center">
                      <span id={`turn-role-${item.conversationId}`} className={`turn-role-badge role-${item.role}`}>
                        {item.role}
                      </span>
                      <span id={`turn-title-${item.conversationId}`} className="font-medium text-sm">
                        {item.title}
                      </span>
                      <span id={`turn-conv-id-${item.conversationId}`} className="text-xs text-muted">
                        ({item.conversationId})
                      </span>
                    </div>
                    <div id={`vector-turn-score-${item.conversationId}`} className="div-row align-center gap-2">
                      <div id={`vector-score-bar-wrap-${item.conversationId}`} className="similarity-bar-container">
                        <div
                          id={`vector-score-fill-${item.conversationId}`}
                          className="similarity-bar-fill"
                          data-score={scorePercent}
                        />
                      </div>
                      <span id={`turn-score-text-${item.conversationId}`} className="text-xs font-semibold text-primary">
                        {scorePercent}%
                      </span>
                    </div>
                  </div>
                  <p id={`turn-snippet-${item.conversationId}`} className="text-sm text-muted my-1">
                    "{item.snippet}"
                  </p>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
