import React, { useState } from "react";
import { IdeIcon } from "../bases/ide-icon";
import { Button } from "../bases/button";
import { Input } from "../bases/input";
import { useSafeTranslations } from "../bases/use-safe-translations";

export interface MessageInput {
  role: "system" | "user" | "assistant";
  content: string;
}

export interface ConversationUploaderProps {
  readonly onUploadConversation: (data: {
    conversationId?: string;
    title: string;
    metadata?: Record<string, string | number | boolean | null>;
    messages: MessageInput[];
  }) => Promise<{ conversationId: string; turnsIndexed: number }>;
}

export const ConversationUploader: React.FC<ConversationUploaderProps> = ({
  onUploadConversation,
}) => {
  const t = useSafeTranslations("vectorclient.uploader");
  const [title, setTitle] = useState<string>("");
  const [domain, setDomain] = useState<string>("general");
  const [userContent, setUserContent] = useState<string>("");
  const [assistantContent, setAssistantContent] = useState<string>("");
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [uploadStatus, setUploadStatus] = useState<string | null>(null);

  const handleLoadSample = (): void => {
    setTitle("Architecture Discussion on Local Vector Engine");
    setDomain("vector-db");
    setUserContent("How does LocalVectorServer correlate conversations and store high-dimensional embeddings?");
    setAssistantContent("LocalVectorServer breaks dialogues into semantic turns, computes dense vector representations, and enables nearest-neighbor cosine similarity queries.");
  };

  const handleUpload = async (): Promise<void> => {
    if (!title.trim() || !userContent.trim()) return;

    setIsSubmitting(true);
    setUploadStatus(null);
    try {
      const messages: MessageInput[] = [
        { role: "user", content: userContent.trim() },
      ];
      if (assistantContent.trim()) {
        messages.push({ role: "assistant", content: assistantContent.trim() });
      }

      const res = await onUploadConversation({
        title: title.trim(),
        metadata: { domain: domain.trim() },
        messages,
      });

      setUploadStatus(`Indexed successfully: ${res.conversationId} (${res.turnsIndexed} turns)`);
      setTitle("");
      setUserContent("");
      setAssistantContent("");
    } catch (err: unknown) {
      setUploadStatus(`Upload failed: ${String(err)}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div id="vector-conversation-uploader-container" className="vector-panel-container">
      <div id="vector-uploader-card" className="vector-card-section">
        <div id="vector-uploader-header" className="div-row gap-2 align-center justify-between">
          <div id="vector-uploader-title-group" className="div-row gap-2 align-center">
            <IdeIcon name="UploadCloud" size="sm" color="var(--primary, #6938ef)" />
            <span id="vector-uploader-title" className="font-semibold text-sm">
              {t("title", "Upload Multi-Turn Conversation to Vector DB")}
            </span>
          </div>
          <Button
            id="vector-load-sample-btn"
            variant="secondary"
            size="sm"
            onClick={handleLoadSample}
          >
            <IdeIcon name="FileText" size="sm" />
            <span id="vector-load-sample-label">{t("loadSample", "Load Sample")}</span>
          </Button>
        </div>

        <div id="vector-uploader-fields" className="div-col gap-3">
          <div id="vector-title-domain-row" className="div-row gap-3">
            <div id="vector-conv-title-wrap" className="flex-1">
              <Input
                id="vector-conversation-title-input"
                placeholder={t("titlePlaceholder", "Conversation Title (e.g. LLM Training Discussion)")}
                value={title}
                onChange={(e: React.ChangeEvent<HTMLInputElement>): void => setTitle(e.target.value)}
              />
            </div>
            <div id="vector-conv-domain-wrap" className="w-180">
              <Input
                id="vector-conversation-domain-input"
                placeholder={t("domainPlaceholder", "Domain / Tag")}
                value={domain}
                onChange={(e: React.ChangeEvent<HTMLInputElement>): void => setDomain(e.target.value)}
              />
            </div>
          </div>

          <div id="vector-turn-user-group" className="div-col gap-1">
            <label id="lbl-user-turn" className="text-xs font-semibold text-muted">
              {t("userTurn", "User Message (Turn 1)")}
            </label>
            <Input
              id="vector-turn-user-input"
              placeholder={t("userPlaceholder", "Enter user prompt or question...")}
              value={userContent}
              onChange={(e: React.ChangeEvent<HTMLInputElement>): void => setUserContent(e.target.value)}
            />
          </div>

          <div id="vector-turn-assistant-group" className="div-col gap-1">
            <label id="lbl-assistant-turn" className="text-xs font-semibold text-muted">
              {t("assistantTurn", "Assistant Response (Turn 2)")}
            </label>
            <Input
              id="vector-turn-assistant-input"
              placeholder={t("assistantPlaceholder", "Enter assistant response...")}
              value={assistantContent}
              onChange={(e: React.ChangeEvent<HTMLInputElement>): void => setAssistantContent(e.target.value)}
            />
          </div>

          <div id="vector-uploader-action-row" className="div-row gap-3 align-center justify-between">
            <div id="vector-upload-status-display">
              {uploadStatus && (
                <span id="span-upload-status" className="text-xs text-primary font-medium">
                  {uploadStatus}
                </span>
              )}
            </div>
            <Button
              id="vector-submit-upload-btn"
              variant="primary"
              size="md"
              onClick={handleUpload}
              disabled={isSubmitting || !title.trim() || !userContent.trim()}
            >
              <IdeIcon name="ArrowUpCircle" size="sm" />
              <span id="vector-upload-btn-label">
                {isSubmitting ? t("indexing", "Indexing...") : t("submitBtn", "Upload & Index Conversation")}
              </span>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};
