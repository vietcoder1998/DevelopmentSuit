import React, { useState } from "react";
import { Modal } from "../bases/modal";
import { Button } from "../bases/button";
import { Badge } from "../bases/badge";
import { IdeIcon } from "../bases/ide-icon";
import { CollectionItem } from "./CollectionsExplorer";
import { useSafeTranslations } from "../bases/use-safe-translations";

export interface TableDetailModalProps {
  readonly collection: CollectionItem | null;
  readonly isOpen: boolean;
  readonly onClose: () => void;
  readonly isActive: boolean;
  readonly onSelectActive?: (name: string) => void;
}

export interface TableSchemaColumn {
  readonly name: string;
  readonly type: string;
  readonly required: boolean;
  readonly nullable: boolean;
  readonly description: string;
}

export const TableDetailModal: React.FC<TableDetailModalProps> = ({
  collection,
  isOpen,
  onClose,
  isActive,
  onSelectActive,
}) => {
  const t: (key: string, fallback: string) => string = useSafeTranslations("vectorclient.tabledetail");
  const [activeTab, setActiveTab]: [
    "overview" | "schema" | "samples",
    React.Dispatch<React.SetStateAction<"overview" | "schema" | "samples">>
  ] = useState<"overview" | "schema" | "samples">("overview");

  if (!collection) {
    return null;
  }

  const formattedDate: string = collection.createdAt
    ? new Date(collection.createdAt).toLocaleString()
    : "Initial startup";

  const metricDescription: string =
    collection.metric === "euclidean"
      ? "L2 Euclidean Distance — measures straight-line distance in Euclidean space, ideal for geometric clustering"
      : collection.metric === "dot"
      ? "Dot Product — measures inner product of vectors, optimized for pre-normalized unit embeddings"
      : "Cosine Similarity — measures angular similarity between vectors, optimal for natural language & semantic retrieval";

  const metricFormula: string =
    collection.metric === "euclidean"
      ? "d(u, v) = sqrt(sum((u_i - v_i)^2))"
      : collection.metric === "dot"
      ? "u · v = sum(u_i * v_i)"
      : "cos(theta) = (u · v) / (||u|| * ||v||)";

  const schemaColumns: TableSchemaColumn[] = [
    {
      name: "id",
      type: "string (UUID / Text Key)",
      required: true,
      nullable: false,
      description: "Unique vector record identifier for upsert, search, and retrieval",
    },
    {
      name: "values",
      type: `Float32Array [${collection.dimension}]`,
      required: true,
      nullable: false,
      description: `Dense embedding coordinates with ${collection.dimension} floating-point values`,
    },
    {
      name: "metadata",
      type: "Record<string, unknown>",
      required: false,
      nullable: true,
      description: "Structured JSON metadata key-value tags for boolean and categorical filtering",
    },
    {
      name: "createdAt",
      type: "number (Unix timestamp ms)",
      required: true,
      nullable: false,
      description: "Epoch millisecond timestamp indicating when the vector was indexed",
    },
  ];

  const previewValues: number[] = Array.from(
    { length: Math.min(collection.dimension, 8) },
    (_: unknown, index: number): number => {
      const val: number = Math.sin(index + 1) * 0.45;
      return Number(val.toFixed(4));
    }
  );

  return (
    <Modal
      id="vector-table-detail-modal"
      isOpen={isOpen}
      onClose={onClose}
      title={`Table Detail: ${collection.name}`}
      footer={
        <div id="vector-table-detail-modal-footer" className="div-row gap-2 justify-end w-full">
          {onSelectActive && !isActive && (
            <Button
              id="vector-table-detail-set-active-btn"
              variant="primary"
              size="sm"
              onClick={(): void => {
                onSelectActive(collection.name);
                onClose();
              }}
            >
              <IdeIcon name="Check" size="sm" />
              <span>{t("setActive", "Set as Active Collection")}</span>
            </Button>
          )}
          <Button
            id="vector-table-detail-close-btn"
            variant="secondary"
            size="sm"
            onClick={onClose}
          >
            <span>{t("close", "Close")}</span>
          </Button>
        </div>
      }
    >
      <div id="vector-table-detail-body" className="vector-detail-modal-body">
        {/* Top Badges & Status */}
        <div id="vector-table-detail-status-row" className="div-row gap-2 align-center">
          <Badge variant={isActive ? "primary" : "secondary"} size="sm">
            {isActive ? "Active Collection" : "Inactive Collection"}
          </Badge>
          <Badge variant="secondary" size="sm">
            {collection.metric.toUpperCase()} METRIC
          </Badge>
          <span id="vector-table-detail-indexed-badge" className="theme-text-muted text-xs">
            {collection.vectorCount} vectors stored
          </span>
        </div>

        {/* 4 Stat Cards */}
        <div id="vector-table-detail-stats-grid" className="vector-detail-grid">
          <div id="vector-stat-dimension-card" className="vector-detail-stat-card">
            <span id="vector-stat-dim-label" className="vector-detail-stat-label">
              {t("dimension", "Dimension")}
            </span>
            <span id="vector-stat-dim-val" className="vector-detail-stat-value">
              {collection.dimension} Dims
            </span>
          </div>

          <div id="vector-stat-metric-card" className="vector-detail-stat-card">
            <span id="vector-stat-metric-label" className="vector-detail-stat-label">
              {t("metric", "Distance Metric")}
            </span>
            <span id="vector-stat-metric-val" className="vector-detail-stat-value">
              {collection.metric}
            </span>
          </div>

          <div id="vector-stat-count-card" className="vector-detail-stat-card">
            <span id="vector-stat-count-label" className="vector-detail-stat-label">
              {t("vectorCount", "Vectors Count")}
            </span>
            <span id="vector-stat-count-val" className="vector-detail-stat-value">
              {collection.vectorCount}
            </span>
          </div>

          <div id="vector-stat-date-card" className="vector-detail-stat-card">
            <span id="vector-stat-date-label" className="vector-detail-stat-label">
              {t("createdAt", "Created Date")}
            </span>
            <span id="vector-stat-date-val" className="vector-detail-stat-value text-xs truncate">
              {formattedDate}
            </span>
          </div>
        </div>

        {/* Tab Navigation */}
        <div id="vector-table-detail-tabs-bar" className="vector-detail-tabs-bar">
          <button
            id="tab-detail-overview-btn"
            type="button"
            className={`vector-detail-tab-button ${activeTab === "overview" ? "active" : ""}`}
            onClick={(): void => setActiveTab("overview")}
          >
            <IdeIcon name="Info" size="xs" />
            <span>{t("tabOverview", "Overview & Index Specs")}</span>
          </button>
          <button
            id="tab-detail-schema-btn"
            type="button"
            className={`vector-detail-tab-button ${activeTab === "schema" ? "active" : ""}`}
            onClick={(): void => setActiveTab("schema")}
          >
            <IdeIcon name="Code" size="xs" />
            <span>{t("tabSchema", "Schema & Columns")}</span>
          </button>
          <button
            id="tab-detail-samples-btn"
            type="button"
            className={`vector-detail-tab-button ${activeTab === "samples" ? "active" : ""}`}
            onClick={(): void => setActiveTab("samples")}
          >
            <IdeIcon name="Layers" size="xs" />
            <span>{t("tabSamples", "Vector Structure Preview")}</span>
          </button>
        </div>

        {/* Tab 1: Overview */}
        {activeTab === "overview" && (
          <div id="vector-detail-tab-overview-content" className="vector-detail-content-section">
            <div id="vector-metric-details-box" className="vector-detail-description-box">
              <strong id="vector-metric-heading" className="font-semibold block mb-1">
                Distance Function: {collection.metric.toUpperCase()}
              </strong>
              <p id="vector-metric-desc" className="mb-2">
                {metricDescription}
              </p>
              <div id="vector-metric-formula-box" className="theme-surface-muted p-2 rounded font-mono text-xs text-primary">
                Formula: {metricFormula}
              </div>
            </div>

            <div id="vector-storage-specs-box" className="vector-detail-description-box">
              <strong id="vector-storage-heading" className="font-semibold block mb-1">
                Storage & Index Specifications
              </strong>
              <div id="vector-storage-specs-list" className="div-col gap-1 text-xs">
                <span id="spec-item-type">Index Type: In-Memory Flat Vector Index (Exact K-NN)</span>
                <span id="spec-item-memory">
                  Estimated Record Size: ~{collection.dimension * 4 + 128} bytes / vector
                </span>
                <span id="spec-item-persistence">
                  Persistence: Local JSON snapshot storage (~/.2tek/vector_storage)
                </span>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Schema */}
        {activeTab === "schema" && (
          <div id="vector-detail-tab-schema-content" className="vector-detail-content-section">
            <div id="vector-schema-table-wrapper" className="overflow-x-auto">
              <table id="vector-detail-schema-data-table" className="vector-table">
                <thead>
                  <tr id="vector-schema-th-row">
                    <th id="th-schema-col">Field Name</th>
                    <th id="th-schema-type">Data Type</th>
                    <th id="th-schema-required">Required</th>
                    <th id="th-schema-desc">Description</th>
                  </tr>
                </thead>
                <tbody id="vector-schema-tbody">
                  {schemaColumns.map((col: TableSchemaColumn) => (
                    <tr id={`vector-schema-row-${col.name}`} key={col.name}>
                      <td id={`td-schema-name-${col.name}`} className="font-mono font-semibold">
                        {col.name}
                      </td>
                      <td id={`td-schema-type-${col.name}`}>
                        <span id={`span-schema-type-${col.name}`} className="turn-role-badge role-user">
                          {col.type}
                        </span>
                      </td>
                      <td id={`td-schema-req-${col.name}`}>
                        {col.required ? (
                          <Badge variant="primary" size="xs">
                            REQUIRED
                          </Badge>
                        ) : (
                          <Badge variant="secondary" size="xs">
                            OPTIONAL
                          </Badge>
                        )}
                      </td>
                      <td id={`td-schema-desc-${col.name}`} className="theme-text-muted text-xs">
                        {col.description}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Tab 3: Sample Vectors */}
        {activeTab === "samples" && (
          <div id="vector-detail-tab-samples-content" className="vector-detail-content-section">
            <div id="vector-sample-vector-item-1" className="vector-sample-vector-row">
              <div id="sample-vector-header-1" className="div-row gap-2 align-center justify-between">
                <span id="sample-vector-id-1" className="vector-sample-vector-id">
                  vec_{collection.name}_0001
                </span>
                <Badge variant="secondary" size="xs">
                  SAMPLE RECORD
                </Badge>
              </div>
              <span id="sample-vector-label-values" className="text-xs theme-text-muted font-semibold">
                Vector Values Preview ({collection.dimension} dimensions):
              </span>
              <div id="sample-vector-values-box-1" className="vector-sample-vector-values theme-surface-muted p-2 rounded">
                [{previewValues.join(", ")}... +{collection.dimension - previewValues.length} more]
              </div>
              <span id="sample-vector-label-meta" className="text-xs theme-text-muted font-semibold mt-1">
                Metadata Attributes:
              </span>
              <div id="sample-vector-meta-box-1" className="theme-surface-muted p-2 rounded font-mono text-xs">
                {JSON.stringify(
                  {
                    collection: collection.name,
                    source: "local_vector_client",
                    dimension: collection.dimension,
                    metric: collection.metric,
                  },
                  null,
                  2
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </Modal>
  );
};
