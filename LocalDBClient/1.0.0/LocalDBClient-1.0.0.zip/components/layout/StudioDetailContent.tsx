"use client";

import React, { useState, useCallback, useRef } from "react";
import { Button, IdeIcon, Badge } from "../bases";
import { TableItemMetadata } from "../sql/TablesExplorer";

export interface ColumnDetailInfo {
  readonly name: string;
  readonly type: string;
  readonly primaryKey?: boolean;
  readonly nullable?: boolean;
}

export interface StudioDetailContentProps {
  readonly isOpen: boolean;
  readonly onClose: () => void;
  readonly activeTable: string | null;
  readonly activeDatabase: string;
  readonly tableMetadata?: TableItemMetadata | null;
  readonly schema?: unknown;
  readonly width?: number;
  readonly onWidthChange?: (width: number) => void;
  readonly onRunSnippetInConsole?: (sql: string) => void;
}

type DetailTabMode = "schema" | "info" | "sql";

export const StudioDetailContent: React.FC<StudioDetailContentProps> = ({
  isOpen,
  onClose,
  activeTable,
  activeDatabase,
  tableMetadata,
  schema,
  width = 300,
  onWidthChange,
  onRunSnippetInConsole,
}) => {
  const [detailTab, setDetailTab]: [DetailTabMode, React.Dispatch<React.SetStateAction<DetailTabMode>>] =
    useState<DetailTabMode>("schema");
  const [copiedSnippet, setCopiedSnippet]: [string | null, React.Dispatch<React.SetStateAction<string | null>>] =
    useState<string | null>(null);

  const isDraggingRef: React.MutableRefObject<boolean> = useRef<boolean>(false);
  const startXRef: React.MutableRefObject<number> = useRef<number>(0);
  const startWidthRef: React.MutableRefObject<number> = useRef<number>(width);

  const handleMouseDown: (e: React.MouseEvent) => void = useCallback(
    (e: React.MouseEvent): void => {
      e.preventDefault();
      isDraggingRef.current = true;
      startXRef.current = e.clientX;
      startWidthRef.current = width;

      const handleMouseMove: (moveEvent: MouseEvent) => void = (moveEvent: MouseEvent): void => {
        if (!isDraggingRef.current) return;
        // Dragging left edge: moving mouse left increases width
        const delta: number = startXRef.current - moveEvent.clientX;
        const targetWidth: number = Math.max(220, Math.min(startWidthRef.current + delta, 560));
        onWidthChange?.(targetWidth);
      };

      const handleMouseUp: () => void = (): void => {
        isDraggingRef.current = false;
        document.removeEventListener("mousemove", handleMouseMove);
        document.removeEventListener("mouseup", handleMouseUp);
      };

      document.addEventListener("mousemove", handleMouseMove);
      document.addEventListener("mouseup", handleMouseUp);
    },
    [width, onWidthChange]
  );

  // Extract columns list from schema or metadata
  const columns: ColumnDetailInfo[] = React.useMemo(() => {
    if (!schema && !tableMetadata) return [];

    if (schema && typeof schema === "object" && "columns" in schema) {
      const colObj: Record<string, unknown> = (schema as { columns: Record<string, unknown> }).columns;
      if (typeof colObj === "object" && colObj !== null) {
        return Object.entries(colObj).map(([name, def]: [string, unknown]): ColumnDetailInfo => {
          if (typeof def === "object" && def !== null) {
            const d: { type?: string; primaryKey?: boolean; nullable?: boolean } = def as {
              type?: string;
              primaryKey?: boolean;
              nullable?: boolean;
            };
            return {
              name,
              type: d.type || "UNKNOWN",
              primaryKey: Boolean(d.primaryKey),
              nullable: d.nullable !== false,
            };
          }
          return { name, type: String(def) };
        });
      }
    }

    if (tableMetadata?.columns && Array.isArray(tableMetadata.columns)) {
      return tableMetadata.columns.map((c: string): ColumnDetailInfo => ({
        name: c,
        type: c.toLowerCase().includes("id") ? "INTEGER" : "VARCHAR",
        primaryKey: c.toLowerCase() === "id",
      }));
    }

    return [];
  }, [schema, tableMetadata]);

  const handleCopySnippet: (text: string, key: string) => void = (text: string, key: string): void => {
    if (typeof navigator !== "undefined" && navigator.clipboard) {
      navigator.clipboard.writeText(text);
      setCopiedSnippet(key);
      setTimeout((): void => setCopiedSnippet(null), 1500);
    }
  };

  if (!isOpen) return null;

  return (
    <aside
      id="studio-detail-content"
      role="complementary"
      aria-label="Table Details & Properties"
      className="word-detail-content vertical-view"
      style={{
        width: `${width}px`,
        minWidth: `${width}px`,
        maxWidth: `${width}px`,
      }}
    >
      {/* Left Edge Resize Handle */}
      {onWidthChange && (
        <div
          id="detail-content-resize-handle"
          role="separator"
          aria-orientation="vertical"
          aria-label="Resize detail inspector"
          className="detail-right-bar-resize-handle"
          onMouseDown={handleMouseDown}
          title="Drag to resize inspector"
        />
      )}

      {/* Header */}
      <div id="detail-content-header" className="word-detail-header">
        <div id="detail-header-title-wrap" className="word-detail-title-wrap">
          <IdeIcon name="Info" size="sm" color="var(--primary, #2563eb)" />
          <span id="detail-header-title-text" className="word-detail-title-text">
            Table Inspector
          </span>
          {activeTable && (
            <span id="detail-header-table-badge" className="stitch-inspector-table-badge">
              {activeTable}
            </span>
          )}
        </div>

        <Button
          id="btn-close-detail-content"
          variant="ghost"
          size="xs"
          className="word-detail-close-btn"
          onClick={onClose}
          title="Close Table Inspector"
          aria-label="Close Inspector"
        >
          <IdeIcon name="X" size="xs" />
        </Button>
      </div>

      {/* Sub Tabs: Schema / Info / SQL */}
      <div id="detail-content-tabs-bar" className="word-detail-tabs-bar" role="tablist">
        <button
          id="tab-detail-schema"
          role="tab"
          aria-selected={detailTab === "schema"}
          type="button"
          className={`word-detail-tab-btn ${detailTab === "schema" ? "active" : ""}`}
          onClick={(): void => setDetailTab("schema")}
        >
          <IdeIcon name="Columns" size="xs" />
          <span>Columns ({columns.length})</span>
        </button>

        <button
          id="tab-detail-info"
          role="tab"
          aria-selected={detailTab === "info"}
          type="button"
          className={`word-detail-tab-btn ${detailTab === "info" ? "active" : ""}`}
          onClick={(): void => setDetailTab("info")}
        >
          <IdeIcon name="Table" size="xs" />
          <span>Properties</span>
        </button>

        <button
          id="tab-detail-sql"
          role="tab"
          aria-selected={detailTab === "sql"}
          type="button"
          className={`word-detail-tab-btn ${detailTab === "sql" ? "active" : ""}`}
          onClick={(): void => setDetailTab("sql")}
        >
          <IdeIcon name="Code" size="xs" />
          <span>SQL Snippets</span>
        </button>
      </div>

      {/* Body Content */}
      <div id="detail-content-body" className="word-detail-body">
        {!activeTable ? (
          <div id="detail-empty-table-state" className="div-col div-center text-center p-6 gap-2 theme-text-muted">
            <IdeIcon name="MousePointer" size="lg" />
            <span className="text-xs">Select a table from the sidebar to inspect its schema and properties</span>
          </div>
        ) : (
          <>
            {/* Tab 1: Columns & Types */}
            {detailTab === "schema" && (
              <div id="detail-schema-section" className="word-detail-section">
                {/* Schema Definition Header */}
                <div id="detail-schema-header-row" className="stitch-schema-header-row">
                  <span id="detail-schema-def-title" className="stitch-schema-def-title">
                    SCHEMA DEFINITION
                  </span>
                  <span id="detail-schema-col-count" className="stitch-schema-col-count">
                    {columns.length} columns
                  </span>
                </div>

                <div id="detail-schema-columns-list" className="word-detail-columns-list">
                  {columns.length === 0 ? (
                    <div id="detail-no-columns" className="text-xs theme-text-muted p-3 text-center">
                      No columns found for {activeTable}
                    </div>
                  ) : (
                    columns.map((col: ColumnDetailInfo) => {
                      const displayType: string = col.type.includes("(")
                        ? col.type
                        : `${col.type}(255)`;
                      const nullableStatus: string = col.primaryKey
                        ? "NOT NULL · UNIQUE"
                        : col.nullable === false
                        ? "NOT NULL"
                        : "NULLABLE";

                      return (
                        <div
                          key={col.name}
                          id={`detail-col-item-${col.name}`}
                          className="stitch-column-card"
                        >
                          <div id={`detail-col-info-${col.name}`} className="stitch-column-card-top">
                            <div className="flex items-center gap-1.5 truncate">
                              <IdeIcon
                                name={col.primaryKey ? "Key" : "Equal"}
                                size="xs"
                                color={col.primaryKey ? "#f59e0b" : "var(--text-muted, #64748b)"}
                              />
                              <span
                                id={`detail-col-name-${col.name}`}
                                className="font-semibold text-xs theme-text truncate"
                              >
                                {col.name}
                              </span>
                              {col.primaryKey && (
                                <span
                                  id={`detail-col-pk-${col.name}`}
                                  className="stitch-pk-badge"
                                  title="Primary Key"
                                >
                                  PK
                                </span>
                              )}
                            </div>
                            <div id={`detail-col-badges-${col.name}`} className="flex items-center gap-1">
                              <span
                                id={`detail-col-type-${col.name}`}
                                className="stitch-type-badge"
                              >
                                {displayType}
                              </span>
                            </div>
                          </div>
                          <div id={`detail-col-status-row-${col.name}`} className="stitch-column-card-bottom">
                            <span
                              id={`detail-col-notnull-${col.name}`}
                              className="stitch-column-status-text"
                            >
                              {nullableStatus}
                            </span>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>

                {/* TABLE STATS in Columns tab (Stitch Design) */}
                <div id="detail-table-stats-section" className="stitch-table-stats-section">
                  <div id="detail-stats-header" className="stitch-stats-header">
                    TABLE STATS
                  </div>
                  <div id="detail-stats-list" className="stitch-stats-list">
                    <div id="detail-stat-engine" className="stitch-stat-row">
                      <span className="stitch-stat-label">Engine</span>
                      <span className="stitch-stat-value">InnoDB</span>
                    </div>
                    <div id="detail-stat-rows" className="stitch-stat-row">
                      <span className="stitch-stat-label">Rows count</span>
                      <span className="stitch-stat-value">{tableMetadata?.rowCount ?? 1}</span>
                    </div>
                    <div id="detail-stat-length" className="stitch-stat-row">
                      <span className="stitch-stat-label">Data length</span>
                      <span className="stitch-stat-value">16.0 KB</span>
                    </div>
                    <div id="detail-stat-collation" className="stitch-stat-row">
                      <span className="stitch-stat-label">Collation</span>
                      <span className="stitch-stat-value font-mono">utf8mb4_unicode_ci</span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Tab 2: Table Properties & Metadata */}
            {detailTab === "info" && (
              <div id="detail-info-section" className="word-detail-section p-3 div-col gap-3">
                <div id="detail-prop-table-name" className="word-detail-prop-item">
                  <span className="word-detail-prop-label">Table Name:</span>
                  <span className="word-detail-prop-value font-semibold">{activeTable}</span>
                </div>
                <div id="detail-prop-db-name" className="word-detail-prop-item">
                  <span className="word-detail-prop-label">Database:</span>
                  <span className="word-detail-prop-value">{activeDatabase}</span>
                </div>
                <div id="detail-prop-rows" className="word-detail-prop-item">
                  <span className="word-detail-prop-label">Record Count:</span>
                  <span className="word-detail-prop-value">{tableMetadata?.rowCount ?? "—"} rows</span>
                </div>
                <div id="detail-prop-cols" className="word-detail-prop-item">
                  <span className="word-detail-prop-label">Column Count:</span>
                  <span className="word-detail-prop-value">{columns.length} columns</span>
                </div>
                <div id="detail-prop-engine" className="word-detail-prop-item">
                  <span className="word-detail-prop-label">Storage Engine:</span>
                  <span className="word-detail-prop-value">SQLite / LocalSQLServer</span>
                </div>
              </div>
            )}

            {/* Tab 3: Generated SQL Snippets */}
            {detailTab === "sql" && (
              <div id="detail-sql-section" className="word-detail-section p-3 div-col gap-3">
                {/* Snippet 1: SELECT TOP 50 */}
                <div id="detail-snippet-select-all" className="word-detail-snippet-card">
                  <div className="div-row justify-between items-center mb-1">
                    <span className="text-xs font-semibold theme-text">Quick Select</span>
                    <div className="div-row gap-1">
                      <Button
                        id="btn-copy-snippet-select"
                        variant="ghost"
                        size="xs"
                        onClick={(): void => handleCopySnippet(`SELECT * FROM ${activeTable} LIMIT 50;`, "select")}
                        title="Copy query"
                      >
                        <IdeIcon name={copiedSnippet === "select" ? "Check" : "Copy"} size="xs" />
                      </Button>
                      {onRunSnippetInConsole && (
                        <Button
                          id="btn-run-snippet-select"
                          variant="ghost"
                          size="xs"
                          onClick={(): void => onRunSnippetInConsole(`SELECT * FROM ${activeTable} LIMIT 50;`)}
                          title="Run in Console"
                        >
                          <IdeIcon name="Play" size="xs" color="var(--primary, #2563eb)" />
                        </Button>
                      )}
                    </div>
                  </div>
                  <pre className="word-detail-code-block">{`SELECT * FROM ${activeTable} LIMIT 50;`}</pre>
                </div>

                {/* Snippet 2: COUNT */}
                <div id="detail-snippet-count" className="word-detail-snippet-card">
                  <div className="div-row justify-between items-center mb-1">
                    <span className="text-xs font-semibold theme-text">Count Rows</span>
                    <div className="div-row gap-1">
                      <Button
                        id="btn-copy-snippet-count"
                        variant="ghost"
                        size="xs"
                        onClick={(): void => handleCopySnippet(`SELECT COUNT(*) AS total FROM ${activeTable};`, "count")}
                        title="Copy query"
                      >
                        <IdeIcon name={copiedSnippet === "count" ? "Check" : "Copy"} size="xs" />
                      </Button>
                      {onRunSnippetInConsole && (
                        <Button
                          id="btn-run-snippet-count"
                          variant="ghost"
                          size="xs"
                          onClick={(): void => onRunSnippetInConsole(`SELECT COUNT(*) AS total FROM ${activeTable};`)}
                          title="Run in Console"
                        >
                          <IdeIcon name="Play" size="xs" color="var(--primary, #2563eb)" />
                        </Button>
                      )}
                    </div>
                  </div>
                  <pre className="word-detail-code-block">{`SELECT COUNT(*) AS total FROM ${activeTable};`}</pre>
                </div>
              </div>
            )}
          </>
        )}
      </div>

      {/* Footer Actions (Stitch Design: + Add Column, </> DDL) */}
      <div id="detail-content-footer" className="stitch-inspector-footer">
        <Button
          id="btn-inspector-add-column"
          variant="secondary"
          size="xs"
          className="stitch-inspector-btn"
          title="Add Column"
        >
          <IdeIcon name="Plus" size="xs" className="mr-1" />
          <span>Add Column</span>
        </Button>
        <Button
          id="btn-inspector-ddl"
          variant="secondary"
          size="xs"
          className="stitch-inspector-btn"
          title="DDL"
          onClick={(): void => onRunSnippetInConsole?.(`SHOW CREATE TABLE ${activeTable};`)}
        >
          <IdeIcon name="Code" size="xs" className="mr-1" />
          <span>DDL</span>
        </Button>
      </div>
    </aside>
  );
};
