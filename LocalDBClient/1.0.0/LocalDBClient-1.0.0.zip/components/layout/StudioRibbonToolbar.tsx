"use client";

import React from "react";
import { Button, IdeIcon } from "../bases";
import type { McpSubTab } from "../mcp/McpExplorer";

export type SqlSubTab = "explorer" | "erd" | "console" | "performance";
export type VectorSubTab = "collections" | "upload" | "related" | "knowledge" | "training" | "telemetry";

export interface StudioRibbonToolbarProps {
  readonly isSqlMode: boolean;
  readonly activeSqlTab: SqlSubTab;
  readonly onChangeSqlTab: (tab: SqlSubTab) => void;
  readonly activeVectorTab: VectorSubTab;
  readonly onChangeVectorTab: (tab: VectorSubTab) => void;
  readonly isMcpMode?: boolean;
  readonly activeMcpTab?: McpSubTab;
  readonly onChangeMcpTab?: (tab: McpSubTab) => void;
  readonly onRefresh: () => void;
  readonly isRefreshing: boolean;
  readonly activeTable: string | null;
  readonly onOpenInConsole?: (tableName: string) => void;
  readonly onOpenErdSchema?: () => void;
  readonly isDetailOpen: boolean;
  readonly onToggleDetail: () => void;
  readonly isSidebarOpen: boolean;
  readonly onToggleSidebar: () => void;
  readonly onExportTable?: () => void;
  readonly databases?: string[];
  readonly activeDatabase?: string;
  readonly onSelectDatabase?: (name: string) => void;
  readonly onCreateDatabase?: (name: string) => Promise<void> | void;
}

interface RibbonTabDef<T extends string> {
  readonly id: T;
  readonly label: string;
  readonly icon: string;
  readonly title: string;
}

const SQL_RIBBON_TABS: RibbonTabDef<SqlSubTab>[] = [
  {
    id: "explorer",
    label: "Tables Explorer",
    icon: "Table",
    title: "Tables Explorer — Browse tables, inspect record columns, and view data grids",
  },
  {
    id: "erd",
    label: "ERD Schema",
    icon: "Network",
    title: "ERD / ERP Schema — View entity relationships, XML ERP mapping, foreign keys, and table schemas",
  },
  {
    id: "console",
    label: "Query Console",
    icon: "Terminal",
    title: "Query Console — Execute custom SQL statements, run queries, and export results",
  },
  {
    id: "performance",
    label: "Performance",
    icon: "Activity",
    title: "Performance & Diagnostics — Server metrics, query throughput, cache hit rates",
  },
];

const VECTOR_RIBBON_TABS: RibbonTabDef<VectorSubTab>[] = [
  { id: "collections", label: "Collections Explorer", icon: "Boxes", title: "Collections Explorer" },
  { id: "upload", label: "Upload", icon: "UploadCloud", title: "Conversation & Vector Importer" },
  { id: "related", label: "Search", icon: "Search", title: "Vector Similarity & Related Conversations" },
  { id: "knowledge", label: "Knowledge Base", icon: "BookOpen", title: "Knowledge Base Documents" },
  { id: "training", label: "Training Exporter", icon: "Cpu", title: "Fine-Tuning Dataset Exporter" },
  { id: "telemetry", label: "Telemetry", icon: "Activity", title: "Vector Engine Telemetry" },
];

const MCP_RIBBON_TABS: RibbonTabDef<McpSubTab>[] = [
  { id: "tools", label: "Tools", icon: "Wrench", title: "Tools — Browse and call available MCP tools" },
  { id: "resources", label: "Resources", icon: "FileCode2", title: "Resources — Read and inspect MCP resources" },
  { id: "prompts", label: "Prompts", icon: "MessageSquare", title: "Prompts — View MCP prompt templates" },
  { id: "console", label: "Console", icon: "Terminal", title: "Console — Test and run MCP tool calls" },
];

export const StudioRibbonToolbar: React.FC<StudioRibbonToolbarProps> = ({
  isSqlMode,
  activeSqlTab,
  onChangeSqlTab,
  activeVectorTab,
  onChangeVectorTab,
  isMcpMode,
  activeMcpTab,
  onChangeMcpTab,
  onRefresh: _onRefresh,
  isRefreshing: _isRefreshing,
  activeTable: _activeTable,
  onOpenInConsole: _onOpenInConsole,
  onOpenErdSchema: _onOpenErdSchema,
  isDetailOpen,
  onToggleDetail,
  isSidebarOpen,
  onToggleSidebar,
  onExportTable: _onExportTable,
  databases: _databases,
  activeDatabase: _activeDatabase,
  onSelectDatabase: _onSelectDatabase,
  onCreateDatabase: _onCreateDatabase,
}) => {
  return (
    <div id="studio-ribbon-toolbar" role="region" aria-label="Ribbon Toolbar" className="word-ribbon-bar">
      {/* ── 1. Top Ribbon Tabs Strip (Word Style / Stitch Design) ── */}
      <div id="studio-ribbon-tabs-strip" className="word-ribbon-tabs-strip">
        <div id="studio-ribbon-tabs-nav" className="word-ribbon-tabs-nav" role="tablist">
          {isSqlMode
            ? SQL_RIBBON_TABS.map((tab: RibbonTabDef<SqlSubTab>) => {
                const isActive: boolean = activeSqlTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    id={`ribbon-tab-${tab.id}`}
                    role="tab"
                    aria-selected={isActive}
                    aria-label={tab.label}
                    type="button"
                    className={`word-ribbon-tab-btn ${isActive ? "active" : ""}`}
                    onClick={(): void => onChangeSqlTab(tab.id)}
                    title={tab.title}
                  >
                    <IdeIcon
                      name={tab.icon}
                      size="sm"
                      color={isActive ? "var(--primary, #2563eb)" : "currentColor"}
                    />
                  </button>
                );
              })
            : isMcpMode
            ? MCP_RIBBON_TABS.map((tab: RibbonTabDef<McpSubTab>) => {
                const isActive: boolean = activeMcpTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    id={`ribbon-tab-${tab.id}`}
                    role="tab"
                    aria-selected={isActive}
                    aria-label={tab.label}
                    type="button"
                    className={`word-ribbon-tab-btn ${isActive ? "active" : ""}`}
                    onClick={(): void => onChangeMcpTab?.(tab.id)}
                    title={tab.title}
                  >
                    <IdeIcon
                      name={tab.icon}
                      size="sm"
                      color={isActive ? "var(--mcp-accent, #16a34a)" : "currentColor"}
                    />
                  </button>
                );
              })
            : VECTOR_RIBBON_TABS.map((tab: RibbonTabDef<VectorSubTab>) => {
                const isActive: boolean = activeVectorTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    id={`ribbon-tab-${tab.id}`}
                    role="tab"
                    aria-selected={isActive}
                    aria-label={tab.label}
                    type="button"
                    className={`word-ribbon-tab-btn ${isActive ? "active" : ""}`}
                    onClick={(): void => onChangeVectorTab(tab.id)}
                    title={tab.title}
                  >
                    <IdeIcon
                      name={tab.icon}
                      size="sm"
                      color={isActive ? "var(--primary, #2563eb)" : "currentColor"}
                    />
                  </button>
                );
              })}
        </div>

        {/* Right-aligned Panel Toggles in Ribbon Tab Bar (Word Style) */}
        <div id="studio-ribbon-tab-right-toggles" className="word-ribbon-right-toggles">
          <Button
            id="btn-toggle-left-sidebar"
            variant="ghost"
            size="xs"
            className={`word-ribbon-toggle-btn ${isSidebarOpen ? "active" : ""}`}
            onClick={onToggleSidebar}
            title={isSidebarOpen ? "Collapse Navigation Sidebar" : "Expand Navigation Sidebar"}
            aria-label={isSidebarOpen ? "Collapse Sidebar" : "Expand Sidebar"}
          >
            <IdeIcon name={isSidebarOpen ? "PanelLeftClose" : "PanelLeft"} size="sm" />
          </Button>

          <Button
            id="btn-toggle-detail-content"
            variant="ghost"
            size="xs"
            className={`word-ribbon-toggle-btn ${isDetailOpen ? "active" : ""}`}
            onClick={onToggleDetail}
            title={isDetailOpen ? "Collapse Table Detail Panel" : "Expand Table Detail Panel"}
            aria-label={isDetailOpen ? "Collapse Detail" : "Expand Detail"}
          >
            <IdeIcon name={isDetailOpen ? "PanelRightClose" : "PanelRight"} size="sm" />
          </Button>
        </div>
      </div>
    </div>
  );
};
