"use client";

import React from "react";
import { Button, IdeIcon } from "../bases";

export interface StudioBottomStatusBarProps {
  readonly isConnected: boolean;
  readonly serviceName: string;
  readonly endpoint: string;
  readonly latencyMs: number | null;
  readonly activeDatabase: string;
  readonly activeTable: string | null;
  readonly recordCount: number | null;
  readonly isSidebarOpen: boolean;
  readonly onToggleSidebar: () => void;
  readonly isDetailOpen: boolean;
  readonly onToggleDetail: () => void;
}

export const StudioBottomStatusBar: React.FC<StudioBottomStatusBarProps> = ({
  isConnected,
  serviceName,
  endpoint,
  latencyMs,
  activeDatabase,
  activeTable,
  recordCount,
  isSidebarOpen,
  onToggleSidebar,
  isDetailOpen,
  onToggleDetail,
}) => {
  return (
    <footer id="studio-bottom-status-bar" role="contentinfo" aria-label="Status Bar" className="word-status-bar">
      {/* ── Left Status Group: Connection & Engine ── */}
      <div id="status-bar-left-group" className="word-status-group">
        <div id="status-indicator-wrap" className="word-status-item">
          <span
            id="status-dot"
            className={`word-status-dot ${isConnected ? "connected" : "disconnected"}`}
          />
          <span id="status-text" className="font-medium">
            {isConnected ? "Connected" : "Disconnected"}
          </span>
        </div>

        <div id="status-service-wrap" className="word-status-item">
          <span className="theme-text-muted">Type:</span>
          <span id="status-service-val" className="font-semibold">
            {serviceName}
          </span>
        </div>

        <div id="status-endpoint-wrap" className="word-status-item font-mono text-xs">
          <span id="status-endpoint-val">{endpoint}</span>
        </div>

        {latencyMs !== null && (
          <div id="status-latency-wrap" className="word-status-item">
            <IdeIcon name="Zap" size="xs" color="#10b981" />
            <span id="status-latency-val">{latencyMs}ms</span>
          </div>
        )}
      </div>

      {/* ── Center Status Group: Active Context (Database & Table) ── */}
      <div id="status-bar-center-group" className="word-status-group">
        <div id="status-db-wrap" className="word-status-item">
          <IdeIcon name="Database" size="xs" className="mr-1" />
          <span className="theme-text-muted">db:</span>
          <span id="status-db-val" className="font-medium">
            {activeDatabase}
          </span>
        </div>

        {activeTable && (
          <div id="status-table-wrap" className="word-status-item">
            <IdeIcon name={serviceName === "Vector" ? "Layers" : "Table"} size="xs" className="mr-1" />
            <span className="theme-text-muted">{serviceName === "Vector" ? "col:" : "table:"}</span>
            <span id="status-table-val" className="font-semibold text-primary">
              {activeTable}
            </span>
          </div>
        )}
      </div>

      {/* ── Right Status Group: Records & Panel Toggles ── */}
      <div id="status-bar-right-group" className="word-status-group">
        <div id="status-encoding-wrap" className="word-status-item text-xs theme-text-muted">
          <span id="status-encoding-val">UTF-8</span>
        </div>

        {recordCount !== null && (
          <div id="status-records-wrap" className="word-status-item">
            <span id="status-records-val" className="font-medium">
              {recordCount} rows
            </span>
          </div>
        )}

        {/* Panel Toggles */}
        <div id="status-toggles-wrap" className="word-status-toggles">
          <Button
            id="status-btn-toggle-sidebar"
            variant="ghost"
            size="xs"
            className={`word-status-btn ${isSidebarOpen ? "active" : ""}`}
            onClick={onToggleSidebar}
            title={isSidebarOpen ? "Hide Sidebar" : "Show Sidebar"}
            aria-label="Toggle Sidebar"
          >
            <IdeIcon name={isSidebarOpen ? "PanelLeftClose" : "PanelLeft"} size="xs" />
          </Button>

          <Button
            id="status-btn-toggle-detail"
            variant="ghost"
            size="xs"
            className={`word-status-btn ${isDetailOpen ? "active" : ""}`}
            onClick={onToggleDetail}
            title={isDetailOpen ? "Hide Table Details" : "Show Table Details"}
            aria-label="Toggle Table Details"
          >
            <IdeIcon name={isDetailOpen ? "PanelRightClose" : "PanelRight"} size="xs" />
          </Button>
        </div>
      </div>
    </footer>
  );
};
