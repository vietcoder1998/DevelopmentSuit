/**
 * Canonical 2-TEK Response Standards implementation.
 * Governing RESTful API, Model Context Protocol (MCP), and Socket responses.
 * Rule Reference: Rule 72 & Section 590 (.agents/standards/response-standards.md)
 */

// ── 1. RESTful API Response Contracts ────────────────────────────────────────

export interface RestApiPagination {
  page: number;
  pageSize: number;
  total: number;
  totalPages: number;
  hasNext: boolean;
  hasPrev: boolean;
}

export interface RestApiSuccessResponse<T = unknown> {
  success: true;
  ok?: boolean;
  data: T;
  error: null;
  meta: {
    timestamp: number;
    durationMs?: number;
    version?: string;
    requestId?: string;
    [key: string]: unknown;
  };
  pagination?: RestApiPagination;
}

export interface RestApiErrorDescriptor {
  code: string;
  message: string;
  details?: unknown;
}

export interface RestApiErrorResponse {
  success: false;
  ok?: boolean;
  data: null;
  error: RestApiErrorDescriptor;
  meta: {
    timestamp: number;
    durationMs?: number;
    requestId?: string;
    [key: string]: unknown;
  };
}

export type RestApiResponse<T = unknown> = RestApiSuccessResponse<T> | RestApiErrorResponse;

// ── 2. MCP (Model Context Protocol) Response Contracts ───────────────────────

export interface McpContentText {
  type: "text";
  text: string;
}

export interface McpContentImage {
  type: "image";
  data: string;
  mimeType: string;
}

export interface McpContentResource {
  type: "resource";
  resource: {
    uri: string;
    text?: string;
    blob?: string;
    mimeType?: string;
  };
}

export type McpContentItem = McpContentText | McpContentImage | McpContentResource;

export interface McpToolCallResult {
  content: McpContentItem[];
  isError?: boolean;
  _meta?: {
    durationMs?: number;
    timestamp?: number;
    toolName?: string;
    [key: string]: unknown;
  };
}

export interface McpToolDefinition {
  name: string;
  description: string;
  inputSchema: {
    type: "object";
    properties: Record<string, unknown>;
    required?: string[];
  };
}

export interface McpResourceDefinition {
  uri: string;
  name: string;
  description?: string;
  mimeType?: string;
}

export interface McpPromptArgument {
  name: string;
  description?: string;
  required?: boolean;
}

export interface McpPromptDefinition {
  name: string;
  description?: string;
  arguments?: McpPromptArgument[];
}

export interface McpListToolsResult {
  tools: McpToolDefinition[];
  nextCursor?: string | null;
}

export interface McpListResourcesResult {
  resources: McpResourceDefinition[];
  nextCursor?: string | null;
}

export interface McpListPromptsResult {
  prompts: McpPromptDefinition[];
  nextCursor?: string | null;
}

export interface McpJsonRpcSuccess<T = unknown> {
  jsonrpc: "2.0";
  id: string | number | null;
  result: T;
  error?: undefined;
}

export interface McpJsonRpcError {
  jsonrpc: "2.0";
  id: string | number | null;
  result?: undefined;
  error: {
    code: number;
    message: string;
    data?: unknown;
  };
}

export type McpJsonRpcResponse<T = unknown> = McpJsonRpcSuccess<T> | McpJsonRpcError;

// ── 3. Socket & Real-Time Response Contracts ─────────────────────────────────

export interface SocketResponsePacket<T = unknown> {
  event: string;
  status: "ok" | "error" | "pending";
  payload: T;
  error?: {
    code: string;
    message: string;
    details?: unknown;
  } | null;
  timestamp: number;
  ackId?: string;
  channelId?: string;
}

export interface SocketStreamChunk<T = string> {
  event: "stream:chunk";
  streamId: string;
  sequence: number;
  chunk: T;
  isComplete: false;
  timestamp: number;
}

export interface SocketStreamEnd {
  event: "stream:end";
  streamId: string;
  sequence: number;
  isComplete: true;
  totalTokens?: number;
  durationMs?: number;
  timestamp: number;
}

export type SocketStreamFrame<T = string> = SocketStreamChunk<T> | SocketStreamEnd;

// ── 4. Standard Response Builders ────────────────────────────────────────────

export function createApiResponse<T>(
  data: T,
  meta?: Partial<RestApiSuccessResponse<T>["meta"]>,
  pagination?: RestApiPagination
): RestApiSuccessResponse<T> {
  const timestamp: number = meta?.timestamp ?? Date.now();
  return {
    success: true,
    ok: true,
    data,
    error: null,
    meta: {
      timestamp,
      ...meta,
    },
    ...(pagination ? { pagination } : {}),
  };
}

export function createApiErrorResponse(
  code: string,
  message: string,
  details?: unknown,
  meta?: Partial<RestApiErrorResponse["meta"]>
): RestApiErrorResponse {
  const timestamp: number = meta?.timestamp ?? Date.now();
  return {
    success: false,
    ok: false,
    data: null,
    error: {
      code,
      message,
      ...(details !== undefined ? { details } : {}),
    },
    meta: {
      timestamp,
      ...meta,
    },
  };
}

export function createMcpToolResult(
  contentInput: string | McpContentItem[],
  isError: boolean = false,
  meta?: Record<string, unknown>
): McpToolCallResult {
  const content: McpContentItem[] =
    typeof contentInput === "string"
      ? [{ type: "text", text: contentInput }]
      : contentInput;

  return {
    content,
    isError,
    _meta: {
      timestamp: Date.now(),
      ...meta,
    },
  };
}

export function createMcpErrorResult(
  errorMessage: string,
  meta?: Record<string, unknown>
): McpToolCallResult {
  return createMcpToolResult(errorMessage, true, meta);
}

export function createMcpJsonRpcSuccess<T>(
  id: string | number | null,
  result: T
): McpJsonRpcSuccess<T> {
  return {
    jsonrpc: "2.0",
    id,
    result,
  };
}

export function createMcpJsonRpcError(
  id: string | number | null,
  code: number,
  message: string,
  data?: unknown
): McpJsonRpcError {
  return {
    jsonrpc: "2.0",
    id,
    error: {
      code,
      message,
      ...(data !== undefined ? { data } : {}),
    },
  };
}

export function createSocketPacket<T>(
  event: string,
  payload: T,
  ackId?: string,
  channelId?: string
): SocketResponsePacket<T> {
  return {
    event,
    status: "ok",
    payload,
    error: null,
    timestamp: Date.now(),
    ...(ackId ? { ackId } : {}),
    ...(channelId ? { channelId } : {}),
  };
}

export function createSocketErrorPacket(
  event: string,
  code: string,
  message: string,
  details?: unknown,
  ackId?: string
): SocketResponsePacket<null> {
  return {
    event,
    status: "error",
    payload: null,
    error: {
      code,
      message,
      ...(details !== undefined ? { details } : {}),
    },
    timestamp: Date.now(),
    ...(ackId ? { ackId } : {}),
  };
}

export function createSocketStreamChunk<T = string>(
  streamId: string,
  sequence: number,
  chunk: T
): SocketStreamChunk<T> {
  return {
    event: "stream:chunk",
    streamId,
    sequence,
    chunk,
    isComplete: false,
    timestamp: Date.now(),
  };
}

export function createSocketStreamEnd(
  streamId: string,
  sequence: number,
  meta?: { totalTokens?: number; durationMs?: number }
): SocketStreamEnd {
  return {
    event: "stream:end",
    streamId,
    sequence,
    isComplete: true,
    totalTokens: meta?.totalTokens,
    durationMs: meta?.durationMs,
    timestamp: Date.now(),
  };
}

// ── 5. Standard Type Guards & Parsers ────────────────────────────────────────

export function isRestApiSuccess<T>(res: unknown): res is RestApiSuccessResponse<T> {
  if (typeof res !== "object" || res === null) return false;
  const obj: Record<string, unknown> = res as Record<string, unknown>;
  return obj.success === true && "data" in obj;
}

export function isRestApiError(res: unknown): res is RestApiErrorResponse {
  if (typeof res !== "object" || res === null) return false;
  const obj: Record<string, unknown> = res as Record<string, unknown>;
  return obj.success === false && typeof obj.error === "object" && obj.error !== null;
}

export function isMcpToolCallResult(res: unknown): res is McpToolCallResult {
  if (typeof res !== "object" || res === null) return false;
  const obj: Record<string, unknown> = res as Record<string, unknown>;
  return Array.isArray(obj.content);
}

export function isSocketPacket<T>(pkt: unknown): pkt is SocketResponsePacket<T> {
  if (typeof pkt !== "object" || pkt === null) return false;
  const obj: Record<string, unknown> = pkt as Record<string, unknown>;
  return typeof obj.event === "string" && (obj.status === "ok" || obj.status === "error" || obj.status === "pending");
}

export function parseApiResponse<T>(raw: unknown): RestApiResponse<T> {
  if (isRestApiSuccess<T>(raw)) {
    return raw;
  }
  if (isRestApiError(raw)) {
    return raw;
  }
  // Graceful fallback for legacy responses missing top-level success wrapper
  if (typeof raw === "object" && raw !== null) {
    const obj: Record<string, unknown> = raw as Record<string, unknown>;
    if (obj.ok === true || obj.success === true) {
      return createApiResponse<T>((obj.data ?? obj) as T);
    }
    if (obj.error) {
      const errMsg: string = typeof obj.error === "string" ? obj.error : String(obj.message || "Unknown error");
      return createApiErrorResponse("LEGACY_ERROR", errMsg, obj.details ?? obj);
    }
    return createApiResponse<T>(raw as T);
  }
  return createApiResponse<T>(raw as T);
}
