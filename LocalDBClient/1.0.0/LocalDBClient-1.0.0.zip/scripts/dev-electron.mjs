/**
 * packages/LocalDBClient/scripts/dev-electron.mjs
 * ─────────────────────────────────────────────────────────────────────────────
 * 2-TEK LocalDBClient — Dev Runner with Native Electron Window
 * Starts Next.js dev server on port 3033 (or reuses active server), waits for
 * HTTP readiness, and launches the Electron desktop application.
 * ─────────────────────────────────────────────────────────────────────────────
 */

import http from "node:http";
import { spawn } from "node:child_process";
import * as path from "node:path";
import * as fs from "node:fs";
import { fileURLToPath } from "node:url";

const currentModulePath = fileURLToPath(import.meta.url);
const currentModuleDir = path.dirname(currentModulePath);
const appDirectory = path.resolve(currentModuleDir, "..");
const workspaceRootDirectory = path.resolve(appDirectory, "..", "..");

function resolvePortFromEnv() {
  try {
    if (typeof process !== "undefined" && process.env) {
      if (process.env.PORT) {
        const parsed = parseInt(process.env.PORT, 10);
        if (!Number.isNaN(parsed) && parsed > 0) return parsed;
      }
      if (process.env.LOCALDBCLIENT_PORT) {
        const parsed = parseInt(process.env.LOCALDBCLIENT_PORT, 10);
        if (!Number.isNaN(parsed) && parsed > 0) return parsed;
      }
    }
  } catch {
    // Ignore resolution errors
  }
  return 3033;
}

const TARGET_PORT = resolvePortFromEnv();
const DEV_SERVER_URL = `http://localhost:${TARGET_PORT}`;
const DEV_FALLBACK_URL = `http://127.0.0.1:${TARGET_PORT}`;
const MAXIMUM_POLL_ATTEMPTS = 60;
const POLL_INTERVAL_MS = 500;

let nextServerProcess = null;
let electronChildProcess = null;
let isCleanExit = false;

function checkServerReady(targetUrl = DEV_SERVER_URL) {
  return new Promise((resolve) => {
    const req = http.get(targetUrl, (res) => {
      resolve(true);
      res.resume();
    });

    req.on("error", () => {
      // Try 127.0.0.1 if localhost failed
      if (targetUrl.includes("localhost:")) {
        const fallbackReq = http.get(DEV_FALLBACK_URL, (res) => {
          resolve(true);
          res.resume();
        });
        fallbackReq.on("error", () => resolve(false));
        fallbackReq.setTimeout(800, () => {
          fallbackReq.destroy();
          resolve(false);
        });
      } else {
        resolve(false);
      }
    });

    req.setTimeout(800, () => {
      req.destroy();
      resolve(false);
    });
  });
}

async function waitForServer(targetUrl = DEV_SERVER_URL) {
  console.log(`[LocalDBClient Runner] Waiting for dev server at ${targetUrl}...`);
  for (let attempt = 1; attempt <= MAXIMUM_POLL_ATTEMPTS; attempt++) {
    const isReady = await checkServerReady(targetUrl);
    if (isReady) {
      console.log(`[LocalDBClient Runner] Dev server is ready at ${targetUrl} (attempt ${attempt})`);
      return true;
    }
    await new Promise((resolve) => setTimeout(resolve, POLL_INTERVAL_MS));
  }
  console.warn(`[LocalDBClient Runner] Server did not respond within timeout, proceeding to launch Electron anyway.`);
  return false;
}

function resolveElectronBinary() {
  const isWindows = process.platform === "win32";
  const binaryName = isWindows ? "electron.exe" : "electron";
  const cmdName = isWindows ? "electron.cmd" : "electron";

  const candidates = [
    path.join(appDirectory, "node_modules", "electron", "dist", binaryName),
    path.join(workspaceRootDirectory, "node_modules", "electron", "dist", binaryName),
    path.join(appDirectory, "node_modules", ".bin", cmdName),
    path.join(workspaceRootDirectory, "node_modules", ".bin", cmdName),
  ];

  for (const candidate of candidates) {
    if (fs.existsSync(candidate)) {
      return candidate;
    }
  }

  return isWindows ? "electron.cmd" : "electron";
}

function cleanupProcesses() {
  if (isCleanExit) return;
  isCleanExit = true;

  if (electronChildProcess && !electronChildProcess.killed) {
    try {
      electronChildProcess.kill("SIGTERM");
    } catch {
      // Ignore
    }
  }

  if (nextServerProcess && !nextServerProcess.killed) {
    try {
      console.log("[LocalDBClient Runner] Stopping Next.js dev server...");
      nextServerProcess.kill("SIGTERM");
    } catch {
      // Ignore
    }
  }
}

async function startDevElectron() {
  // 1. Check if server already running on port
  const alreadyRunning = await checkServerReady(DEV_SERVER_URL);

  if (alreadyRunning) {
    console.log(`[LocalDBClient Runner] Existing dev server detected at ${DEV_SERVER_URL}. Reusing it.`);
  } else {
    console.log(`[LocalDBClient Runner] Starting Next.js dev server on port ${TARGET_PORT}...`);
    nextServerProcess = spawn("npx", ["next", "dev", "-p", String(TARGET_PORT)], {
      cwd: appDirectory,
      stdio: "inherit",
      shell: true,
      env: {
        ...process.env,
        PORT: String(TARGET_PORT),
      },
    });

    nextServerProcess.on("error", (err) => {
      console.error("[LocalDBClient Runner] Next.js dev server error:", err);
    });

    nextServerProcess.on("exit", (code) => {
      if (!isCleanExit) {
        console.log(`[LocalDBClient Runner] Next.js server exited with code ${code}`);
        cleanupProcesses();
        process.exit(code ?? 0);
      }
    });

    // 2. Wait for HTTP readiness
    await waitForServer(DEV_SERVER_URL);
  }

  // 3. Launch Electron
  const electronBin = resolveElectronBinary();
  const electronMainScript = path.join(appDirectory, "electron", "main.js");

  console.log(`[LocalDBClient Runner] Launching Electron with ${electronBin}...`);
  electronChildProcess = spawn(electronBin, [electronMainScript], {
    cwd: appDirectory,
    stdio: "inherit",
    shell: false,
    env: {
      ...process.env,
      ELECTRON_IS_DEV: "1",
      DEV_URL: DEV_SERVER_URL,
      PORT: String(TARGET_PORT),
    },
  });

  electronChildProcess.on("error", (err) => {
    console.error("[LocalDBClient Runner] Electron launch error:", err);
    cleanupProcesses();
    process.exit(1);
  });

  electronChildProcess.on("exit", (code) => {
    console.log(`[LocalDBClient Runner] Electron window closed (exit code: ${code}).`);
    cleanupProcesses();
    process.exit(code ?? 0);
  });

  // Signal handlers
  process.on("SIGINT", () => {
    console.log("\n[LocalDBClient Runner] Received SIGINT, shutting down...");
    cleanupProcesses();
    process.exit(0);
  });

  process.on("SIGTERM", () => {
    console.log("\n[LocalDBClient Runner] Received SIGTERM, shutting down...");
    cleanupProcesses();
    process.exit(0);
  });

  process.on("exit", () => {
    cleanupProcesses();
  });
}

startDevElectron().catch((err) => {
  console.error("[LocalDBClient Runner] Fatal startup error:", err);
  cleanupProcesses();
  process.exit(1);
});
