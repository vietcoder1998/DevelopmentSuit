"use client";

import React from "react";
import Link from "next/link";
import { Container, DivCard, Button, IdeIcon } from "../components/bases";

export default function NotFound(): React.ReactElement {
  return (
    <Container id="localdbclient-not-found-container" className="div-center theme-page-layout">
      <DivCard id="localdbclient-not-found-card" className="div-col div-center text-center p-8 gap-4">
        <IdeIcon name="AlertTriangle" size="xl" className="text-warning" />
        <h2 id="localdbclient-not-found-title" className="theme-text text-xl font-bold">
          404 — Page Not Found
        </h2>
        <p id="localdbclient-not-found-message" className="theme-text-muted text-sm">
          The requested database studio resource could not be found.
        </p>
        <Link href="/">
          <Button id="localdbclient-return-home-btn" variant="primary" className="mt-2">
            <IdeIcon name="Home" size="sm" />
            <span>Return to Studio</span>
          </Button>
        </Link>
      </DivCard>
    </Container>
  );
}
