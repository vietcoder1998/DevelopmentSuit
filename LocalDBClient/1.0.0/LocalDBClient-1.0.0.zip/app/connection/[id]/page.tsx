"use client";

import React, { useState, useEffect, useCallback, useRef } from "react";
import { useRouter, useParams } from "next/navigation";
import {
  IdeIcon,
  Input,
  Modal,
  Button,
  useResizableSidebar,
  SidebarResizeHandle,
  UseResizableSidebarResult,
} from "../../../components/bases";
import { useSafeTranslations } from "../../../components/bases/use-safe-translations";
import {
  ServiceConnectionState,
  SavedConnectionProfile,
  DEFAULT_SQL_CONNECTION,
  DEFAULT_VECTOR_CONNECTION,
  DEFAULT_MCP_CONNECTION,
  INITIAL_SAVED_CONNECTIONS,
  ConnectionProtocol,
} from "../../../components/connection/connection-types";
import { McpExplorer } from "../../../components/mcp/McpExplorer";
import { FastDatabaseSwitcher, ErdSchemaViewer } from "../../../components/sql";
import { TablesExplorer, TableItemMetadata, CellDataType } from "../../../components/sql/TablesExplorer";
import { QueryConsole, QueryResultData } from "../../../components/sql/QueryConsole";
import { PerformanceDashboard, PerformanceMetrics } from "../../../components/sql/PerformanceDashboard";
import { CollectionsExplorer, CollectionItem } from "../../../components/vector/CollectionsExplorer";
import { ConversationUploader, MessageInput } from "../../../components/vector/ConversationUploader";
import { RelatedConversationsView, RelatedItem } from "../../../components/vector/RelatedConversationsView";
import { KnowledgeBaseExplorer, KnowledgeDocItem } from "../../../components/vector/KnowledgeBaseExplorer";
import { TrainingExporter } from "../../../components/vector/TrainingExporter";
import { PerformanceTelemetry, TelemetryData } from "../../../components/vector/PerformanceTelemetry";
import {
  StudioRibbonToolbar,
  StudioDetailContent,
  StudioBottomStatusBar,
  SqlSubTab,
  VectorSubTab,
} from "../../../components/layout";

export default function ConnectionStudioPage(): React.ReactElement {
  const t: (key: string, fallback: string) => string = useSafeTranslations("localdbclient.studio");
  const router: ReturnType<typeof useRouter> = useRouter();
  const routerRef: React.MutableRefObject<ReturnType<typeof useRouter>> = useRef<ReturnType<typeof useRouter>>(router);
  routerRef.current = router;
  const params: ReturnType<typeof useParams> = useParams();
  const connectionId: string = decodeURIComponent(String(params.id ?? ""));

  const {
    sidebarWidth,
    isResizing,
    startResizing,
    handleKeyDown,
    resetWidth,
  }: UseResizableSidebarResult = useResizableSidebar({
    storageKey: "localdb_sidebar_width",
    defaultWidth: 260,
    minWidth: 200,
    maxWidth: 550,
  });

  const [isSidebarOpen, setIsSidebarOpen]: [
    boolean,
    React.Dispatch<React.SetStateAction<boolean>>
  ] = useState<boolean>(true);

  const [isDetailOpen, setIsDetailOpen]: [
    boolean,
    React.Dispatch<React.SetStateAction<boolean>>
  ] = useState<boolean>(true);

  const [detailWidth, setDetailWidth]: [
    number,
    React.Dispatch<React.SetStateAction<number>>
  ] = useState<number>(300);

  const [profile, setProfile]: [
    SavedConnectionProfile | null,
    React.Dispatch<React.SetStateAction<SavedConnectionProfile | null>>
  ] = useState<SavedConnectionProfile | null>(null);

  const [isLoading, setIsLoading]: [
    boolean,
    React.Dispatch<React.SetStateAction<boolean>>
  ] = useState<boolean>(true);

  const [connectionState, setConnectionState]: [
    ServiceConnectionState,
    React.Dispatch<React.SetStateAction<ServiceConnectionState>>
  ] = useState<ServiceConnectionState>(DEFAULT_SQL_CONNECTION);

  const [isRefreshing, setIsRefreshing]: [
    boolean,
    React.Dispatch<React.SetStateAction<boolean>>
  ] = useState<boolean>(false);

  // SQL Studio State
  const [sqlSubTab, setSqlSubTab]: [
    SqlSubTab,
    React.Dispatch<React.SetStateAction<SqlSubTab>>
  ] = useState<SqlSubTab>("explorer");

  const [databases, setDatabases]: [
    string[],
    React.Dispatch<React.SetStateAction<string[]>>
  ] = useState<string[]>(["default"]);

  const [activeSqlDatabase, setActiveSqlDatabase]: [
    string,
    React.Dispatch<React.SetStateAction<string>>
  ] = useState<string>("default");

  const [showCreateDbModal, setShowCreateDbModal]: [
    boolean,
    React.Dispatch<React.SetStateAction<boolean>>
  ] = useState<boolean>(false);

  const [newDbModalName, setNewDbModalName]: [
    string,
    React.Dispatch<React.SetStateAction<string>>
  ] = useState<string>("");

  const [isCreatingDb, setIsCreatingDb]: [
    boolean,
    React.Dispatch<React.SetStateAction<boolean>>
  ] = useState<boolean>(false);

  const [createDbError, setCreateDbError]: [
    string | null,
    React.Dispatch<React.SetStateAction<string | null>>
  ] = useState<string | null>(null);

  const [databaseSwitchError, setDatabaseSwitchError]: [
    string | null,
    React.Dispatch<React.SetStateAction<string | null>>
  ] = useState<string | null>(null);

  const [_isSwitchingDb, setIsSwitchingDb]: [
    boolean,
    React.Dispatch<React.SetStateAction<boolean>>
  ] = useState<boolean>(false);

  const [tables, setTables]: [
    TableItemMetadata[],
    React.Dispatch<React.SetStateAction<TableItemMetadata[]>>
  ] = useState<TableItemMetadata[]>([]);

  const [activeTable, setActiveTable]: [
    string | null,
    React.Dispatch<React.SetStateAction<string | null>>
  ] = useState<string | null>(null);

  const [tableFilter, setTableFilter]: [
    string,
    React.Dispatch<React.SetStateAction<string>>
  ] = useState<string>("");

  const hasAutoSelectedTable: React.MutableRefObject<boolean> = useRef<boolean>(false);

  const [tableData, setTableData]: [
    unknown[],
    React.Dispatch<React.SetStateAction<unknown[]>>
  ] = useState<unknown[]>([]);

  const [tableSchema, setTableSchema]: [
    unknown,
    React.Dispatch<React.SetStateAction<unknown>>
  ] = useState<unknown>(null);

  const [isTableLoading, setIsTableLoading]: [
    boolean,
    React.Dispatch<React.SetStateAction<boolean>>
  ] = useState<boolean>(false);

  const [sqlMetrics, setSqlMetrics]: [
    PerformanceMetrics | null,
    React.Dispatch<React.SetStateAction<PerformanceMetrics | null>>
  ] = useState<PerformanceMetrics | null>(null);

  const [tableLockMap, setTableLockMap]: [
    Record<string, boolean>,
    React.Dispatch<React.SetStateAction<Record<string, boolean>>>
  ] = useState<Record<string, boolean>>({});

  // Vector Studio State
  const [vectorSubTab, setVectorSubTab]: [
    VectorSubTab,
    React.Dispatch<React.SetStateAction<VectorSubTab>>
  ] = useState<VectorSubTab>("collections");

  const [collections, setCollections]: [
    CollectionItem[],
    React.Dispatch<React.SetStateAction<CollectionItem[]>>
  ] = useState<CollectionItem[]>([]);

  const [activeVectorCollection, setActiveVectorCollection]: [
    string,
    React.Dispatch<React.SetStateAction<string>>
  ] = useState<string>("conversations_vectors");

  const [vectorFilter, setVectorFilter]: [
    string,
    React.Dispatch<React.SetStateAction<string>>
  ] = useState<string>("");

  const [knowledgeDocs, setKnowledgeDocs]: [
    KnowledgeDocItem[],
    React.Dispatch<React.SetStateAction<KnowledgeDocItem[]>>
  ] = useState<KnowledgeDocItem[]>([]);

  const [vectorTelemetry, setVectorTelemetry]: [
    TelemetryData | null,
    React.Dispatch<React.SetStateAction<TelemetryData | null>>
  ] = useState<TelemetryData | null>(null);

  const [isCreateCollectionModalOpen, setIsCreateCollectionModalOpen]: [
    boolean,
    React.Dispatch<React.SetStateAction<boolean>>
  ] = useState<boolean>(false);

  // ─── Load Profile ────────────────────────────────────────────────────────────

  useEffect((): void => {
    const loadProfile: () => Promise<void> = async (): Promise<void> => {
      setIsLoading(true);
      try {
        const res: Response = await fetch("/api/connections");
        if (res.ok) {
          const data: { connections?: SavedConnectionProfile[] } = await res.json();
          const allConnections: SavedConnectionProfile[] = Array.isArray(data.connections)
            ? data.connections
            : INITIAL_SAVED_CONNECTIONS;
          const found: SavedConnectionProfile | undefined = allConnections.find(
            (c: SavedConnectionProfile): boolean => c.id === connectionId
          );
          if (found) {
            setProfile(found);
            const initialState: ServiceConnectionState =
              found.serviceName === "SQL"
                ? { ...DEFAULT_SQL_CONNECTION, endpoint: found.endpoint, protocol: found.protocol as ConnectionProtocol }
                : found.serviceName === "MCP"
                ? { ...DEFAULT_MCP_CONNECTION, endpoint: found.endpoint, protocol: found.protocol as ConnectionProtocol, serviceName: "MCP" }
                : { ...DEFAULT_VECTOR_CONNECTION, endpoint: found.endpoint, protocol: found.protocol as ConnectionProtocol, serviceName: "Vector" };
            setConnectionState(initialState);
          } else {
            routerRef.current.push("/");
          }
        } else {
          routerRef.current.push("/");
        }
      } catch {
        const allConnections: SavedConnectionProfile[] = INITIAL_SAVED_CONNECTIONS;
        const found: SavedConnectionProfile | undefined = allConnections.find(
          (c: SavedConnectionProfile): boolean => c.id === connectionId
        );
        if (found) {
          setProfile(found);
          const initialState: ServiceConnectionState =
            found.serviceName === "SQL"
              ? { ...DEFAULT_SQL_CONNECTION, endpoint: found.endpoint, protocol: found.protocol as ConnectionProtocol }
              : found.serviceName === "MCP"
              ? { ...DEFAULT_MCP_CONNECTION, endpoint: found.endpoint, protocol: found.protocol as ConnectionProtocol, serviceName: "MCP" }
              : { ...DEFAULT_VECTOR_CONNECTION, endpoint: found.endpoint, protocol: found.protocol as ConnectionProtocol, serviceName: "Vector" };
            setConnectionState(initialState);
        } else {
          routerRef.current.push("/");
        }
      } finally {
        setIsLoading(false);
      }
    };
    loadProfile();
  }, [connectionId]);

  // ─── Ping / Connection Test ───────────────────────────────────────────────────

  const testPing: () => Promise<void> = useCallback(async (): Promise<void> => {
    if (!profile) return;
    const startTime: number = Date.now();
    setConnectionState((prev: ServiceConnectionState) => ({ ...prev, isTesting: true, errorMessage: null }));
    try {
      const healthPath: string =
        profile.serviceName === "SQL" ? "/health" :
        profile.serviceName === "MCP" ? "/health" : "/api/status";
      const res: Response = await fetch(`${connectionState.endpoint}${healthPath}`, {
        signal: AbortSignal.timeout(2000),
      });
      const latency: number = Date.now() - startTime;
      setConnectionState((prev: ServiceConnectionState) => ({
        ...prev,
        isConnected: res.ok,
        isTesting: false,
        latencyMs: res.ok ? latency : null,
        lastTestedAt: Date.now(),
        errorMessage: res.ok ? null : `HTTP ${res.status}: ${res.statusText}`,
      }));
    } catch (err: unknown) {
      setConnectionState((prev: ServiceConnectionState) => ({
        ...prev,
        isConnected: false,
        isTesting: false,
        latencyMs: null,
        lastTestedAt: Date.now(),
        errorMessage: err instanceof Error ? err.message : "Connection failed",
      }));
    }
  }, [profile, connectionState.endpoint]);

  // ─── SQL Handlers ──────────────────────────────────────────────────────────────

  const handleSelectTable: (name: string) => Promise<void> = useCallback(
    async (name: string): Promise<void> => {
      setActiveTable(name);
      setIsTableLoading(true);
      try {
        let extractedRows: unknown[] = [];
        let extractedSchema: unknown = null;

        // 1. First priority: Direct table records API (/api/tables/:tableName?db=...)
        try {
          const directEndpointUrl: string = `${connectionState.endpoint}/api/tables/${encodeURIComponent(name)}?db=${encodeURIComponent(activeSqlDatabase)}`;
          const tableDirectRes: Response = await fetch(directEndpointUrl, {
            signal: AbortSignal.timeout(3000),
          });
          if (tableDirectRes.ok) {
            const tableJson: {
              rows?: unknown[];
              data?: unknown[];
              schema?: unknown;
            } = await tableDirectRes.json();

            if (Array.isArray(tableJson.rows) && tableJson.rows.length > 0) {
              extractedRows = tableJson.rows;
            } else if (Array.isArray(tableJson.data) && tableJson.data.length > 0) {
              extractedRows = tableJson.data;
            } else if (Array.isArray(tableJson.rows)) {
              extractedRows = tableJson.rows;
            }

            if (tableJson.schema) {
              extractedSchema = tableJson.schema;
            }
          }
        } catch {
          // Fall through to query endpoint
        }

        // 2. Second priority / fallback: SQL Query API (/api/query)
        if (extractedRows.length === 0) {
          try {
            // Try POST /api/query first
            const queryRes: Response = await fetch(`${connectionState.endpoint}/api/query`, {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                sql: `SELECT * FROM ${name} LIMIT 100;`,
                db: activeSqlDatabase,
                database: activeSqlDatabase,
              }),
              signal: AbortSignal.timeout(3000),
            });

            if (queryRes.ok) {
              const queryJson: {
                data?: unknown;
                rows?: unknown;
                schema?: unknown;
              } = await queryRes.json();

              const rawData: unknown = queryJson.rows || queryJson.data;
              if (Array.isArray(rawData)) {
                extractedRows = rawData;
              } else if (
                rawData &&
                typeof rawData === "object" &&
                "columns" in rawData &&
                "rows" in rawData &&
                Array.isArray((rawData as { columns: string[] }).columns) &&
                Array.isArray((rawData as { rows: unknown[][] }).rows)
              ) {
                // Columnar format { columns: string[], rows: unknown[][] }
                const cols: string[] = (rawData as { columns: string[] }).columns;
                const matrixRows: unknown[][] = (rawData as { rows: unknown[][] }).rows;
                extractedRows = matrixRows.map((r: unknown[]): Record<string, unknown> => {
                  const obj: Record<string, unknown> = {};
                  cols.forEach((col: string, idx: number): void => {
                    obj[col] = r[idx];
                  });
                  return obj;
                });
              } else if (rawData && typeof rawData === "object") {
                extractedRows = Object.values(rawData as Record<string, unknown>);
              }

              if (!extractedSchema && queryJson.schema) {
                extractedSchema = queryJson.schema;
              }
            } else {
              // Try GET /api/query as fallback
              const getQueryUrl: string = `${connectionState.endpoint}/api/query?db=${encodeURIComponent(activeSqlDatabase)}&sql=${encodeURIComponent(`SELECT * FROM ${name} LIMIT 100`)}`;
              const getQueryRes: Response = await fetch(getQueryUrl, {
                signal: AbortSignal.timeout(3000),
              });
              if (getQueryRes.ok) {
                const getJson: { data?: unknown; rows?: unknown; schema?: unknown } = await getQueryRes.json();
                const rawData: unknown = getJson.rows || getJson.data;
                if (Array.isArray(rawData)) {
                  extractedRows = rawData;
                }
                if (!extractedSchema && getJson.schema) {
                  extractedSchema = getJson.schema;
                }
              }
            }
          } catch {
            // Ignore query error
          }
        }

        // 3. Fallback schema derivation from first row keys if schema is not provided
        if (!extractedSchema && extractedRows.length > 0) {
          const firstRow: unknown = extractedRows[0];
          if (typeof firstRow === "object" && firstRow !== null) {
            const columnsDef: Record<string, { type: string; primaryKey: boolean; nullable: boolean }> = {};
            for (const [key, val] of Object.entries(firstRow as Record<string, unknown>)) {
              columnsDef[key] = {
                type: typeof val === "number" ? "INTEGER" : typeof val === "boolean" ? "BOOLEAN" : "VARCHAR",
                primaryKey: key === "id" || key.endsWith("_id"),
                nullable: true,
              };
            }
            extractedSchema = {
              tableName: name,
              columns: columnsDef,
            };
          }
        }

        setTableData(extractedRows);
        setTableSchema(extractedSchema);
      } catch {
        setTableData([]);
      } finally {
        setIsTableLoading(false);
      }
    },
    [connectionState.endpoint, activeSqlDatabase]
  );

  const handleSidebarTableClick: (tableName: string) => void = (tableName: string): void => {
    setSqlSubTab("explorer");
    handleSelectTable(tableName);
  };

  const handleLockTable: (tableName: string, locked: boolean) => void = (
    tableName: string,
    locked: boolean
  ): void => {
    setTableLockMap((prev: Record<string, boolean>): Record<string, boolean> => ({
      ...prev,
      [tableName]: locked,
    }));
  };

  // ─── Data Refresh ─────────────────────────────────────────────────────────────

  const refreshData: () => Promise<void> = useCallback(async (): Promise<void> => {
    if (!profile) return;
    setIsRefreshing(true);

    if (profile.serviceName === "SQL") {
      try {
        const targetDb: string = activeSqlDatabase || "default";
        const statusRes: Response = await fetch(
          `${connectionState.endpoint}/api/status?db=${encodeURIComponent(targetDb)}`,
          { signal: AbortSignal.timeout(2000) }
        );
        if (statusRes.ok) {
          setConnectionState((prev: ServiceConnectionState) => ({ ...prev, isConnected: true }));
          const statusData: { activeDatabase?: string } = await statusRes.json();
          let effectiveDb: string = activeSqlDatabase;
          if (!effectiveDb && statusData.activeDatabase) {
            effectiveDb = statusData.activeDatabase;
            setActiveSqlDatabase(statusData.activeDatabase);
          }

          const dbRes: Response = await fetch(`${connectionState.endpoint}/api/databases`, {
            signal: AbortSignal.timeout(2000),
          });
          if (dbRes.ok) {
            const dbData: { databases?: string[] } = await dbRes.json();
            if (Array.isArray(dbData.databases)) setDatabases(dbData.databases);
          }

          const tblRes: Response = await fetch(
            `${connectionState.endpoint}/api/tables?db=${encodeURIComponent(effectiveDb || "default")}`,
            { signal: AbortSignal.timeout(2000) }
          );
          if (tblRes.ok) {
            const tblData: { tables?: TableItemMetadata[] } = await tblRes.json();
            if (Array.isArray(tblData.tables)) {
              setTables(tblData.tables);
              if (tblData.tables.length > 0 && !hasAutoSelectedTable.current) {
                hasAutoSelectedTable.current = true;
                handleSelectTable(tblData.tables[0].name);
              } else if (tblData.tables.length === 0) {
                setActiveTable(null);
                setTableData([]);
                setTableSchema(null);
              }
            }
          }

          const metricsRes: Response = await fetch(`${connectionState.endpoint}/api/metrics`, {
            signal: AbortSignal.timeout(2000),
          });
          if (metricsRes.ok) {
            const mData: { metrics?: PerformanceMetrics } = await metricsRes.json();
            if (mData.metrics) setSqlMetrics(mData.metrics);
          }
        } else {
          setConnectionState((prev: ServiceConnectionState) => ({ ...prev, isConnected: false }));
        }
      } catch {
        setConnectionState((prev: ServiceConnectionState) => ({ ...prev, isConnected: false }));
      }
    } else {
      try {
        const statusRes: Response = await fetch(`${connectionState.endpoint}/api/status`, {
          signal: AbortSignal.timeout(2000),
        });
        if (statusRes.ok) {
          setConnectionState((prev: ServiceConnectionState) => ({ ...prev, isConnected: true }));
          const vecData: { collections?: CollectionItem[]; telemetry?: TelemetryData } =
            await statusRes.json();
          if (vecData.collections) setCollections(vecData.collections);
          if (vecData.telemetry) setVectorTelemetry(vecData.telemetry);

          const kbRes: Response = await fetch(`${connectionState.endpoint}/api/knowledge`, {
            signal: AbortSignal.timeout(2000),
          });
          if (kbRes.ok) {
            const kbData: { documents?: KnowledgeDocItem[] } = await kbRes.json();
            if (kbData.documents) setKnowledgeDocs(kbData.documents);
          }
        } else {
          setConnectionState((prev: ServiceConnectionState) => ({ ...prev, isConnected: false }));
        }
      } catch {
        setConnectionState((prev: ServiceConnectionState) => ({ ...prev, isConnected: false }));
      }
    }

    setIsRefreshing(false);
  }, [profile, connectionState.endpoint, activeSqlDatabase, handleSelectTable]);

  const handleEditTable: (oldName: string, newName: string) => Promise<void> = async (
    oldName: string,
    newName: string
  ): Promise<void> => {
    try {
      const renameRes: Response = await fetch(
        `${connectionState.endpoint}/api/tables/${encodeURIComponent(oldName)}?db=${encodeURIComponent(activeSqlDatabase)}`,
        {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ newName }),
        }
      );
      if (!renameRes.ok) {
        await fetch(`${connectionState.endpoint}/api/query`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            sql: `ALTER TABLE ${oldName} RENAME TO ${newName};`,
            db: activeSqlDatabase,
          }),
        });
      }
      setTableLockMap((prev: Record<string, boolean>): Record<string, boolean> => {
        const updated: Record<string, boolean> = { ...prev };
        if (updated[oldName] !== undefined) {
          updated[newName] = updated[oldName];
          delete updated[oldName];
        }
        return updated;
      });
      setActiveTable(newName);
      await refreshData();
      await handleSelectTable(newName);
    } catch (err: unknown) {
      console.error("Failed to rename table:", err);
    }
  };

  const handleDeleteTable: (tableName: string) => Promise<void> = async (
    tableName: string
  ): Promise<void> => {
    try {
      const deleteRes: Response = await fetch(
        `${connectionState.endpoint}/api/tables/${encodeURIComponent(tableName)}?db=${encodeURIComponent(activeSqlDatabase)}`,
        {
          method: "DELETE",
        }
      );
      if (!deleteRes.ok) {
        await fetch(`${connectionState.endpoint}/api/query`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            sql: `DROP TABLE ${tableName};`,
            db: activeSqlDatabase,
          }),
        });
      }
      setActiveTable(null);
      setTableData([]);
      setTableSchema(null);
      await refreshData();
    } catch (err: unknown) {
      console.error("Failed to delete table:", err);
    }
  };

  const handleDeleteRows: (tableName: string, rowKeys: string[]) => Promise<void> = async (
    tableName: string,
    rowKeys: string[]
  ): Promise<void> => {
    try {
      const deleteRowsRes: Response = await fetch(
        `${connectionState.endpoint}/api/tables/${encodeURIComponent(tableName)}/delete-rows?db=${encodeURIComponent(activeSqlDatabase)}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ rowKeys }),
        }
      );
      if (!deleteRowsRes.ok) {
        const formattedKeys: string = rowKeys.map((k: string): string => `'${k}'`).join(", ");
        await fetch(`${connectionState.endpoint}/api/query`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            sql: `DELETE FROM ${tableName} WHERE id IN (${formattedKeys}) OR key IN (${formattedKeys});`,
            db: activeSqlDatabase,
          }),
        });
      }
      await refreshData();
      await handleSelectTable(tableName);
    } catch (err: unknown) {
      console.error("Failed to delete rows:", err);
    }
  };

  const handleUpdateCellValue: (
    tableName: string,
    rowIndex: number,
    column: string,
    newValue: unknown,
    dataType: CellDataType
  ) => Promise<void> = async (
    tableName: string,
    rowIndex: number,
    column: string,
    newValue: unknown,
    _dataType: CellDataType
  ): Promise<void> => {
    setTableData((prev: unknown[]): unknown[] => {
      const copy: unknown[] = [...prev];
      if (copy[rowIndex] && typeof copy[rowIndex] === "object") {
        copy[rowIndex] = {
          ...(copy[rowIndex] as Record<string, unknown>),
          [column]: newValue,
        };
      }
      return copy;
    });

    try {
      const targetRow: Record<string, unknown> | undefined = (tableData[rowIndex] as Record<string, unknown>) || undefined;
      const rowId: unknown = targetRow?.id ?? targetRow?.key ?? targetRow?.rowid;
      if (rowId !== undefined) {
        const upperTableName: string = tableName.toUpperCase();
        const updatedRow: Record<string, unknown> = {
          ...(targetRow || {}),
          [column]: newValue,
          id: rowId,
        };
        const cols: string[] = Object.keys(updatedRow);
        const formatSqlVal: (val: unknown) => string = (val: unknown): string => {
          if (val === null || val === undefined) return "NULL";
          if (typeof val === "number") return String(val);
          if (typeof val === "boolean") return val ? "1" : "0";
          if (typeof val === "object") return `'${JSON.stringify(val).replace(/'/g, "''")}'`;
          return `'${String(val).replace(/'/g, "''")}'`;
        };
        const colsStr: string = cols.map((c: string): string => `"${c}"`).join(", ");
        const valsStr: string = cols.map((c: string): string => formatSqlVal(updatedRow[c])).join(", ");
        const insertSql: string = `INSERT OR REPLACE INTO "${upperTableName}" (${colsStr}) VALUES (${valsStr})`;

        await fetch(`${connectionState.endpoint}/api/query`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            db: activeSqlDatabase,
            database: activeSqlDatabase,
            sql: insertSql,
          }),
        });
      }
    } catch {
      // In-memory fallback
    }
  };

  const handleDuplicateRow: (
    tableName: string,
    rowIndex: number,
    duplicatedRow: Record<string, unknown>
  ) => Promise<void> = async (
    tableName: string,
    rowIndex: number,
    duplicatedRow: Record<string, unknown>
  ): Promise<void> => {
    setTableData((prev: unknown[]): unknown[] => {
      const next: unknown[] = [...prev];
      next.splice(rowIndex + 1, 0, duplicatedRow);
      return next;
    });

    try {
      const upperTableName: string = tableName.toUpperCase();
      const cols: string[] = Object.keys(duplicatedRow);
      const formatSqlVal: (val: unknown) => string = (val: unknown): string => {
        if (val === null || val === undefined) return "NULL";
        if (typeof val === "number") return String(val);
        if (typeof val === "boolean") return val ? "1" : "0";
        if (typeof val === "object") return `'${JSON.stringify(val).replace(/'/g, "''")}'`;
        return `'${String(val).replace(/'/g, "''")}'`;
      };
      const colsStr: string = cols.map((c: string): string => `"${c}"`).join(", ");
      const valsStr: string = cols.map((c: string): string => formatSqlVal(duplicatedRow[c])).join(", ");
      const insertSql: string = `INSERT OR REPLACE INTO "${upperTableName}" (${colsStr}) VALUES (${valsStr})`;

      await fetch(`${connectionState.endpoint}/api/query`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          db: activeSqlDatabase,
          database: activeSqlDatabase,
          sql: insertSql,
        }),
      });
    } catch {
      // In-memory fallback
    }
  };

  const handleInsertRow: (
    tableName: string,
    newRow: Record<string, unknown>
  ) => Promise<void> = async (
    tableName: string,
    newRow: Record<string, unknown>
  ): Promise<void> => {
    setTableData((prev: unknown[]): unknown[] => [...prev, newRow]);

    try {
      const upperTableName: string = tableName.toUpperCase();
      const cols: string[] = Object.keys(newRow);
      const formatSqlVal: (val: unknown) => string = (val: unknown): string => {
        if (val === null || val === undefined) return "NULL";
        if (typeof val === "number") return String(val);
        if (typeof val === "boolean") return val ? "1" : "0";
        if (typeof val === "object") return `'${JSON.stringify(val).replace(/'/g, "''")}'`;
        return `'${String(val).replace(/'/g, "''")}'`;
      };
      const colsStr: string = cols.map((c: string): string => `"${c}"`).join(", ");
      const valsStr: string = cols.map((c: string): string => formatSqlVal(newRow[c])).join(", ");
      const insertSql: string = `INSERT INTO "${upperTableName}" (${colsStr}) VALUES (${valsStr})`;

      await fetch(`${connectionState.endpoint}/api/query`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          db: activeSqlDatabase,
          database: activeSqlDatabase,
          sql: insertSql,
        }),
      });
    } catch {
      // In-memory fallback
    }
  };

  useEffect((): (() => void) => {
    if (!profile) return (): void => {};
    testPing();
    refreshData();
    const interval: NodeJS.Timeout = setInterval((): void => {
      refreshData();
    }, 10000);
    return (): void => clearInterval(interval);
  }, [profile, refreshData, testPing]);

  const handleExecuteSqlQuery: (sql: string) => Promise<QueryResultData> = async (
    sql: string
  ): Promise<QueryResultData> => {
    const res: Response = await fetch(`${connectionState.endpoint}/api/query`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ db: activeSqlDatabase, database: activeSqlDatabase, sql }),
    });
    if (!res.ok) {
      let errDetail: string = res.statusText;
      try {
        const errJson: { error?: string } = await res.json();
        if (errJson.error) errDetail = errJson.error;
      } catch {
        // ignore
      }
      throw new Error(`Query failed: ${errDetail}`);
    }
    const result: QueryResultData = await res.json();
    await refreshData();
    return result;
  };

  const handleSelectDatabase: (name: string) => Promise<boolean> = useCallback(
    async (name: string): Promise<boolean> => {
      if (name === activeSqlDatabase) return true;
      setIsSwitchingDb(true);
      setDatabaseSwitchError(null);
      try {
        // Only switch if connect successfully!
        const checkUrl: string = `${connectionState.endpoint}/api/tables?db=${encodeURIComponent(name)}`;
        const res: Response = await fetch(checkUrl, {
          signal: AbortSignal.timeout(3000),
        });

        if (res.ok) {
          // Connected successfully! Update state with new database and its genuine tables
          const tblData: { tables?: TableItemMetadata[] } = await res.json();
          const newTables: TableItemMetadata[] = Array.isArray(tblData.tables) ? tblData.tables : [];
          setActiveSqlDatabase(name);
          setTables(newTables);
          setTableData([]);
          setTableSchema(null);
          setDatabaseSwitchError(null);
          if (newTables.length > 0) {
            hasAutoSelectedTable.current = true;
            setActiveTable(newTables[0].name);
            handleSelectTable(newTables[0].name);
          } else {
            hasAutoSelectedTable.current = false;
            setActiveTable(null);
          }
          return true;
        } else {
          // Connection failed -> DO NOT SWITCH
          setDatabaseSwitchError(
            `Cannot switch to database "${name}": Server returned HTTP ${res.status}. Only switch if connected successfully.`
          );
          return false;
        }
      } catch (err: unknown) {
        // Connection failed -> DO NOT SWITCH
        const msg: string = err instanceof Error ? err.message : "Connection failed";
        setDatabaseSwitchError(
          `Cannot switch to database "${name}": ${msg}. Only switch if connected successfully.`
        );
        return false;
      } finally {
        setIsSwitchingDb(false);
      }
    },
    [activeSqlDatabase, connectionState.endpoint, handleSelectTable]
  );

  const handleCreateDatabase: (name: string) => Promise<void> = async (name: string): Promise<void> => {
    const res: Response = await fetch(`${connectionState.endpoint}/api/databases`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name }),
    });
    if (!res.ok) {
      let errDetail: string = res.statusText;
      try {
        const errJson: { error?: string } = await res.json();
        if (errJson.error) errDetail = errJson.error;
      } catch {
        // ignore
      }
      throw new Error(`Failed to create database: ${errDetail}`);
    }
    await refreshData();
    await handleSelectDatabase(name);
  };

  const handleModalCreateDbSubmit: () => Promise<void> = async (): Promise<void> => {
    const trimmed: string = newDbModalName.trim();
    if (!trimmed || isCreatingDb) return;
    if (databases.includes(trimmed)) {
      setCreateDbError(`Database "${trimmed}" already exists.`);
      return;
    }
    setIsCreatingDb(true);
    setCreateDbError(null);
    try {
      await handleCreateDatabase(trimmed);
      setNewDbModalName("");
      setShowCreateDbModal(false);
    } catch (err: unknown) {
      const msg: string = err instanceof Error ? err.message : "Failed to create database";
      setCreateDbError(msg);
    } finally {
      setIsCreatingDb(false);
    }
  };

  // ─── Vector Handlers ───────────────────────────────────────────────────────────

  const handleCreateCollection: (name: string, dimension: number, metric: string) => Promise<void> = async (
    name: string,
    dimension: number,
    metric: string
  ): Promise<void> => {
    await fetch(`${connectionState.endpoint}/api/collections`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, dimension, metric }),
    });
    await refreshData();
    setActiveVectorCollection(name);
  };

  const handleUploadConversation: (data: {
    conversationId?: string;
    title: string;
    metadata?: Record<string, string | number | boolean | null>;
    messages: MessageInput[];
  }) => Promise<{ conversationId: string; turnsIndexed: number }> = async (data: {
    conversationId?: string;
    title: string;
    metadata?: Record<string, string | number | boolean | null>;
    messages: MessageInput[];
  }): Promise<{ conversationId: string; turnsIndexed: number }> => {
    const res: Response = await fetch(`${connectionState.endpoint}/api/conversations/upload`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error(`Upload failed: ${res.statusText}`);
    const result: { conversationId: string; turnsIndexed: number } = await res.json();
    await refreshData();
    return result;
  };

  const handleSearchRelated: (query: string, topK: number) => Promise<RelatedItem[]> = async (
    query: string,
    topK: number
  ): Promise<RelatedItem[]> => {
    const res: Response = await fetch(
      `${connectionState.endpoint}/api/conversations/related?query=${encodeURIComponent(query)}&topK=${topK}`
    );
    if (!res.ok) return [];
    const data: { related?: RelatedItem[] } = await res.json();
    return data.related || [];
  };

  const handleUploadKnowledgeDoc: (data: {
    title: string;
    category: string;
    tags: string[];
    content: string;
  }) => Promise<void> = async (data: {
    title: string;
    category: string;
    tags: string[];
    content: string;
  }): Promise<void> => {
    await fetch(`${connectionState.endpoint}/api/knowledge/upload`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    await refreshData();
  };

  const handleGenerateExport: (params: {
    format: "sharegpt" | "openai";
    limit: number;
    domain?: string;
  }) => Promise<{ format: string; recordCount: number; jsonlContent: string }> = async (params: {
    format: "sharegpt" | "openai";
    limit: number;
    domain?: string;
  }): Promise<{ format: string; recordCount: number; jsonlContent: string }> => {
    const queryParams: string = new URLSearchParams({
      format: params.format,
      limit: String(params.limit),
      ...(params.domain ? { domain: params.domain } : {}),
    }).toString();
    const res: Response = await fetch(`${connectionState.endpoint}/api/training/export?${queryParams}`);
    if (!res.ok) throw new Error("Failed to export training dataset");
    return res.json();
  };

  // ─── Loading / Not Found ───────────────────────────────────────────────────────

  if (isLoading) {
    return (
      <div id="studio-loading-screen" className="connection-home-shell div-center">
        <div id="studio-loading-inner" className="div-col gap-3 items-center">
          <IdeIcon name="Loader" size="xl" color="var(--primary, #2563eb)" />
          <span id="studio-loading-text" className="theme-text-muted">
            {t("loading", "Loading connection…")}
          </span>
        </div>
      </div>
    );
  }

  if (!profile) {
    return (
      <div id="studio-not-found-screen" className="connection-home-shell div-center">
        <div id="studio-not-found-inner" className="div-col gap-3 items-center">
          <IdeIcon name="AlertCircle" size="xl" color="var(--danger, #ef4444)" />
          <span id="studio-not-found-text" className="theme-text">
            {t("notFound", "Connection not found")}
          </span>
          <button
            id="btn-go-home-from-404"
            type="button"
            className="connection-btn-primary"
            onClick={(): void => router.push("/")}
          >
            {t("goBack", "Back to Connections")}
          </button>
        </div>
      </div>
    );
  }

  const isSqlMode: boolean = profile.serviceName === "SQL";
  const isMcpMode: boolean = profile.serviceName === "MCP";

  const filteredTables: TableItemMetadata[] = tables.filter(
    (tbl: TableItemMetadata): boolean =>
      tbl.name.toLowerCase().includes(tableFilter.toLowerCase())
  );

  const filteredCollections: CollectionItem[] = collections.filter(
    (col: CollectionItem): boolean =>
      col.name.toLowerCase().includes(vectorFilter.toLowerCase())
  );

  const schemaColumns: Array<{
    name: string;
    type: string;
    primaryKey: boolean;
    nullable: boolean;
  }> = [];

  if (tableSchema && typeof tableSchema === "object" && "columns" in tableSchema) {
    const rawCols: Record<
      string,
      { type?: string; primaryKey?: boolean; nullable?: boolean }
    > =
      (
        tableSchema as {
          columns: Record<
            string,
            { type?: string; primaryKey?: boolean; nullable?: boolean }
          >;
        }
      ).columns || {};
    for (const [colName, def] of Object.entries(rawCols)) {
      schemaColumns.push({
        name: colName,
        type: def.type || "VARCHAR",
        primaryKey: Boolean(def.primaryKey),
        nullable: Boolean(def.nullable ?? true),
      });
    }
  }

  return (
    <div id="studio-page-root" className="system-layout-shell">
      {/* Studio Header (Sticky Header) */}
      <header id="studio-app-header" className="system-layout-header sticky-header">
        <div id="studio-header-left" className="localdb-header-left">
          {/* Back to Home */}
          <button
            id="btn-studio-back-home"
            type="button"
            className="studio-back-btn"
            onClick={(): void => router.push("/")}
            title={t("backToHome", "Back to Connections")}
          >
            <IdeIcon name="ChevronLeft" size="sm" />
            <span>{t("connections", "Connections")}</span>
          </button>

          <div id="studio-brand-divider" className="studio-header-divider" />

          <div id="studio-connection-info" className="div-row gap-2 items-center">
            <IdeIcon
              name={isSqlMode ? "Database" : isMcpMode ? "Plug" : "Cpu"}
              size="md"
              color={
                isSqlMode
                  ? "var(--primary, #2563eb)"
                  : isMcpMode
                  ? "var(--mcp-accent, #16a34a)"
                  : "var(--purple-600, #9333ea)"
              }
            />
            <div id="studio-connection-titles" className="div-col">
              <span id="studio-connection-name" className="localdb-brand-title">
                {isSqlMode ? profile.name : isMcpMode ? (profile.name || "MCP Client (LocalMCPServer)") : "Vector DB (LocalVectorServer)"}
              </span>
              {isMcpMode && (
                <span id="studio-mcp-subtitle" className="text-2xs theme-text-muted">
                  Model Context Protocol · Tools, Resources & Prompts
                </span>
              )}
              {!isSqlMode && !isMcpMode && (
                <span id="studio-vector-subtitle" className="text-2xs theme-text-muted">
                  similarity search & fine-tuning datasets
                </span>
              )}
            </div>
          </div>

          {/* Connection Status */}
          <div
            id="studio-status-badge"
            className="localdb-status-badge cursor-pointer"
            onClick={testPing}
            title={`${connectionState.endpoint} (click to test)`}
          >
            <span
              id="studio-status-dot"
              className={`localdb-status-dot ${connectionState.isConnected ? "status-online" : connectionState.isTesting ? "status-testing" : "status-offline"}`}
            />
            <span id="studio-status-text" className="font-semibold text-xs">
              {connectionState.isTesting
                ? t("testing", "Testing…")
                : connectionState.isConnected
                ? `${connectionState.protocol.toUpperCase()} · ${connectionState.latencyMs ?? 24}ms`
                : t("offline", "Offline")}
            </span>
          </div>
        </div>

        {/* Right Actions */}
        <div id="studio-header-right" className="localdb-header-right">
          {isSqlMode && (
            <FastDatabaseSwitcher
              id="studio-header-fast-db-switcher"
              databases={databases}
              activeDatabase={activeSqlDatabase}
              onSelectDatabase={handleSelectDatabase}
              onCreateDatabase={handleCreateDatabase}
              variant="header"
            />
          )}
          {isMcpMode && (
            <div id="context-badge-mcp" className="localdb-status-badge">
              <IdeIcon name="Plug" size="xs" color="var(--mcp-accent, #16a34a)" />
              <span id="text-active-mcp-studio" className="text-xs truncate font-mono">
                {(profile.mcpTransport ?? "sse").toUpperCase()}
              </span>
            </div>
          )}
          {!isSqlMode && !isMcpMode && (
            <div id="context-badge-col" className="localdb-status-badge">
              <IdeIcon name="Layers" size="xs" />
              <span id="text-active-col-studio" className="text-xs truncate">
                Col: {activeVectorCollection || "conversations_vectors"}
              </span>
              <IdeIcon name="ChevronDown" size="xs" />
            </div>
          )}
          <button
            id="btn-studio-refresh"
            type="button"
            className="studio-icon-btn"
            onClick={refreshData}
            disabled={isRefreshing}
            title={t("refresh", "Refresh")}
          >
            <IdeIcon name={isRefreshing ? "Loader" : "RotateCcw"} size="sm" />
          </button>
          <button
            id="btn-studio-filter"
            type="button"
            className="studio-icon-btn"
            title="Filter and Sort Options"
            aria-label="Filter and Sort"
          >
            <IdeIcon name="SlidersHorizontal" size="sm" />
          </button>
          <button
            id="btn-studio-toggle-inspector"
            type="button"
            className={`studio-icon-btn ${isDetailOpen ? "active" : ""}`}
            onClick={(): void => setIsDetailOpen((prev: boolean): boolean => !prev)}
            title={isDetailOpen ? "Hide Table Inspector" : "Show Table Inspector"}
            aria-label="Toggle Table Inspector"
          >
            <IdeIcon name="Columns3" size="sm" />
          </button>
        </div>
      </header>

      {/* ── 2. Word-Style Ribbon Toolbar (Tabs & Quick Action Strip) ── */}
      <StudioRibbonToolbar
        isSqlMode={isSqlMode}
        isMcpMode={isMcpMode}
        activeSqlTab={sqlSubTab}
        onChangeSqlTab={setSqlSubTab}
        activeVectorTab={vectorSubTab}
        onChangeVectorTab={setVectorSubTab}
        onRefresh={refreshData}
        isRefreshing={isRefreshing}
        activeTable={activeTable}
        onOpenInConsole={(): void => setSqlSubTab("console")}
        onOpenErdSchema={(): void => setSqlSubTab("erd")}
        isDetailOpen={isDetailOpen}
        onToggleDetail={(): void => setIsDetailOpen((prev: boolean): boolean => !prev)}
        isSidebarOpen={isSidebarOpen}
        onToggleSidebar={(): void => setIsSidebarOpen((prev: boolean): boolean => !prev)}
        databases={databases}
        activeDatabase={activeSqlDatabase}
        onSelectDatabase={handleSelectDatabase}
        onCreateDatabase={handleCreateDatabase}
      />

      {/* ── Database Switch Error Alert Banner ── */}
      {databaseSwitchError && (
        <div id="studio-db-switch-error-banner" className="connection-error-banner" role="alert">
          <IdeIcon name="AlertCircle" size="sm" color="var(--destructive, #ef4444)" />
          <span id="studio-db-switch-error-text" className="text-xs font-medium text-red-600 flex-1">
            {databaseSwitchError}
          </span>
          <button
            id="btn-dismiss-db-switch-error"
            type="button"
            className="connection-btn-dismiss"
            onClick={(): void => setDatabaseSwitchError(null)}
            aria-label="Dismiss error"
          >
            <IdeIcon name="X" size="xs" />
          </button>
        </div>
      )}

      {/* ── 3. Main Studio Workspace: Sidebar + Content + DetailContent ── */}
      <div id="studio-body-layout" className="word-studio-workspace system-layout-body">
        {/* Left Sidebar (Collapsible & Resizable) */}
        {isSidebarOpen && (
          <>
            <aside
              id="studio-sidebar"
              className="word-sidebar system-layout-sidebar"
              style={{ width: `${sidebarWidth}px` }}
            >
              {isSqlMode ? (
                <>
                  {/* Tables & Schemas in Sidebar (sidebar-db-section removed) */}
                  <div id="sidebar-tables-section" className="system-sidebar-section flex-1">
                    <div id="sidebar-tables-heading-row" className="div-between items-center px-2 py-1">
                      <span id="sidebar-tables-heading" className="system-sidebar-header">
                        TABLES
                      </span>
                      <span id="badge-sidebar-tables-count" className="system-nav-badge">
                        {tables.length}
                      </span>
                    </div>

                    <div id="sidebar-table-search-box" className="sidebar-search-box">
                      <Input
                        id="sidebar-table-search-input"
                        size="sm"
                        placeholder={t("filterTables", "Filter tables...")}
                        value={tableFilter}
                        onChange={(e: React.ChangeEvent<HTMLInputElement>): void =>
                          setTableFilter(e.target.value)
                        }
                      />
                    </div>

                    <div id="sidebar-tables-list" className="sidebar-tables-list">
                      {filteredTables.map((tbl: TableItemMetadata): React.ReactElement => {
                        const isSelected: boolean = activeTable === tbl.name;
                        return (
                          <div key={tbl.name} id={`sidebar-table-group-${tbl.name}`} className="div-col">
                            <button
                              id={`sidebar-table-item-${tbl.name}`}
                              type="button"
                              className={`sidebar-table-item-btn ${isSelected ? "active" : ""}`}
                              onClick={(): void => handleSidebarTableClick(tbl.name)}
                              title={`${tbl.name} (${tbl.rowCount} rows)`}
                            >
                              <div className="div-row gap-2 items-center truncate">
                                <IdeIcon
                                  name="Table2"
                                  size="xs"
                                  color={isSelected ? "var(--primary, #2563eb)" : "var(--text-muted, #64748b)"}
                                />
                                <span className="truncate">{tbl.name}</span>
                              </div>
                              <span id={`badge-row-count-${tbl.name}`} className="system-nav-badge">
                                {tbl.rowCount}
                              </span>
                            </button>

                            {/* Expandable Schema Columns */}
                            {isSelected && (
                              <div id={`sidebar-table-schema-${tbl.name}`} className="sidebar-schema-tree">
                                {schemaColumns.length > 0 ? (
                                  schemaColumns.map((col) => (
                                    <div
                                      key={col.name}
                                      id={`sidebar-schema-col-${tbl.name}-${col.name}`}
                                      className="sidebar-schema-col-item"
                                      title={`${col.name} (${col.type}${col.primaryKey ? ", PK" : ""}${col.nullable ? "" : ", NOT NULL"})`}
                                    >
                                      <div className="div-row gap-1.5 items-center truncate">
                                        <IdeIcon
                                          name={col.primaryKey ? "Key" : "Equal"}
                                          size="xs"
                                          color={col.primaryKey ? "#f59e0b" : "var(--text-muted, #64748b)"}
                                        />
                                        <span className="sidebar-schema-col-name truncate">{col.name}</span>
                                      </div>
                                      <span className="sidebar-schema-col-type">{col.type.split("(")[0]}</span>
                                    </div>
                                  ))
                                ) : tbl.columns && tbl.columns.length > 0 ? (
                                  tbl.columns.map((colName: string) => (
                                    <div
                                      key={colName}
                                      id={`sidebar-schema-col-${tbl.name}-${colName}`}
                                      className="sidebar-schema-col-item"
                                      title={colName}
                                    >
                                      <div className="div-row gap-1.5 items-center truncate">
                                        <IdeIcon name="Equal" size="xs" color="var(--text-muted, #64748b)" />
                                        <span className="sidebar-schema-col-name truncate">{colName}</span>
                                      </div>
                                    </div>
                                  ))
                                ) : (
                                  <div
                                    id={`sidebar-schema-empty-${tbl.name}`}
                                    className="sidebar-schema-col-item text-xs theme-text-muted"
                                  >
                                    {isTableLoading ? t("loadingSchema", "Loading schema…") : t("noColumns", "No columns")}
                                  </div>
                                )}
                              </div>
                            )}
                          </div>
                        );
                      })}

                      {filteredTables.length === 0 && (
                        <div id="sidebar-no-tables" className="p-3 text-center text-xs theme-text-muted">
                          {t("noTablesFound", "No tables found")}
                        </div>
                      )}
                    </div>
                  </div>
                </>
              ) : isMcpMode ? (
                <div id="sidebar-mcp-nav-section" className="system-sidebar-section flex-1">
                  <div id="sidebar-mcp-heading-row" className="div-between items-center px-2 py-1">
                    <span id="sidebar-mcp-heading" className="system-sidebar-header">
                      MCP CLIENT
                    </span>
                    <span id="badge-sidebar-mcp-transport" className="system-nav-badge">
                      {(profile.mcpTransport ?? "sse").toUpperCase()}
                    </span>
                  </div>
                  <div id="sidebar-mcp-info-box" className="p-2 text-xs theme-text-muted div-col gap-2">
                    <div id="sidebar-mcp-endpoint-row" className="div-row gap-1 items-center">
                      <IdeIcon name="Globe" size="xs" color="var(--mcp-accent, #16a34a)" />
                      <span id="sidebar-mcp-endpoint-val" className="font-mono text-2xs truncate">
                        {connectionState.endpoint}
                      </span>
                    </div>
                    <div id="sidebar-mcp-status-row" className="div-row gap-1 items-center">
                      <IdeIcon
                        name={connectionState.isConnected ? "CheckCircle" : "AlertCircle"}
                        size="xs"
                        color={connectionState.isConnected ? "var(--mcp-accent, #16a34a)" : "var(--text-muted, #64748b)"}
                      />
                      <span id="sidebar-mcp-status-label">
                        {connectionState.isConnected ? "Connected" : "Standby"}
                      </span>
                    </div>
                  </div>
                </div>
              ) : (
                <div id="sidebar-vec-nav-section" className="system-sidebar-section flex-1">
                  <div id="sidebar-collections-heading-row" className="div-between items-center px-2 py-1">
                    <span id="sidebar-vector-heading" className="system-sidebar-header">
                      COLLECTIONS ({collections.length})
                    </span>
                    <div id="sidebar-vector-header-actions" className="div-row gap-1 items-center">
                      <button
                        id="btn-sidebar-add-collection"
                        type="button"
                        className="system-sidebar-action-btn"
                        title="Create new vector collection"
                        aria-label="Create new vector collection"
                        onClick={(): void => setIsCreateCollectionModalOpen(true)}
                      >
                        <IdeIcon name="Plus" size="xs" />
                      </button>
                      <button
                        id="btn-sidebar-vector-filter"
                        type="button"
                        className="system-sidebar-action-btn"
                        title="Filter collections"
                        aria-label="Filter collections"
                      >
                        <IdeIcon name="SlidersHorizontal" size="xs" />
                      </button>
                    </div>
                  </div>

                  <div id="sidebar-vector-search-box" className="sidebar-search-box">
                    <Input
                      id="sidebar-vector-filter-input"
                      size="sm"
                      placeholder="Filter collections..."
                      value={vectorFilter}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>): void =>
                        setVectorFilter(e.target.value)
                      }
                    />
                  </div>

                  <div id="sidebar-collections-list" className="sidebar-tables-list">
                    {filteredCollections.map((col: CollectionItem): React.ReactElement => {
                      const isSelected: boolean = activeVectorCollection === col.name;
                      if (isSelected) {
                        return (
                          <div
                            key={col.name}
                            id={`sidebar-vector-card-${col.name}`}
                            className="stitch-vector-card-active cursor-pointer"
                            role="button"
                            tabIndex={0}
                            onClick={(): void => {
                              setVectorSubTab("collections");
                              setActiveVectorCollection(col.name);
                            }}
                          >
                            <div id={`sidebar-vector-header-${col.name}`} className="div-row gap-2 items-center justify-between">
                              <div id={`sidebar-vector-name-group-${col.name}`} className="div-row gap-2 items-center truncate">
                                <IdeIcon name="Folder" size="xs" color="var(--primary, #2563eb)" />
                                <span className="font-semibold text-xs truncate theme-text">{col.name}</span>
                              </div>
                              <span id={`badge-active-pill-${col.name}`} className="stitch-vector-active-tag">Active</span>
                            </div>
                            <div id={`sidebar-vector-meta-grid-${col.name}`} className="stitch-vector-meta-grid">
                              <div id={`meta-dim-${col.name}`} className="stitch-vector-meta-item">
                                <span className="stitch-vector-meta-label">Dimension:</span>
                                <span className="stitch-vector-meta-val">{col.dimension}D</span>
                              </div>
                              <div id={`meta-metric-${col.name}`} className="stitch-vector-meta-item">
                                <span className="stitch-vector-meta-label">Metric:</span>
                                <span className="stitch-vector-meta-val">{col.metric.toUpperCase()}</span>
                              </div>
                              <div id={`meta-vectors-${col.name}`} className="stitch-vector-meta-item">
                                <span className="stitch-vector-meta-label">Vectors:</span>
                                <span className="stitch-vector-meta-val">{col.vectorCount}</span>
                              </div>
                              <div id={`meta-type-${col.name}`} className="stitch-vector-meta-item">
                                <span className="stitch-vector-meta-label">Type:</span>
                                <span className="stitch-vector-meta-val">Float32</span>
                              </div>
                            </div>
                          </div>
                        );
                      }

                      return (
                        <button
                          key={col.name}
                          id={`sidebar-vector-card-${col.name}`}
                          type="button"
                          className="stitch-vector-card-inactive"
                          onClick={(): void => {
                            setVectorSubTab("collections");
                            setActiveVectorCollection(col.name);
                          }}
                          title={`${col.name} (${col.dimension}D · ${col.metric.toUpperCase()} · ${col.vectorCount} vectors)`}
                        >
                          <div id={`sidebar-vector-row-${col.name}`} className="div-row gap-2 items-center justify-between w-full">
                            <div className="div-row gap-2 items-center truncate">
                              <IdeIcon name="Folder" size="xs" color="var(--text-muted, #64748b)" />
                              <span className="text-xs truncate font-medium theme-text">{col.name}</span>
                            </div>
                            <span id={`badge-vec-count-${col.name}`} className="system-nav-badge">
                              {col.vectorCount}
                            </span>
                          </div>
                          <div id={`sidebar-vector-sub-${col.name}`} className="text-2xs theme-text-muted mt-1 text-left">
                            {col.dimension}D · {col.metric.toUpperCase()} · {col.vectorCount} vectors
                          </div>
                        </button>
                      );
                    })}

                    {filteredCollections.length === 0 && (
                      <div id="sidebar-no-collections" className="p-3 text-center text-xs theme-text-muted">
                        No collections found
                      </div>
                    )}
                  </div>
                </div>
              )}
            </aside>

            {/* Sidebar Resize Handle */}
            <SidebarResizeHandle
              id="studio-sidebar-resize-handle"
              isResizing={isResizing}
              sidebarWidth={sidebarWidth}
              minWidth={200}
              maxWidth={550}
              onMouseDown={startResizing}
              onTouchStart={startResizing}
              onDoubleClick={resetWidth}
              onKeyDown={handleKeyDown}
            />
          </>
        )}

        {/* Main Stage Content: Table Detail in Content */}
        <main id="studio-main-stage" className="word-content system-layout-content">
          {/* SQL Views */}
          {isSqlMode && (
            <div id="studio-sql-container" className="div-col flex-1 h-full">
              {sqlSubTab === "explorer" && (
                <TablesExplorer
                  hideInternalSidebar={true}
                  tables={tables}
                  activeTable={activeTable}
                  onSelectTable={handleSelectTable}
                  tableData={tableData}
                  tableSchema={tableSchema}
                  isLoading={isTableLoading}
                  isLocked={activeTable ? tableLockMap[activeTable] ?? false : false}
                  onLockTable={handleLockTable}
                  onEditTable={handleEditTable}
                  onDeleteTable={handleDeleteTable}
                  onDeleteRows={handleDeleteRows}
                  onUpdateCellValue={handleUpdateCellValue}
                  onDuplicateRow={handleDuplicateRow}
                  onInsertRow={handleInsertRow}
                />
              )}
              {sqlSubTab === "erd" && (
                <div id="studio-sql-erd-wrapper" className="div-col flex-1 h-full">
                  <ErdSchemaViewer
                    tables={tables}
                    activeTable={activeTable}
                    onSelectTable={handleSelectTable}
                    onOpenInConsole={(tableName: string): void => {
                      setActiveTable(tableName);
                      setSqlSubTab("console");
                    }}
                    onSwitchToExplorer={(): void => setSqlSubTab("explorer")}
                  />
                </div>
              )}
              {sqlSubTab === "console" && (
                <div id="studio-sql-console-wrapper" className="div-col gap-4 p-4 flex-1">
                  <QueryConsole
                    activeDatabase={activeSqlDatabase}
                    onRunQuery={handleExecuteSqlQuery}
                  />
                </div>
              )}
              {sqlSubTab === "performance" && (
                <div id="studio-sql-performance-wrapper" className="div-col gap-4 p-4 flex-1">
                  <PerformanceDashboard
                    metrics={sqlMetrics}
                    onRefresh={refreshData}
                    isRefreshing={isRefreshing}
                  />
                </div>
              )}
            </div>
          )}

          {/* MCP Views */}
          {isMcpMode && (
            <div id="studio-mcp-container" className="div-col flex-1 h-full">
              <McpExplorer
                endpoint={connectionState.endpoint}
                transport={profile.mcpTransport ?? "sse"}
              />
            </div>
          )}

          {/* Vector Views */}
          {!isSqlMode && !isMcpMode && (
            <div id="studio-vector-container" className="div-col gap-4 flex-1">
              {vectorSubTab === "collections" && (
                <CollectionsExplorer
                  collections={collections}
                  activeCollection={activeVectorCollection}
                  endpoint={connectionState.endpoint}
                  onSelectCollection={(name: string): void => setActiveVectorCollection(name)}
                  onCreateCollection={handleCreateCollection}
                  isCreateModalOpen={isCreateCollectionModalOpen}
                  onOpenCreateModal={(): void => setIsCreateCollectionModalOpen(true)}
                  onCloseCreateModal={(): void => setIsCreateCollectionModalOpen(false)}
                />
              )}
              {vectorSubTab === "upload" && (
                <ConversationUploader onUploadConversation={handleUploadConversation} />
              )}
              {vectorSubTab === "related" && (
                <RelatedConversationsView onSearchRelated={handleSearchRelated} />
              )}
              {vectorSubTab === "knowledge" && (
                <KnowledgeBaseExplorer
                  documents={knowledgeDocs}
                  onUploadDoc={handleUploadKnowledgeDoc}
                />
              )}
              {vectorSubTab === "training" && (
                <TrainingExporter onGenerateExport={handleGenerateExport} />
              )}
              {vectorSubTab === "telemetry" && (
                <PerformanceTelemetry
                  telemetry={vectorTelemetry}
                  onRefresh={refreshData}
                />
              )}
            </div>
          )}
        </main>

        {/* Right DetailContent (Word-Style Table Inspector) */}
        {isSqlMode && isDetailOpen && (
          <StudioDetailContent
            isOpen={isDetailOpen}
            onClose={(): void => setIsDetailOpen(false)}
            activeTable={activeTable}
            activeDatabase={activeSqlDatabase}
            tableMetadata={tables.find((t: TableItemMetadata): boolean => t.name === activeTable) || null}
            schema={tableSchema}
            width={detailWidth}
            onWidthChange={setDetailWidth}
            onRunSnippetInConsole={(): void => setSqlSubTab("console")}
          />
        )}
      </div>

      {/* ── 4. Bottom Status Bar (Word Style) ── */}
      <StudioBottomStatusBar
        isConnected={connectionState.isConnected}
        serviceName={profile.serviceName}
        endpoint={connectionState.endpoint}
        latencyMs={connectionState.latencyMs}
        activeDatabase={isSqlMode ? activeSqlDatabase : isMcpMode ? "mcp-server" : "default"}
        activeTable={isSqlMode ? activeTable : isMcpMode ? "tools" : activeVectorCollection}
        recordCount={
          tableData.length > 0
            ? tableData.length
            : (tables.find((t: TableItemMetadata): boolean => t.name === activeTable)?.rowCount ?? null)
        }
        isSidebarOpen={isSidebarOpen}
        onToggleSidebar={(): void => setIsSidebarOpen((prev: boolean): boolean => !prev)}
        isDetailOpen={isDetailOpen}
        onToggleDetail={(): void => setIsDetailOpen((prev: boolean): boolean => !prev)}
      />

      {/* ── 5. Electron Modal: Create New Database ── */}
      {showCreateDbModal && (
        <Modal
          id="sidebar-modal-create-database"
          isOpen={showCreateDbModal}
          onClose={(): void => {
            if (!isCreatingDb) {
              setShowCreateDbModal(false);
              setNewDbModalName("");
              setCreateDbError(null);
            }
          }}
          title={t("createDatabaseModalTitle", "Create New Database")}
          footer={
            <div id="sidebar-modal-create-db-footer" className="flex items-center justify-end gap-2 w-full">
              <Button
                id="sidebar-modal-cancel-db-btn"
                variant="secondary"
                size="sm"
                onClick={(): void => {
                  setShowCreateDbModal(false);
                  setNewDbModalName("");
                  setCreateDbError(null);
                }}
                disabled={isCreatingDb}
              >
                {t("cancel", "Cancel")}
              </Button>
              <Button
                id="sidebar-modal-confirm-db-btn"
                variant="primary"
                size="sm"
                onClick={(): void => {
                  void handleModalCreateDbSubmit();
                }}
                disabled={!newDbModalName.trim() || isCreatingDb}
              >
                {isCreatingDb ? t("creating", "Creating...") : t("createDatabase", "Create Database")}
              </Button>
            </div>
          }
        >
          <div id="sidebar-modal-create-db-body" className="div-col gap-3 py-2">
            <div id="sidebar-modal-create-db-desc-box" className="flex items-center gap-2">
              <IdeIcon name="Database" size="sm" color="var(--primary, #2563eb)" />
              <p id="sidebar-modal-create-db-desc" className="text-xs theme-text-muted">
                {t(
                  "createDatabasePrompt",
                  "Enter a name for the new SQLite database in LocalSQLServer. It will be initialized and switched to automatically."
                )}
              </p>
            </div>

            <div id="sidebar-modal-create-db-input-group" className="div-col gap-1.5">
              <label htmlFor="sidebar-modal-new-db-input" className="text-xs font-semibold theme-text">
                {t("databaseName", "Database Name")}
              </label>
              <Input
                id="sidebar-modal-new-db-input"
                size="sm"
                placeholder={t("dbNamePlaceholder", "e.g. analytics_db...")}
                value={newDbModalName}
                onChange={(e: React.ChangeEvent<HTMLInputElement>): void => {
                  setNewDbModalName(e.target.value);
                  if (createDbError) setCreateDbError(null);
                }}
                onKeyDown={(e: React.KeyboardEvent<HTMLInputElement>): void => {
                  if (e.key === "Enter" && newDbModalName.trim() && !isCreatingDb) {
                    e.preventDefault();
                    void handleModalCreateDbSubmit();
                  }
                }}
                autoFocus
              />
              {createDbError && (
                <span id="sidebar-modal-create-db-error" className="text-xs text-red-500 font-medium">
                  {createDbError}
                </span>
              )}
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
