"use client";

import React, { useEffect } from "react";
import { Container, DivCard, Button, IdeIcon } from "../components/bases";

export default function ErrorBoundary({
  error,
  reset,
}: {
  readonly error: Error & { digest?: string };
  readonly reset: () => void;
}): React.ReactElement {
  useEffect((): void => {
    console.error("[LocalDBClient] Global error boundary caught:", error);
  }, [error]);

  return (
    <Container id="localdbclient-error-container" className="div-center theme-page-layout">
      <DivCard id="localdbclient-error-card" className="div-col div-center text-center p-8 gap-4">
        <IdeIcon name="AlertCircle" size="xl" className="text-danger" />
        <h2 id="localdbclient-error-title" className="theme-text text-xl font-bold">
          Something went wrong
        </h2>
        <p id="localdbclient-error-message" className="theme-text-muted text-sm">
          {error.message || "An unexpected error occurred in LocalDBClient."}
        </p>
        <Button id="localdbclient-retry-btn" variant="primary" onClick={reset} className="mt-2">
          <IdeIcon name="RotateCcw" size="sm" />
          <span>Try Again</span>
        </Button>
      </DivCard>
    </Container>
  );
}
