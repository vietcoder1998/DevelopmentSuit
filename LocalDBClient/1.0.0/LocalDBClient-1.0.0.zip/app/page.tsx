"use client";

import React, { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import {
  IdeIcon,
  Modal,
  useResizableSidebar,
  SidebarResizeHandle,
  UseResizableSidebarResult,
} from "../components/bases";
import { useSafeTranslations } from "../components/bases/use-safe-translations";
import {
  SavedConnectionProfile,
  INITIAL_SAVED_CONNECTIONS,
  ConnectionProtocol,
} from "../components/connection/connection-types";
import {
  RestApiResponse,
  parseApiResponse,
  isRestApiSuccess,
} from "../components/standards/response-standards";

export default function ConnectionListPage(): React.ReactElement {
  const t: (key: string, fallback: string) => string = useSafeTranslations("localdbclient.home");
  const router: ReturnType<typeof useRouter> = useRouter();

  const {
    sidebarWidth,
    isResizing,
    startResizing,
    handleKeyDown,
    resetWidth,
  }: UseResizableSidebarResult = useResizableSidebar({
    storageKey: "localdb_sidebar_width",
    defaultWidth: 240,
    minWidth: 180,
    maxWidth: 500,
  });

  const [savedProfiles, setSavedProfiles]: [
    SavedConnectionProfile[],
    React.Dispatch<React.SetStateAction<SavedConnectionProfile[]>>
  ] = useState<SavedConnectionProfile[]>(INITIAL_SAVED_CONNECTIONS);

  const [showCreateModal, setShowCreateModal]: [
    boolean,
    React.Dispatch<React.SetStateAction<boolean>>
  ] = useState<boolean>(false);

  const [formName, setFormName]: [
    string,
    React.Dispatch<React.SetStateAction<string>>
  ] = useState<string>("");

  const [formServiceName, setFormServiceName]: [
    "SQL" | "Vector" | "MCP",
    React.Dispatch<React.SetStateAction<"SQL" | "Vector" | "MCP">>
  ] = useState<"SQL" | "Vector" | "MCP">("SQL");

  const [formProtocol, setFormProtocol]: [
    ConnectionProtocol,
    React.Dispatch<React.SetStateAction<ConnectionProtocol>>
  ] = useState<ConnectionProtocol>("http");

  const [formEndpoint, setFormEndpoint]: [
    string,
    React.Dispatch<React.SetStateAction<string>>
  ] = useState<string>("http://127.0.0.1:3110");

  const [isCreating, setIsCreating]: [
    boolean,
    React.Dispatch<React.SetStateAction<boolean>>
  ] = useState<boolean>(false);

  const [connectingProfileId, setConnectingProfileId]: [
    string | null,
    React.Dispatch<React.SetStateAction<string | null>>
  ] = useState<string | null>(null);

  const [connectionError, setConnectionError]: [
    string | null,
    React.Dispatch<React.SetStateAction<string | null>>
  ] = useState<string | null>(null);

  useEffect((): void => {
    const fetchConnections: () => Promise<void> = async (): Promise<void> => {
      try {
        const res: Response = await fetch("/api/connections");
        if (res.ok) {
          const raw: unknown = await res.json();
          const parsed: RestApiResponse<{ connections?: SavedConnectionProfile[] }> =
            parseApiResponse<{ connections?: SavedConnectionProfile[] }>(raw);
          const list: SavedConnectionProfile[] | undefined =
            (isRestApiSuccess(parsed) && parsed.data?.connections) ||
            (raw as { connections?: SavedConnectionProfile[] }).connections;
          if (Array.isArray(list) && list.length > 0) {
            setSavedProfiles(list);
          }
        }
      } catch {
        // fallback to initial
      }
    };
    fetchConnections();
  }, []);

  const handleConnect: (profile: SavedConnectionProfile) => Promise<boolean> = async (
    profile: SavedConnectionProfile
  ): Promise<boolean> => {
    setConnectingProfileId(profile.id);
    setConnectionError(null);
    try {
      const healthPath: string =
        profile.serviceName === "SQL" ? "/health" :
        profile.serviceName === "MCP" ? "/health" : "/api/status";
      const checkUrl: string = `${profile.endpoint}${healthPath}`;
      const res: Response = await fetch(checkUrl, {
        signal: AbortSignal.timeout(3000),
      });

      if (res.ok) {
        // Connected successfully -> switch to connection studio!
        router.push(`/connection/${encodeURIComponent(profile.id)}`);
        return true;
      } else {
        // Connect failed -> DO NOT SWITCH
        setConnectionError(
          `Cannot switch to "${profile.name}": Server returned HTTP ${res.status}. Only switch if connect successfully.`
        );
        return false;
      }
    } catch (err: unknown) {
      // Connect failed -> DO NOT SWITCH
      const msg: string = err instanceof Error ? err.message : "Connection failed";
      setConnectionError(
        `Cannot switch to "${profile.name}" at ${profile.endpoint}: ${msg}. Only switch if connect successfully.`
      );
      return false;
    } finally {
      setConnectingProfileId(null);
    }
  };

  const handleDeleteProfile: (id: string) => Promise<void> = async (
    id: string
  ): Promise<void> => {
    try {
      const res: Response = await fetch(`/api/connections?id=${encodeURIComponent(id)}`, {
        method: "DELETE",
      });
      if (res.ok) {
        const raw: unknown = await res.json();
        const parsed: RestApiResponse<{ connections?: SavedConnectionProfile[] }> =
          parseApiResponse<{ connections?: SavedConnectionProfile[] }>(raw);
        const list: SavedConnectionProfile[] | undefined =
          (isRestApiSuccess(parsed) && parsed.data?.connections) ||
          (raw as { connections?: SavedConnectionProfile[] }).connections;
        if (Array.isArray(list)) {
          setSavedProfiles(list);
          return;
        }
      }
    } catch {
      // fallback
    }
    setSavedProfiles((prev: SavedConnectionProfile[]): SavedConnectionProfile[] =>
      prev.filter((p: SavedConnectionProfile): boolean => p.id !== id)
    );
  };

  const handleCreateConnection: (e: React.FormEvent) => Promise<void> = async (
    e: React.FormEvent
  ): Promise<void> => {
    e.preventDefault();
    if (!formName.trim() || !formEndpoint.trim()) return;
    setIsCreating(true);
    setConnectionError(null);

    try {
      const res: Response = await fetch("/api/connections", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: formName.trim(),
          serviceName: formServiceName,
          protocol: formProtocol,
          endpoint: formEndpoint.trim(),
        }),
      });

      if (res.ok) {
        const raw: unknown = await res.json();
        const parsed: RestApiResponse<{ connections?: SavedConnectionProfile[] }> =
          parseApiResponse<{ connections?: SavedConnectionProfile[] }>(raw);
        const list: SavedConnectionProfile[] | undefined =
          (isRestApiSuccess(parsed) && parsed.data?.connections) ||
          (raw as { connections?: SavedConnectionProfile[] }).connections;
        if (Array.isArray(list)) {
          setSavedProfiles(list);
          const created: SavedConnectionProfile | undefined = list.find(
            (c: SavedConnectionProfile): boolean => c.name === formName.trim()
          );
          if (created) {
            // Only switch if connect successfully
            const healthPath: string =
              created.serviceName === "SQL" ? "/health" :
              created.serviceName === "MCP" ? "/health" : "/api/status";
            try {
              const resCheck: Response = await fetch(`${created.endpoint}${healthPath}`, {
                signal: AbortSignal.timeout(3000),
              });
              if (resCheck.ok) {
                router.push(`/connection/${encodeURIComponent(created.id)}`);
                return;
              } else {
                setConnectionError(
                  `Connection "${created.name}" created, but server returned HTTP ${resCheck.status}. Only switch if connect successfully.`
                );
              }
            } catch (errCheck: unknown) {
              const msg: string = errCheck instanceof Error ? errCheck.message : "Connection failed";
              setConnectionError(
                `Connection "${created.name}" created, but cannot connect: ${msg}. Only switch if connect successfully.`
              );
            }
          }
        }
      }
    } catch {
      // fallback
    }

    setIsCreating(false);
    setShowCreateModal(false);
    setFormName("");
  };

  const [categoryFilter, setCategoryFilter]: [
    "all" | "sql" | "vector" | "mcp",
    React.Dispatch<React.SetStateAction<"all" | "sql" | "vector" | "mcp">>
  ] = useState<"all" | "sql" | "vector" | "mcp">("all");

  const filteredProfiles: SavedConnectionProfile[] = savedProfiles.filter(
    (p: SavedConnectionProfile): boolean => {
      if (categoryFilter === "sql") return p.serviceName === "SQL";
      if (categoryFilter === "vector") return p.serviceName === "Vector";
      if (categoryFilter === "mcp") return p.serviceName === "MCP";
      return true;
    }
  );

  const sqlCount: number = savedProfiles.filter(
    (p: SavedConnectionProfile): boolean => p.serviceName === "SQL"
  ).length;

  const vectorCount: number = savedProfiles.filter(
    (p: SavedConnectionProfile): boolean => p.serviceName === "Vector"
  ).length;

  const mcpCount: number = savedProfiles.filter(
    (p: SavedConnectionProfile): boolean => p.serviceName === "MCP"
  ).length;

  const getServiceIcon: (service: "SQL" | "Vector" | "MCP") => string = (
    service: "SQL" | "Vector" | "MCP"
  ): string => {
    if (service === "SQL") return "Database";
    if (service === "MCP") return "Plug";
    return "Cpu";
  };

  const getProtocolColor: (protocol: ConnectionProtocol) => string = (
    protocol: ConnectionProtocol
  ): string => {
    const colors: Record<ConnectionProtocol, string> = {
      http: "badge-protocol-http",
      grpc: "badge-protocol-grpc",
      websocket: "badge-protocol-ws",
      ipc: "badge-protocol-ipc",
    };
    return colors[protocol] ?? "badge-protocol-http";
  };

  return (
    <div id="connection-home-root" className="system-layout-shell desktop-window-shell">
      {/* App Header */}
      <header id="connection-home-header" className="system-layout-header sticky-header">
        <div id="connection-home-brand" className="div-row gap-2">
          <IdeIcon name="Database" size="md" color="var(--primary, #2563eb)" />
          <span id="connection-home-title" className="localdb-brand-title">
            {t("brandTitle", "2-TEK LocalDB Studio")}
          </span>
        </div>
        <div id="connection-home-header-actions" className="div-row gap-2">
          <button
            id="btn-new-connection"
            type="button"
            className="connection-btn-primary"
            onClick={(): void => setShowCreateModal(true)}
            data-testid="btn-create-connection"
          >
            <IdeIcon name="Plus" size="sm" />
            <span>{t("createConnection", "Create Connection")}</span>
          </button>
        </div>
      </header>

      {/* Main Body: Sidebar + Content */}
      <div id="connection-home-body" className="system-layout-body">
        {/* Left Sidebar */}
        <aside
          id="connection-home-sidebar"
          className="system-layout-sidebar"
          style={{ width: `${sidebarWidth}px` }}
        >
          <div id="sidebar-categories-section" className="system-sidebar-section">
            <span id="sidebar-categories-title" className="system-sidebar-header">
              {t("categories", "Categories")}
            </span>
            <div id="sidebar-categories-nav" className="system-sidebar-nav">
              <button
                id="btn-filter-all"
                type="button"
                className={`system-nav-item ${categoryFilter === "all" ? "active" : ""}`}
                onClick={(): void => setCategoryFilter("all")}
              >
                <div className="div-row gap-2">
                  <IdeIcon name="DatabaseZap" size="sm" />
                  <span>{t("allConnections", "All Connections")}</span>
                </div>
                <span id="badge-count-all" className="system-nav-badge">
                  {savedProfiles.length}
                </span>
              </button>

              <button
                id="btn-filter-sql"
                type="button"
                className={`system-nav-item ${categoryFilter === "sql" ? "active" : ""}`}
                onClick={(): void => setCategoryFilter("sql")}
              >
                <div className="div-row gap-2">
                  <IdeIcon name="Database" size="sm" />
                  <span>{t("sqlDatabases", "SQL Databases")}</span>
                </div>
                <span id="badge-count-sql" className="system-nav-badge">
                  {sqlCount}
                </span>
              </button>

              <button
                id="btn-filter-vector"
                type="button"
                className={`system-nav-item ${categoryFilter === "vector" ? "active" : ""}`}
                onClick={(): void => setCategoryFilter("vector")}
              >
                <div className="div-row gap-2">
                  <IdeIcon name="Cpu" size="sm" />
                  <span>{t("vectorDatabases", "Vector Databases")}</span>
                </div>
                <span id="badge-count-vector" className="system-nav-badge">
                  {vectorCount}
                </span>
              </button>

              <button
                id="btn-filter-mcp"
                type="button"
                className={`system-nav-item ${categoryFilter === "mcp" ? "active" : ""}`}
                onClick={(): void => setCategoryFilter("mcp")}
              >
                <div className="div-row gap-2">
                  <IdeIcon name="Plug" size="sm" color={categoryFilter === "mcp" ? "var(--mcp-accent, #16a34a)" : undefined} />
                  <span>{t("mcpClients", "MCP Clients")}</span>
                </div>
                <span id="badge-count-mcp" className="system-nav-badge">
                  {mcpCount}
                </span>
              </button>
            </div>
          </div>

          <div id="sidebar-divider-connections" className="system-sidebar-divider" />

          {/* Quick Connect List in Sidebar */}
          <div id="sidebar-quick-connections-section" className="system-sidebar-section flex-1">
            <span id="sidebar-saved-title" className="system-sidebar-header">
              {t("quickConnect", "Quick Connect")}
            </span>
            <div id="sidebar-quick-connections-nav" className="system-sidebar-nav">
              {savedProfiles.map((p: SavedConnectionProfile): React.ReactElement => {
                const isConnecting: boolean = connectingProfileId === p.id;
                const badgeClass: string =
                  p.serviceName === "SQL" ? "badge-type-sql" :
                  p.serviceName === "MCP" ? "badge-type-mcp" : "badge-type-vector";
                return (
                  <button
                    key={`quick-${p.id}`}
                    id={`btn-quick-connect-${p.id}`}
                    type="button"
                    className="system-nav-item"
                    onClick={(): void => void handleConnect(p)}
                    disabled={isConnecting}
                    title={`${p.name} (${p.endpoint})`}
                  >
                    <div className="div-row gap-2 truncate">
                      <IdeIcon
                        name={isConnecting ? "Loader" : getServiceIcon(p.serviceName)}
                        size="xs"
                        color="var(--primary, #2563eb)"
                      />
                      <span className="truncate">{isConnecting ? "Connecting…" : p.name}</span>
                    </div>
                    <span className={`connection-type-badge ${badgeClass}`}>
                      {p.serviceName}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </aside>

        {/* Sidebar Resize Handle */}
        <SidebarResizeHandle
          id="connection-home-sidebar-resize-handle"
          isResizing={isResizing}
          sidebarWidth={sidebarWidth}
          minWidth={180}
          maxWidth={500}
          onMouseDown={startResizing}
          onTouchStart={startResizing}
          onDoubleClick={resetWidth}
          onKeyDown={handleKeyDown}
        />

        {/* Content Stage */}
        <main id="connection-home-main" className="system-layout-content">
          {connectionError && (
            <div id="connection-error-banner" className="connection-error-banner" role="alert">
              <IdeIcon name="AlertCircle" size="sm" color="var(--destructive, #ef4444)" />
              <span id="connection-error-text" className="text-xs font-medium flex-1">
                {connectionError}
              </span>
              <button
                id="btn-dismiss-connection-error"
                type="button"
                className="connection-btn-dismiss"
                onClick={(): void => setConnectionError(null)}
                aria-label="Dismiss error"
              >
                <IdeIcon name="X" size="xs" />
              </button>
            </div>
          )}

          <div id="connection-list-section" className="div-col gap-3">
            <div id="connection-list-header-row" className="div-between">
              <h2 id="connection-list-heading" className="connection-section-title">
                {categoryFilter === "sql"
                  ? t("sqlDatabases", "SQL Databases")
                  : categoryFilter === "vector"
                  ? t("vectorDatabases", "Vector Databases")
                  : categoryFilter === "mcp"
                  ? t("mcpClients", "MCP Clients")
                  : t("savedConnections", "Saved Connections")}
              </h2>
              <span id="connection-count-badge" className="connection-count-badge">
                {filteredProfiles.length}
              </span>
            </div>

            {filteredProfiles.length === 0 && (
              <div id="connection-empty-state" className="connection-empty-state">
                <IdeIcon name="DatabaseZap" size="xl" color="var(--text-subtle, #94a3b8)" />
                <p id="connection-empty-title" className="connection-empty-title">
                  {t("noConnections", "No saved connections")}
                </p>
                <p id="connection-empty-desc" className="connection-empty-desc">
                  {t("noConnectionsDesc", "Create your first connection to get started")}
                </p>
                <button
                  id="btn-create-first-connection"
                  type="button"
                  className="connection-btn-primary"
                  onClick={(): void => setShowCreateModal(true)}
                >
                  <IdeIcon name="Plus" size="sm" />
                  <span>{t("createFirst", "Create Connection")}</span>
                </button>
              </div>
            )}

            <div id="connection-cards-grid" className="connection-cards-grid">
              {filteredProfiles.map((profile: SavedConnectionProfile): React.ReactElement => {
                const isConnecting: boolean = connectingProfileId === profile.id;
                const iconBoxClass: string =
                  profile.serviceName === "Vector"
                    ? "icon-box-vector"
                    : profile.serviceName === "MCP"
                    ? "icon-box-mcp"
                    : "";
                const iconColor: string =
                  profile.serviceName === "SQL"
                    ? "var(--primary, #2563eb)"
                    : profile.serviceName === "MCP"
                    ? "var(--mcp-accent, #16a34a)"
                    : "var(--purple-600, #9333ea)";
                const badgeClass: string =
                  profile.serviceName === "SQL"
                    ? "badge-type-sql"
                    : profile.serviceName === "MCP"
                    ? "badge-type-mcp"
                    : "badge-type-vector";

                return (
                  <div
                    id={`connection-card-${profile.id}`}
                    key={profile.id}
                    className="connection-profile-card cursor-pointer"
                    onClick={(): void => void handleConnect(profile)}
                  >
                    <div id={`card-header-${profile.id}`} className="connection-card-header">
                      <div
                        id={`card-icon-box-${profile.id}`}
                        className={`connection-card-icon-box ${iconBoxClass}`}
                      >
                        <IdeIcon
                          name={isConnecting ? "Loader" : getServiceIcon(profile.serviceName)}
                          size="md"
                          color={iconColor}
                        />
                      </div>
                      <div id={`card-info-${profile.id}`} className="connection-card-info-wrap">
                        <div id={`card-title-row-${profile.id}`} className="connection-card-title-row">
                          <span id={`card-name-${profile.id}`} className="connection-card-name">
                            {profile.name}
                          </span>
                          <span
                            id={`badge-type-${profile.id}`}
                            className={`connection-type-badge ${badgeClass}`}
                          >
                            {profile.serviceName}
                          </span>
                        </div>
                        <div id={`card-protocol-row-${profile.id}`} className="connection-card-protocol-row">
                          <span
                            id={`badge-protocol-${profile.id}`}
                            className={`connection-protocol-badge ${getProtocolColor(profile.protocol)}`}
                          >
                            {profile.protocol.toUpperCase()}
                          </span>
                        </div>
                        <span id={`card-endpoint-${profile.id}`} className="connection-card-endpoint">
                          {profile.endpoint}
                        </span>
                      </div>
                    </div>

                    <div id={`card-actions-${profile.id}`} className="connection-card-actions">
                      <button
                        id={`btn-connect-${profile.id}`}
                        type="button"
                        className="connection-btn-connect"
                        disabled={isConnecting}
                        onClick={(e: React.MouseEvent): void => {
                          e.stopPropagation();
                          void handleConnect(profile);
                        }}
                        data-testid={`btn-connect-${profile.id}`}
                      >
                        <IdeIcon name={isConnecting ? "Loader" : "Zap"} size="sm" />
                        <span>{isConnecting ? t("connecting", "Connecting…") : t("connect", "Connect")}</span>
                      </button>
                      {!profile.isDefault && (
                        <button
                          id={`btn-delete-${profile.id}`}
                          type="button"
                          className="connection-btn-delete"
                          onClick={(e: React.MouseEvent): void => {
                            e.stopPropagation();
                            void handleDeleteProfile(profile.id);
                          }}
                          title={t("delete", "Delete connection")}
                        >
                          <IdeIcon name="Trash2" size="sm" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </main>
      </div>

      {/* Desktop Window Bottom Status Bar */}
      <footer id="window-status-bar" className="desktop-window-status-bar" role="contentinfo">
        <div id="status-bar-left" className="div-row items-center gap-2">
          <span id="status-ready-dot" className="status-ready-dot" />
          <span id="status-ready-text">Ready</span>
          <span className="status-separator">|</span>
          <span id="status-daemon-text" className="status-mono-text">
            Local Daemon: 127.0.0.1:3110
          </span>
        </div>
        <div id="status-bar-right" className="div-row items-center gap-2">
          <span id="status-sync-version">SQLite / VectorSync v1.2</span>
          <span className="status-separator">|</span>
          <span id="status-encoding">UTF-8</span>
        </div>
      </footer>

      {/* Create Connection Modal */}
      <Modal
        id="connection-create-form-card"
        isOpen={showCreateModal}
        onClose={(): void => setShowCreateModal(false)}
        title={t("createTitle", "Create Connection")}
      >
        <form id="connection-create-form" onSubmit={handleCreateConnection}>
          <div id="connection-form-fields" className="connection-form-grid">
            <div id="connection-field-name" className="connection-form-field connection-form-field-full">
              <label id="label-conn-name" className="connection-form-label" htmlFor="input-conn-name">
                {t("fieldName", "Connection Name")}
              </label>
              <input
                id="input-conn-name"
                type="text"
                className="connection-form-input"
                placeholder="My SQL Server"
                value={formName}
                onChange={(e: React.ChangeEvent<HTMLInputElement>): void =>
                  setFormName(e.target.value)
                }
                required
              />
            </div>

            <div id="connection-field-service" className="connection-form-field">
              <label id="label-conn-service" className="connection-form-label" htmlFor="select-conn-service">
                {t("fieldType", "Database Type")}
              </label>
              <select
                id="select-conn-service"
                className="connection-form-input"
                value={formServiceName}
                onChange={(e: React.ChangeEvent<HTMLSelectElement>): void => {
                  const svc: "SQL" | "Vector" | "MCP" = e.target.value as "SQL" | "Vector" | "MCP";
                  setFormServiceName(svc);
                  setFormEndpoint(
                    svc === "SQL"
                      ? "http://127.0.0.1:3110"
                      : svc === "MCP"
                      ? "http://127.0.0.1:3130"
                      : "http://127.0.0.1:3120"
                  );
                }}
              >
                <option value="SQL">SQL Database</option>
                <option value="Vector">Vector Database</option>
                <option value="MCP">MCP Client</option>
              </select>
            </div>

            <div id="connection-field-protocol" className="connection-form-field">
              <label id="label-conn-protocol" className="connection-form-label" htmlFor="select-conn-protocol">
                {t("fieldProtocol", "Protocol")}
              </label>
              <select
                id="select-conn-protocol"
                className="connection-form-input"
                value={formProtocol}
                onChange={(e: React.ChangeEvent<HTMLSelectElement>): void =>
                  setFormProtocol(e.target.value as ConnectionProtocol)
                }
              >
                <option value="http">HTTP / REST</option>
                <option value="grpc">gRPC</option>
                <option value="websocket">WebSocket</option>
                <option value="ipc">IPC</option>
              </select>
            </div>

            <div id="connection-field-endpoint" className="connection-form-field connection-form-field-full">
              <label id="label-conn-endpoint" className="connection-form-label" htmlFor="input-conn-endpoint">
                {t("fieldEndpoint", "Endpoint URL")}
              </label>
              <input
                id="input-conn-endpoint"
                type="text"
                className="connection-form-input"
                placeholder="http://127.0.0.1:3110"
                value={formEndpoint}
                onChange={(e: React.ChangeEvent<HTMLInputElement>): void =>
                  setFormEndpoint(e.target.value)
                }
                required
              />
            </div>
          </div>

          <div id="connection-form-actions" className="div-row gap-2 mt-4 justify-end">
            <button
              id="btn-cancel-create"
              type="button"
              className="connection-btn-ghost"
              onClick={(): void => setShowCreateModal(false)}
            >
              {t("cancel", "Cancel")}
            </button>
            <button
              id="btn-submit-create"
              type="submit"
              className="connection-btn-primary"
              disabled={isCreating}
            >
              {isCreating ? (
                <IdeIcon name="Loader" size="sm" />
              ) : (
                <IdeIcon name="PlugZap" size="sm" />
              )}
              <span>
                {isCreating
                  ? t("connecting", "Connecting…")
                  : t("connectAndSave", "Connect & Save")}
              </span>
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
