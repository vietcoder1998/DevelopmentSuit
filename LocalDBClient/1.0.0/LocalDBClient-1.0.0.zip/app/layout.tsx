import React from "react";
import "./globals.css";
import "./theme-sync.css";

export const metadata: { title: string; description: string } = {
  title: "2-TEK LocalDB Studio",
  description: "Unified Local Database Studio: SQL & Vector database management, interactive query console, similarity search, and multi-connection protocol manager.",
};

export default function RootLayout({
  children,
}: {
  readonly children: React.ReactNode;
}): React.ReactElement {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <script
          dangerouslySetInnerHTML={{
            __html: `(function(){try{var m=window.matchMedia('(prefers-color-scheme: dark)');var t=m.matches?'dark':'light';document.documentElement.setAttribute('data-theme',t);document.documentElement.className=t+'-theme';document.addEventListener('DOMContentLoaded',function(){document.body.className=t+'-theme';});m.addEventListener('change',function(e){var nt=e.matches?'dark':'light';document.documentElement.setAttribute('data-theme',nt);document.documentElement.className=nt+'-theme';document.body.className=nt+'-theme';});}catch(e){}})();`,
          }}
        />
      </head>
      <body id="localdbclient-root-body">
        <div id="localdbclient-root-container" className="localdb-app-shell">
          {children}
        </div>
      </body>
    </html>
  );
}
