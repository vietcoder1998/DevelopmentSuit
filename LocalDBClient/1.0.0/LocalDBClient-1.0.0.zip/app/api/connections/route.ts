import { NextResponse } from "next/server";
import {
  SavedConnectionProfile,
  INITIAL_SAVED_CONNECTIONS,
} from "../../../components/connection/connection-types";
import {
  createApiResponse,
  createApiErrorResponse,
} from "../../../components/standards/response-standards";

// In-memory persistence across Next.js API requests
let savedConnections: SavedConnectionProfile[] = [...INITIAL_SAVED_CONNECTIONS];

export async function GET(): Promise<NextResponse> {
  const payload: { connections: SavedConnectionProfile[] } = {
    connections: savedConnections,
  };
  return NextResponse.json({
    ...createApiResponse(payload, { version: "1.0.0" }),
    connections: savedConnections,
  });
}

export async function POST(request: Request): Promise<NextResponse> {
  try {
    const body: {
      name?: string;
      serviceName?: "SQL" | "Vector" | "MCP";
      protocol?: "http" | "grpc" | "websocket" | "ipc";
      endpoint?: string;
      mcpTransport?: "sse" | "stdio" | "http";
    } = await request.json();

    const serviceName: "SQL" | "Vector" | "MCP" =
      body.serviceName === "Vector"
        ? "Vector"
        : body.serviceName === "MCP"
        ? "MCP"
        : "SQL";
    const name: string =
      (body.name || "").trim() || `${serviceName} Connection (${body.protocol || "http"})`;
    const protocol: "http" | "grpc" | "websocket" | "ipc" = body.protocol || "http";
    const defaultEndpoint: string =
      serviceName === "SQL"
        ? "http://127.0.0.1:3110"
        : serviceName === "MCP"
        ? "http://127.0.0.1:3130"
        : "http://127.0.0.1:3120";
    const endpoint: string = (body.endpoint || "").trim() || defaultEndpoint;

    const newConnection: SavedConnectionProfile = {
      id: `conn-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      name,
      serviceName,
      protocol,
      endpoint,
      isDefault: false,
      mcpTransport: serviceName === "MCP" ? (body.mcpTransport ?? "sse") : undefined,
      createdAt: Date.now(),
    };

    savedConnections = [...savedConnections, newConnection];

    const payload: {
      connection: SavedConnectionProfile;
      connections: SavedConnectionProfile[];
    } = {
      connection: newConnection,
      connections: savedConnections,
    };

    return NextResponse.json({
      ...createApiResponse(payload, { version: "1.0.0" }),
      connection: newConnection,
      connections: savedConnections,
    });
  } catch (error: unknown) {
    const message: string = error instanceof Error ? error.message : "Invalid payload";
    return NextResponse.json(
      createApiErrorResponse("INVALID_PAYLOAD", message),
      { status: 400 }
    );
  }
}

export async function DELETE(request: Request): Promise<NextResponse> {
  const url: URL = new URL(request.url);
  const id: string | null = url.searchParams.get("id");
  if (!id) {
    return NextResponse.json(
      createApiErrorResponse("MISSING_PARAMETER", "Missing connection id parameter"),
      { status: 400 }
    );
  }

  savedConnections = savedConnections.filter((conn: SavedConnectionProfile): boolean => conn.id !== id);
  const payload: { connections: SavedConnectionProfile[] } = {
    connections: savedConnections,
  };
  return NextResponse.json({
    ...createApiResponse(payload, { version: "1.0.0" }),
    connections: savedConnections,
  });
}
