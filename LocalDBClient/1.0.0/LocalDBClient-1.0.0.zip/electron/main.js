/**
 * packages/LocalDBClient/electron/main.js
 * ─────────────────────────────────────────────────────────────────────────────
 * 2-TEK LocalDB Studio — Electron Main Process
 * Wraps Next.js dev server in an Electron BrowserWindow for native desktop studio.
 * ─────────────────────────────────────────────────────────────────────────────
 */

const { app, BrowserWindow, shell, Menu } = require("electron");
const path = require("path");

const DEV_PORT = process.env.PORT || "3033";
const DEV_URL = process.env.DEV_URL || `http://localhost:${DEV_PORT}`;
const WINDOW_TITLE = "2-TEK LocalDB Studio";

let mainWindow = null;
let retryTimer = null;

function createMainWindow() {
  mainWindow = new BrowserWindow({
    width: 1360,
    height: 860,
    minWidth: 960,
    minHeight: 620,
    title: WINDOW_TITLE,
    backgroundColor: "#ffffff",
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: true,
    },
    show: false,
    autoHideMenuBar: true,
    titleBarStyle: process.platform === "darwin" ? "hiddenInset" : "default",
  });

  mainWindow.loadURL(DEV_URL);

  mainWindow.once("ready-to-show", () => {
    mainWindow.show();
    mainWindow.focus();
  });

  // Handle transient dev compilation reload delays
  mainWindow.webContents.on("did-fail-load", (_event, errorCode, errorDescription) => {
    if (errorCode === -3) {
      // ERR_ABORTED - navigation cancelled (e.g. redirect or new request started)
      return;
    }
    console.warn(`[LocalDBClient Electron] Failed to load ${DEV_URL}: ${errorDescription} (${errorCode}). Retrying in 1s...`);
    if (retryTimer) clearTimeout(retryTimer);
    retryTimer = setTimeout(() => {
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.loadURL(DEV_URL);
      }
    }, 1000);
  });

  // Open external links in system browser
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith("http:") || url.startsWith("https:")) {
      shell.openExternal(url);
    }
    return { action: "deny" };
  });

  mainWindow.on("closed", () => {
    if (retryTimer) clearTimeout(retryTimer);
    mainWindow = null;
  });
}

app.whenReady().then(() => {
  if (Menu && typeof Menu.setApplicationMenu === "function") {
    Menu.setApplicationMenu(null);
  }
  createMainWindow();

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createMainWindow();
    }
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") {
    app.quit();
  }
});
