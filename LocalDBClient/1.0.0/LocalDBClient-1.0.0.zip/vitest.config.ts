import path from "node:path";
import { fileURLToPath } from "node:url";
import { defineConfig } from "vitest/config";

const currentDirname: string = path.dirname(fileURLToPath(import.meta.url));
const rootNodeModules: string = path.resolve(currentDirname, "../../node_modules");

export default defineConfig({
  root: currentDirname,
  test: {
    globals: true,
    environment: "jsdom",
    fileParallelism: false,
    include: ["__tests__/**/*.test.{ts,tsx}"],
  },
  resolve: {
    dedupe: ["react", "react-dom"],
    alias: {
      react: path.resolve(rootNodeModules, "react"),
      "react-dom": path.resolve(rootNodeModules, "react-dom"),
      "@": path.resolve(currentDirname, "."),
      "@/components/bases": path.resolve(currentDirname, "components/bases"),
      "@/components": path.resolve(currentDirname, "components"),
      "@/styles": path.resolve(currentDirname, "styles"),
    },
  },
});
