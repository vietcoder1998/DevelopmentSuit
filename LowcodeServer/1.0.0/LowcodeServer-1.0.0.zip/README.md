# LowcodeServer

LowcodeServer is a high performance service designed to operate seamlessly with LowcodeStudio (quick IDE for generating fullstack applications using LowcodeFramework).

## Transports
- **HTTP REST**: Default Port 3001
- **gRPC**: Default Port 50051

## Capabilities
- Generate complete Next.js fullstack applications from declarative schemas.
- Compile and validate AST trees.
- Sandbox WASM microservice runtime execution.
- Project templates and scaffold inspection.
