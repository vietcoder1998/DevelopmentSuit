import { lowcode_service } from "../service/lowcode-service.js";

export interface GrpcConfig {
  readonly host: string;
  readonly port: number;
}

export class LowcodeGrpcServer {
  private readonly config: GrpcConfig;
  private isRunning: boolean = false;

  constructor(config: GrpcConfig = { host: "0.0.0.0", port: 50051 }) {
    this.config = config;
  }

  public start(): Promise<void> {
    return new Promise((resolve: () => void): void => {
      this.isRunning = true;
      resolve();
    });
  }

  public stop(): Promise<void> {
    return new Promise((resolve: () => void): void => {
      this.isRunning = false;
      resolve();
    });
  }

  public getStatus(): { readonly running: boolean; readonly host: string; readonly port: number } {
    return {
      running: this.isRunning,
      host: this.config.host,
      port: this.config.port,
    };
  }

  public handleHealthCall(): { readonly status: string; readonly uptime: number } {
    const health = lowcode_service.getHealth();
    return {
      status: health.status,
      uptime: health.uptime,
    };
  }
}

export const lowcode_grpc_server: LowcodeGrpcServer = new LowcodeGrpcServer();
