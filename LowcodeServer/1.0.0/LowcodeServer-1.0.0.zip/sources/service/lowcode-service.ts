import { app_generator, FullstackAppSchema, GeneratedFile, wasm_runtime_engine } from "@2-tek/lowcode-framework";

export interface LowcodeProjectSummary {
  readonly id: string;
  readonly name: string;
  readonly status: "active" | "archived" | "template";
  readonly updatedAt: string;
}

export class LowcodeService {
  private readonly startTime: number = Date.now();
  private readonly projectRegistry: Map<string, LowcodeProjectSummary> = new Map<string, LowcodeProjectSummary>([
    [
      "demo-starter",
      {
        id: "demo-starter",
        name: "Standard Starter Template",
        status: "template",
        updatedAt: new Date().toISOString(),
      },
    ],
  ]);

  public getHealth(): { readonly status: string; readonly uptime: number; readonly version: string } {
    const currentUptime: number = Math.floor((Date.now() - this.startTime) / 1000);
    return {
      status: "healthy",
      uptime: currentUptime,
      version: "1.0.0",
    };
  }

  public listProjects(): readonly LowcodeProjectSummary[] {
    return Array.from(this.projectRegistry.values());
  }

  public getProject(projectId: string): LowcodeProjectSummary | undefined {
    return this.projectRegistry.get(projectId);
  }

  public generateFullstackApp(schema: FullstackAppSchema): {
    readonly success: boolean;
    readonly filesCount: number;
    readonly files: readonly GeneratedFile[];
  } {
    const generatedFiles: readonly GeneratedFile[] = app_generator.generateFullstackApp(schema);
    const summary: LowcodeProjectSummary = {
      id: schema.name.toLowerCase().replace(/\s+/g, "-"),
      name: schema.name,
      status: "active",
      updatedAt: new Date().toISOString(),
    };
    this.projectRegistry.set(summary.id, summary);

    return {
      success: true,
      filesCount: generatedFiles.length,
      files: generatedFiles,
    };
  }

  public compileServiceBytecode(serviceName: string, logicPayload: string): unknown {
    return wasm_runtime_engine.compileServiceToBytecode(serviceName, logicPayload);
  }
}

export const lowcode_service: LowcodeService = new LowcodeService();
