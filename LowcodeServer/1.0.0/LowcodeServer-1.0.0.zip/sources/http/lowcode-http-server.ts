import http, { IncomingMessage, ServerResponse } from "node:http";
import { FullstackAppSchema } from "@2-tek/lowcode-framework";
import { lowcode_service } from "../service/lowcode-service.js";

export interface HttpConfig {
  readonly host: string;
  readonly port: number;
}

export class LowcodeHttpServer {
  private readonly config: HttpConfig;
  private server: http.Server | null = null;

  constructor(config: HttpConfig = { host: "127.0.0.1", port: 3001 }) {
    this.config = config;
  }

  public start(): Promise<void> {
    return new Promise((resolve: () => void, reject: (err: Error) => void): void => {
      this.server = http.createServer((req: IncomingMessage, res: ServerResponse): void => {
        res.setHeader("Access-Control-Allow-Origin", "*");
        res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
        res.setHeader("Access-Control-Allow-Headers", "Content-Type");

        if (req.method === "OPTIONS") {
          res.writeHead(204);
          res.end();
          return;
        }

        const url: string = req.url || "/";

        if (url === "/health" && req.method === "GET") {
          const health = lowcode_service.getHealth();
          res.writeHead(200, { "Content-Type": "application/json" });
          res.end(JSON.stringify(health));
          return;
        }

        if (url === "/api/projects" && req.method === "GET") {
          const projects = lowcode_service.listProjects();
          res.writeHead(200, { "Content-Type": "application/json" });
          res.end(JSON.stringify({ success: true, projects }));
          return;
        }

        if (url === "/api/generate" && req.method === "POST") {
          let body: string = "";
          req.on("data", (chunk: Buffer): void => {
            body += chunk.toString();
          });
          req.on("end", (): void => {
            try {
              const schema: FullstackAppSchema = JSON.parse(body);
              const result = lowcode_service.generateFullstackApp(schema);
              res.writeHead(200, { "Content-Type": "application/json" });
              res.end(JSON.stringify(result));
            } catch (err: unknown) {
              const errorMessage: string = err instanceof Error ? err.message : "Invalid JSON";
              res.writeHead(400, { "Content-Type": "application/json" });
              res.end(JSON.stringify({ success: false, error: errorMessage }));
            }
          });
          return;
        }

        if (url.startsWith("/api/projects/") && req.method === "GET") {
          const projectId: string = url.replace("/api/projects/", "").trim();
          const project: unknown = lowcode_service.getProject(projectId);
          if (project) {
            res.writeHead(200, { "Content-Type": "application/json" });
            res.end(JSON.stringify({ success: true, project }));
          } else {
            res.writeHead(404, { "Content-Type": "application/json" });
            res.end(JSON.stringify({ success: false, error: `Project '${projectId}' not found` }));
          }
          return;
        }

        if (url === "/api/validate" && req.method === "POST") {
          let body: string = "";
          req.on("data", (chunk: Buffer): void => {
            body += chunk.toString();
          });
          req.on("end", (): void => {
            try {
              const schema: FullstackAppSchema = JSON.parse(body);
              const isValid: boolean = Boolean(
                schema &&
                schema.name &&
                Array.isArray(schema.pages) &&
                Array.isArray(schema.services)
              );
              res.writeHead(200, { "Content-Type": "application/json" });
              res.end(JSON.stringify({ success: true, valid: isValid, appName: schema?.name || "" }));
            } catch {
              res.writeHead(400, { "Content-Type": "application/json" });
              res.end(JSON.stringify({ success: false, valid: false, error: "Invalid JSON schema" }));
            }
          });
          return;
        }

        if (url === "/api/wasm/compile" && req.method === "POST") {
          let body: string = "";
          req.on("data", (chunk: Buffer): void => {
            body += chunk.toString();
          });
          req.on("end", (): void => {
            try {
              const payload: { serviceName: string; logicPayload: string } = JSON.parse(body);
              const bytecode: unknown = lowcode_service.compileServiceBytecode(payload.serviceName, payload.logicPayload);
              res.writeHead(200, { "Content-Type": "application/json" });
              res.end(JSON.stringify({ success: true, bytecode }));
            } catch {
              res.writeHead(400, { "Content-Type": "application/json" });
              res.end(JSON.stringify({ success: false, error: "Compilation failed" }));
            }
          });
          return;
        }

        res.writeHead(404, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ error: "Not Found" }));
      });

      this.server.listen(this.config.port, this.config.host, (): void => {
        resolve();
      });

      this.server.on("error", (err: Error): void => {
        reject(err);
      });
    });
  }

  public stop(): Promise<void> {
    return new Promise((resolve: () => void): void => {
      if (this.server) {
        this.server.close((): void => {
          this.server = null;
          resolve();
        });
      } else {
        resolve();
      }
    });
  }

  public getPort(): number {
    return this.config.port;
  }
}

export const lowcode_http_server: LowcodeHttpServer = new LowcodeHttpServer();
