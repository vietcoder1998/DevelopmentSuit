"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// packages/LowcodeFramework/sources/theme/design-system.ts
var defaultThemeTokens = {
  primaryColor: "#6938ef",
  surfaceColor: "var(--surface, #0f172a)",
  textColor: "var(--text, #f8fafc)",
  borderColor: "var(--border, #334155)",
  gridUnit: 8
};
var DesignSystemEngine = class {
  generateThemeCss(tokens = defaultThemeTokens) {
    const cssContent = `:root {
  --primary: ${tokens.primaryColor};
  --surface: ${tokens.surfaceColor};
  --text: ${tokens.textColor};
  --border: ${tokens.borderColor};
  --grid-unit: ${tokens.gridUnit}px;
}

.theme-surface {
  background-color: var(--surface);
  color: var(--text);
}

.theme-border {
  border-color: var(--border);
}

.div-row {
  display: flex;
  flex-direction: row;
  align-items: center;
  gap: var(--grid-unit);
}

.div-col {
  display: flex;
  flex-direction: column;
  gap: var(--grid-unit);
}
`;
    return cssContent;
  }
};
var design_system_engine = new DesignSystemEngine();

// packages/LowcodeFramework/sources/generator/app-generator.ts
var AppGenerator = class {
  generateFullstackApp(schema) {
    const generatedFiles = [];
    const packageJsonContent = JSON.stringify(
      {
        name: schema.name.toLowerCase().replace(/\s+/g, "-"),
        version: schema.version,
        private: true,
        scripts: {
          dev: "next dev",
          build: "next build",
          start: "next start"
        },
        dependencies: {
          next: "^15.0.0",
          react: "^19.0.0",
          "react-dom": "^19.0.0"
        }
      },
      null,
      2
    ) + "\n";
    generatedFiles.push({ path: "package.json", content: packageJsonContent });
    const globalCssContent = design_system_engine.generateThemeCss();
    generatedFiles.push({ path: "app/globals.css", content: globalCssContent });
    const layoutContent = `"use client";
import React from "react";
import "./globals.css";

export default function RootLayout({
  children,
}: {
  readonly children: React.ReactNode;
}): React.JSX.Element {
  return (
    <html lang="en">
      <body id="app-root-body" className="theme-surface">
        <main id="app-main-viewport">{children}</main>
      </body>
    </html>
  );
}
`;
    generatedFiles.push({ path: "app/layout.tsx", content: layoutContent });
    for (const page of schema.pages) {
      const pageFile = this.generatePage(page);
      generatedFiles.push(pageFile);
    }
    for (const service of schema.services) {
      const serviceFiles = this.generateServiceRoutes(service);
      for (const serviceFile of serviceFiles) {
        generatedFiles.push(serviceFile);
      }
    }
    return generatedFiles;
  }
  generatePage(page) {
    const renderedAst = this.renderAstNode(page.root);
    const pageContent = `"use client";
import React from "react";

export default function ${this.toPascalCase(page.id)}Page(): React.JSX.Element {
  return (
    <div id="${page.id}-page-container" className="div-col">
      <h1 id="${page.id}-page-title">${page.title}</h1>
      ${renderedAst}
    </div>
  );
}
`;
    const normalizedPath = page.path === "/" ? "app/page.tsx" : `app/${page.path.replace(/^\//, "")}/page.tsx`;
    return { path: normalizedPath, content: pageContent };
  }
  renderAstNode(node) {
    const idAttr = `id="${node.props.id || node.id}"`;
    const classAttr = node.props.className ? `className="${node.props.className}"` : "";
    const childrenStr = node.children && node.children.length > 0 ? node.children.map((child) => this.renderAstNode(child)).join("\n") : node.props.text || "";
    switch (node.type) {
      case "Container":
        return `<div ${idAttr} ${classAttr} className="theme-surface">
${childrenStr}
</div>`;
      case "DivRow":
        return `<div ${idAttr} className="div-row">
${childrenStr}
</div>`;
      case "DivCol":
        return `<div ${idAttr} className="div-col">
${childrenStr}
</div>`;
      case "Button":
        return `<button ${idAttr} type="button" className="btn-primary">${node.props.text || "Action"}</button>`;
      case "Input":
        return `<input ${idAttr} type="text" placeholder="${node.props.placeholder || ""}" className="input-base" />`;
      case "Card":
        return `<div ${idAttr} className="theme-surface theme-border">
${childrenStr}
</div>`;
      case "Badge":
        return `<span ${idAttr} className="badge-base">${node.props.text || ""}</span>`;
      case "Typography":
      default:
        return `<p ${idAttr}>${node.props.text || childrenStr}</p>`;
    }
  }
  generateServiceRoutes(service) {
    const routeFiles = [];
    for (const route of service.routes) {
      const handlerContent = `import { NextResponse } from "next/server";

export async function ${route.method}(): Promise<NextResponse> {
  return NextResponse.json({
    service: "${service.name}",
    route: "${route.path}",
    status: "healthy",
    description: "${route.description}",
    timestamp: new Date().toISOString(),
  });
}
`;
      const routePath = `app/api/${service.id}/${route.path.replace(/^\//, "")}/route.ts`;
      routeFiles.push({ path: routePath, content: handlerContent });
    }
    return routeFiles;
  }
  toPascalCase(str) {
    return str.replace(/[-_](\w)/g, (_, char) => char.toUpperCase()).replace(/^\w/, (c) => c.toUpperCase());
  }
};
var app_generator = new AppGenerator();

// packages/LowcodeFramework/sources/runtime/wasm-runtime.ts
var WasmRuntimeEngine = class {
  loadedModules = /* @__PURE__ */ new Map();
  compileServiceToBytecode(serviceName, logicPayload) {
    const calculatedBytes = Buffer.byteLength(logicPayload, "utf8") + 64;
    const metadata = {
      moduleName: serviceName,
      byteLength: calculatedBytes,
      memoryPages: Math.ceil(calculatedBytes / 65536) || 1,
      exportedFunctions: ["init", "execute", "dispose"]
    };
    this.loadedModules.set(serviceName, metadata);
    return metadata;
  }
  getModule(serviceName) {
    return this.loadedModules.get(serviceName);
  }
  listLoadedModules() {
    return Array.from(this.loadedModules.values());
  }
};
var wasm_runtime_engine = new WasmRuntimeEngine();

// packages/LowcodeServer/sources/service/lowcode-service.ts
var LowcodeService = class {
  startTime = Date.now();
  projectRegistry = /* @__PURE__ */ new Map([
    [
      "demo-starter",
      {
        id: "demo-starter",
        name: "Standard Starter Template",
        status: "template",
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      }
    ]
  ]);
  getHealth() {
    const currentUptime = Math.floor((Date.now() - this.startTime) / 1e3);
    return {
      status: "healthy",
      uptime: currentUptime,
      version: "1.0.0"
    };
  }
  listProjects() {
    return Array.from(this.projectRegistry.values());
  }
  getProject(projectId) {
    return this.projectRegistry.get(projectId);
  }
  generateFullstackApp(schema) {
    const generatedFiles = app_generator.generateFullstackApp(schema);
    const summary = {
      id: schema.name.toLowerCase().replace(/\s+/g, "-"),
      name: schema.name,
      status: "active",
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    this.projectRegistry.set(summary.id, summary);
    return {
      success: true,
      filesCount: generatedFiles.length,
      files: generatedFiles
    };
  }
  compileServiceBytecode(serviceName, logicPayload) {
    return wasm_runtime_engine.compileServiceToBytecode(serviceName, logicPayload);
  }
};
var lowcode_service = new LowcodeService();

// packages/LowcodeServer/sources/grpc/lowcode-grpc-server.ts
var LowcodeGrpcServer = class {
  config;
  isRunning = false;
  constructor(config = { host: "0.0.0.0", port: 50051 }) {
    this.config = config;
  }
  start() {
    return new Promise((resolve) => {
      this.isRunning = true;
      resolve();
    });
  }
  stop() {
    return new Promise((resolve) => {
      this.isRunning = false;
      resolve();
    });
  }
  getStatus() {
    return {
      running: this.isRunning,
      host: this.config.host,
      port: this.config.port
    };
  }
  handleHealthCall() {
    const health = lowcode_service.getHealth();
    return {
      status: health.status,
      uptime: health.uptime
    };
  }
};
var lowcode_grpc_server = new LowcodeGrpcServer();

// packages/LowcodeServer/sources/http/lowcode-http-server.ts
var import_node_http = __toESM(require("node:http"), 1);
var LowcodeHttpServer = class {
  config;
  server = null;
  constructor(config = { host: "127.0.0.1", port: 3001 }) {
    this.config = config;
  }
  start() {
    return new Promise((resolve, reject) => {
      this.server = import_node_http.default.createServer((req, res) => {
        res.setHeader("Access-Control-Allow-Origin", "*");
        res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
        res.setHeader("Access-Control-Allow-Headers", "Content-Type");
        if (req.method === "OPTIONS") {
          res.writeHead(204);
          res.end();
          return;
        }
        const url = req.url || "/";
        if (url === "/health" && req.method === "GET") {
          const health = lowcode_service.getHealth();
          res.writeHead(200, { "Content-Type": "application/json" });
          res.end(JSON.stringify(health));
          return;
        }
        if (url === "/api/projects" && req.method === "GET") {
          const projects = lowcode_service.listProjects();
          res.writeHead(200, { "Content-Type": "application/json" });
          res.end(JSON.stringify({ success: true, projects }));
          return;
        }
        if (url === "/api/generate" && req.method === "POST") {
          let body = "";
          req.on("data", (chunk) => {
            body += chunk.toString();
          });
          req.on("end", () => {
            try {
              const schema = JSON.parse(body);
              const result = lowcode_service.generateFullstackApp(schema);
              res.writeHead(200, { "Content-Type": "application/json" });
              res.end(JSON.stringify(result));
            } catch (err) {
              const errorMessage = err instanceof Error ? err.message : "Invalid JSON";
              res.writeHead(400, { "Content-Type": "application/json" });
              res.end(JSON.stringify({ success: false, error: errorMessage }));
            }
          });
          return;
        }
        if (url.startsWith("/api/projects/") && req.method === "GET") {
          const projectId = url.replace("/api/projects/", "").trim();
          const project = lowcode_service.getProject(projectId);
          if (project) {
            res.writeHead(200, { "Content-Type": "application/json" });
            res.end(JSON.stringify({ success: true, project }));
          } else {
            res.writeHead(404, { "Content-Type": "application/json" });
            res.end(JSON.stringify({ success: false, error: `Project '${projectId}' not found` }));
          }
          return;
        }
        if (url === "/api/validate" && req.method === "POST") {
          let body = "";
          req.on("data", (chunk) => {
            body += chunk.toString();
          });
          req.on("end", () => {
            try {
              const schema = JSON.parse(body);
              const isValid = Boolean(
                schema && schema.name && Array.isArray(schema.pages) && Array.isArray(schema.services)
              );
              res.writeHead(200, { "Content-Type": "application/json" });
              res.end(JSON.stringify({ success: true, valid: isValid, appName: schema?.name || "" }));
            } catch {
              res.writeHead(400, { "Content-Type": "application/json" });
              res.end(JSON.stringify({ success: false, valid: false, error: "Invalid JSON schema" }));
            }
          });
          return;
        }
        if (url === "/api/wasm/compile" && req.method === "POST") {
          let body = "";
          req.on("data", (chunk) => {
            body += chunk.toString();
          });
          req.on("end", () => {
            try {
              const payload = JSON.parse(body);
              const bytecode = lowcode_service.compileServiceBytecode(payload.serviceName, payload.logicPayload);
              res.writeHead(200, { "Content-Type": "application/json" });
              res.end(JSON.stringify({ success: true, bytecode }));
            } catch {
              res.writeHead(400, { "Content-Type": "application/json" });
              res.end(JSON.stringify({ success: false, error: "Compilation failed" }));
            }
          });
          return;
        }
        res.writeHead(404, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ error: "Not Found" }));
      });
      this.server.listen(this.config.port, this.config.host, () => {
        resolve();
      });
      this.server.on("error", (err) => {
        reject(err);
      });
    });
  }
  stop() {
    return new Promise((resolve) => {
      if (this.server) {
        this.server.close(() => {
          this.server = null;
          resolve();
        });
      } else {
        resolve();
      }
    });
  }
  getPort() {
    return this.config.port;
  }
};
var lowcode_http_server = new LowcodeHttpServer();

// packages/LowcodeServer/server.ts
async function bootstrap() {
  const httpPort = 3001;
  const grpcPort = 50051;
  console.log(`[LowcodeServer] Starting HTTP REST server on port ${httpPort}...`);
  await lowcode_http_server.start();
  console.log(`[LowcodeServer] Starting gRPC server on port ${grpcPort}...`);
  await lowcode_grpc_server.start();
  console.log("[LowcodeServer] Successfully running and ready for LowcodeStudio connections.");
}
bootstrap().catch((err) => {
  console.error("[LowcodeServer] Fatal bootstrap error:", err);
  process.exit(1);
});
