import { lowcode_grpc_server } from "./sources/grpc/lowcode-grpc-server.js";
import { lowcode_http_server } from "./sources/http/lowcode-http-server.js";

async function bootstrap(): Promise<void> {
  const httpPort: number = 3001;
  const grpcPort: number = 50051;

  console.log(`[LowcodeServer] Starting HTTP REST server on port ${httpPort}...`);
  await lowcode_http_server.start();

  console.log(`[LowcodeServer] Starting gRPC server on port ${grpcPort}...`);
  await lowcode_grpc_server.start();

  console.log("[LowcodeServer] Successfully running and ready for LowcodeStudio connections.");
}

bootstrap().catch((err: Error): void => {
  console.error("[LowcodeServer] Fatal bootstrap error:", err);
  process.exit(1);
});
